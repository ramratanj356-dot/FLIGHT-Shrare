import { describe, expect, it } from "vitest";
import { scoreMatch, type RideGroupSnapshot, type SearchIntent } from "@/lib/match/score";
import { destinationCompatibility } from "@/lib/match/geo";
import { BOM_DESTINATIONS, type DestinationSeed } from "@/lib/data/destinations";
import { DEFAULT_PRICING_RULES } from "@/lib/config/pricing";

const dest = (id: string): DestinationSeed => {
  const d = BOM_DESTINATIONS.find((x) => x.id === id);
  if (!d) throw new Error(`Unknown fixture destination ${id}`);
  return d;
};

const arrival = new Date(Date.now() + 6 * 3600_000);

function intent(overrides: Partial<SearchIntent> = {}): SearchIntent {
  return {
    airportId: "apt_bom",
    airlineCode: "AI",
    flightNumber: "AI864",
    flightDate: "2026-10-24",
    destination: dest("thane-w"),
    passengers: 1,
    luggageUnits: 1,
    expectedReadyAt: new Date(arrival.getTime() + 50 * 60_000),
    ...overrides,
  };
}

function group(overrides: Partial<RideGroupSnapshot> = {}): RideGroupSnapshot {
  return {
    id: "rg_test",
    airportId: "apt_bom",
    airlineCode: "AI",
    flightNumber: "AI864",
    flightDate: "2026-10-24",
    scheduledArrival: arrival,
    estimatedArrival: arrival,
    flightStatus: "enroute",
    destination: dest("thane-w"),
    additionalStops: [dest("mulund")],
    vehicleCategory: "suv",
    seatsTotal: 4,
    seatsTaken: 2,
    luggageTotal: 4,
    luggageTaken: 2,
    departureWindowStart: new Date(arrival.getTime() + 30 * 60_000),
    members: [
      { readiness: "landed", expectedReadyAt: new Date(arrival.getTime() + 40 * 60_000), flightVerified: true, identityVerified: true },
      { readiness: "collecting_baggage", expectedReadyAt: new Date(arrival.getTime() + 45 * 60_000), flightVerified: true, identityVerified: false },
    ],
    ...overrides,
  };
}

describe("match scoring", () => {
  it("scores a same-flight, same-direction group highly", () => {
    const r = scoreMatch(intent(), group(), DEFAULT_PRICING_RULES);
    expect(r.eligible).toBe(true);
    expect(r.blockers).toHaveLength(0);
    expect(r.score).toBeGreaterThanOrEqual(70);
    expect(r.reasons.length).toBeGreaterThan(0);
  });

  it("blocks a different travel date regardless of score", () => {
    const r = scoreMatch(intent(), group({ flightDate: "2026-10-25" }), DEFAULT_PRICING_RULES);
    expect(r.eligible).toBe(false);
    expect(r.blockers.join(" ")).toMatch(/date/i);
    expect(r.score).toBeLessThanOrEqual(45);
  });

  it("blocks a full group", () => {
    const r = scoreMatch(intent(), group({ seatsTaken: 4 }), DEFAULT_PRICING_RULES);
    expect(r.eligible).toBe(false);
    expect(r.blockers.join(" ")).toMatch(/full/i);
  });

  it("blocks when luggage space is insufficient", () => {
    const r = scoreMatch(intent({ luggageUnits: 3 }), group({ luggageTaken: 3 }), DEFAULT_PRICING_RULES);
    expect(r.eligible).toBe(false);
    expect(r.blockers.join(" ")).toMatch(/luggage|bag/i);
  });

  it("penalises an incompatible destination", () => {
    const compatible = scoreMatch(intent({ destination: dest("mulund") }), group(), DEFAULT_PRICING_RULES);
    const incompatible = scoreMatch(intent({ destination: dest("colaba") }), group(), DEFAULT_PRICING_RULES);
    expect(compatible.score).toBeGreaterThan(incompatible.score);
  });

  it("never exceeds 100 or dips below 0", () => {
    const best = scoreMatch(intent(), group({ destination: dest("thane-w") }), DEFAULT_PRICING_RULES);
    expect(best.score).toBeLessThanOrEqual(100);
    expect(best.score).toBeGreaterThanOrEqual(0);
  });
});

describe("destination compatibility", () => {
  it("treats identical destinations as fully compatible", () => {
    expect(destinationCompatibility(dest("thane-w"), dest("thane-w"))).toBe(1);
  });

  it("allows neighbouring corridor pairs", () => {
    expect(destinationCompatibility(dest("mulund"), dest("thane-w"))).toBeGreaterThan(0.6);
  });

  it("rejects opposite ends of the city", () => {
    expect(destinationCompatibility(dest("colaba"), dest("borivali"))).toBeLessThan(0.35);
  });

  it("is symmetric", () => {
    expect(destinationCompatibility(dest("andheri-e"), dest("powai"))).toBeCloseTo(
      destinationCompatibility(dest("powai"), dest("andheri-e")),
      6,
    );
  });
});
