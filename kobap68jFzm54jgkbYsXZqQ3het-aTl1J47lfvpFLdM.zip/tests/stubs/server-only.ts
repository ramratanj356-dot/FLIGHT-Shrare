// Stub: the real `server-only` package throws outside a React Server Component.
