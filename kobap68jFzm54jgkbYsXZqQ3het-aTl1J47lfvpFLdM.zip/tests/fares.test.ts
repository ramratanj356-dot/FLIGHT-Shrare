import { describe, expect, it } from "vitest";
import { computeGroupFare } from "@/lib/fares/group";
import { DEFAULT_PRICING_RULES, type FareStrategy } from "@/lib/config/pricing";

const member = (userId: string, destinationId: string, distanceKm: number, soloFarePaise: number) => ({
  id: `rm_${userId}`,
  userId,
  destinationId,
  distanceKm,
  soloFarePaise,
  seatCount: 1,
  luggageUnits: 1,
});

const THANE = member("u1", "thane-w", 26, 115000);
const MULUND = member("u2", "mulund", 22, 98000);
const POWAI = member("u3", "powai", 12, 75000);

const strategies: FareStrategy[] = ["equal", "distance", "hybrid"];

describe.each(strategies)("group fare — %s strategy", (strategy) => {
  const fare = computeGroupFare({
    members: [THANE, MULUND],
    vehicleCategory: "sedan",
    strategy,
    tollsPaise: 12000,
  });

  it("allocates every rupee of the total across members", () => {
    const sum = fare.members.reduce((s, m) => s + m.contributionPaise, 0);
    expect(sum).toBe(fare.breakdown.totalPaise);
  });

  it("keeps contributions as whole rupees", () => {
    for (const m of fare.members) expect(m.contributionPaise % 100).toBe(0);
  });

  it("charges each member less than their solo fare", () => {
    for (const m of fare.members) {
      expect(m.contributionPaise).toBeLessThan(m.soloEstimatePaise);
      expect(m.savingsPaise).toBe(m.soloEstimatePaise - m.contributionPaise);
    }
  });

  it("reconciles the breakdown components", () => {
    const { breakdown } = fare;
    expect(breakdown.vehicleFarePaise + breakdown.platformFeePaise + breakdown.taxPaise).toBe(breakdown.totalPaise);
    expect(sumSavings(fare)).toBe(breakdown.totalSavingsPaise);
  });
});

describe("distance-weighted allocation", () => {
  it("charges the longer leg more", () => {
    const fare = computeGroupFare({ members: [THANE, POWAI], vehicleCategory: "sedan", strategy: "distance" });
    const thane = fare.members.find((m) => m.userId === "u1")!;
    const powai = fare.members.find((m) => m.userId === "u3")!;
    expect(thane.contributionPaise).toBeGreaterThan(powai.contributionPaise);
  });
});

describe("fare edges", () => {
  it("handles a single passenger without inventing a discount", () => {
    const fare = computeGroupFare({ members: [THANE], vehicleCategory: "sedan", strategy: "equal" });
    expect(fare.members).toHaveLength(1);
    expect(fare.breakdown.totalPaise).toBe(fare.members[0].contributionPaise);
    expect(fare.members[0].contributionPaise).toBeLessThanOrEqual(THANE.soloFarePaise);
  });

  it("applies the minimum platform fee on very short trips", () => {
    const short = member("u9", "vile-parle", 6, 48000);
    const fare = computeGroupFare({ members: [short], vehicleCategory: "sedan", strategy: "equal" });
    expect(fare.breakdown.platformFeePaise).toBeGreaterThanOrEqual(DEFAULT_PRICING_RULES.platformFeeMinPaise);
  });

  it("spreads passengers across all seat counts without losing paise", () => {
    const members = Array.from({ length: 6 }, (_, i) =>
      member(`u${i}`, i % 2 ? "mulund" : "thane-w", i % 2 ? 22 : 26, i % 2 ? 98000 : 115000),
    );
    const fare = computeGroupFare({ members, vehicleCategory: "mpv", strategy: "hybrid", tollsPaise: 8000 });
    expect(fare.members.reduce((s, m) => s + m.contributionPaise, 0)).toBe(fare.breakdown.totalPaise);
    expect(fare.members.every((m) => m.contributionPaise > 0)).toBe(true);
  });

  it("rejects an empty group", () => {
    expect(() => computeGroupFare({ members: [], vehicleCategory: "sedan", strategy: "equal" })).toThrow();
  });
});

function sumSavings(fare: ReturnType<typeof computeGroupFare>) {
  return fare.members.reduce((s, m) => s + m.savingsPaise, 0);
}
