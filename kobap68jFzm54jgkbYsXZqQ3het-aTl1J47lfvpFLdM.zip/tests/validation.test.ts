import { describe, expect, it } from "vitest";
import {
  createRideSchema, joinRequestSchema, normalizeFlight, pricingRulesSchema, reportSchema,
  supportTicketSchema, flightNumberSchema,
} from "@/lib/validation/schemas";

describe("flight number normalisation", () => {
  it("accepts lowercase and spaced input", () => {
    expect(normalizeFlight(" ai 864 ")).toEqual({ airlineCode: "AI", number: "864", flightNumber: "AI864" });
    expect(normalizeFlight("6e-5123")?.flightNumber).toBe("6E5123");
  });

  it("does not treat a four digit number as a flight", () => {
    // "1234" parses as an alphanumeric two-character prefix plus digits, so the
    // stricter check is the airline-code allowlist used by the search form.
    expect(normalizeFlight("1234")?.airlineCode).toBe("12");
    expect(flightNumberSchema.safeParse("A").success).toBe(false);
  });

  it("normalises via the schema used by the search form", () => {
    expect(flightNumberSchema.parse("uk 927")).toBe("UK927");
  });
});

describe("ride creation validation", () => {
  const base = {
    flightNumber: "AI864",
    flightDate: new Date(Date.now() + 3 * 864e5).toISOString().slice(0, 10),
    airportId: "apt_bom",
    destinationId: "thane-w",
    vehicleCategory: "suv" as const,
    maxWaitMinutes: 45,
    strategy: "hybrid" as const,
    passengerCount: 1,
    luggageUnits: 1,
  };

  it("accepts a well formed ride", () => {
    expect(createRideSchema.safeParse(base).success).toBe(true);
  });

  it("rejects past travel dates", () => {
    expect(createRideSchema.safeParse({ ...base, flightDate: "2020-01-01" }).success).toBe(false);
  });

  it("rejects malformed dates", () => {
    expect(createRideSchema.safeParse({ ...base, flightDate: "02/01/2099" }).success).toBe(false);
  });

  it("caps the waiting window", () => {
    expect(createRideSchema.safeParse({ ...base, maxWaitMinutes: 5 }).success).toBe(false);
    expect(createRideSchema.safeParse({ ...base, maxWaitMinutes: 400 }).success).toBe(false);
  });

  it("limits passengers to the largest vehicle", () => {
    expect(createRideSchema.safeParse({ ...base, passengerCount: 7 }).success).toBe(false);
  });

  it("rejects an unknown vehicle category", () => {
    expect(createRideSchema.safeParse({ ...base, vehicleCategory: "bus" }).success).toBe(false);
  });
});

describe("join request validation", () => {
  const base = { rideGroupId: "rg_1", destinationId: "thane-w", passengerCount: 1, luggageUnits: 1 };

  it("accepts a reference of plausible length", () => {
    expect(joinRequestSchema.safeParse({ ...base, bookingReference: "6X7Y2Q" }).success).toBe(true);
  });

  it("rejects a one-character booking reference", () => {
    expect(joinRequestSchema.safeParse({ ...base, bookingReference: "A" }).success).toBe(false);
  });

  it("allows omitting the reference (manual review path)", () => {
    expect(joinRequestSchema.safeParse(base).success).toBe(true);
  });
});

describe("admin pricing validation", () => {
  const valid = {
    baseFareRupees: 240, perKmRupees: 25, extraStopRupees: 50, platformFeePct: 8,
    platformFeeMinRupees: 25, taxPct: 18, maxWaitMinutes: 45, destinationThreshold: 0.6,
  };

  it("accepts sane values", () => {
    expect(pricingRulesSchema.safeParse(valid).success).toBe(true);
  });

  it("rejects a negative base fare", () => {
    expect(pricingRulesSchema.safeParse({ ...valid, baseFareRupees: -1 }).success).toBe(false);
  });

  it("rejects an out-of-range threshold", () => {
    expect(pricingRulesSchema.safeParse({ ...valid, destinationThreshold: 1.4 }).success).toBe(false);
  });

  it("rejects an absurd platform fee", () => {
    expect(pricingRulesSchema.safeParse({ ...valid, platformFeePct: 90 }).success).toBe(false);
  });
});

describe("reporting and support", () => {
  it("requires a meaningful report description", () => {
    expect(reportSchema.safeParse({ category: "safety", details: "bad" }).success).toBe(false);
    expect(reportSchema.safeParse({ category: "safety", details: "Passenger did not arrive at the meeting point." }).success).toBe(true);
  });

  it("limits ticket categories to the API contract", () => {
    expect(supportTicketSchema.safeParse({ subject: "Fare query", category: "unknown", body: "x".repeat(30) }).success).toBe(false);
    expect(supportTicketSchema.safeParse({ subject: "Fare query", category: "fare", body: "The estimate changed after another passenger joined." }).success).toBe(true);
  });
});
