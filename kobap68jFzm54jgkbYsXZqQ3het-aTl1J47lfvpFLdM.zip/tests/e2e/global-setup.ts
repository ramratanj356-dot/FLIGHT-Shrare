import { chromium, type FullConfig } from "@playwright/test";
import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";

/**
 * Signs each demo role in once and stores the session cookie for reuse.
 *
 * 1. Clears the `rate_limits` table first. The limiter is deliberately
 *    IP-scoped, so repeated local test runs would otherwise trip the
 *    "too many sign-in attempts" guard. This touches the test database only —
 *    no application code is aware of it.
 * 2. Saves one storage state per role so specs never re-authenticate.
 */
const ROLES = [
  { name: "passenger", email: "aarav@demo.flightshare.app", password: "Demo@1234" },
  { name: "requester", email: "kavya@demo.flightshare.app", password: "Demo@1234" },
  { name: "driver", email: "driver@demo.flightshare.app", password: "Driver@1234" },
  { name: "admin", email: "admin@demo.flightshare.app", password: "Admin@1234" },
] as const;

export const AUTH_DIR = path.resolve(__dirname, ".auth");

export default async function globalSetup(config: FullConfig) {
  const baseURL =
    process.env.E2E_BASE_URL ?? `http://localhost:${process.env.E2E_PORT ?? 3100}`;

  const dbPath = path.resolve(process.cwd(), process.env.DATABASE_PATH ?? "./data/flightshare.db");
  try {
    const db = new Database(dbPath);
    db.prepare("DELETE FROM rate_limits").run();
    db.close();
  } catch {
    // A Postgres-backed deployment would not have this file; nothing to clear.
  }

  fs.mkdirSync(AUTH_DIR, { recursive: true });
  const browser = await chromium.launch();
  for (const role of ROLES) {
    const context = await browser.newContext({ baseURL });
    const page = await context.newPage();
    await page.goto("/login");
    await page.getByLabel("Email", { exact: true }).fill(role.email);
    await page.getByLabel("Password", { exact: true }).fill(role.password);
    await page.getByRole("button", { name: /^sign in$/i }).click();
    await page.waitForURL((u) => !u.pathname.startsWith("/login"), { timeout: 60_000 });
    await context.storageState({ path: path.join(AUTH_DIR, `${role.name}.json`) });
    await context.close();
  }
  await browser.close();
  void config;
}
