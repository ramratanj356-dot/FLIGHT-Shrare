import { expect, test } from "@playwright/test";
import path from "node:path";

/**
 * The money path: a passenger searches a flight, opens a scored match, requests
 * a seat (with an explicit "nothing is charged" confirmation), the coordinator
 * approves, and a signed-out visitor is stopped at every protected route.
 *
 * Sessions are created once in tests/e2e/global-setup.ts and reused here, so
 * runs stay inside the real sign-in rate limit.
 *
 * The specs assert the visible contract rather than a frozen dataset: if a
 * previous run filled the last seat, the affected test skips instead of lying.
 */
const DEMO_DATE = new Date().toISOString().slice(0, 10);
const auth = (role: "passenger" | "requester" | "driver" | "admin") =>
  path.resolve(__dirname, ".auth", `${role}.json`);

test.describe("public site", () => {
  test("home page communicates the proposition in seconds", async ({ page }) => {
    await page.goto("/");
    await expect(page.getByRole("heading", { level: 1 })).toContainText(/your flight has landed/i);
    await expect(page.getByRole("heading", { level: 1 })).toContainText(/your cab costs less/i);
    await expect(page.getByRole("link", { name: /find my ride/i }).first()).toBeVisible();
    // The fare comparison is labelled as an example, not a live quote.
    await expect(page.getByText(/example/i).first()).toBeVisible();
  });

  test("signed-out visitors cannot reach protected areas", async ({ page }) => {
    for (const route of ["/app", "/app/trips", "/driver", "/admin", "/app/profile"]) {
      await page.goto(route);
      await expect(page).toHaveURL(/\/login/, { timeout: 20_000 });
    }
  });

  test("marketing sub-pages render and are reachable from the footer", async ({ page }) => {
    for (const route of ["/how-it-works", "/destinations", "/safety", "/partners", "/help", "/status"]) {
      const res = await page.goto(route);
      expect(res?.status(), route).toBe(200);
      await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
    }
    await page.goto("/legal/privacy");
    await expect(page.getByText(/not been reviewed/i).first()).toBeVisible();
  });

  test("search validates input and reaches scored results", async ({ page }) => {
    await page.goto("/search");

    await page.getByLabel(/flight number/i).fill("12");
    await page.getByRole("button", { name: /find my ride/i }).click();
    await expect(page.getByText(/enter a flight number|airline code and number/i).first()).toBeVisible();
    await expect(page).toHaveURL(/\/search/);

    await page.getByLabel(/flight number/i).fill("AI864");
    await page.getByRole("button", { name: /find my ride/i }).click();
    await page.waitForURL(/\/rides/, { timeout: 40_000 });

    await expect(page.getByRole("heading", { level: 1 })).toContainText(/AI864/i);
    await expect(page.getByText(/compatible ride|no compatible rides/i).first()).toBeVisible();
    await expect(page.getByText(/est\. per person/i).first()).toBeVisible();
    await expect(page.getByText(/how we ranked these/i).first()).toBeVisible();
  });

  test("opening a match shows a transparent, estimate-labelled fare breakdown", async ({ page }) => {
    await page.goto(`/rides?flight=AI864&date=${DEMO_DATE}&dest=thane-w&pax=1&luggage=1`);
    const firstMatch = page.getByRole("link", { name: /view ride/i }).first();
    test.skip(!(await firstMatch.isVisible().catch(() => false)), "No open groups for today in this dataset.");
    await firstMatch.click();
    await page.waitForURL(/\/rides\/.+/);
    await expect(page.getByText(/vehicle fare|ride provider fare|base fare/i).first()).toBeVisible();
    await expect(page.getByText(/estimate/i).first()).toBeVisible();
  });
});

test.describe("passenger", () => {
  test.use({ storageState: auth("requester") });

  test("requesting to join never charges and lands on the trip", async ({ page }) => {
    await page.goto(`/rides?flight=AI864&date=${DEMO_DATE}&dest=powai&pax=1&luggage=1`);

    // The requester is already a member of some seeded groups, so walk the
    // results until a group she can actually request to join shows up.
    const viewLinks = page.getByRole("link", { name: /view ride/i });
    const hrefs = await viewLinks.evaluateAll((nodes) =>
      nodes.map((n) => (n as HTMLAnchorElement).getAttribute("href")).filter((h): h is string => Boolean(h)).slice(0, 6),
    );
    expect(hrefs.length).toBeGreaterThan(0);

    let joined = false;
    for (const href of hrefs) {
      await page.goto(href);
      const join = page.getByRole("link", { name: /request to join|join this ride/i }).first();
      if (!(await join.isVisible().catch(() => false))) continue;
      await join.click();
      await page.waitForURL(/\/join$/);
      joined = true;
      break;
    }
    test.skip(!joined, "Every candidate group is already joined or full in this dataset.");

    // The disclosure that nothing is charged must be present before submitting.
    await expect(page.getByText(/nothing is charged|always free/i).first()).toBeVisible();

    await page.getByRole("button", { name: /review & send request/i }).click();
    const dialog = page.getByRole("dialog");
    await expect(dialog).toBeVisible();
    await expect(dialog).toContainText(/nothing is charged/i);
    await dialog.getByRole("button", { name: /send request/i }).click();

    // Success redirects to the trip; a refusal must explain itself on screen.
    await page.waitForTimeout(3000);
    if (page.url().includes("/app/trips/")) {
      // Either the request is pending approval, or it was auto-accepted and the
      // full trip page opens. Both are honest outcomes; a blank page is not.
      await expect(
        page.getByRole("heading", { level: 1 }).filter({ hasText: /request sent|→/i }).first(),
      ).toBeVisible();
    } else {
      await expect(page.getByText(/filled up|not enough|already|cancelled|declined|too many/i).first()).toBeVisible();
    }
  });
});

test.describe("coordinator", () => {
  test.use({ storageState: auth("passenger") });

  test("trip page exposes the coordinator panel and fare ledger", async ({ page }) => {
    await page.goto("/app/trips");
    const openTrip = page.getByRole("link", { name: /open trip/i }).first();
    test.skip(!(await openTrip.isVisible().catch(() => false)), "No trips in this dataset.");
    await openTrip.click();
    await page.waitForURL(/\/app\/trips\/.+/);
    await expect(page.getByText(/fare breakdown/i)).toBeVisible();
    await expect(page.getByText(/split between/i)).toBeVisible();
    await expect(page.getByText(/coordinator controls/i)).toBeVisible();
  });

  test("dashboard, notifications, messages and profile all render", async ({ page }) => {
    for (const route of ["/app", "/app/trips", "/app/messages", "/app/notifications", "/app/profile", "/app/rides/new"]) {
      const res = await page.goto(route);
      expect(res?.status(), route).toBe(200);
      await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
    }
  });
});

test.describe("driver & admin separation", () => {
  test.use({ storageState: auth("driver") });

  test("driver sees trips and earnings but is refused the admin console", async ({ page }) => {
    await page.goto("/driver");
    await expect(page.getByRole("heading", { level: 1 })).toContainText(/namaste/i);
    await page.goto("/driver/earnings");
    await expect(page.getByText(/net earnings/i).first()).toBeVisible();

    // Server-side role checks, not just hidden links: the layout redirects a
    // driver away from the admin console.
    await page.goto("/admin");
    await expect(page).toHaveURL(/\?denied=/, { timeout: 15_000 });
    await expect(page.getByText(/platform overview/i)).toHaveCount(0);

    // The API refuses too, even with a valid driver session.
    const api = await page.request.post("/api/admin/pricing", {
      headers: { Origin: process.env.E2E_BASE_URL ?? `http://localhost:${process.env.E2E_PORT ?? 3100}` },
      data: { baseFareRupees: 240, perKmRupees: 25, extraStopRupees: 50, platformFeePct: 8, platformFeeMinRupees: 25, taxPct: 18, maxWaitMinutes: 45, destinationThreshold: 0.6 },
    });
    expect(api.status()).toBe(403);
  });

  test("admin console loads metrics and the audit log", async ({ browser }) => {
    const context = await browser.newContext({ storageState: auth("admin") });
    const page = await context.newPage();
    await page.goto("/admin");
    await expect(page.getByRole("heading", { level: 1 })).toContainText(/platform overview/i);
    await expect(page.getByText(/registered users/i)).toBeVisible();
    for (const route of ["/admin/verifications", "/admin/rides", "/admin/users", "/admin/pricing", "/admin/audit"]) {
      const res = await page.goto(route);
      expect(res?.status(), route).toBe(200);
    }
    await context.close();
  });
});

test.describe("responsive", () => {
  test("mobile keeps navigation reachable without horizontal scroll", async ({ page }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto("/");
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    expect(overflow).toBeLessThanOrEqual(1);
    await expect(page.getByRole("link", { name: /find my ride/i }).first()).toBeVisible();
  });
});
