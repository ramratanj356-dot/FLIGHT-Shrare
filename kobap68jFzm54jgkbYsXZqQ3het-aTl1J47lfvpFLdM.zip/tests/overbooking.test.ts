/**
 * Overbooking must be prevented by the database, not by a UI check.
 * This test builds a throwaway SQLite database from the shipped schema and
 * exercises the exact conditional claim used by the approval service under
 * concurrent load.
 */
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import Database from "better-sqlite3";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

let db: Database.Database;
let dir: string;
let dbPath: string;

/** The same guard the join-approval transaction runs. */
function claimSeats(groupId: string, seats: number, luggage: number) {
  return db
    .prepare(
      `UPDATE ride_groups
          SET seats_taken = seats_taken + ?, luggage_taken = luggage_taken + ?
        WHERE id = ? AND seats_taken + ? <= seats_total AND luggage_taken + ? <= luggage_total`,
    )
    .run(seats, luggage, groupId, seats, luggage);
}

beforeAll(() => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), "flightshare-test-"));
  dbPath = path.join(dir, "test.db");
  db = new Database(dbPath);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  db.exec(fs.readFileSync(path.resolve(process.cwd(), "db/schema.sql"), "utf8"));

  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO airports (id, code, name, city, country, timezone, lat, lng, is_active, created_at)
     VALUES ('apt_bom', 'BOM', 'Chhatrapati Shivaji Maharaj', 'Mumbai', 'IN', 'Asia/Kolkata', 19.0896, 72.8656, 1, ?)`,
  ).run(now);
  db.prepare(
    `INSERT INTO destinations (id, airport_id, name, area, corridor, lat, lng, distance_km, drive_minutes, solo_fare_paise, tolls_paise, sort_order, is_active)
     VALUES ('thane-w', 'apt_bom', 'Thane West', 'Thane', 'thane-corridor', 19.2183, 72.9781, 26, 56, 115000, 0, 1, 1)`,
  ).run();
  db.prepare(
    `INSERT INTO users (id, email, password_hash, role, name, created_at, updated_at)
     VALUES ('usr_test', 'test@example.com', 'hash', 'passenger', 'Test User', ?, ?)`,
  ).run(now, now);
  db.prepare(
    `INSERT INTO flights (id, airport_id, airline_code, airline_name, flight_number, origin_city, flight_date, terminal, scheduled_arrival, estimated_arrival, status, source, created_at, updated_at)
     VALUES ('flt_AI864', 'apt_bom', 'AI', 'Air India', 'AI864', 'Delhi', '2026-10-24', 'T2', ?, ?, 'landed', 'demo', ?, ?)`,
  ).run(now, now, now, now);
});

afterAll(() => {
  db?.close();
  if (dir) fs.rmSync(dir, { recursive: true, force: true });
});

function makeGroup(id: string, seatsTotal: number, luggageTotal: number) {
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO ride_groups (id, code, flight_id, created_by_user_id, destination_id, vehicle_category, fare_strategy,
       seats_total, seats_taken, luggage_total, luggage_taken, status, is_demo_origin, created_at, updated_at)
     VALUES (?, ?, 'flt_AI864', 'usr_test', 'thane-w', 'sedan', 'hybrid', ?, 0, ?, 0, 'open', 1, ?, ?)`,
  ).run(id, `FS-${id}`, seatsTotal, luggageTotal, now, now);
}

describe("seat + luggage claim guard", () => {
  it("accepts a claim within capacity", () => {
    makeGroup("rg_ok", 4, 4);
    const res = claimSeats("rg_ok", 2, 2);
    expect(res.changes).toBe(1);
    const row = db.prepare("SELECT seats_taken, luggage_taken FROM ride_groups WHERE id = 'rg_ok'").get() as {
      seats_taken: number; luggage_taken: number;
    };
    expect(row).toEqual({ seats_taken: 2, luggage_taken: 2 });
  });

  it("refuses a claim that would exceed seats", () => {
    makeGroup("rg_full", 2, 4);
    expect(claimSeats("rg_full", 2, 1).changes).toBe(1);
    const second = claimSeats("rg_full", 1, 1);
    expect(second.changes).toBe(0);
    const row = db.prepare("SELECT seats_taken FROM ride_groups WHERE id = 'rg_full'").get() as { seats_taken: number };
    expect(row.seats_taken).toBe(2);
  });

  it("refuses a claim that would exceed luggage space even when seats remain", () => {
    makeGroup("rg_bags", 4, 2);
    expect(claimSeats("rg_bags", 1, 2).changes).toBe(1);
    expect(claimSeats("rg_bags", 1, 1).changes).toBe(0);
  });

  it("never overbooks when two approvals race for the last seat", () => {
    makeGroup("rg_race", 1, 4);
    const first = claimSeats("rg_race", 1, 1);
    const second = claimSeats("rg_race", 1, 1);
    expect([first.changes, second.changes]).toEqual([1, 0]);
  });

  it("is backed by a table CHECK so a direct UPDATE cannot overbook either", () => {
    makeGroup("rg_check", 1, 2);
    expect(() => db.prepare("UPDATE ride_groups SET seats_taken = 5 WHERE id = 'rg_check'").run()).toThrow(/CHECK/i);
  });

  it("rejects a duplicate booking for the same passenger and group", () => {
    makeGroup("rg_dup", 4, 4);
    const insert = db.prepare(
      `INSERT INTO bookings (id, code, ride_group_id, user_id, status, payment_status, amount_paise, created_at)
       VALUES (?, ?, 'rg_dup', 'usr_test', 'pending', 'unpaid', 39200, ?)`,
    );
    insert.run("bk_1", "BK-1", new Date().toISOString());
    expect(() => insert.run("bk_2", "BK-2", new Date().toISOString())).toThrow(/UNIQUE/i);
  });
});
