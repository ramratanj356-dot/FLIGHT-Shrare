import { describe, expect, it } from "vitest";
import { allocate, allocateRupees, formatPaise, roundToRupee } from "@/lib/money";

const w = (...weights: number[]) => weights.map((weight, i) => ({ id: `m${i}`, weight }));
const sum = (rows: { amount: number }[]) => rows.reduce((s, r) => s + r.amount, 0);

describe("money helpers", () => {
  it("formats integer paise as Indian rupees", () => {
    expect(formatPaise(120000)).toBe("₹1,200");
    expect(formatPaise(115000)).toBe("₹1,150");
    expect(formatPaise(39200)).toBe("₹392");
  });

  it("allocates paise exactly, distributing the remainder deterministically", () => {
    const parts = allocate(1000, w(1, 1, 1));
    expect(sum(parts)).toBe(1000);
    expect(parts.map((p) => p.amount).sort((a, b) => a - b)).toEqual([333, 333, 334]);
    expect(parts.filter((p) => p.remainder)).toHaveLength(1);
    // Deterministic: same input, same recipient.
    expect(allocate(1000, w(1, 1, 1))).toEqual(parts);
  });

  it("allocates by weight rather than equally", () => {
    const [a, b] = allocate(1000, w(3, 1));
    expect([a.amount, b.amount]).toEqual([750, 250]);
  });

  it("falls back to an equal split when every weight is zero", () => {
    const parts = allocate(500, w(0, 0));
    expect(sum(parts)).toBe(500);
    expect(parts.map((p) => p.amount).sort()).toEqual([250, 250]);
  });

  it("rejects fractional paise instead of silently rounding", () => {
    expect(() => allocate(100.5, w(1, 1))).toThrow(/integer paise/i);
  });

  it("rounds paise totals to whole rupees", () => {
    expect(roundToRupee(39152)).toBe(39200);
    expect(roundToRupee(114365)).toBe(114400);
    expect(roundToRupee(0)).toBe(0);
  });

  it("allocates rupees exactly at rupee granularity", () => {
    const parts = allocateRupees(114400, w(360, 370, 410));
    expect(sum(parts)).toBe(114400);
    expect(parts.every((p) => p.amount % 100 === 0)).toBe(true);
  });

  it("refuses rupee allocation when the total is not a whole number of rupees", () => {
    expect(() => allocateRupees(114365, w(1, 1))).toThrow(/whole-rupee/i);
  });
});
