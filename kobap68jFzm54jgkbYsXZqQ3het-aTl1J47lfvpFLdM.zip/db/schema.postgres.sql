-- ─────────────────────────────────────────────────────────────────────────────
-- FlightShare — PostgreSQL / Supabase schema
--
-- This mirrors db/schema.sql (SQLite, used by the running prototype) with
-- production types, enums, indexes and Row Level Security. Money is always
-- integer paise. Timestamps are timestamptz (UTC in storage, IST in display).
--
-- Apply with:
--   psql "$DATABASE_URL" -f db/schema.postgres.sql
-- or paste into the Supabase SQL editor. RLS is enabled but permissive until
-- you create the policies in section 9 — the API is the only writer today.
-- ─────────────────────────────────────────────────────────────────────────────

create extension if not exists "pgcrypto";

-- ── Enums ───────────────────────────────────────────────────────────────────
do $$ begin
  create type user_role as enum ('passenger','driver','coordinator','admin','support');
exception when duplicate_object then null; end $$;
do $$ begin
  create type user_status as enum ('active','suspended','deleted');
exception when duplicate_object then null; end $$;
do $$ begin
  create type vehicle_category as enum ('sedan','suv','mpv');
exception when duplicate_object then null; end $$;
do $$ begin
  create type fare_strategy as enum ('equal','distance','hybrid');
exception when duplicate_object then null; end $$;
do $$ begin
  create type ride_status as enum ('draft','open','full','confirmed','in_progress','completed','cancelled','expired');
exception when duplicate_object then null; end $$;
do $$ begin
  create type readiness_state as enum ('not_landed','landed','collecting_baggage','ready_at_meeting_point','boarding_vehicle','trip_started');
exception when duplicate_object then null; end $$;
do $$ begin
  create type member_status as enum ('invited','accepted','removed','left','no_show');
exception when duplicate_object then null; end $$;
do $$ begin
  create type member_role as enum ('owner','member');
exception when duplicate_object then null; end $$;
do $$ begin
  create type request_status as enum ('pending','approved','declined','withdrawn','expired');
exception when duplicate_object then null; end $$;
do $$ begin
  create type booking_status as enum ('pending','confirmed','cancelled','completed','no_show');
exception when duplicate_object then null; end $$;
do $$ begin
  create type payment_status as enum ('unpaid','authorised','captured','refund_pending','refunded','failed');
exception when duplicate_object then null; end $$;
do $$ begin
  create type refund_status as enum ('pending','processed','failed','cancelled');
exception when duplicate_object then null; end $$;
do $$ begin
  create type verification_status as enum ('pending','in_review','verified','rejected','expired');
exception when duplicate_object then null; end $$;
do $$ begin
  create type flight_status as enum ('scheduled','enroute','landed','delayed','cancelled');
exception when duplicate_object then null; end $$;
do $$ begin
  create type flight_source as enum ('demo','provider','manual');
exception when duplicate_object then null; end $$;
do $$ begin
  create type ticket_status as enum ('open','in_progress','waiting','resolved','closed');
exception when duplicate_object then null; end $$;
do $$ begin
  create type report_status as enum ('open','reviewing','resolved','dismissed');
exception when duplicate_object then null; end $$;
do $$ begin
  create type message_kind as enum ('text','system','meeting_point','readiness','fare_update','driver_assigned');
exception when duplicate_object then null; end $$;

-- ── Reference ───────────────────────────────────────────────────────────────
create table if not exists airports (
  id          text primary key,
  code        text not null unique,                 -- IATA, e.g. BOM
  name        text not null,
  city        text not null,
  country     text not null default 'IN',
  timezone    text not null default 'Asia/Kolkata',
  lat         double precision not null,
  lng         double precision not null,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now()
);

create table if not exists destinations (
  id              text primary key,
  airport_id      text not null references airports(id) on delete cascade,
  name            text not null,
  area            text not null,
  corridor        text not null,
  lat             double precision not null,
  lng             double precision not null,
  distance_km     numeric(7,2) not null,
  drive_minutes   integer not null,
  solo_fare_paise integer not null check (solo_fare_paise >= 0),
  tolls_paise     integer not null default 0 check (tolls_paise >= 0),
  blurb           text,
  is_active       boolean not null default true,
  sort_order      integer not null default 0,
  unique (airport_id, name)
);
create index if not exists idx_destinations_airport on destinations(airport_id, is_active, sort_order);

-- ── Identity ────────────────────────────────────────────────────────────────
-- `users.id` doubles as the Supabase auth subject when Supabase Auth is used;
-- otherwise the API issues its own sessions (see `sessions`).
create table if not exists users (
  id                text primary key,
  email             text not null unique,
  password_hash     text,                                  -- scrypt; null for OAuth-only
  role              user_role not null default 'passenger',
  name              text not null,
  phone             text,
  avatar_url        text,
  email_verified_at timestamptz,
  phone_verified_at timestamptz,
  status            user_status not null default 'active',
  last_login_at     timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  deleted_at        timestamptz
);
create index if not exists idx_users_role_status on users(role, status);
create index if not exists idx_users_email_lower on users(lower(email));

create table if not exists sessions (
  id            text primary key,
  user_id       text not null references users(id) on delete cascade,
  token_hash    text not null unique,                      -- sha256 of the cookie value
  user_agent    text,
  ip_hash       text,                                      -- hashed, never the raw IP
  expires_at    timestamptz not null,
  revoked_at    timestamptz,
  created_at    timestamptz not null default now()
);
create index if not exists idx_sessions_user on sessions(user_id) where revoked_at is null;

create table if not exists password_resets (
  id          text primary key,
  user_id     text not null references users(id) on delete cascade,
  token_hash  text not null unique,
  expires_at  timestamptz not null,
  used_at     timestamptz,
  created_at  timestamptz not null default now()
);

create table if not exists email_verifications (
  id          text primary key,
  user_id     text not null references users(id) on delete cascade,
  token_hash  text not null unique,
  expires_at  timestamptz not null,
  verified_at timestamptz,
  created_at  timestamptz not null default now()
);

create table if not exists passenger_profiles (
  user_id               text primary key references users(id) on delete cascade,
  identity_status       verification_status not null default 'pending',
  identity_provider     text not null default 'simulated',
  identity_verified_at  timestamptz,
  home_destination_id   text references destinations(id) on delete set null,
  luggage_preference    text not null default 'one_checkin',
  accessibility_needs   text,
  language              text not null default 'en',
  quiet_ride            boolean not null default false,
  emergency_contact_name  text,
  emergency_contact_phone text,
  rating_avg            numeric(3,2) not null default 0,
  rating_count          integer not null default 0,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

create table if not exists driver_profiles (
  id                  text primary key,
  user_id             text not null unique references users(id) on delete cascade,
  company_name        text,
  license_number      text,
  verification_status verification_status not null default 'pending',
  verification_notes  text,
  verified_at         timestamptz,
  rating_avg          numeric(3,2) not null default 0,
  rating_count        integer not null default 0,
  is_available        boolean not null default false,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

create table if not exists vehicles (
  id                  text primary key,
  driver_id           text not null references driver_profiles(id) on delete cascade,
  category            vehicle_category not null,
  make_model          text not null,
  registration_number text not null unique,
  seats               integer not null check (seats between 1 and 8),
  luggage_units       integer not null check (luggage_units between 0 and 12),
  verification_status verification_status not null default 'pending',
  is_active           boolean not null default true,
  created_at          timestamptz not null default now()
);

-- ── Flights & verification ──────────────────────────────────────────────────
create table if not exists flights (
  id                text primary key,
  airport_id        text not null references airports(id),
  airline_code      text not null,
  airline_name      text not null,
  flight_number     text not null,
  origin_city       text not null,
  flight_date       date not null,
  terminal          text,
  scheduled_arrival timestamptz not null,
  estimated_arrival timestamptz not null,
  status            flight_status not null default 'scheduled',
  source            flight_source not null default 'demo',
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (airport_id, flight_number, flight_date)
);
create index if not exists idx_flights_date on flights(flight_date, estimated_arrival);

create table if not exists flight_verifications (
  id               text primary key,
  user_id          text not null references users(id) on delete cascade,
  flight_id        text not null references flights(id) on delete cascade,
  method           text not null default 'booking_reference',
  status           verification_status not null default 'pending',
  reference_masked text,                                    -- e.g. ••••42
  reference_hash   text,                                    -- never the raw reference
  provider         text not null default 'demo',
  notes            text,
  verified_at      timestamptz,
  created_at       timestamptz not null default now()
);
create unique index if not exists idx_flight_verifications_user_flight on flight_verifications(user_id, flight_id);

-- ── Ride groups ─────────────────────────────────────────────────────────────
create table if not exists ride_groups (
  id                     text primary key,
  code                   text not null unique,
  flight_id              text not null references flights(id),
  created_by_user_id     text not null references users(id),
  destination_id         text not null references destinations(id),
  vehicle_category       vehicle_category not null,
  fare_strategy          fare_strategy not null default 'hybrid',
  seats_total            integer not null check (seats_total between 1 and 6),
  seats_taken            integer not null default 0 check (seats_taken >= 0),
  luggage_total          integer not null default 4,
  luggage_taken          integer not null default 0,
  meet_point             text,
  departure_window_start timestamptz,
  departure_window_end   timestamptz,
  max_wait_minutes       integer not null default 45 check (max_wait_minutes between 15 and 90),
  status                 ride_status not null default 'open',
  driver_id              text references driver_profiles(id) on delete set null,
  vehicle_id             text references vehicles(id) on delete set null,
  fare_estimate_id       text,
  is_demo_origin         boolean not null default false,
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now(),
  -- overbooking guard at the table level
  constraint seats_within_capacity   check (seats_taken <= seats_total),
  constraint luggage_within_capacity check (luggage_taken <= luggage_total)
);
create index if not exists idx_ride_groups_flight on ride_groups(flight_id, status);
create index if not exists idx_ride_groups_status_window on ride_groups(status, departure_window_start);
create index if not exists idx_ride_groups_destination on ride_groups(destination_id);

create table if not exists ride_members (
  id                   text primary key,
  ride_group_id        text not null references ride_groups(id) on delete cascade,
  user_id              text not null references users(id) on delete cascade,
  join_request_id      text,
  seat_count           integer not null default 1 check (seat_count between 1 and 6),
  luggage_units        integer not null default 1,
  destination_id       text not null references destinations(id),
  readiness            readiness_state not null default 'not_landed',
  expected_ready_at    timestamptz,
  readiness_updated_at timestamptz,
  status               member_status not null default 'accepted',
  role                 member_role not null default 'member',
  joined_at            timestamptz not null default now(),
  unique (ride_group_id, user_id)
);
create index if not exists idx_ride_members_user on ride_members(user_id, status);

create table if not exists join_requests (
  id              text primary key,
  ride_group_id   text not null references ride_groups(id) on delete cascade,
  user_id         text not null references users(id) on delete cascade,
  passenger_count integer not null check (passenger_count between 1 and 6),
  luggage_units   integer not null default 1,
  destination_id  text not null references destinations(id),
  message         text,
  match_score     integer check (match_score between 0 and 100),
  status          request_status not null default 'pending',
  decided_by      text references users(id) on delete set null,
  decided_at      timestamptz,
  decision_note   text,
  created_at      timestamptz not null default now(),
  unique (ride_group_id, user_id)
);
create index if not exists idx_join_requests_group_status on join_requests(ride_group_id, status);

-- ── Fares ───────────────────────────────────────────────────────────────────
create table if not exists fare_estimates (
  id                 text primary key,
  ride_group_id      text references ride_groups(id) on delete cascade,
  strategy           fare_strategy not null,
  vehicle_category   vehicle_category not null,
  breakdown_json     jsonb not null,
  total_paise        integer not null check (total_paise >= 0),
  vehicle_fare_paise integer not null,
  fee_paise          integer not null,
  tax_paise          integer not null,
  solo_total_paise   integer not null,
  savings_paise      integer not null,
  expires_at         timestamptz not null,
  created_at         timestamptz not null default now()
);
create index if not exists idx_fare_estimates_group on fare_estimates(ride_group_id, created_at desc);

create table if not exists fare_allocations (
  id                  text primary key,
  fare_estimate_id    text not null references fare_estimates(id) on delete cascade,
  ride_group_id       text not null references ride_groups(id) on delete cascade,
  user_id             text references users(id) on delete set null,
  destination_id      text not null references destinations(id),
  distance_km         numeric(7,2) not null,
  weight              numeric(8,4) not null,
  vehicle_share_paise integer not null,
  fee_paise           integer not null default 0,
  tax_paise           integer not null default 0,
  contribution_paise  integer not null check (contribution_paise >= 0),
  solo_fare_paise     integer not null,
  savings_paise       integer not null,
  savings_pct         numeric(5,2) not null,
  created_at          timestamptz not null default now(),
  unique (ride_group_id, user_id)
);

-- ── Bookings & payments ─────────────────────────────────────────────────────
create table if not exists bookings (
  id               text primary key,
  code             text not null unique,
  ride_group_id    text not null references ride_groups(id) on delete cascade,
  user_id          text not null references users(id) on delete cascade,
  fare_estimate_id text references fare_estimates(id) on delete set null,
  status           booking_status not null default 'pending',
  payment_status   payment_status not null default 'unpaid',
  amount_paise     integer not null default 0 check (amount_paise >= 0),
  currency         text not null default 'INR',
  confirmed_at     timestamptz,
  cancelled_at     timestamptz,
  cancel_reason    text,
  created_at       timestamptz not null default now(),
  unique (ride_group_id, user_id)
);
create index if not exists idx_bookings_user on bookings(user_id, status);

create table if not exists payment_records (
  id                  text primary key,
  booking_id          text not null references bookings(id) on delete cascade,
  provider            text not null default 'demo',
  provider_order_id   text,
  provider_payment_id text,
  provider_event_id   text,                                  -- webhook dedupe key
  amount_paise        integer not null check (amount_paise >= 0),
  currency            text not null default 'INR',
  status              payment_status not null default 'unpaid',
  method              text,
  failure_reason      text,
  captured_at         timestamptz,
  created_at          timestamptz not null default now()
);
create unique index if not exists idx_payments_provider_payment on payment_records(provider, provider_payment_id) where provider_payment_id is not null;
create unique index if not exists idx_payments_provider_event on payment_records(provider, provider_event_id) where provider_event_id is not null;

create table if not exists refunds (
  id            text primary key,
  payment_id    text not null references payment_records(id) on delete cascade,
  amount_paise  integer not null check (amount_paise > 0),
  status        refund_status not null default 'pending',
  reason        text not null,
  requested_by  text references users(id) on delete set null,
  provider_ref  text,
  processed_at  timestamptz,
  created_at    timestamptz not null default now()
);

create table if not exists driver_earnings (
  id                text primary key,
  driver_id         text not null references driver_profiles(id) on delete cascade,
  ride_group_id     text not null references ride_groups(id) on delete cascade,
  gross_paise       integer not null check (gross_paise >= 0),
  commission_paise  integer not null default 0,
  deductions_paise  integer not null default 0,
  net_paise         integer not null check (net_paise >= 0),
  status            text not null default 'pending' check (status in ('pending','paid','failed','held')),
  payout_reference  text,
  period            text,
  created_at        timestamptz not null default now()
);
create index if not exists idx_driver_earnings_driver on driver_earnings(driver_id, created_at desc);

-- ── Coordination ────────────────────────────────────────────────────────────
create table if not exists ride_status_events (
  id            text primary key,
  ride_group_id text not null references ride_groups(id) on delete cascade,
  actor_user_id text references users(id) on delete set null,
  type          text not null,
  from_status   text,
  to_status     text,
  payload_json  jsonb,
  created_at    timestamptz not null default now()
);
create index if not exists idx_status_events_group on ride_status_events(ride_group_id, created_at desc);

create table if not exists conversations (
  id            text primary key,
  ride_group_id text not null unique references ride_groups(id) on delete cascade,
  created_at    timestamptz not null default now()
);

create table if not exists messages (
  id              text primary key,
  conversation_id text not null references conversations(id) on delete cascade,
  sender_user_id  text not null references users(id) on delete cascade,
  body            text not null check (char_length(body) between 1 and 2000),
  kind            message_kind not null default 'text',
  created_at      timestamptz not null default now()
);
create index if not exists idx_messages_conversation on messages(conversation_id, created_at);

create table if not exists message_reads (
  message_id text not null references messages(id) on delete cascade,
  user_id    text not null references users(id) on delete cascade,
  read_at    timestamptz not null default now(),
  primary key (message_id, user_id)
);

create table if not exists notifications (
  id            text primary key,
  user_id       text not null references users(id) on delete cascade,
  type          text not null,
  title         text not null,
  body          text not null,
  ride_group_id text references ride_groups(id) on delete cascade,
  href          text,
  is_demo       boolean not null default false,
  read_at       timestamptz,
  created_at    timestamptz not null default now()
);
create index if not exists idx_notifications_user_unread on notifications(user_id, created_at desc) where read_at is null;

-- ── Trust & safety ──────────────────────────────────────────────────────────
create table if not exists reviews (
  id                text primary key,
  ride_group_id     text not null references ride_groups(id) on delete cascade,
  author_user_id    text not null references users(id) on delete cascade,
  subject_user_id   text references users(id) on delete set null,
  role_subject      text not null default 'driver',
  rating            integer not null check (rating between 1 and 5),
  comment           text,
  created_at        timestamptz not null default now(),
  unique (ride_group_id, author_user_id, role_subject)
);

create table if not exists reports (
  id               text primary key,
  reporter_user_id text not null references users(id) on delete cascade,
  subject_user_id  text references users(id) on delete set null,
  ride_group_id    text references ride_groups(id) on delete set null,
  category         text not null,
  details          text not null,
  status           report_status not null default 'open',
  priority         text not null default 'normal',
  resolution       text,
  resolved_by      text references users(id) on delete set null,
  resolved_at      timestamptz,
  created_at       timestamptz not null default now()
);
create index if not exists idx_reports_status on reports(status, created_at desc);

create table if not exists support_tickets (
  id            text primary key,
  user_id       text not null references users(id) on delete cascade,
  ride_group_id text references ride_groups(id) on delete set null,
  subject       text not null,
  category      text not null,
  body          text not null,
  status        ticket_status not null default 'open',
  priority      text not null default 'normal',
  assigned_to   text references users(id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists idx_tickets_status on support_tickets(status, created_at desc);

-- ── Platform ────────────────────────────────────────────────────────────────
create table if not exists pricing_rules (
  key         text primary key,
  value_json  jsonb not null,
  description text,
  updated_by  text references users(id) on delete set null,
  updated_at  timestamptz not null default now()
);

create table if not exists audit_logs (
  id             text primary key,
  actor_user_id  text references users(id) on delete set null,
  actor_role     text,
  action         text not null,
  entity_type    text not null,
  entity_id      text,
  before_json    jsonb,
  after_json     jsonb,
  ip_hash        text,
  created_at     timestamptz not null default now()
);
create index if not exists idx_audit_actor on audit_logs(actor_user_id, created_at desc);
create index if not exists idx_audit_entity on audit_logs(entity_type, entity_id);

create table if not exists analytics_events (
  id         text primary key,
  user_id    text references users(id) on delete set null,
  name       text not null,
  props_json jsonb,
  created_at timestamptz not null default now()
);
create index if not exists idx_analytics_name on analytics_events(name, created_at desc);

-- Server-side rate limiting. In production prefer Redis/Upstash; this table is
-- the portable fallback and is safe under concurrent writes via the primary key.
create table if not exists rate_limits (
  key          text primary key,
  count        integer not null default 0,
  window_start timestamptz not null default now()
);

-- ── Row Level Security ──────────────────────────────────────────────────────
-- Enabled on every user-scoped table. The API connects with a privileged role
-- that bypasses RLS; these policies protect direct client access (e.g. the
-- Supabase anon key). On plain PostgreSQL the policies are skipped so the file
-- can be applied before Supabase auth is installed.
alter table users              enable row level security;
alter table passenger_profiles enable row level security;
alter table driver_profiles    enable row level security;
alter table vehicles           enable row level security;
alter table ride_groups        enable row level security;
alter table ride_members       enable row level security;
alter table join_requests      enable row level security;
alter table bookings           enable row level security;
alter table payment_records    enable row level security;
alter table refunds            enable row level security;
alter table driver_earnings    enable row level security;
alter table conversations      enable row level security;
alter table messages           enable row level security;
alter table notifications      enable row level security;
alter table reviews            enable row level security;
alter table reports            enable row level security;
alter table support_tickets    enable row level security;
alter table audit_logs         enable row level security;

do $$
begin
  if not exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname = 'auth' and p.proname = 'uid') then
    raise notice 'auth.uid() not found — skipping RLS policies (run inside Supabase to enable them).';
    return;
  end if;

  execute $p$create or replace function fs_uid() returns text
    language sql stable as $f$ select auth.uid()::text $f$$p$;

  -- Own profile only.
  execute $p$create policy users_self_read on users for select using (id = fs_uid())$p$;
  execute $p$create policy passenger_profile_self on passenger_profiles for all using (user_id = fs_uid()) with check (user_id = fs_uid())$p$;

  -- Ride groups are readable by any signed-in user; they contain no private data.
  execute $p$create policy ride_groups_read on ride_groups for select using (auth.uid() is not null)$p$;

  -- Members can see everyone else in a group they belong to.
  execute $p$create policy ride_members_member_read on ride_members for select using (
    user_id = fs_uid()
    or exists (select 1 from ride_members m where m.ride_group_id = ride_members.ride_group_id and m.user_id = fs_uid() and m.status = 'accepted')
  )$p$;

  execute $p$create policy join_requests_own on join_requests for select using (
    user_id = fs_uid()
    or exists (select 1 from ride_groups g where g.id = join_requests.ride_group_id and g.created_by_user_id = fs_uid())
  )$p$;

  execute $p$create policy messages_participants on messages for select using (
    exists (
      select 1 from conversations c
      join ride_members m on m.ride_group_id = c.ride_group_id
      where c.id = messages.conversation_id and m.user_id = fs_uid() and m.status = 'accepted'
    )
  )$p$;

  execute $p$create policy notifications_own on notifications for select using (user_id = fs_uid())$p$;
  execute $p$create policy bookings_own on bookings for select using (user_id = fs_uid())$p$;
  execute $p$create policy payments_via_booking on payment_records for select using (
    exists (select 1 from bookings b where b.id = payment_records.booking_id and b.user_id = fs_uid())
  )$p$;

  -- audit_logs is append-only: no UPDATE or DELETE policies are created.
  execute $p$create policy audit_staff_read on audit_logs for select using (
    exists (select 1 from users u where u.id = fs_uid() and u.role in ('admin','support'))
  )$p$;
end $$;

-- ── Seed reference data (idempotent) ────────────────────────────────────────
insert into airports (id, code, name, city, country, timezone, lat, lng)
values ('apt_bom', 'BOM', 'Chhatrapati Shivaji Maharaj International Airport', 'Mumbai', 'IN', 'Asia/Kolkata', 19.0896, 72.8656)
on conflict (id) do nothing;

insert into pricing_rules (key, value_json, description) values
  ('base_fare_paise',        '24000'::jsonb,  'Fixed flag-fall on every airport transfer'),
  ('per_km_paise',           '2500'::jsonb,   'Per-km rate applied to the shared route'),
  ('extra_stop_paise',       '5000'::jsonb,   'Added per additional drop-off'),
  ('detour_km_per_stop',     '2.4'::jsonb,    'Extra distance assumed per stop'),
  ('platform_fee_bps',       '800'::jsonb,    'Platform fee (8%)'),
  ('platform_fee_min_paise', '2500'::jsonb,   'Floor to cover processing'),
  ('tax_bps',                '1800'::jsonb,   'GST on the platform fee'),
  ('max_wait_minutes',       '45'::jsonb,     'Default kerb waiting window'),
  ('destination_threshold',  '0.6'::jsonb,    'Minimum route compatibility to join'),
  ('fare_strategy',          '"hybrid"'::jsonb, 'Default allocation strategy'),
  ('estimate_ttl_minutes',   '45'::jsonb,     'How long a fare estimate stays valid')
on conflict (key) do nothing;
