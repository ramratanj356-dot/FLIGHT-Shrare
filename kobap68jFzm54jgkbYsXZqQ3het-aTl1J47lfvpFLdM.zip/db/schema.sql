-- ════════════════════════════════════════════════════════════════════════════
--  FlightShare — SQLite schema (local / demo adapter)
--  Mirrors db/schema.postgres.sql (production, Supabase + RLS).
--  All money columns are INTEGER paise. All timestamps are ISO-8601 UTC text.
-- ════════════════════════════════════════════════════════════════════════════
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- ── Reference data ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS airports (
  id            TEXT PRIMARY KEY,
  code          TEXT NOT NULL UNIQUE,          -- IATA, e.g. BOM
  name          TEXT NOT NULL,
  city          TEXT NOT NULL,
  country       TEXT NOT NULL DEFAULT 'IN',
  timezone      TEXT NOT NULL DEFAULT 'Asia/Kolkata',
  lat           REAL NOT NULL,
  lng           REAL NOT NULL,
  is_active     INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS destinations (
  id              TEXT PRIMARY KEY,
  airport_id      TEXT NOT NULL REFERENCES airports(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  area            TEXT NOT NULL,
  corridor        TEXT NOT NULL,
  lat             REAL NOT NULL,
  lng             REAL NOT NULL,
  distance_km     REAL NOT NULL,
  drive_minutes   INTEGER NOT NULL,
  solo_fare_paise INTEGER NOT NULL,
  tolls_paise     INTEGER NOT NULL DEFAULT 0,
  blurb           TEXT,
  is_active       INTEGER NOT NULL DEFAULT 1,
  sort_order      INTEGER NOT NULL DEFAULT 0,
  UNIQUE (airport_id, name)
);
CREATE INDEX IF NOT EXISTS idx_destinations_airport ON destinations(airport_id, is_active);

-- ── Identity ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id                TEXT PRIMARY KEY,
  email             TEXT NOT NULL UNIQUE,
  password_hash     TEXT,                      -- scrypt; NULL for OAuth-only accounts
  role              TEXT NOT NULL DEFAULT 'passenger'
                    CHECK (role IN ('passenger','driver','coordinator','admin','support')),
  name              TEXT NOT NULL,
  phone             TEXT,
  avatar_url        TEXT,
  email_verified_at TEXT,
  phone_verified_at TEXT,
  status            TEXT NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active','suspended','deleted')),
  last_login_at     TEXT,
  created_at        TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at        TEXT NOT NULL DEFAULT (datetime('now')),
  deleted_at        TEXT
);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role, status);

CREATE TABLE IF NOT EXISTS sessions (
  id           TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash   TEXT NOT NULL UNIQUE,           -- sha256 of the opaque token
  user_agent   TEXT,
  ip_hash      TEXT,
  created_at   TEXT NOT NULL DEFAULT (datetime('now')),
  last_seen_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at   TEXT NOT NULL,
  revoked_at   TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id, revoked_at);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);

CREATE TABLE IF NOT EXISTS password_resets (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL UNIQUE,
  expires_at  TEXT NOT NULL,
  used_at     TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS email_verifications (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL UNIQUE,
  expires_at  TEXT NOT NULL,
  used_at     TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS passenger_profiles (
  user_id                  TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  identity_status          TEXT NOT NULL DEFAULT 'unverified'
                           CHECK (identity_status IN ('unverified','pending','verified','rejected')),
  identity_provider        TEXT,               -- 'simulated' in demo mode
  identity_verified_at     TEXT,
  home_destination_id      TEXT REFERENCES destinations(id),
  luggage_preference       TEXT NOT NULL DEFAULT 'one_checkin'
                           CHECK (luggage_preference IN ('cabin','one_checkin','two_checkin','heavy')),
  accessibility_needs      TEXT,
  language                 TEXT NOT NULL DEFAULT 'en',
  quiet_ride               INTEGER NOT NULL DEFAULT 0,
  emergency_contact_name   TEXT,
  emergency_contact_phone  TEXT,
  rating_avg               REAL NOT NULL DEFAULT 0,
  rating_count             INTEGER NOT NULL DEFAULT 0,
  created_at               TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at               TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS driver_profiles (
  id                   TEXT PRIMARY KEY,
  user_id              TEXT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  company_name         TEXT,
  license_number       TEXT,
  verification_status  TEXT NOT NULL DEFAULT 'pending'
                       CHECK (verification_status IN ('pending','in_review','verified','rejected','expired')),
  verification_notes   TEXT,
  verified_at          TEXT,
  rating_avg           REAL NOT NULL DEFAULT 0,
  rating_count         INTEGER NOT NULL DEFAULT 0,
  is_available         INTEGER NOT NULL DEFAULT 0,
  created_at           TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at           TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_driver_status ON driver_profiles(verification_status);

CREATE TABLE IF NOT EXISTS vehicles (
  id                  TEXT PRIMARY KEY,
  driver_id           TEXT NOT NULL REFERENCES driver_profiles(id) ON DELETE CASCADE,
  category            TEXT NOT NULL CHECK (category IN ('sedan','suv','mpv')),
  make_model          TEXT NOT NULL,
  registration_number TEXT NOT NULL UNIQUE,
  seats               INTEGER NOT NULL CHECK (seats BETWEEN 2 AND 8),
  luggage_units       INTEGER NOT NULL CHECK (luggage_units BETWEEN 1 AND 12),
  verification_status TEXT NOT NULL DEFAULT 'pending'
                      CHECK (verification_status IN ('pending','verified','rejected')),
  is_active           INTEGER NOT NULL DEFAULT 1,
  created_at          TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_vehicles_driver ON vehicles(driver_id);

-- ── Flights and verification ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS flights (
  id                TEXT PRIMARY KEY,
  airport_id        TEXT NOT NULL REFERENCES airports(id),
  airline_code      TEXT NOT NULL,
  airline_name      TEXT NOT NULL,
  flight_number     TEXT NOT NULL,             -- normalised, e.g. AI864
  origin_city       TEXT NOT NULL,
  flight_date       TEXT NOT NULL,             -- yyyy-mm-dd (IST)
  terminal          TEXT,
  scheduled_arrival TEXT NOT NULL,
  estimated_arrival TEXT NOT NULL,
  status            TEXT NOT NULL DEFAULT 'scheduled'
                    CHECK (status IN ('scheduled','enroute','landed','delayed','cancelled')),
  source            TEXT NOT NULL DEFAULT 'demo'
                    CHECK (source IN ('demo','provider','manual')),
  created_at        TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at        TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (airport_id, flight_number, flight_date)
);
CREATE INDEX IF NOT EXISTS idx_flights_lookup ON flights(airport_id, flight_date, flight_number);

CREATE TABLE IF NOT EXISTS flight_verifications (
  id                TEXT PRIMARY KEY,
  user_id           TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  flight_id         TEXT NOT NULL REFERENCES flights(id) ON DELETE CASCADE,
  method            TEXT NOT NULL DEFAULT 'booking_reference'
                    CHECK (method IN ('booking_reference','provider_api','document','manual')),
  status            TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','verified','rejected','expired')),
  reference_masked  TEXT,                      -- only last 2 chars retained
  reference_hash    TEXT,                      -- sha256, never the raw reference
  provider          TEXT NOT NULL DEFAULT 'demo',
  reviewed_by       TEXT REFERENCES users(id),
  notes             TEXT,
  verified_at       TEXT,
  created_at        TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (user_id, flight_id)
);
CREATE INDEX IF NOT EXISTS idx_flight_verif_status ON flight_verifications(status);

-- ── Ride groups ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ride_groups (
  id                 TEXT PRIMARY KEY,
  code               TEXT NOT NULL UNIQUE,     -- human reference, e.g. FS-864-THA
  flight_id          TEXT NOT NULL REFERENCES flights(id),
  created_by_user_id TEXT NOT NULL REFERENCES users(id),
  destination_id     TEXT NOT NULL REFERENCES destinations(id),
  vehicle_category   TEXT NOT NULL CHECK (vehicle_category IN ('sedan','suv','mpv')),
  fare_strategy      TEXT NOT NULL DEFAULT 'hybrid' CHECK (fare_strategy IN ('equal','distance','hybrid')),
  seats_total        INTEGER NOT NULL CHECK (seats_total BETWEEN 1 AND 6),
  seats_taken        INTEGER NOT NULL DEFAULT 0 CHECK (seats_taken >= 0),
  luggage_total      INTEGER NOT NULL DEFAULT 4,
  luggage_taken      INTEGER NOT NULL DEFAULT 0,
  meet_point         TEXT,
  departure_window_start TEXT,
  departure_window_end   TEXT,
  max_wait_minutes   INTEGER NOT NULL DEFAULT 45,
  status             TEXT NOT NULL DEFAULT 'open'
                     CHECK (status IN ('draft','open','full','confirmed','in_progress','completed','cancelled','expired')),
  driver_id          TEXT REFERENCES driver_profiles(id),
  vehicle_id         TEXT REFERENCES vehicles(id),
  fare_estimate_id   TEXT,
  is_demo_origin     INTEGER NOT NULL DEFAULT 0,
  created_at         TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at         TEXT NOT NULL DEFAULT (datetime('now')),
  -- database-level overbooking guard
  CHECK (seats_taken <= seats_total),
  CHECK (luggage_taken <= luggage_total)
);
CREATE INDEX IF NOT EXISTS idx_ride_groups_flight ON ride_groups(flight_id, status);
CREATE INDEX IF NOT EXISTS idx_ride_groups_status ON ride_groups(status, departure_window_start);

CREATE TABLE IF NOT EXISTS ride_members (
  id               TEXT PRIMARY KEY,
  ride_group_id    TEXT NOT NULL REFERENCES ride_groups(id) ON DELETE CASCADE,
  user_id          TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  join_request_id  TEXT,
  seat_count       INTEGER NOT NULL DEFAULT 1 CHECK (seat_count BETWEEN 1 AND 6),
  luggage_units    INTEGER NOT NULL DEFAULT 1,
  destination_id   TEXT NOT NULL REFERENCES destinations(id),
  readiness        TEXT NOT NULL DEFAULT 'not_landed'
                   CHECK (readiness IN ('not_landed','landed','collecting_baggage','ready_at_meeting_point','boarding_vehicle','trip_started')),
  expected_ready_at TEXT,
  readiness_updated_at TEXT,
  status           TEXT NOT NULL DEFAULT 'accepted'
                   CHECK (status IN ('invited','accepted','removed','left','no_show')),
  role             TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('owner','member')),
  joined_at        TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (ride_group_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_ride_members_user ON ride_members(user_id, status);
CREATE INDEX IF NOT EXISTS idx_ride_members_group ON ride_members(ride_group_id, status);

CREATE TABLE IF NOT EXISTS join_requests (
  id              TEXT PRIMARY KEY,
  ride_group_id   TEXT NOT NULL REFERENCES ride_groups(id) ON DELETE CASCADE,
  user_id         TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  passenger_count INTEGER NOT NULL CHECK (passenger_count BETWEEN 1 AND 6),
  luggage_units   INTEGER NOT NULL DEFAULT 1,
  destination_id  TEXT NOT NULL REFERENCES destinations(id),
  message         TEXT,
  match_score     INTEGER,
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','approved','declined','withdrawn','expired')),
  decided_by      TEXT REFERENCES users(id),
  decided_at      TEXT,
  decision_note   TEXT,
  created_at      TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (ride_group_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_join_requests_group ON join_requests(ride_group_id, status);
CREATE INDEX IF NOT EXISTS idx_join_requests_user ON join_requests(user_id, status);

-- ── Fares, bookings, payments ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fare_estimates (
  id                 TEXT PRIMARY KEY,
  ride_group_id      TEXT REFERENCES ride_groups(id) ON DELETE CASCADE,
  strategy           TEXT NOT NULL,
  vehicle_category   TEXT NOT NULL,
  breakdown_json     TEXT NOT NULL,            -- full FrozenBreakdown
  total_paise        INTEGER NOT NULL,
  vehicle_fare_paise INTEGER NOT NULL,
  fee_paise          INTEGER NOT NULL,
  tax_paise          INTEGER NOT NULL,
  solo_total_paise   INTEGER NOT NULL,
  savings_paise      INTEGER NOT NULL,
  expires_at         TEXT NOT NULL,
  created_at         TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_fare_estimates_group ON fare_estimates(ride_group_id, created_at DESC);

CREATE TABLE IF NOT EXISTS fare_allocations (
  id                TEXT PRIMARY KEY,
  fare_estimate_id  TEXT NOT NULL REFERENCES fare_estimates(id) ON DELETE CASCADE,
  ride_group_id     TEXT NOT NULL REFERENCES ride_groups(id) ON DELETE CASCADE,
  user_id           TEXT REFERENCES users(id) ON DELETE SET NULL,
  destination_id    TEXT NOT NULL,
  distance_km       REAL NOT NULL,
  weight            REAL NOT NULL,
  vehicle_share_paise INTEGER NOT NULL,
  fee_paise         INTEGER NOT NULL,
  tax_paise         INTEGER NOT NULL,
  contribution_paise INTEGER NOT NULL,
  solo_fare_paise   INTEGER NOT NULL,
  savings_paise     INTEGER NOT NULL,
  savings_pct       REAL NOT NULL,
  created_at        TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_fare_allocations_estimate ON fare_allocations(fare_estimate_id);

CREATE TABLE IF NOT EXISTS bookings (
  id               TEXT PRIMARY KEY,
  code             TEXT NOT NULL UNIQUE,
  ride_group_id    TEXT NOT NULL REFERENCES ride_groups(id),
  user_id          TEXT NOT NULL REFERENCES users(id),
  fare_estimate_id TEXT REFERENCES fare_estimates(id),
  status           TEXT NOT NULL DEFAULT 'pending'
                   CHECK (status IN ('pending','confirmed','cancelled','completed','no_show')),
  payment_status   TEXT NOT NULL DEFAULT 'unpaid'
                   CHECK (payment_status IN ('unpaid','authorised','captured','refund_pending','refunded','failed')),
  amount_paise     INTEGER NOT NULL DEFAULT 0,
  currency         TEXT NOT NULL DEFAULT 'INR',
  confirmed_at     TEXT,
  cancelled_at     TEXT,
  cancel_reason    TEXT,
  created_at       TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (ride_group_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_bookings_user ON bookings(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS payment_records (
  id                  TEXT PRIMARY KEY,
  booking_id          TEXT NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  provider            TEXT NOT NULL DEFAULT 'demo' CHECK (provider IN ('demo','razorpay','stripe')),
  provider_order_id   TEXT,
  provider_payment_id TEXT,
  amount_paise        INTEGER NOT NULL,
  currency            TEXT NOT NULL DEFAULT 'INR',
  status              TEXT NOT NULL DEFAULT 'created'
                      CHECK (status IN ('created','authorised','captured','failed','refunded')),
  method              TEXT,
  idempotency_key     TEXT UNIQUE,
  provider_event_id   TEXT UNIQUE,             -- webhook de-duplication
  failure_reason      TEXT,
  captured_at         TEXT,
  created_at          TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at          TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_payments_booking ON payment_records(booking_id);

CREATE TABLE IF NOT EXISTS refunds (
  id              TEXT PRIMARY KEY,
  payment_id      TEXT NOT NULL REFERENCES payment_records(id) ON DELETE CASCADE,
  amount_paise    INTEGER NOT NULL,
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','processing','processed','failed')),
  reason          TEXT,
  requested_by    TEXT REFERENCES users(id),
  approved_by     TEXT REFERENCES users(id),
  provider_refund_id TEXT,
  processed_at    TEXT,
  created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS driver_earnings (
  id              TEXT PRIMARY KEY,
  driver_id       TEXT NOT NULL REFERENCES driver_profiles(id) ON DELETE CASCADE,
  ride_group_id   TEXT REFERENCES ride_groups(id),
  booking_id      TEXT REFERENCES bookings(id),
  gross_paise     INTEGER NOT NULL,
  commission_paise INTEGER NOT NULL,
  deductions_paise INTEGER NOT NULL DEFAULT 0,
  net_paise       INTEGER NOT NULL,
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','processing','paid','failed')),
  payout_reference TEXT,
  period          TEXT,
  created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_earnings_driver ON driver_earnings(driver_id, created_at DESC);

-- ── Operational events ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ride_status_events (
  id            TEXT PRIMARY KEY,
  ride_group_id TEXT NOT NULL REFERENCES ride_groups(id) ON DELETE CASCADE,
  actor_user_id TEXT REFERENCES users(id),
  type          TEXT NOT NULL,
  from_status   TEXT,
  to_status     TEXT,
  payload_json  TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ride_events_group ON ride_status_events(ride_group_id, created_at DESC);

CREATE TABLE IF NOT EXISTS conversations (
  id            TEXT PRIMARY KEY,
  ride_group_id TEXT NOT NULL UNIQUE REFERENCES ride_groups(id) ON DELETE CASCADE,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS messages (
  id              TEXT PRIMARY KEY,
  conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_user_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body            TEXT NOT NULL,
  kind            TEXT NOT NULL DEFAULT 'text'
                  CHECK (kind IN ('text','system','meeting_point','readiness','fare_update','driver_assigned')),
  created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id, created_at);

CREATE TABLE IF NOT EXISTS message_reads (
  message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  read_at    TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (message_id, user_id)
);

CREATE TABLE IF NOT EXISTS notifications (
  id            TEXT PRIMARY KEY,
  user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type          TEXT NOT NULL,
  title         TEXT NOT NULL,
  body          TEXT NOT NULL,
  ride_group_id TEXT REFERENCES ride_groups(id) ON DELETE CASCADE,
  href          TEXT,
  is_demo       INTEGER NOT NULL DEFAULT 0,
  read_at       TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, read_at, created_at DESC);

CREATE TABLE IF NOT EXISTS reviews (
  id              TEXT PRIMARY KEY,
  ride_group_id   TEXT NOT NULL REFERENCES ride_groups(id) ON DELETE CASCADE,
  author_user_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_user_id TEXT REFERENCES users(id),
  role_subject    TEXT NOT NULL DEFAULT 'passenger' CHECK (role_subject IN ('passenger','driver')),
  rating          INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment         TEXT,
  created_at      TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (ride_group_id, author_user_id, subject_user_id)
);

CREATE TABLE IF NOT EXISTS reports (
  id               TEXT PRIMARY KEY,
  reporter_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_user_id  TEXT REFERENCES users(id),
  ride_group_id    TEXT REFERENCES ride_groups(id) ON DELETE SET NULL,
  category         TEXT NOT NULL,
  details          TEXT NOT NULL,
  status           TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','reviewing','resolved','dismissed')),
  priority         TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('low','normal','high','urgent')),
  resolution       TEXT,
  resolved_at      TEXT,
  created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS support_tickets (
  id            TEXT PRIMARY KEY,
  user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  ride_group_id TEXT REFERENCES ride_groups(id) ON DELETE SET NULL,
  subject       TEXT NOT NULL,
  category      TEXT NOT NULL,
  body          TEXT NOT NULL,
  status        TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','in_progress','waiting','resolved','closed')),
  priority      TEXT NOT NULL DEFAULT 'normal',
  assigned_to   TEXT REFERENCES users(id),
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS pricing_rules (
  key         TEXT PRIMARY KEY,
  value_json  TEXT NOT NULL,
  description TEXT,
  updated_by  TEXT REFERENCES users(id),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id            TEXT PRIMARY KEY,
  actor_user_id TEXT REFERENCES users(id),
  actor_role    TEXT,
  action        TEXT NOT NULL,
  entity_type   TEXT NOT NULL,
  entity_id     TEXT,
  before_json   TEXT,
  after_json    TEXT,
  ip_hash       TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_logs(actor_user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS analytics_events (
  id            TEXT PRIMARY KEY,
  user_id       TEXT REFERENCES users(id) ON DELETE SET NULL,
  session_id    TEXT,
  name          TEXT NOT NULL,
  props_json    TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_analytics_name ON analytics_events(name, created_at DESC);

CREATE TABLE IF NOT EXISTS rate_limits (
  key          TEXT PRIMARY KEY,
  count        INTEGER NOT NULL DEFAULT 0,
  window_start TEXT NOT NULL
);
