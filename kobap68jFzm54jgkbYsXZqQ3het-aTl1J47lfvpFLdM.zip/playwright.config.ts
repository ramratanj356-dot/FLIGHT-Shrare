import { defineConfig, devices } from "@playwright/test";

/**
 * End-to-end specs run against a real server. Locally:
 *   npm run dev            # in one terminal
 *   npm run test:e2e       # in another
 * In CI the webServer block boots a production build automatically.
 */
const PORT = Number(process.env.E2E_PORT ?? 3100);
const reuse = process.env.E2E_REUSE_SERVER === "1";

export default defineConfig({
  testDir: "./tests/e2e",
  timeout: 90_000,
  expect: { timeout: 15_000 },
  fullyParallel: false,
  workers: 1,
  retries: process.env.CI ? 1 : 0,
  reporter: process.env.CI ? [["dot"]] : [["list"]],
  globalSetup: "./tests/e2e/global-setup.ts",
  use: {
    baseURL: process.env.E2E_BASE_URL ?? `http://localhost:${PORT}`,
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    viewport: { width: 1440, height: 950 },
  },
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
  webServer: reuse
    ? undefined
    : {
        command: `npm run build && npm start -- -p ${PORT}`,
        url: `http://localhost:${PORT}/api/health`,
        timeout: 240_000,
        reuseExistingServer: true,
      },
});
