import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        navy: { DEFAULT: "#101828", 900: "#101828", 800: "#182230", 700: "#344054" },
        ink: { DEFAULT: "#182230", soft: "#475467", muted: "#667085" },
        indigo: { DEFAULT: "#5145FF", 50: "#F0EEFF", 100: "#E4E0FF", 200: "#CFC8FF", 600: "#5145FF", 700: "#4034E0" },
        lavender: { DEFAULT: "#F0EEFF", 50: "#F7F6FF" },
        canvas: "#F7F8FC",
        success: { DEFAULT: "#16A36A", soft: "#E7F7EF", dark: "#0E7A4E" },
        amber: { DEFAULT: "#F4B740", soft: "#FFF6E3", dark: "#8A5A00" },
        danger: { DEFAULT: "#D92D20", soft: "#FEF3F2" },
        line: "#E4E7EC",
      },
      fontFamily: {
        sans: ["var(--font-inter)", "Inter", "system-ui", "sans-serif"],
        display: ["var(--font-inter)", "Inter", "system-ui", "sans-serif"],
      },
      fontSize: {
        "display-xl": ["clamp(2.5rem,6vw,4.25rem)", { lineHeight: "1.03", letterSpacing: "-0.035em", fontWeight: "700" }],
        "display-lg": ["clamp(2rem,4.4vw,3rem)", { lineHeight: "1.08", letterSpacing: "-0.03em", fontWeight: "700" }],
        "display-md": ["clamp(1.6rem,3vw,2.15rem)", { lineHeight: "1.15", letterSpacing: "-0.025em", fontWeight: "700" }],
        h4: ["1.125rem", { lineHeight: "1.4", letterSpacing: "-0.01em", fontWeight: "600" }],
      },
      borderRadius: { xl: "0.875rem", "2xl": "1.125rem", "3xl": "1.5rem", "4xl": "2rem" },
      boxShadow: {
        card: "0 1px 2px rgba(16,24,40,0.04), 0 12px 32px -16px rgba(16,24,40,0.18)",
        lift: "0 2px 4px rgba(16,24,40,0.03), 0 24px 48px -24px rgba(16,24,40,0.28)",
        focus: "0 0 0 4px rgba(81,69,255,0.16)",
        inset: "inset 0 1px 0 rgba(255,255,255,0.6)",
      },
      backgroundImage: {
        "grid-faint":
          "linear-gradient(to right, rgba(228,231,236,0.7) 1px, transparent 1px), linear-gradient(to bottom, rgba(228,231,236,0.7) 1px, transparent 1px)",
      },
      keyframes: {
        "fade-up": { "0%": { opacity: "0", transform: "translateY(10px)" }, "100%": { opacity: "1", transform: "translateY(0)" } },
        float: { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-7px)" } },
        "pulse-ring": { "0%": { transform: "scale(0.85)", opacity: "0.6" }, "80%,100%": { transform: "scale(1.9)", opacity: "0" } },
        dash: { to: { strokeDashoffset: "-240" } },
        shimmer: { "100%": { transform: "translateX(100%)" } },
        "slide-in": { "0%": { opacity: "0", transform: "translateY(8px) scale(0.99)" }, "100%": { opacity: "1", transform: "translateY(0) scale(1)" } },
        "grow-x": { "0%": { transform: "scaleX(0)" }, "100%": { transform: "scaleX(1)" } },
      },
      animation: {
        "fade-up": "fade-up 0.5s cubic-bezier(0.16,1,0.3,1) both",
        float: "float 6s ease-in-out infinite",
        "pulse-ring": "pulse-ring 2.4s cubic-bezier(0.24,0,0.38,1) infinite",
        dash: "dash 6s linear infinite",
        shimmer: "shimmer 1.6s infinite",
        "slide-in": "slide-in 0.35s cubic-bezier(0.16,1,0.3,1) both",
      },
    },
  },
  plugins: [],
};
export default config;
