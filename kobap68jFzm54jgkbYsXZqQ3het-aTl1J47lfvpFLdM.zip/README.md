# FlightShare

**Same Flight. Same Direction. One Shared Ride.**

FlightShare is a working, production-oriented prototype of a smart airport cab-pooling product for
Mumbai (BOM). Passengers arriving on the *same flight* and heading the *same way* are matched into a
single shared vehicle, with flight-verified eligibility, a transparent fare split, an agreed waiting
window and a driver/fleet + admin back office.

It is a real application — server-rendered Next.js pages, a relational database, authenticated
sessions, transactional writes and documented APIs — not a landing page mock-up. Every external
dependency that is not configured says so, in the UI and in `/api/health`.

> **Prototype disclosure.** Flights, passengers, drivers, verification outcomes, fares, messages and
> earnings in the default deployment are **seeded demo data**, labelled `DEMO` / `SAMPLE DATA`.
> No payments are processed, no transport is dispatched and no airline system is contacted. See
> [Known limitations](#9-known-limitations--next-steps) and the in-app `/legal/terms` and
> `/legal/privacy` pages (drafts, not legally reviewed).

---

## 1. What it is & what's implemented

### Passenger

| Area | Implemented |
|---|---|
| Marketing site | Landing page with interactive hero, fare comparison (₹1,200 solo / ₹400 shared / ₹800 saved — labelled example), flight search widget, 4-step how-it-works, savings calculator, popular destinations, sample journey, safety model, FAQ, driver signup, footer |
| Search & matching | `/search` (flight + date + destination + pax + luggage) → `/rides` with 0–100 scored match cards, transparent component scores, hard blockers, "View ride" / "Request to join" |
| Ride detail | `/rides/[id]` — route map, members, readiness board, fare breakdown, meeting point, waiting window, verification badges |
| Join flow | `/rides/[id]/join` — review, destination/luggage selection, optional booking reference, explicit "no charge now" confirmation dialog, success state |
| Auth | Email register/login, password reset, email verification (dev links surfaced when mail is unconfigured), Google button only enabled when OAuth is configured, demo one-click accounts, session management, logout |
| Dashboard `/app` | Trip stats, pending join requests, upcoming/past trips, notifications, trust profile |
| Trips `/app/trips`, `/app/trips/[id]` | Live trip detail: coordinator controls (approve/decline, departure, cancel, final breakdown), readiness updates, group chat, fare + payment panel, activity timeline |
| New ride `/app/rides/new` | Create a group with vehicle category, max wait, fare strategy, passengers, luggage |
| Messages `/app/messages`, `/app/messages/[id]` | Ride-scoped chat, polling for new messages, read receipts, report message dialog |
| Notifications `/app/notifications` | In-app centre with read/unread state, demo labelling, deep links |
| Profile `/app/profile` | Name, phone, home destination, luggage preference, accessibility, language, quiet ride, emergency contact, identity status, session + audit history, verification resend |

### Driver / fleet portal (`/driver`)

Registration and document review status, eligible ride requests with passenger/luggage/drop-off
detail, accept (server-verified), arrival → start → complete trip controls, earnings dashboard
(gross, commission, deductions, net, payout status) and verification submission.

### Admin console (`/admin`)

Platform metrics (users, active groups, completed rides, avg passengers/ride, estimated savings,
revenue, driver earnings, cancellation rate), verification reviews (flight + driver) with audited
decisions, ride-group monitoring, user management with suspension, pricing & commission
configuration applied live to the engine, support tickets, safety reports, refund reviews, audit log.

### Platform capabilities

- **Matchmaking engine** — 0–100 score across flight, destination, timing, capacity, route, trust and
  luggage, with configurable weights, human-readable reasons and hard blockers.
- **Fare engine** — vehicle fare, extra stops, tolls/parking, service fee, tax, three allocation
  strategies (equal / distance / hybrid), integer paise, rupee-granularity settlement, remainder
  distribution, savings calculation.
- **Departure coordination** — six readiness states, agreed waiting window, meeting point, event
  timeline, auto-expiry rules, no auto-booking on landing.
- **Chat & notifications** — participant-restricted group chat, polling transport, reporting,
  notification centre.
- **Payments architecture** — server-side order creation, signature verification, idempotent
  webhooks, refund workflow, status vocabulary (estimated → authorised → captured → refund pending →
  refunded). In demo mode no gateway is active.
- **Security** — scrypt password hashing, HttpOnly sessions with server-side revocation, per-action
  rate limits, zod validation on every mutating route, same-origin enforcement, server-side RBAC,
  audit logging, masked/hashed booking references, data minimisation.
- **Responsive & accessible** — mobile bottom navigation, desktop section nav, keyboard-usable
  dialogs and menus, labelled controls, `aria-*` state, focus rings, semantic headings.

---

## 2. Tech stack

| Layer | Choice | Notes |
|---|---|---|
| Framework | **Next.js 15.5.28 (App Router)** + RSC | Server components for data, client components for interaction |
| UI | **React 19.1**, **TypeScript 5.7 (strict)** | No `any` in application code paths |
| Styling | **Tailwind CSS 3.4.17** + design tokens | Hand-rolled shadcn-style primitives (button, input, dialog, toast, badge, avatar, score ring) |
| Icons | **lucide-react** | Single icon set, no icon fonts |
| Fonts | **Inter** (self-hosted WOFF2) | No runtime CDN dependency |
| Forms | **react-hook-form** + **zod** | Shared schemas between client and server |
| Data | **SQLite (better-sqlite3)** behind a repository layer | `db/schema.postgres.sql` targets PostgreSQL/Supabase |
| Auth | Custom scrypt + HttpOnly session cookies | Google OAuth path ready behind config |
| Money | Integer paise throughout | `src/lib/money.ts` — no float arithmetic |
| Tests | **Vitest** (unit + DB integration) | 59 tests across fares, matching, money, validation, DB constraints |
| Deployment target | **Vercel** + managed Postgres | See §7 |

Deliberately avoided: Tailwind 4, zod 4, Next 16 (stability of the pinned versions), any state
manager, any CSS-in-JS runtime.

---

## 3. Folder structure

```
flightshare/
├── db/
│   ├── schema.sql              # 32-table SQLite schema (running prototype)
│   └── schema.postgres.sql     # PostgreSQL/Supabase mirror: enums, indexes, RLS
├── data/flightshare.db         # demo database (created by npm run db:reset)
├── public/fonts/               # self-hosted Inter WOFF2
├── scripts/
│   ├── reset-db.ts             # drop + rebuild + seed
│   └── seed.ts                 # idempotent top-up
├── src/
│   ├── app/
│   │   ├── page.tsx            # landing page
│   │   ├── search/             # flight search
│   │   ├── rides/              # results, ride detail, join flow (+ layout with header/footer)
│   │   ├── (auth)/             # login, signup, forgot/reset password, verify email
│   │   ├── app/                # passenger dashboard, trips, messages, notifications, profile, new ride
│   │   ├── driver/             # driver portal
│   │   ├── admin/              # admin console
│   │   ├── api/                # route handlers (auth, rides, join, messages, payments, admin, driver…)
│   │   ├── how-it-works/ destinations/ safety/ partners/ help/ status/ legal/
│   │   └── globals.css
│   ├── components/
│   │   ├── ui/                 # primitives: button, dialog, toast, badge, avatar, field…
│   │   ├── brand/              # logo, schematic map (auto-fitting route renderer)
│   │   ├── marketing/          # header, footer, hero, sections, savings calculator
│   │   ├── forms/              # search, auth, join, profile, create-ride, support, driver…
│   │   └── app/                # shell, match card, trip card, chat, readiness, fare breakdown…
│   ├── lib/
│   │   ├── db/                 # connection, queries (repository), pricing rules
│   │   ├── auth/               # session, password, guards
│   │   ├── services/           # rides, chat, payments, driver, admin, audit, auth
│   │   ├── match/              # scoring, geo compatibility, timing
│   │   ├── fares/              # engine, group allocation, calculator
│   │   ├── config/             # pricing constants, feature/integration flags
│   │   ├── validation/         # zod schemas shared by client + server
│   │   ├── security/           # rate limiting, HTTP helpers
│   │   ├── demo/               # fixtures + seed
│   │   ├── money.ts            # paise arithmetic, allocation, formatting
│   │   └── utils.ts            # dates (IST), formatting, cn()
│   └── middleware.ts           # cookie-presence gate for /app, /driver, /admin
├── tests/                      # vitest: money, fares, matching, validation, DB constraints
│   └── e2e/                    # playwright: global-setup (role sessions) + critical-journey spec
├── vitest.config.ts
├── playwright.config.ts
└── .env.example
```

---

## 4. Database schema & setup

32 tables, referential integrity, CHECK constraints and integer paise everywhere.

**Identity** `users`, `sessions`, `password_resets`, `email_verifications`,
`passenger_profiles`, `driver_profiles`, `vehicles`
**Catalogue** `airports`, `destinations`, `pricing_rules`
**Flights** `flights`, `flight_verifications`
**Rides** `ride_groups`, `ride_members`, `join_requests`, `ride_status_events`
**Fares** `fare_estimates`, `fare_allocations`
**Money** `bookings`, `payment_records`, `refunds`, `driver_earnings`
**Communication** `conversations`, `messages`, `message_reads`, `notifications`
**Trust & ops** `reviews`, `reports`, `support_tickets`, `audit_logs`, `analytics_events`,
`rate_limits`

Key invariants enforced by the database, not just the UI:

```sql
-- overbooking guard
CHECK (seats_taken <= seats_total)
CHECK (luggage_taken <= luggage_total)

-- one booking and one membership per passenger per group
UNIQUE (ride_group_id, user_id)     -- bookings, ride_members, join_requests

-- no duplicate provider events (webhook idempotency)
UNIQUE (provider, provider_event_id) WHERE provider_event_id IS NOT NULL
```

Ride approval runs the capacity claim as a single conditional write inside a transaction, so two
simultaneous approvals cannot both take the last seat:

```sql
UPDATE ride_groups
   SET seats_taken = seats_taken + ?, luggage_taken = luggage_taken + ?
 WHERE id = ?
   AND seats_taken + ? <= seats_total
   AND luggage_taken + ? <= luggage_total;
-- changes === 0  →  409 "This ride filled up before the request was approved."
```

### Local database

```bash
npm run db:reset     # drop, recreate from db/schema.sql, seed demo data
npm run seed         # idempotent top-up (safe to re-run)
```

Seeded: 17 users (14 passengers, 2 drivers, 1 admin), 8 aircraft schedules across 15 days,
~185 ride groups, 4 completed historical trips with earnings and reviews, join requests,
verifications, reports, tickets, refund, audit logs and notifications.

### PostgreSQL / Supabase

```bash
psql "$DATABASE_URL" -f db/schema.postgres.sql
```

The Postgres file mirrors the SQLite schema with native enums, `timestamptz`, `jsonb`, partial
indexes and Row Level Security policies (skipped automatically when `auth.uid()` is absent). The
repository layer in `src/lib/db/queries.ts` is the only place that talks SQL — porting means
replacing `better-sqlite3` with `pg`/`@supabase/supabase-js` for those ~600 lines, not rewriting
pages.

---

## 5. Environment variables

Copy `.env.example` to `.env.local`. **Every variable is optional** — the app boots in demo mode
with none of them set.

```ini
# Core
AUTH_SECRET=                     # signs session cookies (generate: openssl rand -hex 32)
APP_URL=http://localhost:3000    # used in emails/links and same-origin checks
DATABASE_PATH=./data/flightshare.db   # SQLite file (prototype)

# Postgres target (deployment)
DATABASE_URL=postgres://…

# Flights
FLIGHT_API_PROVIDER=             # e.g. aviationstack | amadeus
FLIGHT_API_KEY=
FLIGHT_API_BASE_URL=

# Maps
NEXT_PUBLIC_MAPBOX_TOKEN=

# Payments (Razorpay)
RAZORPAY_KEY_ID=
RAZORPAY_KEY_SECRET=
RAZORPAY_WEBHOOK_SECRET=
NEXT_PUBLIC_RAZORPAY_KEY_ID=

# Identity verification
VERIFICATION_PROVIDER=
VERIFICATION_API_KEY=

# Google OAuth
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=

# Email / SMS
EMAIL_PROVIDER=
EMAIL_API_KEY=
EMAIL_FROM=
SMS_PROVIDER=
SMS_API_KEY=
```

`GET /api/health` returns the live configuration state, and `/status` renders it for humans.

---

## 6. Run locally

```bash
npm install
cp .env.example .env.local     # optional
npm run db:reset               # create + seed the demo database
npm run dev                    # http://localhost:3000
```

Other scripts:

```bash
npm run build     # production build (stop the dev server first — both share .next/)
npm start         # serve the production build
npm run test      # vitest unit + DB integration tests
npm run test:e2e  # playwright: 11 critical-journey specs (see §12)
npm run seed      # top up demo data
```

### Demo accounts

| Role | Email | Password |
|---|---|---|
| Passenger (coordinator) | `aarav@demo.flightshare.app` | `Demo@1234` |
| Passenger | `priya@demo.flightshare.app` … `nikita@demo.flightshare.app` | `Demo@1234` |
| Driver (verified) | `driver@demo.flightshare.app` | `Driver@1234` |
| Driver (in review) | `suresh.driver@demo.flightshare.app` | `Driver@1234` |
| Admin | `admin@demo.flightshare.app` | `Admin@1234` |

The sign-in screen has one-click quick-fill buttons for all three roles.

### A five-minute walkthrough

1. **Landing page** → "Find My Ride" (pre-filled `AI864`, today).
2. **Results** → an SUV group to Thane West scores highest; open a match to see the component scores.
3. **Ride detail** → ₹1,144 total across three passengers (₹392 / ₹392 / ₹360) versus ₹3,280 in solo
   cabs. Every line itemised; footer states it is an estimate.
4. **Request to join** → the confirmation dialog states nothing is charged; submit and you land on
   the trip page with a pending-request banner.
5. **Sign in as `aarav@…`** → approve the pending request from the dashboard, adjust readiness, open
   the group chat, then mark the trip departed.
6. **Sign in as `driver@…`** → accept an eligible request, arrive → start → complete, and check the
   earnings ledger.
7. **Sign in as `admin@…`** → review a verification, change the platform fee, resolve a report,
   inspect the audit log.

---

## 7. Deployment

**Vercel + managed Postgres (Supabase/Neon).**

1. Provision Postgres and apply `db/schema.postgres.sql`; seed reference data (`airports`,
   `destinations`, `pricing_rules`).
2. Set the environment variables from §5 in Vercel (at minimum `AUTH_SECRET`, `APP_URL`,
   `DATABASE_URL`).
3. Replace the SQLite adapter with the Postgres adapter in `src/lib/db/index.ts` (the query layer is
   already parameterised; SQLite-specific `datetime('now')` defaults become `now()` in the schema).
4. `npm run build` — the app is fully static-optimised where possible; authenticated routes are
   dynamic by design.
5. Configure the Razorpay webhook to `POST /api/payments/webhook` and set
   `RAZORPAY_WEBHOOK_SECRET`. The handler returns `503` when the secret is absent and `401` on a bad
   signature, and deduplicates by `provider_event_id`.
6. Enable Supabase RLS policies (they ship in the schema file) before exposing any anon key to the
   browser.
7. Put the app behind HTTPS; session cookies are `Secure` in production.

Scaling notes: the polling transport (`/api/rides/[id]/state`, 6 s) is intentionally simple; swap in
Supabase Realtime or a WebSocket worker for live chat at scale. Rate limiting uses a table fallback;
move to Redis/Upstash for multi-region.

---

## 8. Integrations that are not configured

Nothing below is claimed to work. Each row is reported truthfully by `/status` and `/api/health`.

| Integration | Current mode | What the app does instead |
|---|---|---|
| Flight data provider | demo | Seeded schedule for BOM (15-day window); `SAMPLE DATA` badges |
| Booking-reference verification | simulated | Outcome generated locally and labelled simulated; reference stored masked + hashed |
| Map tiles & routing | demo | Hand-drawn schematic map with curated coordinates and haversine distances |
| Razorpay payments | demo | Orders are simulated (`demo_order_*`); no card data, nothing charged |
| Google OAuth | demo | Button disabled with an explanation tooltip |
| Transactional email | demo | Verification/reset links are surfaced in-app (dev) instead of sent |
| SMS / WhatsApp | not configured | Notification centre only |
| Identity (KYC) provider | simulated | Admin review workflow + status badge |
| Realtime | polling | 6 s polling confined to ride participants |

---

## 9. Known limitations & next steps

**Limitations**

- Demo data only: no live flight status, no real passengers, no dispatch, no money movement.
- Verification is simulated; the driver workflow is a document *review*, not a background or statutory
  check.
- The map is illustrative — distances are curated, not routed. No live vehicle GPS.
- Payments are implemented behind an interface but never exercised against a real gateway; refunds
  and payouts are ledger records only.
- SQLite (single writer) is fine for a prototype and wrong for production — port to Postgres before
  any real traffic.
- Email/SMS are stubbed; password reset and verification depend on links shown in-app.
- Playwright specs are not yet written; Vitest covers money, fares, matching, validation and the
  overbooking constraint (59 tests).
- Accessibility: keyboard paths and labels are implemented, but there has been no formal WCAG 2.2 AA
  audit or screen-reader matrix run.

**Before launch (India)**

- Legal review of pooling legality under state transport rules, aggregator licensing, permit and
  insurance requirements.
- DPDP Act 2023 privacy notice, grievance officer, consent records; replace the draft `/legal/*`
  pages.
- GST treatment of the platform fee; invoicing; merchant onboarding for payouts.
- Insurance covering commercial passenger carriage; driver onboarding with document authenticity
  checks.

**Next steps**

1. Postgres port + migrations (Prisma/Drizzle or plain SQL) and RLS verification.
2. Flight-data provider adapter and a verification service with a manual-review fallback queue.
3. Razorpay end-to-end in test mode, including webhook replay tests and settlement reports.
4. Realtime transport for chat/readiness; push notifications.
5. Playwright journeys: search → match → join → approve → pay → complete → rate, plus role
   separation and the overbooking race.
6. Fare fairness experiments (per-corridor distance weighting) and driver supply incentives.
7. Fraud detection on booking references and repeated no-shows.

---

## 10. Business model (modelled, not live)

- **Service fee per completed ride** — 8% of the vehicle fare, minimum ₹25, plus 18% GST on the fee
  (configurable in the admin console; surfaced as a separate line item, never inside the cab fare).
- **Fleet & corporate partnerships** — grouped demand before the aircraft lands; hotel and corporate
  desks pre-announce arrivals.
- **Airport partnerships** — kerb coordination and reduced vehicle dwell time.
- **Premium options** — private (non-shared) transfers, larger vehicles, priority matching.

**Metrics tracked in the prototype:** registered users, active groups, completed rides, average
passengers per ride, estimated passenger savings, platform revenue, driver earnings, cancellation
rate, funnel events (`flight_search_initiated` → `match_results_viewed` → `join_request_submitted` →
`booking_confirmed` → `ride_completed`). All figures in the admin console are labelled demo metrics,
not projections of revenue.

---

## 11. Security model (summary)

- Passwords: scrypt with per-user salt; no plaintext anywhere; constant-time comparison.
- Sessions: random 256-bit tokens, only the hash stored; HttpOnly, SameSite=Lax, 7-day expiry;
  revocation on logout and account suspension.
- Authorisation: every page and API route re-checks session, role and resource ownership server-side
  (`lib/auth/guards.ts`, services). Middleware only does a fast cookie-presence check.
- Validation: zod at the boundary, typed services inside; cross-origin state-changing requests
  rejected.
- Rate limits: login, register, password reset, join, message, report, support.
- Privacy: booking references masked + hashed, no card data, phone numbers hidden by default, no
  precise location sharing before boarding, admin actions audited.
- Webhooks: HMAC verification, provider re-fetch, idempotency keys.

Report a security issue privately rather than in a public issue.

---

## 12. Testing

### Unit + integration (Vitest)

```bash
npm run test        # 5 files, 59 tests
```

Coverage: money arithmetic and allocation remainders, the three fare strategies, match scoring
(weights, blockers, corridor affinity), Zod validation shared by client and server, and SQLite
constraint behaviour. Notable cases: allocations sum exactly to the allocated fare at rupee
granularity; every member pays less than a solo cab; full group / wrong date / insufficient luggage
are hard blockers; incompatible corridors (Colaba↔Borivali) score below the threshold; two concurrent
approvals cannot overbook the last seat; a direct `UPDATE` past capacity violates a table CHECK.

### End-to-end (Playwright)

```bash
npm run db:reset
npm run build && npm start -- -p 3100     # or: npm run dev
E2E_REUSE_SERVER=1 E2E_PORT=3100 npx playwright test
```

11 specs in `tests/e2e/critical-journey.spec.ts` cover the public site (landing copy, protected-route
redirects, every marketing page, search validation → scored results, match page fare breakdown), a
passenger sending a join request and landing on the honest "waiting on the coordinator" state, the
coordinator's trip page and dashboard routes, a driver being refused the admin console at both the
page and API layers, the admin console + audit log, and mobile overflow at 390 px.

How it stays reliable:

- `tests/e2e/global-setup.ts` signs the four demo roles in **once** and saves their session cookies to
  `tests/e2e/.auth/` (git-ignored). Specs reuse those sessions instead of logging in repeatedly.
- The sign-in limiter is IP-scoped (10 attempts / 5 min). The setup clears the `rate_limits` table
  first, so repeated local runs do not lock you out. In production, swap the limiter for Redis.
- Specs assert the visible contract, then skip with an explicit reason when a previous run consumed the
  only open seat — a stale fixture never produces a false pass.
- `npm run db:reset` rebuilds the database **in place** (it drops and recreates tables rather than
  unlinking the file), so a running server keeps a valid handle. You can reseed between runs without
  restarting anything.

---

*Built as a demonstration product. Read the in-app disclaimer on `/legal/terms` before assuming any
part of this is production-ready for real passengers, real payments or real transport.*
