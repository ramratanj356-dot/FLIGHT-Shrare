import { defineConfig } from "vitest/config";
import path from "node:path";

export default defineConfig({
  test: {
    environment: "node",
    include: ["tests/**/*.test.ts"],
    reporters: process.env.CI ? "dot" : "default",
    // Each integration-style test builds its own SQLite file, so no shared state.
    pool: "forks",
  },
  resolve: {
    alias: [
      // `server-only` is a build-time guard that throws under plain Node.
      { find: "server-only", replacement: path.resolve(__dirname, "tests/stubs/server-only.ts") },
      { find: "@", replacement: path.resolve(__dirname, "src") },
    ],
  },
});
