/**
 * Top-up demo data (idempotent). Use `npm run db:reset` for a clean rebuild.
 */
import Database from "better-sqlite3";
import path from "node:path";
import { ensureDemoData } from "../src/lib/demo/seed";

const dbPath = path.resolve(process.cwd(), process.env.DATABASE_PATH ?? "./data/flightshare.db");
const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
ensureDemoData(db);
const n = (db.prepare("SELECT COUNT(*) AS n FROM ride_groups").get() as { n: number }).n;
console.log(`✓ Demo data ensured — ${n} ride groups.`);
db.close();
