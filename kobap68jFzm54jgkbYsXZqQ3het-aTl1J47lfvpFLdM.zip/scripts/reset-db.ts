/**
 * Rebuild the local database from db/schema.sql and reseed demo data.
 *   npm run db:reset
 */
import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";
import { ensureDemoData } from "../src/lib/demo/seed";

const dbPath = path.resolve(process.cwd(), process.env.DATABASE_PATH ?? "./data/flightshare.db");
const schemaPath = path.join(process.cwd(), "db", "schema.sql");

fs.mkdirSync(path.dirname(dbPath), { recursive: true });

/**
 * Rebuild in place rather than unlinking the file.
 *
 * Deleting the database swaps the inode, so any running `next dev`/`next start`
 * process keeps serving the old, deleted file (and would still hold stale rate
 * limits and users). Dropping the tables in the existing file keeps every open
 * handle valid, which makes `npm run db:reset` safe while the app is running.
 */
const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = OFF");
const existing = db
  .prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")
  .all() as { name: string }[];
db.exec("BEGIN");
for (const { name } of existing) {
  if (name.startsWith("sqlite_")) continue;
  db.exec(`DROP TABLE IF EXISTS "${name.replace(/"/g, '""')}"`);
}
db.exec("COMMIT");
db.pragma("foreign_keys = ON");
db.exec(fs.readFileSync(schemaPath, "utf8"));
ensureDemoData(db);

const counts = ["users", "flights", "ride_groups", "ride_members", "fare_estimates", "bookings", "messages"].map(
  (t) => `${t}=${(db.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get() as { n: number }).n}`,
);
console.log("✓ Database rebuilt at", dbPath);
console.log("  " + counts.join("  "));

const accounts = db
  .prepare("SELECT email, role FROM users WHERE email LIKE '%@demo.flightshare.app' ORDER BY role, email")
  .all() as { email: string; role: string }[];
console.log("  Demo accounts:");
for (const a of accounts) console.log(`   · ${a.role.padEnd(9)} ${a.email}`);
db.close();
