"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { CheckCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { post } from "@/lib/client/api";

export function MarkAllRead() {
  const router = useRouter();
  const [busy, setBusy] = React.useState(false);
  return (
    <Button
      variant="outline"
      size="md"
      loading={busy}
      leftIcon={<CheckCheck className="h-4 w-4" />}
      onClick={async () => {
        setBusy(true);
        try { await post("/api/notifications/read", {}); router.refresh(); } finally { setBusy(false); }
      }}
    >
      Mark all read
    </Button>
  );
}
