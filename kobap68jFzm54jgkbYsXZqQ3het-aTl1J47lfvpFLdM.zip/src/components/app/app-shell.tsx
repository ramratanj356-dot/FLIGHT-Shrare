"use client";
import * as React from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Bell, Car, ChevronDown, Compass, Home, LayoutDashboard, LogOut, MessageSquare, Plus,
  Search, Settings, ShieldCheck, User, Users, Wallet, Menu, X,
} from "lucide-react";
import { Logo } from "@/components/brand/logo";
import { Avatar, Badge, DemoBadge } from "@/components/ui/primitives";
import { Button } from "@/components/ui/button";
import { post } from "@/lib/client/api";
import { cn } from "@/lib/utils";

export interface ShellUser {
  id: string;
  name: string;
  email: string;
  role: string;
  demoAccount: boolean;
  emailVerified: boolean;
}

const PASSENGER_NAV = [
  { href: "/app", label: "Home", icon: Home, exact: true },
  { href: "/search", label: "Find Ride", icon: Search },
  { href: "/app/trips", label: "My Trips", icon: Compass },
  { href: "/app/messages", label: "Messages", icon: MessageSquare },
  { href: "/app/profile", label: "Profile", icon: User },
];

const DRIVER_NAV = [
  { href: "/driver", label: "Requests", icon: LayoutDashboard, exact: true },
  { href: "/driver/trips", label: "Trips", icon: Car },
  { href: "/driver/earnings", label: "Earnings", icon: Wallet },
  { href: "/driver/verification", label: "Verification", icon: ShieldCheck },
];

const ADMIN_NAV = [
  { href: "/admin", label: "Overview", icon: LayoutDashboard, exact: true },
  { href: "/admin/verifications", label: "Verifications", icon: ShieldCheck },
  { href: "/admin/rides", label: "Rides", icon: Compass },
  { href: "/admin/users", label: "Users", icon: Users },
  { href: "/admin/pricing", label: "Pricing", icon: Settings },
  { href: "/admin/support", label: "Support", icon: MessageSquare },
  { href: "/admin/audit", label: "Audit log", icon: Bell },
];

export function AppShell({
  user, children, unreadNotifications = 0, unreadMessages = 0, variant = "passenger",
}: {
  user: ShellUser;
  children: React.ReactNode;
  unreadNotifications?: number;
  unreadMessages?: number;
  variant?: "passenger" | "driver" | "admin";
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [loggingOut, setLoggingOut] = React.useState(false);

  const nav = variant === "driver" ? DRIVER_NAV : variant === "admin" ? ADMIN_NAV : PASSENGER_NAV;
  const isActive = (href: string, exact?: boolean) => (exact ? pathname === href : pathname === href || pathname.startsWith(href + "/"));

  async function logout() {
    setLoggingOut(true);
    try {
      await post("/api/auth/logout");
      router.push("/");
      router.refresh();
    } finally {
      setLoggingOut(false);
    }
  }

  return (
    <div className="min-h-screen bg-canvas">
      <header className="sticky top-0 z-40 border-b border-line bg-white/90 backdrop-blur-lg">
        <div className="mx-auto flex h-16 w-full max-w-[1320px] items-center justify-between gap-4 px-4 sm:px-6">
          <div className="flex items-center gap-6">
            <Link href="/" aria-label="FlightShare home"><Logo /></Link>
            <span className="hidden items-center gap-1.5 sm:flex">
              <Badge tone={variant === "admin" ? "navy" : variant === "driver" ? "indigo" : "muted"}>
                {variant === "admin" ? "Admin console" : variant === "driver" ? "Driver portal" : "Passenger"}
              </Badge>
              <DemoBadge label="DEMO" />
            </span>
          </div>

          <div className="flex items-center gap-2">
            {variant === "passenger" && (
              <Link
                href="/app/rides/new"
                className="hidden items-center gap-1.5 rounded-lg border border-line px-3 py-2 text-[12.5px] font-semibold text-ink-soft transition hover:border-indigo-200 hover:text-indigo"
              >
                <Plus className="h-3.5 w-3.5" /> Start a ride
              </Link>
            )}
            <Link
              href={variant === "passenger" ? "/app/notifications" : "/app/notifications"}
              className="relative grid h-9 w-9 place-items-center rounded-lg text-ink-soft transition hover:bg-[#F2F4F9]"
              aria-label={`Notifications${unreadNotifications ? `, ${unreadNotifications} unread` : ""}`}
            >
              <Bell className="h-4.5 w-4.5" />
              {unreadNotifications > 0 && (
                <span className="absolute right-1.5 top-1.5 grid h-4 min-w-4 place-items-center rounded-full bg-indigo px-1 text-[9px] font-bold text-white">
                  {unreadNotifications > 9 ? "9+" : unreadNotifications}
                </span>
              )}
            </Link>

            <div className="relative">
              <button
                onClick={() => setMenuOpen((o) => !o)}
                className="flex items-center gap-2 rounded-lg py-1 pl-1 pr-2 transition hover:bg-[#F2F4F9]"
                aria-expanded={menuOpen}
                aria-haspopup="menu"
              >
                <Avatar name={user.name} size="sm" />
                <span className="hidden text-left sm:block">
                  <span className="block max-w-[120px] truncate text-[12.5px] font-semibold leading-tight text-navy">{user.name}</span>
                  <span className="block text-[10.5px] capitalize text-ink-muted">{user.role}</span>
                </span>
                <ChevronDown className="h-3.5 w-3.5 text-ink-muted" />
              </button>

              {menuOpen && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} />
                  <div className="absolute right-0 z-20 mt-2 w-64 animate-slide-in overflow-hidden rounded-xl border border-line bg-white shadow-lift" role="menu">
                    <div className="border-b border-line px-4 py-3">
                      <p className="truncate text-[13px] font-semibold text-navy">{user.name}</p>
                      <p className="truncate text-[11.5px] text-ink-muted">{user.email}</p>
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        <Badge tone="muted" className="capitalize">{user.role}</Badge>
                        {user.emailVerified ? <Badge tone="success">Email verified</Badge> : <Badge tone="amber">Email unverified</Badge>}
                        {user.demoAccount && <DemoBadge label="DEMO" />}
                      </div>
                    </div>
                    <nav className="p-1.5" role="none">
                      {variant === "passenger" && (
                        <Link href="/app/profile" className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[12.5px] font-medium text-ink-soft hover:bg-[#F7F8FC]" role="menuitem">
                          <User className="h-4 w-4" /> Profile & preferences
                        </Link>
                      )}
                      {user.role === "admin" && (
                        <Link href="/admin" className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[12.5px] font-medium text-ink-soft hover:bg-[#F7F8FC]" role="menuitem">
                          <ShieldCheck className="h-4 w-4" /> Admin console
                        </Link>
                      )}
                      {user.role === "driver" && (
                        <Link href="/driver" className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[12.5px] font-medium text-ink-soft hover:bg-[#F7F8FC]" role="menuitem">
                          <Car className="h-4 w-4" /> Driver portal
                        </Link>
                      )}
                      <Link href="/help" className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[12.5px] font-medium text-ink-soft hover:bg-[#F7F8FC]" role="menuitem">
                        <MessageSquare className="h-4 w-4" /> Help & support
                      </Link>
                      <button
                        onClick={logout}
                        disabled={loggingOut}
                        className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-[12.5px] font-medium text-danger hover:bg-danger-soft"
                        role="menuitem"
                      >
                        <LogOut className="h-4 w-4" /> {loggingOut ? "Signing out…" : "Sign out"}
                      </button>
                    </nav>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* desktop / tablet section nav — on phones the bottom bar covers this */}
        {(
          <div className={cn("border-t border-line bg-white", variant === "passenger" && "hidden sm:block")}>
            <nav className="mx-auto flex w-full max-w-[1320px] gap-1 overflow-x-auto px-4 sm:px-6" aria-label={variant === "passenger" ? "Account" : "Portal"}>
              {nav.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "shrink-0 border-b-2 px-3 py-2.5 text-[12.5px] font-medium transition-colors",
                    isActive(item.href, item.exact) ? "border-indigo text-indigo" : "border-transparent text-ink-muted hover:text-navy",
                  )}
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
        )}
      </header>

      <main id="main" className={cn("mx-auto w-full max-w-[1320px] px-4 py-6 sm:px-6 sm:py-8", variant === "passenger" && "pb-24 lg:pb-10")}>
        {children}
      </main>

      {/* mobile bottom nav (passenger only) */}
      {variant === "passenger" && (
        <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-white/95 backdrop-blur-lg lg:hidden" aria-label="Primary">
          <div className="mx-auto grid max-w-md grid-cols-5">
            {PASSENGER_NAV.map((item) => {
              const active = isActive(item.href, item.exact);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn("relative flex flex-col items-center gap-0.5 py-2.5", active ? "text-indigo" : "text-ink-muted")}
                  aria-current={active ? "page" : undefined}
                >
                  <item.icon className={cn("h-5 w-5", active && "stroke-[2.4]")} />
                  <span className="text-[10px] font-medium">{item.label}</span>
                  {item.label === "Messages" && unreadMessages > 0 && (
                    <span className="absolute right-[26%] top-1.5 h-1.5 w-1.5 rounded-full bg-indigo" />
                  )}
                </Link>
              );
            })}
          </div>
        </nav>
      )}
    </div>
  );
}

export function PageHeading({
  title, description, actions, badge,
}: { title: string; description?: string; actions?: React.ReactNode; badge?: React.ReactNode }) {
  return (
    <div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
      <div>
        {badge && <div className="mb-2 flex items-center gap-2">{badge}</div>}
        <h1 className="text-[22px] font-bold tracking-[-0.02em] text-navy sm:text-[26px]">{title}</h1>
        {description && <p className="mt-1 max-w-2xl text-[13.5px] leading-relaxed text-ink-muted">{description}</p>}
      </div>
      {actions && <div className="flex shrink-0 flex-wrap gap-2">{actions}</div>}
    </div>
  );
}
