"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { Check, Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Textarea, Input } from "@/components/ui/primitives";
import { ApiError, post } from "@/lib/client/api";
import { useToast } from "@/components/ui/toast";

export function VerificationDecision({ kind, id }: { kind: "flight" | "driver"; id: string }) {
  const router = useRouter();
  const { push } = useToast();
  const [open, setOpen] = React.useState<null | "verified" | "rejected">(null);
  const [note, setNote] = React.useState("");
  const [busy, setBusy] = React.useState(false);

  async function submit() {
    if (!open) return;
    setBusy(true);
    try {
      await post(`/api/admin/${kind === "flight" ? "flight-verification" : "driver-verification"}`, {
        ...(kind === "flight" ? { id } : { driverId: id }),
        status: open,
        note: note || undefined,
      });
      push({
        tone: open === "verified" ? "success" : "info",
        title: open === "verified" ? "Approved" : "Rejected",
        description: "The applicant has been notified. This action is recorded in the audit log.",
      });
      setOpen(null);
      setNote("");
      router.refresh();
    } catch (err) {
      push({ tone: "error", title: "Action failed", description: err instanceof ApiError ? err.message : "Try again" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <div className="flex gap-1.5">
        <Button size="sm" className="h-8 px-2.5" onClick={() => setOpen("verified")} leftIcon={<Check className="h-3.5 w-3.5" />}>Approve</Button>
        <Button size="sm" variant="outline" className="h-8 px-2.5" onClick={() => setOpen("rejected")} leftIcon={<X className="h-3.5 w-3.5" />}>Reject</Button>
      </div>

      <Dialog
        open={open !== null}
        onClose={() => setOpen(null)}
        title={open === "verified" ? "Approve this verification?" : "Reject this verification?"}
        description={
          open === "verified"
            ? "Approval is recorded with your account and shown to the applicant. Only approve genuine, legible submissions."
            : "The applicant will see your note and can re-submit. Be specific about what was wrong."
        }
        footer={
          <>
            <Button variant="outline" onClick={() => setOpen(null)}>Cancel</Button>
            <Button variant={open === "rejected" ? "danger" : "primary"} onClick={submit} loading={busy}>
              {open === "verified" ? "Approve" : "Reject"}
            </Button>
          </>
        }
      >
        <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Review note (optional for approval, recommended for rejection)" maxLength={280} />
      </Dialog>
    </>
  );
}

export function UserStatusControl({ userId, status }: { userId: string; status: string }) {
  const router = useRouter();
  const { push } = useToast();
  const [busy, setBusy] = React.useState(false);
  const next = status === "active" ? "suspended" : "active";

  async function toggle() {
    setBusy(true);
    try {
      await post("/api/admin/user", { userId, status: next });
      push({ tone: "info", title: `Account ${next}`, description: next === "suspended" ? "All sessions were revoked immediately." : "The account can sign in again." });
      router.refresh();
    } catch (err) {
      push({ tone: "error", title: "Could not update", description: err instanceof ApiError ? err.message : "Try again" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Button size="sm" variant={next === "suspended" ? "outline" : "success"} className="h-8 px-2.5" loading={busy} onClick={toggle}>
      {next === "suspended" ? "Suspend" : "Reactivate"}
    </Button>
  );
}

export function ReportResolution({ reportId, status }: { reportId: string; status: string }) {
  const router = useRouter();
  const { push } = useToast();
  const [open, setOpen] = React.useState(false);
  const [resolution, setResolution] = React.useState("");
  const [busy, setBusy] = React.useState(false);

  async function submit(next: "reviewing" | "resolved" | "dismissed") {
    setBusy(true);
    try {
      await post("/api/admin/report", { id: reportId, status: next, resolution: resolution || undefined });
      push({ tone: "success", title: `Report ${next}`, description: "The reporter has been notified." });
      setOpen(false);
      router.refresh();
    } catch (err) {
      push({ tone: "error", title: "Could not update", description: err instanceof ApiError ? err.message : "Try again" });
    } finally {
      setBusy(false);
    }
  }

  if (status !== "open" && status !== "reviewing") return <span className="text-[10.5px] capitalize text-ink-muted">{status}</span>;

  return (
    <>
      <Button size="sm" variant="outline" className="h-8 px-2.5" onClick={() => setOpen(true)}>Resolve</Button>
      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title="Review this report"
        description="Document what you found. The reporter receives this note."
        footer={
          <>
            <Button variant="outline" onClick={() => submit("dismissed")} loading={busy}>Dismiss</Button>
            <Button onClick={() => submit("resolved")} loading={busy}>Mark resolved</Button>
          </>
        }
      >
        <Textarea value={resolution} onChange={(e) => setResolution(e.target.value)} placeholder="Findings and resolution" maxLength={500} />
      </Dialog>
    </>
  );
}

export function RefundDecision({ refundId }: { refundId: string }) {
  const router = useRouter();
  const { push } = useToast();
  const [busy, setBusy] = React.useState<"processed" | "failed" | null>(null);

  async function decide(decision: "processed" | "failed") {
    setBusy(decision);
    try {
      await post("/api/admin/refund", { id: refundId, decision });
      push({
        tone: decision === "processed" ? "success" : "error",
        title: decision === "processed" ? "Refund marked processed" : "Refund marked failed",
        description: decision === "processed" ? "Payment and booking statuses were updated atomically." : "The passenger has been notified to contact support.",
      });
      router.refresh();
    } catch (err) {
      push({ tone: "error", title: "Could not process", description: err instanceof ApiError ? err.message : "Try again" });
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="flex gap-1.5">
      <Button size="sm" className="h-8 px-2.5" loading={busy === "processed"} onClick={() => decide("processed")}>Approve</Button>
      <Button size="sm" variant="outline" className="h-8 px-2.5" loading={busy === "failed"} onClick={() => decide("failed")}>Reject</Button>
    </div>
  );
}

export function TicketStatusControl({ ticketId, status }: { ticketId: string; status: string }) {
  const router = useRouter();
  const { push } = useToast();
  const [busy, setBusy] = React.useState(false);

  async function set(next: "in_progress" | "resolved" | "closed") {
    setBusy(true);
    try {
      await post("/api/admin/ticket", { id: ticketId, status: next });
      push({ tone: "success", title: `Ticket ${next.replace(/_/g, " ")}` });
      router.refresh();
    } catch (err) {
      push({ tone: "error", title: "Could not update", description: err instanceof ApiError ? err.message : "Try again" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex gap-1.5">
      {status === "open" && <Button size="sm" variant="outline" className="h-8 px-2.5" loading={busy} onClick={() => set("in_progress")}>Take</Button>}
      {status !== "resolved" && status !== "closed" && <Button size="sm" className="h-8 px-2.5" loading={busy} onClick={() => set("resolved")}>Resolve</Button>}
      {status === "resolved" && <Button size="sm" variant="outline" className="h-8 px-2.5" loading={busy} onClick={() => set("closed")}>Close</Button>}
    </div>
  );
}

export function PricingForm({
  initial,
}: {
  initial: { baseFareRupees: number; perKmRupees: number; extraStopRupees: number; platformFeePct: number; platformFeeMinRupees: number; taxPct: number; maxWaitMinutes: number; destinationThreshold: number };
}) {
  const router = useRouter();
  const { push } = useToast();
  const [values, setValues] = React.useState(initial);
  const [busy, setBusy] = React.useState(false);

  function update<K extends keyof typeof values>(key: K, raw: string) {
    const num = Number(raw);
    setValues((v) => ({ ...v, [key]: Number.isNaN(num) ? v[key] : num }));
  }

  async function save() {
    setBusy(true);
    try {
      await post("/api/admin/pricing", values);
      push({ tone: "success", title: "Pricing updated", description: "New estimates use these rules immediately. Existing bookings are unchanged." });
      router.refresh();
    } catch (err) {
      push({ tone: "error", title: "Could not save", description: err instanceof ApiError ? err.message : "Try again" });
    } finally {
      setBusy(false);
    }
  }

  const fields: { key: keyof typeof values; label: string; hint: string; step?: string }[] = [
    { key: "baseFareRupees", label: "Base fare (₹)", hint: "Fixed flag-fall on every airport transfer." },
    { key: "perKmRupees", label: "Per km (₹)", hint: "Applied to the shared route distance." },
    { key: "extraStopRupees", label: "Extra drop-off (₹)", hint: "Added per additional stop." },
    { key: "platformFeePct", label: "Platform fee (%)", hint: "Of the vehicle fare, minimum applies.", step: "0.1" },
    { key: "platformFeeMinRupees", label: "Minimum fee (₹)", hint: "Floor so short trips still cover processing." },
    { key: "taxPct", label: "Tax on fee (%)", hint: "GST applied to the platform fee only." },
    { key: "maxWaitMinutes", label: "Default max wait (min)", hint: "Ceiling for group kerb wait." },
    { key: "destinationThreshold", label: "Destination threshold", hint: "0–1. Minimum route compatibility to allow a join.", step: "0.01" },
  ];

  return (
    <div className="card p-4">
      <div className="grid gap-3 sm:grid-cols-2">
        {fields.map((f) => (
          <div key={f.key}>
            <label htmlFor={f.key} className="label">{f.label}</label>
            <Input id={f.key} type="number" step={f.step ?? "1"} min={0} value={values[f.key]} onChange={(e) => update(f.key, e.target.value)} />
            <p className="hint">{f.hint}</p>
          </div>
        ))}
      </div>
      <div className="mt-4 flex items-center gap-2">
        <Button size="md" onClick={save} loading={busy}>Save rules</Button>
        <Button size="md" variant="outline" onClick={() => setValues(initial)}>Reset</Button>
      </div>
      <p className="mt-2 text-[10.5px] text-ink-muted">
        Changes are audited with your account and take effect on the next estimate calculation. Existing bookings never silently change price.
      </p>
    </div>
  );
}
