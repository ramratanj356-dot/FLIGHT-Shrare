"use client";
import * as React from "react";
import { Radio, WifiOff } from "lucide-react";
import { usePolling } from "@/lib/client/use-polling";
import { cn } from "@/lib/utils";

/**
 * Visible connection state for the live ride channel. Honest beats clever:
 * if polling fails the passenger is told, rather than shown a stale timestamp.
 */
export function LiveStatus({ rideId }: { rideId: string }) {
  const { data, error, isStale } = usePolling(async () => {
    const res = await fetch(`/api/rides/${rideId}/state`, { credentials: "same-origin" });
    if (!res.ok) throw new Error(res.status === 403 ? "Access denied" : "Connection issue");
    const json = await res.json();
    return json.data as { serverTime: string; unreadNotifications: number };
  }, { intervalMs: 8000 });

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2 py-1 text-[10px] font-semibold",
        error ? "border-[#FBD5D1] bg-danger-soft text-[#912018]" : "border-[#BFE8D4] bg-success-soft text-success-dark",
      )}
      title={error ?? "Live updates every few seconds"}
    >
      {error ? <WifiOff className="h-2.5 w-2.5" /> : <Radio className="h-2.5 w-2.5 animate-pulse" />}
      {error ? "Reconnecting…" : isStale ? "Syncing…" : "Live"}
      {data?.serverTime && !error && (
        <span className="font-normal opacity-70">· {new Date(data.serverTime).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}</span>
      )}
    </span>
  );
}
