import Link from "next/link";
import { ArrowRight, Clock, MapPin, MessageSquare, Users } from "lucide-react";
import { Avatar, Badge, DemoBadge } from "@/components/ui/primitives";
import { formatDateLong, formatTime } from "@/lib/utils";
import { formatPaise } from "@/lib/money";
import { READINESS_LABELS, type ReadinessState } from "@/lib/config/pricing";
import type { UserTrip } from "@/lib/db/queries";

const STATUS_TONE: Record<string, "success" | "indigo" | "amber" | "muted" | "danger"> = {
  open: "indigo", full: "amber", confirmed: "success", in_progress: "success",
  completed: "muted", cancelled: "danger", expired: "muted",
};

const STATUS_LABEL: Record<string, string> = {
  open: "Forming", full: "Full — awaiting driver", confirmed: "Driver assigned",
  in_progress: "On the way", completed: "Completed", cancelled: "Cancelled", expired: "Expired",
};

export function PassengerTripCard({ trip }: { trip: UserTrip }) {
  const g = trip.group;
  return (
    <article className="card group overflow-hidden transition-shadow hover:shadow-lift">
      <div className="flex flex-col justify-between gap-3 border-b border-line bg-[#FBFBFE] px-4 py-2.5 sm:flex-row sm:items-center">
        <div className="flex flex-wrap items-center gap-1.5">
          <Badge tone={STATUS_TONE[g.status] ?? "muted"}>{STATUS_LABEL[g.status] ?? g.status}</Badge>
          {g.isDemo && <DemoBadge label="DEMO" />}
          <span className="text-[10.5px] text-ink-muted">{g.code}</span>
        </div>
        <span className="text-[11px] text-ink-muted">
          {formatDateLong(g.flight.flight_date)} · {g.flight.airline_code} {g.flight.flight_number} · {formatTime(g.flight.estimated_arrival)}
        </span>
      </div>

      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-muted">Drop-off</p>
            <h3 className="truncate text-[16px] font-bold text-navy">{g.destination.name}</h3>
            <p className="mt-0.5 flex items-center gap-2 text-[11px] text-ink-muted">
              <MapPin className="h-3 w-3" /> {g.destination.distance_km} km
              <Clock className="ml-1 h-3 w-3" /> {formatTime(g.departureWindowStart)}–{formatTime(g.departureWindowEnd)}
            </p>
          </div>
          <div className="shrink-0 text-right">
            <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-muted">Your share</p>
            <p className="text-[17px] font-bold text-navy tabular">{formatPaise(trip.myContributionPaise)}</p>
            {trip.mySavingsPaise > 0 && <p className="text-[10px] font-medium text-success-dark">saves {formatPaise(trip.mySavingsPaise)}</p>}
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <div className="flex -space-x-1.5">
              {g.members.slice(0, 4).map((m) => (
                <Avatar key={m.memberId} name={m.firstName} size="xs" className="ring-2 ring-white" verified={m.identityVerified} />
              ))}
            </div>
            <span className="text-[11px] text-ink-muted">
              <Users className="mr-0.5 inline h-3 w-3" />
              {g.members.length} travelling
            </span>
          </div>
          <Badge tone={trip.readiness === "ready_at_meeting_point" ? "success" : "muted"}>
            You: {READINESS_LABELS[trip.readiness as ReadinessState] ?? trip.readiness}
          </Badge>
        </div>

        <div className="mt-3.5 flex items-center gap-2 border-t border-line pt-3">
          <Link
            href={`/app/trips/${g.id}`}
            className="flex h-9 flex-1 items-center justify-center gap-1.5 rounded-lg bg-indigo text-[12.5px] font-semibold text-white transition hover:bg-indigo-700"
          >
            Open trip <ArrowRight className="h-3.5 w-3.5" />
          </Link>
          <Link
            href={`/app/messages/${g.id}`}
            className="flex h-9 items-center gap-1.5 rounded-lg border border-line px-3 text-[12.5px] font-semibold text-ink-soft transition hover:border-indigo-200 hover:text-indigo"
          >
            <MessageSquare className="h-3.5 w-3.5" /> Chat
          </Link>
        </div>
      </div>
    </article>
  );
}
