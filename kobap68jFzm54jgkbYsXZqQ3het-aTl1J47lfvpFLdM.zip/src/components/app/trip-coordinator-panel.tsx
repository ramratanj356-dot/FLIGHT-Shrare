"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { Check, ChevronDown, Loader2, ShieldCheck, UserCheck, UserX, X } from "lucide-react";
import { Avatar, Badge, EmptyState } from "@/components/ui/primitives";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/primitives";
import { ApiError, post } from "@/lib/client/api";
import { useToast } from "@/components/ui/toast";
import { cn } from "@/lib/utils";

interface Req {
  id: string; name: string; passengerCount: number; luggage: number;
  destination: string; message: string | null; score: number | null; identityVerified: boolean;
}

export function TripCoordinatorPanel({
  rideId, status, driverAssigned, requests, seatsAvailable, maxWaitMinutes,
}: {
  rideId: string; status: string; driverAssigned: boolean; hasDriver: boolean;
  requests: Req[]; seatsAvailable: number; maxWaitMinutes: number;
}) {
  const router = useRouter();
  const { push } = useToast();
  const [busy, setBusy] = React.useState<string | null>(null);
  const [cancelOpen, setCancelOpen] = React.useState(false);
  const [cancelReason, setCancelReason] = React.useState("");
  const [expanded, setExpanded] = React.useState<string | null>(requests[0]?.id ?? null);

  async function decide(id: string, decision: "approved" | "declined") {
    setBusy(`${id}:${decision}`);
    try {
      const res = await post<{ status: string; contributionPaise?: number }>("/api/join/decision", { requestId: id, decision });
      push({
        tone: "success",
        title: decision === "approved" ? "Passenger added" : "Request declined",
        description:
          decision === "approved"
            ? "The fare was re-split for everyone. They've been notified and can confirm readiness."
            : "The passenger has been notified with your note.",
      });
      void res;
      router.refresh();
    } catch (err) {
      push({
        tone: "error",
        title: decision === "approved" ? "Could not approve" : "Could not decline",
        description: err instanceof ApiError ? err.message : "Try again",
      });
    } finally {
      setBusy(null);
    }
  }

  async function depart() {
    setBusy("depart");
    try {
      await post(`/api/rides/${rideId}/depart`);
      push({ tone: "success", title: "Departure confirmed", description: "Everyone in the group has been notified." });
      router.refresh();
    } catch (err) {
      push({ tone: "error", title: "Could not confirm", description: err instanceof ApiError ? err.message : "Try again" });
    } finally {
      setBusy(null);
    }
  }

  async function doCancel() {
    setBusy("cancel");
    try {
      await post(`/api/rides/${rideId}/cancel`, { reason: cancelReason || "Cancelled by the coordinator" });
      push({ tone: "info", title: "Ride cancelled", description: "No payment was taken. Members can join another group." });
      setCancelOpen(false);
      router.refresh();
    } catch (err) {
      push({ tone: "error", title: "Could not cancel", description: err instanceof ApiError ? err.message : "Try again" });
    } finally {
      setBusy(null);
    }
  }

  return (
    <>
      <section className="card overflow-hidden">
        <div className="flex items-center justify-between border-b border-line px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-[#F4F3FF] text-indigo"><UserCheck className="h-4 w-4" /></span>
            <div>
              <p className="text-[13px] font-semibold text-navy">Coordinator controls</p>
              <p className="text-[10.5px] text-ink-muted">Only you see this panel · authorised server-side</p>
            </div>
          </div>
          <Badge tone={requests.length ? "amber" : "muted"}>{requests.length} request{requests.length === 1 ? "" : "s"}</Badge>
        </div>

        {requests.length === 0 ? (
          <div className="px-4 py-6 text-center">
            <p className="text-[12px] font-medium text-ink-soft">No requests waiting</p>
            <p className="mx-auto mt-1 max-w-sm text-[11px] text-ink-muted">
              {seatsAvailable > 0
                ? `${seatsAvailable} seat${seatsAvailable === 1 ? "" : "s"} still free. Others on your flight will see this group in their matches.`
                : "This group is full."}
            </p>
          </div>
        ) : (
          <ul className="divide-y divide-line">
            {requests.map((r) => (
              <li key={r.id} className="px-4 py-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <Avatar name={r.name} size="md" verified={r.identityVerified} />
                    <div className="min-w-0">
                      <p className="truncate text-[12.5px] font-semibold text-navy">{r.name}</p>
                      <p className="truncate text-[10.5px] text-ink-muted">
                        {r.passengerCount} pax · {r.luggage} bag{r.luggage === 1 ? "" : "s"} · → {r.destination}
                      </p>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {r.score !== null && <Badge tone={r.score >= 70 ? "success" : "amber"}>Match {r.score}</Badge>}
                        <Badge tone={r.identityVerified ? "indigo" : "muted"} icon={<ShieldCheck className="h-2.5 w-2.5" />}>
                          {r.identityVerified ? "ID verified" : "ID pending"}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setExpanded(expanded === r.id ? null : r.id)}
                    className="rounded-md p-1 text-ink-muted hover:bg-[#F2F4F9]"
                    aria-label={expanded === r.id ? "Hide details" : "Show details"}
                  >
                    <ChevronDown className={cn("h-4 w-4 transition", expanded === r.id && "rotate-180")} />
                  </button>
                </div>

                {expanded === r.id && r.message && (
                  <p className="mt-2 rounded-lg bg-[#F9FAFD] px-2.5 py-2 text-[11px] leading-relaxed text-ink-muted">“{r.message}”</p>
                )}

                <div className="mt-2.5 flex gap-2">
                  <Button
                    size="sm"
                    className="flex-1"
                    onClick={() => decide(r.id, "approved")}
                    loading={busy === `${r.id}:approved`}
                    disabled={busy !== null || seatsAvailable < r.passengerCount}
                    leftIcon={<Check className="h-3.5 w-3.5" />}
                  >
                    Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1"
                    onClick={() => decide(r.id, "declined")}
                    loading={busy === `${r.id}:declined`}
                    disabled={busy !== null}
                    leftIcon={<UserX className="h-3.5 w-3.5" />}
                  >
                    Decline
                  </Button>
                </div>
                {seatsAvailable < r.passengerCount && (
                  <p className="mt-1 text-[10px] text-amber-dark">Not enough seats left for this party — they would need to split up.</p>
                )}
              </li>
            ))}
          </ul>
        )}

        <div className="flex flex-col gap-2 border-t border-line bg-[#FBFBFE] px-4 py-3 sm:flex-row">
          <Button
            size="sm"
            variant={driverAssigned ? "success" : "secondary"}
            className="flex-1"
            onClick={depart}
            loading={busy === "depart"}
            disabled={status !== "open" && status !== "full" && status !== "confirmed"}
          >
            {driverAssigned ? "Confirm departure" : "Confirm departure window"}
          </Button>
          <Button size="sm" variant="outline" className="flex-1" onClick={() => setCancelOpen(true)} leftIcon={<X className="h-3.5 w-3.5" />}>
            Cancel ride
          </Button>
        </div>
        <p className="border-t border-line px-4 py-2 text-[10px] leading-relaxed text-ink-muted">
          Confirming departure notifies everyone and closes further join requests. Cancelling costs nothing — no money has moved at this stage.
        </p>
      </section>

      <Dialog
        open={cancelOpen}
        onClose={() => setCancelOpen(false)}
        title="Cancel this ride?"
        description={`Everyone in the group will be notified and can join another group on the same flight. The group has agreed to wait up to ${maxWaitMinutes} minutes; cancelling ends that window.`}
        footer={
          <>
            <Button variant="outline" onClick={() => setCancelOpen(false)}>Keep the ride</Button>
            <Button variant="danger" onClick={doCancel} loading={busy === "cancel"}>Cancel ride</Button>
          </>
        }
      >
        <Textarea
          value={cancelReason}
          onChange={(e) => setCancelReason(e.target.value)}
          placeholder="Reason (shared with the group)"
          maxLength={240}
        />
      </Dialog>
    </>
  );
}
