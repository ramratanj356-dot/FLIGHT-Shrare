"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { AlertCircle, CreditCard, Info, Loader2, Lock, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge, Alert } from "@/components/ui/primitives";
import { Dialog } from "@/components/ui/dialog";
import { ApiError, post } from "@/lib/client/api";
import { useToast } from "@/components/ui/toast";
import { formatPaise } from "@/lib/money";

export function PaymentPanel({
  bookingId, bookingCode, amountPaise, paymentStatus, hasDriver, rideId,
}: {
  bookingId: string; bookingCode: string; amountPaise: number;
  paymentStatus: string; hasDriver: boolean; rideId: string;
}) {
  const router = useRouter();
  const { push } = useToast();
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [confirmOpen, setConfirmOpen] = React.useState(false);
  const [mode, setMode] = React.useState<string | null>(null);

  async function pay() {
    setBusy(true);
    setError(null);
    try {
      const order = await post<{ mode: string; paymentId: string }>("/api/payments/order", { bookingId });
      setMode(order.mode);
      const result = await post<{ status: string; demo?: boolean }>("/api/payments/verify", { paymentId: order.paymentId });
      push({
        tone: "success",
        title: result.demo ? "Demo payment recorded" : "Payment captured",
        description: result.demo
          ? "A simulated capture was stored so the whole flow is visible. No money moved."
          : "Verified server-side with the payment provider.",
      });
      setConfirmOpen(false);
      router.refresh();
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "Payment failed";
      setError(message);
      push({ tone: "error", title: "Payment unsuccessful", description: message });
    } finally {
      setBusy(false);
    }
  }

  if (paymentStatus === "captured") {
    return (
      <div className="card border-[#BFE8D4] p-4">
        <p className="flex items-center gap-1.5 text-[12.5px] font-semibold text-success-dark"><ShieldCheck className="h-4 w-4" /> Payment captured</p>
        <p className="mt-1 text-[11px] leading-relaxed text-ink-muted">
          {formatPaise(amountPaise)} recorded against booking {bookingCode}. Your driver and the group can see that you are settled.
        </p>
        <p className="mt-2 rounded-lg bg-success-soft px-2.5 py-1.5 text-[10px] text-success-dark">
          Verified server-side — never trusted from the browser.
        </p>
      </div>
    );
  }

  return (
    <>
      <div className="card p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-[12.5px] font-semibold text-navy">Confirm and pay</p>
            <p className="mt-0.5 text-[10.5px] text-ink-muted">Booking {bookingCode}</p>
          </div>
          <Badge tone={hasDriver ? "success" : "amber"}>{hasDriver ? "Fare confirmed" : "Estimate"}</Badge>
        </div>

        <p className="mt-3 text-[26px] font-bold leading-none tracking-tight text-navy tabular">{formatPaise(amountPaise)}</p>
        <p className="mt-1 text-[10.5px] text-ink-muted">
          {hasDriver ? "Confirmed fare for your share" : "Estimated share — may change if the group changes"}
        </p>

        {!hasDriver && (
          <div className="mt-2.5 flex items-start gap-1.5 rounded-lg border border-[#F8E2B0] bg-amber-soft px-2.5 py-2 text-[10.5px] leading-relaxed text-amber-dark">
            <Info className="mt-px h-3 w-3 shrink-0" />
            A driver hasn&apos;t accepted this trip yet. You can pay now to hold your seat, or wait until pickup is confirmed.
          </div>
        )}

        {error && (
          <div className="mt-2.5 flex items-start gap-1.5 rounded-lg border border-[#FBD5D1] bg-danger-soft px-2.5 py-2 text-[10.5px] text-[#912018]">
            <AlertCircle className="mt-px h-3 w-3 shrink-0" />
            <div>
              {error}
              <button onClick={() => setError(null)} className="ml-1 underline">Dismiss</button>
            </div>
          </div>
        )}

        <Button size="md" className="mt-3 w-full" loading={busy} onClick={() => setConfirmOpen(true)} leftIcon={<CreditCard className="h-4 w-4" />}>
          Pay {formatPaise(amountPaise)}
        </Button>
        <p className="mt-2 flex items-center justify-center gap-1 text-[9.5px] text-ink-muted">
          <Lock className="h-2.5 w-2.5" /> Card details are never stored on our servers.
        </p>
      </div>

      <Dialog
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        title="Confirm your payment"
        description={`You are paying ${formatPaise(amountPaise)} for your share of this shared ride. The amount is read from the booking on the server, not from this screen.`}
        footer={
          <>
            <Button variant="outline" onClick={() => setConfirmOpen(false)}>Not now</Button>
            <Button onClick={pay} loading={busy}>Pay {formatPaise(amountPaise)}</Button>
          </>
        }
      >
        <Alert tone="info" title="Demo payment gateway">
          No Razorpay keys are configured, so this records a clearly-labelled demo capture. No card is charged and no money moves.
          With keys configured, this screen creates a server-side order and verifies the signature before marking anything paid.
        </Alert>
        {mode && <p className="mt-2 text-[10.5px] text-ink-muted">Gateway mode: {mode}</p>}
      </Dialog>
    </>
  );
}
