import { Info, Receipt } from "lucide-react";
import { formatPaise } from "@/lib/money";
import { STRATEGY_LABELS, type FareStrategy } from "@/lib/config/pricing";
import type { GroupFare, MemberFare } from "@/lib/fares/group";
import { cn } from "@/lib/utils";

export function FareBreakdownCard({
  fare, viewerUserId, compact, showMembers = true, className, memberNames,
}: {
  fare: GroupFare;
  viewerUserId?: string | null;
  compact?: boolean;
  showMembers?: boolean;
  className?: string;
  /** userId → display name, so shares are attributed to people, not place ids. */
  memberNames?: Record<string, string>;
}) {
  const b = fare.breakdown;
  const rows: { label: string; value: number; hint?: string }[] = [
    { label: "Base fare", value: b.baseFarePaise },
    { label: `Distance · ${b.routeDistanceKm} km`, value: b.distanceComponentPaise, hint: `${b.extraStopCount} extra drop-off${b.extraStopCount === 1 ? "" : "s"} · ${b.detourKm} km detour` },
  ];
  if (b.extraStopsPaise > 0) rows.push({ label: "Additional drop-off fee", value: b.extraStopsPaise });
  if (b.tollsPaise > 0) rows.push({ label: "Tolls", value: b.tollsPaise });
  if (b.parkingPaise > 0) rows.push({ label: "Airport parking", value: b.parkingPaise });
  if (b.discountPaise > 0) rows.push({ label: "Discount / promo", value: -b.discountPaise });

  return (
    <div className={cn("card overflow-hidden", className)}>
      <div className="flex items-center justify-between border-b border-line px-4 py-3">
        <div className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-[#F4F3FF] text-indigo"><Receipt className="h-4 w-4" /></span>
          <div>
            <p className="text-[13px] font-semibold text-navy">Fare breakdown</p>
            <p className="text-[10.5px] text-ink-muted">{STRATEGY_LABELS[b.strategy as FareStrategy]} · {b.vehicleCategory.toUpperCase()}</p>
          </div>
        </div>
        <span className="rounded-md bg-amber-soft px-2 py-0.5 text-[9.5px] font-bold uppercase tracking-wide text-amber-dark">Estimate</span>
      </div>

      <div className={cn("px-4 py-3", compact ? "space-y-1.5" : "space-y-2")}>
        {rows.map((r) => (
          <div key={r.label} className="flex items-start justify-between gap-3 text-[12.5px]">
            <span className="text-ink-muted">
              {r.label}
              {r.hint && <span className="ml-1 text-[10.5px] text-[#98A2B3]">({r.hint})</span>}
            </span>
            <span className="shrink-0 font-medium text-ink tabular">{formatPaise(r.value)}</span>
          </div>
        ))}

        <div className="flex items-center justify-between border-t border-line pt-2 text-[12.5px]">
          <span className="font-medium text-ink-soft">Ride provider fare</span>
          <span className="font-semibold text-navy tabular">{formatPaise(b.vehicleFarePaise)}</span>
        </div>
        <div className="flex items-center justify-between text-[12.5px]">
          <span className="text-ink-muted">
            Platform fee <span className="text-[10.5px] text-[#98A2B3]">({(b.vehicleFarePaise ? Math.round((b.platformFeePaise / b.vehicleFarePaise) * 1000) / 10 : 0)}%)</span>
          </span>
          <span className="font-medium text-ink tabular">{formatPaise(b.platformFeePaise)}</span>
        </div>
        <div className="flex items-center justify-between text-[12.5px]">
          <span className="text-ink-muted">Tax on platform fee (18% GST)</span>
          <span className="font-medium text-ink tabular">{formatPaise(b.taxPaise)}</span>
        </div>

        <div className="mt-1 flex items-center justify-between rounded-lg bg-[#F7F6FF] px-2.5 py-2">
          <span className="text-[12.5px] font-semibold text-navy">Total shared fare</span>
          <span className="text-[15px] font-bold text-navy tabular">{formatPaise(b.totalPaise)}</span>
        </div>
      </div>

      {showMembers && fare.members.length > 0 && (
        <div className="border-t border-line px-4 py-3">
          <p className="mb-2 text-[10.5px] font-semibold uppercase tracking-wide text-ink-muted">Split between {fare.members.length} passenger{fare.members.length === 1 ? "" : "s"}</p>
          <ul className="space-y-2">
            {fare.members.map((m: MemberFare) => {
              const you = viewerUserId === m.userId;
              return (
                <li key={m.memberId} className={cn("rounded-lg border px-2.5 py-2", you ? "border-indigo-100 bg-[#F7F6FF]" : "border-line bg-white")}>
                  <div className="flex items-center justify-between gap-2">
                    <span className="truncate text-[12px] font-medium text-navy">
                      {you ? "You" : (memberNames?.[m.userId] ?? "Passenger")}
                      <span className="ml-1 text-[10px] font-normal text-ink-muted">
                        → {m.destinationId.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase())}
                        {m.seatCount > 1 ? ` · ×${m.seatCount} seats` : ""}
                      </span>
                    </span>
                    <span className="shrink-0 text-[13px] font-bold text-navy tabular">{formatPaise(m.contributionPaise)}</span>
                  </div>
                  <div className="mt-0.5 flex items-center justify-between text-[10.5px]">
                    <span className="text-ink-muted">solo est. <span className="line-through">{formatPaise(m.soloEstimatePaise)}</span></span>
                    <span className={cn("font-semibold", m.savingsIsPositive ? "text-success-dark" : "text-amber-dark")}>
                      {m.savingsIsPositive ? `saves ${formatPaise(m.savingsPaise)} (${m.savingsPct}%)` : `costs ${formatPaise(Math.abs(m.savingsPaise))} more`}
                    </span>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      <div className="flex items-start gap-1.5 border-t border-line bg-[#FBFBFE] px-4 py-2.5 text-[10.5px] leading-relaxed text-ink-muted">
        <Info className="mt-px h-3 w-3 shrink-0" />
        <span>
          All amounts are estimates in INR, calculated in integer paise (rounding of {b.roundingRemainderPaise} paise distributed so the split
          sums exactly to {formatPaise(b.totalPaise)}). No charge occurs until a verified driver accepts and you confirm.
        </span>
      </div>
    </div>
  );
}
