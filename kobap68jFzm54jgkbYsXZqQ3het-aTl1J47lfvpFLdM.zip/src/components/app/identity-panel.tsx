"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { Fingerprint, Info, ShieldCheck, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge, Alert } from "@/components/ui/primitives";
import { post, ApiError } from "@/lib/client/api";
import { useToast } from "@/components/ui/toast";
import { VERIFICATION_MODE } from "@/lib/config/features";

export function IdentityPanel({
  status, provider, verifiedAt,
}: { status: "unverified" | "pending" | "verified" | "rejected"; provider: string | null; verifiedAt: string | null }) {
  const router = useRouter();
  const { push } = useToast();
  const [busy, setBusy] = React.useState(false);

  async function start() {
    setBusy(true);
    try {
      await post("/api/profile/identity", {});
      push({
        tone: "info",
        title: "Identity marked verified (simulated)",
        description: "No document was reviewed. In production this requires a configured identity provider.",
      });
      router.refresh();
    } catch (err) {
      push({ tone: "error", title: "Could not start the check", description: err instanceof ApiError ? err.message : "Try again" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="card p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-2.5">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-[#F4F3FF] text-indigo"><Fingerprint className="h-4 w-4" /></span>
          <div>
            <p className="text-[13px] font-semibold text-navy">Identity verification</p>
            <p className="mt-0.5 text-[11px] leading-relaxed text-ink-muted">
              Optional. Adds a trust badge and a small boost to your match score. Documents are handled by a verification provider in
              production — never stored by FlightShare.
            </p>
          </div>
        </div>
        <Badge tone={status === "verified" ? "success" : status === "pending" ? "amber" : "muted"} className="shrink-0 capitalize">{status}</Badge>
      </div>

      <div className="mt-3">
        {VERIFICATION_MODE === "simulated" ? (
          <Alert tone="warning" title="Simulated in this environment">
            No identity provider is configured, so this control marks your account as <strong>simulated-verified</strong> and is labelled that
            way everywhere it appears. It is not a real identity check.
          </Alert>
        ) : (
          <Alert tone="info" title="Provider configured">
            A verification provider is connected. You will be redirected to complete a document check.
          </Alert>
        )}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Button size="md" loading={busy} onClick={start} disabled={status === "verified"} leftIcon={<ShieldCheck className="h-4 w-4" />}>
          {status === "verified" ? "Verified" : "Run simulated check"}
        </Button>
        {verifiedAt && <span className="text-[10.5px] text-ink-muted">Marked {new Date(verifiedAt).toLocaleDateString("en-IN")} · provider {provider ?? "simulated"}</span>}
      </div>

      <p className="mt-3 flex items-start gap-1.5 text-[10px] leading-relaxed text-ink-muted">
        <Info className="mt-px h-3 w-3 shrink-0" />
        We minimise identity data: only the verification result and a provider reference are retained. Raw documents are never visible to other
        passengers or to FlightShare staff beyond the review queue.
      </p>
      <p className="mt-1.5 flex items-start gap-1.5 text-[10px] leading-relaxed text-amber-dark">
        <TriangleAlert className="mt-px h-3 w-3 shrink-0" />
        For a real launch, identity handling must meet applicable Indian data-protection requirements, including consent and retention limits.
      </p>
    </div>
  );
}
