"use client";
import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight, BadgeCheck, Briefcase, Clock, Info, MapPin, Route, ShieldAlert, Users, X,
} from "lucide-react";
import { Avatar, Badge, DemoBadge, ScoreRing } from "@/components/ui/primitives";
import { Button } from "@/components/ui/button";
import { formatPaise } from "@/lib/money";
import { formatTime, cn } from "@/lib/utils";
import type { MatchResult, MatchReason } from "@/lib/match/score";

export interface MatchCardData {
  groupId: string;
  code: string;
  destinationName: string;
  extraStops: string[];
  distanceKm: number;
  driveMinutes: number;
  vehicleCategory: string;
  seatsAvailable: number;
  seatsTotal: number;
  passengers: { name: string; verified: boolean; identityVerified: boolean }[];
  perPersonPaise: number;
  totalPaise: number;
  soloPaise: number;
  savingsPct: number;
  departureWindowStart: string;
  departureWindowEnd: string;
  maxWaitMinutes: number;
  luggageAvailable: number;
  flightVerifiedCount: number;
  isDemo: boolean;
}

export function MatchCard({
  data, match, rank, authed,
}: { data: MatchCardData; match: MatchResult; rank: number; authed: boolean }) {
  const router = useRouter();
  const [showReasons, setShowReasons] = React.useState(false);
  const strong = match.score >= 70;
  const reasons = match.reasons.filter((r) => r.tone === "positive").slice(0, 3);

  function onJoin() {
    if (!authed) {
      router.push(`/login?next=${encodeURIComponent(`/rides/${data.groupId}/join`)}`);
      return;
    }
    router.push(`/rides/${data.groupId}/join`);
  }

  return (
    <article className={cn("card overflow-hidden transition-shadow hover:shadow-lift", !match.eligible && "opacity-[0.92]")}>
      <div className={cn("h-1 w-full", match.eligible ? (strong ? "bg-gradient-to-r from-indigo to-[#8C82FF]" : "bg-amber") : "bg-[#E4E7EC]")} />
      <div className="p-4 sm:p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-1.5">
              <Badge tone="muted">#{rank} match</Badge>
              <Badge tone="indigo">{data.vehicleCategory.toUpperCase()}</Badge>
              {data.isDemo && <DemoBadge label="DEMO" />}
              {match.blockers.length === 0 && data.seatsAvailable > 0 ? (
                <Badge tone="success">{data.seatsAvailable} seat{data.seatsAvailable === 1 ? "" : "s"} free</Badge>
              ) : (
                <Badge tone="danger">Cannot join</Badge>
              )}
            </div>
            <h3 className="mt-2 text-[18px] font-bold tracking-[-0.01em] text-navy">{data.destinationName}</h3>
            <p className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11.5px] text-ink-muted">
              <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" />{data.distanceKm} km</span>
              <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" />~{data.driveMinutes} min drive</span>
              {data.extraStops.length > 0 && (
                <span className="inline-flex items-center gap-1">
                  <Route className="h-3 w-3" /> then {data.extraStops.join(", ")}
                </span>
              )}
            </p>
          </div>
          <div className="flex shrink-0 flex-col items-center">
            <ScoreRing score={match.score} size={58} />
            <span className="mt-1 text-[9.5px] font-semibold uppercase tracking-wide text-ink-muted">match</span>
          </div>
        </div>

        <div className="mt-3.5 grid gap-2.5 rounded-xl border border-line bg-[#FBFBFE] p-3 sm:grid-cols-3">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-muted">Est. per person</p>
            <p className="text-[17px] font-bold text-navy tabular">{formatPaise(data.perPersonPaise)}</p>
            <p className="text-[10.5px] text-ink-muted">of {formatPaise(data.totalPaise)} group total</p>
          </div>
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-muted">vs solo cab</p>
            <p className="text-[13.5px] font-bold text-navy tabular line-through decoration-[#C7CBD6]">{formatPaise(data.soloPaise)}</p>
            <p className={cn("text-[10.5px] font-semibold", data.savingsPct > 0 ? "text-success-dark" : "text-amber-dark")}>
              {data.savingsPct > 0 ? `save ~${data.savingsPct}%` : "no saving — see breakdown"}
            </p>
          </div>
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-muted">Departure window</p>
            <p className="text-[13px] font-bold text-navy tabular">
              {formatTime(data.departureWindowStart)} – {formatTime(data.departureWindowEnd)}
            </p>
            <p className="text-[10.5px] text-ink-muted">waits up to {data.maxWaitMinutes} min</p>
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="flex -space-x-1.5">
              {data.passengers.slice(0, 3).map((p, i) => (
                <Avatar key={i} name={p.name} size="xs" verified={p.identityVerified} className="ring-2 ring-white" />
              ))}
            </div>
            <span className="text-[11.5px] text-ink-muted">
              {data.passengers.length} interested · {data.seatsAvailable}/{data.seatsTotal} seats free
            </span>
          </div>
          <div className="flex items-center gap-2.5 text-[11px] text-ink-muted">
            <span className="inline-flex items-center gap-1"><Briefcase className="h-3 w-3" />{data.luggageAvailable} bag space</span>
            <span className="inline-flex items-center gap-1">
              <BadgeCheck className={cn("h-3 w-3", data.flightVerifiedCount > 0 ? "text-success" : "text-ink-muted")} />
              {data.flightVerifiedCount}/{data.passengers.length} flight-verified
            </span>
          </div>
        </div>

        {reasons.length > 0 && (
          <ul className="mt-3 flex flex-wrap gap-1.5">
            {reasons.map((r) => (
              <li key={r.label} className="inline-flex items-center gap-1 rounded-md bg-success-soft px-1.5 py-1 text-[10.5px] font-medium text-success-dark">
                <span className="h-1 w-1 rounded-full bg-success" /> {r.label}
              </li>
            ))}
          </ul>
        )}

        {match.blockers.length > 0 && (
          <div className="mt-3 flex items-start gap-1.5 rounded-lg border border-[#FBD5D1] bg-danger-soft px-2.5 py-2 text-[11.5px] text-[#912018]">
            <ShieldAlert className="mt-px h-3.5 w-3.5 shrink-0" />
            <span>{match.blockers.join(" · ")}</span>
          </div>
        )}

        <div className="mt-4 flex items-center gap-2">
          <Link href={`/rides/${data.groupId}`} className="flex-1">
            <Button variant="outline" size="md" className="w-full">View Ride</Button>
          </Link>
          <Button
            size="md"
            className="flex-1"
            disabled={!match.eligible}
            onClick={onJoin}
            rightIcon={match.eligible ? <ArrowRight className="h-4 w-4" /> : undefined}
          >
            {match.eligible ? "Request to Join" : "Unavailable"}
          </Button>
          <button
            onClick={() => setShowReasons(true)}
            className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-line text-ink-muted transition hover:text-indigo"
            aria-label="Why this match score"
          >
            <Info className="h-4 w-4" />
          </button>
        </div>
      </div>

      <ReasonSheet open={showReasons} onClose={() => setShowReasons(false)} reasons={match.reasons} score={match.score} components={match.components} />
    </article>
  );
}

function ReasonSheet({
  open, onClose, reasons, score, components,
}: {
  open: boolean; onClose: () => void; reasons: MatchReason[];
  score: number; components: Record<string, number>;
}) {
  React.useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const labels: Record<string, string> = {
    flight: "Flight identity", destination: "Destination compatibility", capacity: "Seats",
    luggage: "Luggage space", timing: "Timing", route: "Route efficiency", trust: "Verification",
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center sm:items-center" role="dialog" aria-modal="true" aria-label="Match score explanation">
      <div className="absolute inset-0 bg-[#101828]/40" onClick={onClose} />
      <div className="relative w-full max-w-md animate-slide-in rounded-t-3xl border border-line bg-white p-5 shadow-lift sm:rounded-3xl">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-[16px] font-bold text-navy">Why this score?</h2>
            <p className="mt-0.5 text-[12px] text-ink-muted">Transparent, weighted, and configurable by operations.</p>
          </div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-ink-muted hover:bg-[#F2F4F9]" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-4 flex items-center gap-3 rounded-xl bg-[#F7F6FF] p-3">
          <ScoreRing score={score} size={52} />
          <div>
            <p className="text-[13px] font-semibold text-navy">Composite match score</p>
            <p className="text-[11.5px] text-ink-muted">Weighted across seven explainable dimensions.</p>
          </div>
        </div>

        <dl className="mt-4 space-y-2.5">
          {Object.entries(components).map(([key, value]) => (
            <div key={key}>
              <div className="flex items-center justify-between text-[11.5px]">
                <dt className="font-medium text-ink-soft">{labels[key] ?? key}</dt>
                <dd className="font-semibold text-navy tabular">{Math.round(value * 100)}%</dd>
              </div>
              <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-[#EEF0F6]">
                <div className="h-full rounded-full bg-indigo" style={{ width: `${Math.round(value * 100)}%` }} />
              </div>
            </div>
          ))}
        </dl>

        <ul className="mt-4 space-y-2 border-t border-line pt-3">
          {reasons.map((r) => (
            <li key={r.label} className="flex gap-2">
              <span className={cn(
                "mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full",
                r.tone === "positive" ? "bg-success" : r.tone === "warning" ? "bg-amber" : "bg-[#98A2B3]",
              )} />
              <div>
                <p className="text-[12px] font-semibold text-navy">{r.label}</p>
                <p className="text-[11.5px] leading-relaxed text-ink-muted">{r.detail}</p>
              </div>
            </li>
          ))}
        </ul>
        <p className="mt-4 rounded-lg bg-[#F9FAFD] px-3 py-2 text-[10.5px] leading-relaxed text-ink-muted">
          <Users className="mr-1 inline h-3 w-3" />
          Scores never reveal another passenger&apos;s booking reference, contact details or documents.
        </p>
      </div>
    </div>
  );
}
