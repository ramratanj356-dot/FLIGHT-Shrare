"use client";
import * as React from "react";
import { Flag, Loader2, Send, ShieldAlert } from "lucide-react";
import { Avatar } from "@/components/ui/primitives";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/primitives";
import { ApiError, post } from "@/lib/client/api";
import { useToast } from "@/components/ui/toast";
import { formatTime, relativeTime, cn } from "@/lib/utils";

export interface ChatMessage {
  id: string;
  body: string;
  kind: string;
  created_at: string;
  sender_user_id: string;
  sender_name: string;
  is_mine: number;
}

const SYSTEM_KINDS = new Set(["system", "meeting_point", "readiness", "fare_update", "driver_assigned"]);

export function GroupChat({
  rideId, initialMessages, currentUserId, readOnly, conversationId,
}: {
  rideId: string;
  initialMessages: ChatMessage[];
  currentUserId: string;
  readOnly?: boolean;
  conversationId: string | null;
}) {
  const [messages, setMessages] = React.useState<ChatMessage[]>(initialMessages);
  const [body, setBody] = React.useState("");
  const [sending, setSending] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [reporting, setReporting] = React.useState<ChatMessage | null>(null);
  const [reportReason, setReportReason] = React.useState("");
  const listRef = React.useRef<HTMLDivElement>(null);
  const { push } = useToast();

  const scrollToBottom = React.useCallback((smooth = true) => {
    const el = listRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: smooth ? "smooth" : "auto" });
  }, []);

  React.useEffect(() => { scrollToBottom(false); }, [scrollToBottom]);

  // Poll for new messages (swap for Supabase Realtime without changing this UI).
  React.useEffect(() => {
    let cancelled = false;
    const interval = setInterval(async () => {
      if (document.hidden) return;
      try {
        const res = await fetch(`/api/rides/${rideId}/state`, { credentials: "same-origin" });
        if (!res.ok) return;
        const json = await res.json();
        const incoming = (json?.data?.messages ?? []) as ChatMessage[];
        if (cancelled || incoming.length === 0) return;
        setMessages((prev) => {
          const seen = new Set(prev.map((m) => m.id));
          const fresh = incoming.filter((m) => !seen.has(m.id));
          if (fresh.length === 0) return prev;
          requestAnimationFrame(() => scrollToBottom());
          return [...prev, ...fresh];
        });
      } catch {
        /* keep last good state; the banner in the trip page reports staleness */
      }
    }, 6000);
    return () => { cancelled = true; clearInterval(interval); };
  }, [rideId, scrollToBottom]);

  React.useEffect(() => {
    if (!conversationId) return;
    post("/api/messages/read", { conversationId }).catch(() => {});
  }, [conversationId, messages.length]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    const text = body.trim();
    if (!text || sending) return;
    setSending(true);
    setError(null);
    // optimistic append
    const optimistic: ChatMessage = {
      id: `local_${Date.now()}`, body: text, kind: "text", created_at: new Date().toISOString(),
      sender_user_id: currentUserId, sender_name: "You", is_mine: 1,
    };
    setMessages((m) => [...m, optimistic]);
    setBody("");
    requestAnimationFrame(() => scrollToBottom());
    try {
      await post("/api/messages", { rideId, body: text });
    } catch (err) {
      setMessages((m) => m.filter((x) => x.id !== optimistic.id));
      setBody(text);
      const message = err instanceof ApiError ? err.message : "Message not sent";
      setError(message);
      push({ tone: "error", title: "Message not sent", description: message });
    } finally {
      setSending(false);
    }
  }

  async function submitReport() {
    if (!reporting) return;
    try {
      await post("/api/reports", { messageId: reporting.id, reason: reportReason || "Reported from ride chat" });
      push({ tone: "success", title: "Reported", description: "Trust & safety will review this message." });
      setReporting(null);
      setReportReason("");
    } catch (err) {
      push({ tone: "error", title: "Could not report", description: err instanceof ApiError ? err.message : "Try again" });
    }
  }

  return (
    <div className="card flex h-[520px] flex-col overflow-hidden">
      <div className="flex items-center justify-between border-b border-line px-4 py-2.5">
        <div>
          <p className="text-[13px] font-semibold text-navy">Ride chat</p>
          <p className="text-[10.5px] text-ink-muted">Only accepted passengers and the coordinator can read this.</p>
        </div>
        <span className="rounded-full bg-success-soft px-2 py-0.5 text-[9.5px] font-bold uppercase tracking-wide text-success-dark">Live</span>
      </div>

      <div ref={listRef} className="flex-1 space-y-2.5 overflow-y-auto px-4 py-3 scrollbar-thin">
        {messages.length === 0 && (
          <p className="py-10 text-center text-[12px] text-ink-muted">No messages yet. Say hello and share your baggage belt.</p>
        )}
        {messages.map((m) => {
          const mine = m.sender_user_id === currentUserId;
          const system = SYSTEM_KINDS.has(m.kind);
          if (system) {
            return (
              <div key={m.id} className="flex justify-center">
                <p className={cn(
                  "max-w-[92%] rounded-lg px-2.5 py-1.5 text-center text-[10.5px] leading-relaxed",
                  m.kind === "meeting_point" ? "bg-indigo-50 text-indigo-700" : "bg-[#F2F4F7] text-ink-muted",
                )}>
                  {m.body}
                  <span className="ml-1.5 opacity-60">{formatTime(m.created_at)}</span>
                </p>
              </div>
            );
          }
          return (
            <div key={m.id} className={cn("group flex gap-2", mine && "flex-row-reverse")}>
              {!mine && <Avatar name={m.sender_name} size="xs" className="mt-0.5" />}
              <div className={cn("max-w-[78%]", mine && "text-right")}>
                {!mine && <p className="mb-0.5 text-[10px] font-medium text-ink-muted">{m.sender_name.split(" ")[0]}</p>}
                <div className={cn(
                  "relative inline-block rounded-2xl px-3 py-2 text-left text-[12.5px] leading-relaxed",
                  mine ? "rounded-br-md bg-indigo text-white" : "rounded-bl-md bg-[#F2F4F7] text-ink",
                )}>
                  {m.body}
                </div>
                <p className="mt-0.5 flex items-center gap-1.5 text-[9.5px] text-[#98A2B3]" style={{ justifyContent: mine ? "flex-end" : "flex-start" }}>
                  {relativeTime(m.created_at)}
                  {!mine && (
                    <button onClick={() => setReporting(m)} className="opacity-0 transition group-hover:opacity-100" aria-label="Report message">
                      <Flag className="h-2.5 w-2.5" />
                    </button>
                  )}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {error && (
        <div className="mx-4 mb-2 flex items-center gap-1.5 rounded-lg bg-danger-soft px-2.5 py-1.5 text-[11px] text-[#912018]">
          <ShieldAlert className="h-3.5 w-3.5" /> {error}
        </div>
      )}

      {readOnly ? (
        <p className="border-t border-line px-4 py-3 text-center text-[11.5px] text-ink-muted">
          This ride is closed — chat is read-only.
        </p>
      ) : (
        <form onSubmit={send} className="flex items-end gap-2 border-t border-line p-2.5">
          <label htmlFor="chat-input" className="sr-only">Message</label>
          <Textarea
            id="chat-input"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(e); }
            }}
            placeholder="Message the group…"
            className="min-h-[42px] max-h-24 flex-1 resize-none py-2.5 text-[12.5px]"
            maxLength={1000}
          />
          <Button type="submit" size="icon" className="h-[42px] w-[42px]" disabled={!body.trim() || sending} aria-label="Send message">
            {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </form>
      )}

      <Dialog
        open={Boolean(reporting)}
        onClose={() => setReporting(null)}
        title="Report this message"
        description="Reports go to trust & safety with the message text and ride context. The other passenger is not told."
        footer={
          <>
            <Button variant="outline" onClick={() => setReporting(null)}>Cancel</Button>
            <Button variant="danger" onClick={submitReport} disabled={reportReason.trim().length < 10}>
              Submit report
            </Button>
          </>
        }
      >
        <Textarea
          value={reportReason}
          onChange={(e) => setReportReason(e.target.value)}
          placeholder="What happened? (at least 10 characters)"
          className="min-h-[90px]"
        />
      </Dialog>
    </div>
  );
}
