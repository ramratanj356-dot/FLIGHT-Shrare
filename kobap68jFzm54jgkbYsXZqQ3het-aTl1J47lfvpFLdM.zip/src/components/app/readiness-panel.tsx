"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { BaggageClaim, CheckCircle2, Loader2, MapPin, PlaneLanding, PlaneTakeoff, CarFront, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/primitives";
import { post, ApiError } from "@/lib/client/api";
import { useToast } from "@/components/ui/toast";
import { READINESS_LABELS, READINESS_ORDER, type ReadinessState } from "@/lib/config/pricing";
import { cn } from "@/lib/utils";

const ICONS: Record<ReadinessState, React.ComponentType<{ className?: string }>> = {
  not_landed: PlaneTakeoff,
  landed: PlaneLanding,
  collecting_baggage: BaggageClaim,
  ready_at_meeting_point: MapPin,
  boarding_vehicle: CarFront,
  trip_started: CheckCircle2,
};

const ORDER: ReadinessState[] = ["landed", "collecting_baggage", "ready_at_meeting_point", "boarding_vehicle"];

export function ReadinessPanel({
  rideId, current, disabled, disabledReason,
}: { rideId: string; current: ReadinessState; disabled?: boolean; disabledReason?: string }) {
  const router = useRouter();
  const { push } = useToast();
  const [pending, setPending] = React.useState<ReadinessState | null>(null);
  const [error, setError] = React.useState<string | null>(null);

  async function update(next: ReadinessState) {
    setPending(next);
    setError(null);
    try {
      await post(`/api/rides/${rideId}/readiness`, { readiness: next });
      push({ tone: "success", title: "Readiness updated", description: `You are now marked "${READINESS_LABELS[next]}".` });
      router.refresh();
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "Could not update readiness";
      setError(message);
      push({ tone: "error", title: "Update failed", description: message });
    } finally {
      setPending(null);
    }
  }

  return (
    <div className="card p-4">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[13px] font-semibold text-navy">Confirm your readiness</p>
          <p className="mt-0.5 text-[11px] text-ink-muted">Nobody guesses this for you — the group waits on real confirmations.</p>
        </div>
        <Badge tone={current === "ready_at_meeting_point" ? "success" : "amber"}>{READINESS_LABELS[current]}</Badge>
      </div>

      {disabled ? (
        <p className="mt-3 rounded-lg bg-[#F9FAFD] px-3 py-2 text-[11.5px] text-ink-muted">
          {disabledReason ?? "Readiness controls are closed for this ride."}
        </p>
      ) : (
        <div className="mt-3 grid grid-cols-2 gap-2">
          {ORDER.map((state) => {
            const Icon = ICONS[state];
            const active = READINESS_ORDER[current] === READINESS_ORDER[state];
            const past = READINESS_ORDER[current] > READINESS_ORDER[state];
            return (
              <button
                key={state}
                type="button"
                onClick={() => update(state)}
                disabled={pending !== null || active}
                className={cn(
                  "flex items-center gap-2 rounded-xl border p-2.5 text-left text-[11.5px] font-medium transition",
                  active ? "border-success bg-success-soft text-success-dark" : past ? "border-line bg-[#FBFBFE] text-ink-muted" : "border-line bg-white text-ink-soft hover:border-indigo-200 hover:text-indigo",
                  pending === state && "opacity-70",
                )}
                aria-pressed={active}
              >
                {pending === state ? <Loader2 className="h-4 w-4 shrink-0 animate-spin" /> : <Icon className="h-4 w-4 shrink-0" />}
                <span className="leading-tight">{READINESS_LABELS[state]}</span>
              </button>
            );
          })}
        </div>
      )}

      {error && (
        <div className="mt-2 flex items-start gap-1.5 rounded-lg border border-[#FBD5D1] bg-danger-soft px-2.5 py-2 text-[11px] text-[#912018]">
          <AlertTriangle className="mt-px h-3.5 w-3.5 shrink-0" />
          {error}
        </div>
      )}

      <p className="mt-3 text-[10px] leading-relaxed text-ink-muted">
        Readiness is shared with the group as a status only. Your exact location is never broadcast before pickup.
      </p>
    </div>
  );
}
