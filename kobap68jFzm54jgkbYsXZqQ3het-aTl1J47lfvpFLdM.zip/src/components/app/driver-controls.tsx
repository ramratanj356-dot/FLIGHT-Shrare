"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { Car, Check, CircleCheck, Flag, Play, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { ApiError, post } from "@/lib/client/api";
import { useToast } from "@/components/ui/toast";

export function AcceptRideButton({ rideId, disabled }: { rideId: string; disabled?: boolean }) {
  const router = useRouter();
  const { push } = useToast();
  const [busy, setBusy] = React.useState(false);
  const [confirm, setConfirm] = React.useState(false);

  async function accept() {
    setBusy(true);
    try {
      await post("/api/driver/accept", { rideGroupId: rideId });
      push({ tone: "success", title: "Trip accepted", description: "Passengers have been notified with your vehicle details." });
      setConfirm(false);
      router.refresh();
    } catch (err) {
      push({ tone: "error", title: "Could not accept", description: err instanceof ApiError ? err.message : "Try again" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <Button size="md" className="flex-1" disabled={disabled} onClick={() => setConfirm(true)} leftIcon={<Check className="h-4 w-4" />}>
        Accept trip
      </Button>
      <Dialog
        open={confirm}
        onClose={() => setConfirm(false)}
        title="Accept this trip?"
        description="You are committing to pick this group up at the agreed meeting point within their waiting window. Passengers will see your name and vehicle."
        footer={
          <>
            <Button variant="outline" onClick={() => setConfirm(false)}>Not now</Button>
            <Button onClick={accept} loading={busy}>Accept trip</Button>
          </>
        }
      >
        <p className="rounded-xl bg-[#F9FAFD] px-3 py-2.5 text-[11.5px] leading-relaxed text-ink-muted">
          Accepting confirms transport for this group. Fares shown are estimates until the trip completes, when your earnings are recorded in
          the settlement ledger.
        </p>
      </Dialog>
    </>
  );
}

export function TripStatusControls({ rideId, status }: { rideId: string; status: string }) {
  const router = useRouter();
  const { push } = useToast();
  const [busy, setBusy] = React.useState<string | null>(null);

  async function act(next: "arrived" | "start" | "complete") {
    setBusy(next);
    try {
      await post("/api/driver/trip", { rideGroupId: rideId, status: next });
      push({
        tone: "success",
        title: next === "arrived" ? "Arrival broadcast" : next === "start" ? "Trip started" : "Trip completed",
        description: next === "complete" ? "Earnings recorded. Passengers can now rate the trip." : "Passengers have been notified.",
      });
      router.refresh();
    } catch (err) {
      push({ tone: "error", title: "Update failed", description: err instanceof ApiError ? err.message : "Try again" });
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="flex flex-wrap gap-1.5">
      <Button size="sm" variant="outline" onClick={() => act("arrived")} loading={busy === "arrived"} leftIcon={<Flag className="h-3.5 w-3.5" />}>
        I&apos;ve arrived
      </Button>
      <Button size="sm" variant="secondary" onClick={() => act("start")} loading={busy === "start"} disabled={status === "in_progress"} leftIcon={<Play className="h-3.5 w-3.5" />}>
        Start trip
      </Button>
      <Button size="sm" variant="success" onClick={() => act("complete")} loading={busy === "complete"} leftIcon={<CircleCheck className="h-3.5 w-3.5" />}>
        Complete
      </Button>
    </div>
  );
}
