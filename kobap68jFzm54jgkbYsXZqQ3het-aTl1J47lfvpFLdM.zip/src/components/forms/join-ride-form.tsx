"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { AlertCircle, ArrowRight, CheckCircle, Info, Ticket, Users } from "lucide-react";
import { joinRequestSchema, type JoinRequestInput } from "@/lib/validation/schemas";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Checkbox, Badge, Alert } from "@/components/ui/primitives";
import { DestinationPicker } from "./destination-picker";
import { Dialog } from "@/components/ui/dialog";
import { ApiError, post } from "@/lib/client/api";
import { useToast } from "@/components/ui/toast";

interface Props {
  rideGroupId: string;
  destinations: { id: string; name: string; area: string; distanceKm: number; soloFarePaise: number; compatibility: number }[];
  defaultDestinationId: string;
  maxSeats: number;
  maxLuggage: number;
  matchScore: number;
  matchReasons: string[];
}

export function JoinRideForm({
  rideGroupId, destinations, defaultDestinationId, maxSeats, maxLuggage, matchScore, matchReasons,
}: Props) {
  const router = useRouter();
  const { push } = useToast();
  const [destinationId, setDestinationId] = React.useState(defaultDestinationId);
  const [error, setError] = React.useState<string | null>(null);
  const [success, setSuccess] = React.useState<{ autoApproved?: boolean } | null>(null);
  const [confirmOpen, setConfirmOpen] = React.useState(false);

  const {
    register, handleSubmit, setValue, watch, formState: { errors, isSubmitting },
  } = useForm<JoinRequestInput>({
    resolver: zodResolver(joinRequestSchema),
    defaultValues: {
      rideGroupId, passengerCount: 1, luggageUnits: Math.min(1, Math.max(0, maxLuggage)),
      destinationId: defaultDestinationId, bookingReference: "", message: "",
    },
  });

  const passengerCount = Number(watch("passengerCount") ?? 1);
  const selected = destinations.find((d) => d.id === destinationId);
  const seatsOk = passengerCount <= maxSeats;

  React.useEffect(() => setValue("destinationId", destinationId), [destinationId, setValue]);

  async function onSubmit(values: JoinRequestInput) {
    setError(null);
    try {
      const res = await post<{ requestId: string; requiresApproval: boolean }>("/api/join", values);
      setSuccess({ autoApproved: !res.requiresApproval });
      push({ tone: "success", title: "Request sent", description: "The coordinator has been notified. Nothing has been charged." });
      setTimeout(() => router.push(`/app/trips/${rideGroupId}?requested=1`), 1800);
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "Could not send your request";
      setError(message);
      setConfirmOpen(false);
      push({ tone: "error", title: "Request not sent", description: message });
    }
  }

  if (success) {
    return (
      <div className="card p-6 text-center">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-success-soft">
          <CheckCircle className="h-7 w-7 text-success" />
        </div>
        <h2 className="mt-4 text-[18px] font-bold text-navy">Request sent to the coordinator</h2>
        <p className="mx-auto mt-1.5 max-w-sm text-[13px] leading-relaxed text-ink-muted">
          You&apos;ll get a notification the moment they decide. Your fare is not final and nothing has been charged — the group split is
          recalculated when you&apos;re accepted.
        </p>
        <div className="mt-4 flex flex-wrap justify-center gap-2">
          <Button variant="outline" onClick={() => router.push("/app/trips")}>My trips</Button>
          <Button onClick={() => router.push("/app")} rightIcon={<ArrowRight className="h-4 w-4" />}>Dashboard</Button>
        </div>
        <p className="mt-3 text-[10.5px] text-ink-muted">Redirecting you to your trips…</p>
      </div>
    );
  }

  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)} className="card p-4 sm:p-5" noValidate>
        <div className="flex items-center justify-between">
          <h2 className="text-[15px] font-semibold text-navy">Your details for this ride</h2>
          <Badge tone="indigo">Match {matchScore}/100</Badge>
        </div>
        {matchReasons.length > 0 && (
          <ul className="mt-2 flex flex-wrap gap-1.5">
            {matchReasons.map((r) => (
              <li key={r} className="rounded-md bg-success-soft px-1.5 py-1 text-[10px] font-medium text-success-dark">{r}</li>
            ))}
          </ul>
        )}

        <div className="mt-4 grid gap-3.5 sm:grid-cols-2">
          <Field label="Your drop-off" htmlFor="dest" error={errors.destinationId?.message}>
            <DestinationPicker
              id="dest"
              destinations={destinations.filter((d) => d.compatibility > 0).map((d) => ({
                id: d.id, name: d.name, area: `${d.area} · ${Math.round(d.compatibility * 100)}% route match`,
                distanceKm: d.distanceKm, soloFarePaise: d.soloFarePaise,
              }))}
              value={destinationId}
              onChange={(v) => { setDestinationId(v); setValue("destinationId", v); }}
              placeholder="Choose a compatible drop-off"
            />
            <p className="hint">Only destinations on this ride&apos;s route are offered.</p>
          </Field>

          <Field label="Passengers" htmlFor="pax" error={errors.passengerCount?.message}>
            <div className="relative">
              <Users className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
              <Select id="pax" className="pl-9" {...register("passengerCount")}>
                {Array.from({ length: Math.max(1, Math.min(6, maxSeats)) }).map((_, i) => (
                  <option key={i + 1} value={i + 1}>{i + 1} passenger{i > 0 ? "s" : ""}</option>
                ))}
              </Select>
            </div>
            {!seatsOk && <p className="hint text-danger">Only {maxSeats} seat(s) left in this ride.</p>}
          </Field>

          <Field label="Luggage units" htmlFor="luggage" error={errors.luggageUnits?.message} hint={`This vehicle has space for ${maxLuggage} more unit(s).`}>
            <Select id="luggage" {...register("luggageUnits")}>
              {Array.from({ length: Math.min(5, Math.max(0, maxLuggage)) + 1 }).map((_, i) => (
                <option key={i} value={i}>{i === 0 ? "Cabin bag only" : `${i} checked bag${i > 1 ? "s" : ""}`}</option>
              ))}
            </Select>
          </Field>

          <Field label="Booking reference" htmlFor="ref" error={errors.bookingReference?.message} optional hint="Used to verify you were on this flight.">
            <div className="relative">
              <Ticket className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
              <Input id="ref" placeholder="e.g. 6X7Y2Q" className="pl-9 uppercase" maxLength={8} {...register("bookingReference")} />
            </div>
          </Field>
        </div>

        <div className="mt-3.5">
          <Field label="Message to the coordinator" htmlFor="msg" error={errors.message?.message} optional>
            <Input id="msg" placeholder="e.g. Landed with one bag, happy to be the second drop-off" maxLength={280} {...register("message")} />
          </Field>
        </div>

        <div className="mt-3.5 rounded-xl border border-indigo-100 bg-[#F7F6FF] px-3 py-2.5">
          <p className="flex items-start gap-1.5 text-[11px] leading-relaxed text-indigo-700">
            <Info className="mt-px h-3.5 w-3.5 shrink-0" />
            Your booking reference is stored hashed and masked. In demo mode the verification is simulated and labelled as such — no airline
            system is contacted.
          </p>
        </div>

        {error && (
          <div className="mt-3 flex items-start gap-2 rounded-xl border border-[#FBD5D1] bg-danger-soft px-3 py-2.5 text-[12px] text-[#912018]" role="alert">
            <AlertCircle className="mt-px h-4 w-4 shrink-0" />
            <div>
              {error}
              <button type="button" onClick={() => setError(null)} className="ml-1 underline">Dismiss</button>
            </div>
          </div>
        )}

        <Button
          type="button"
          size="lg"
          className="mt-4 w-full"
          onClick={handleSubmit(() => setConfirmOpen(true))}
          disabled={!seatsOk}
          rightIcon={<ArrowRight className="h-4 w-4" />}
        >
          Review &amp; send request
        </Button>
        <p className="mt-2 text-center text-[10.5px] text-ink-muted">
          You will confirm the final fare before any payment. Requesting a seat is always free.
        </p>

        <Dialog
          open={confirmOpen}
          onClose={() => setConfirmOpen(false)}
          title="Send this request?"
          description="The coordinator sees your first name, destination, passenger count and bag size. Nothing is charged."
          footer={
            <>
              <Button variant="outline" onClick={() => setConfirmOpen(false)}>Go back</Button>
              <Button onClick={handleSubmit(onSubmit)} loading={isSubmitting}>Send request</Button>
            </>
          }
        >
          <dl className="space-y-2 rounded-xl border border-line bg-[#FBFBFE] p-3 text-[12px]">
            <div className="flex justify-between"><dt className="text-ink-muted">Drop-off</dt><dd className="font-medium text-navy">{selected?.name}</dd></div>
            <div className="flex justify-between"><dt className="text-ink-muted">Passengers</dt><dd className="font-medium text-navy">{passengerCount}</dd></div>
            <div className="flex justify-between"><dt className="text-ink-muted">Route match</dt><dd className="font-medium text-navy">{Math.round((selected?.compatibility ?? 0) * 100)}%</dd></div>
            <div className="flex justify-between border-t border-line pt-2"><dt className="text-ink-muted">Match score</dt><dd className="font-bold text-indigo">{matchScore}/100</dd></div>
          </dl>
          <label className="mt-3 flex items-start gap-2 text-[11px] leading-relaxed text-ink-soft">
            <Checkbox defaultChecked className="mt-0.5" />
            I&apos;ll confirm readiness at the meeting point and understand this is an estimate, not a booking, until a driver accepts.
          </label>
        </Dialog>
      </form>
    </>
  );
}
