"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowRight, Car, Clock, Info, Plane, Users } from "lucide-react";
import { createRideSchema } from "@/lib/validation/schemas";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Alert } from "@/components/ui/primitives";
import { DestinationPicker } from "./destination-picker";
import { ApiError, post } from "@/lib/client/api";
import { useToast } from "@/components/ui/toast";
import { STRATEGY_HELP, STRATEGY_LABELS, VEHICLE_LABELS, type VehicleCategory, type FareStrategy } from "@/lib/config/pricing";
import { cn } from "@/lib/utils";

type Values = z.infer<typeof createRideSchema>;

export function CreateRideForm({
  destinations, defaultFlight, defaultDate, defaultDestinationId, capacity, defaultMaxWait, defaultStrategy,
}: {
  destinations: { id: string; name: string; area: string; distanceKm: number; soloFarePaise: number }[];
  defaultFlight: string; defaultDate: string; defaultDestinationId: string;
  capacity: Record<VehicleCategory, { seats: number; luggage: number }>;
  defaultMaxWait: number; defaultStrategy: FareStrategy;
}) {
  const router = useRouter();
  const { push } = useToast();
  const [destinationId, setDestinationId] = React.useState(defaultDestinationId);
  const [error, setError] = React.useState<string | null>(null);

  const { register, handleSubmit, setValue, watch, formState: { errors, isSubmitting } } = useForm<Values>({
    resolver: zodResolver(createRideSchema),
    defaultValues: {
      flightNumber: defaultFlight, flightDate: defaultDate, airportId: "apt_bom",
      destinationId: defaultDestinationId, vehicleCategory: "sedan", maxWaitMinutes: defaultMaxWait,
      strategy: defaultStrategy, passengerCount: 1, luggageUnits: 1, meetPoint: "",
    },
  });

  const vehicle = watch("vehicleCategory") as VehicleCategory;
  const strategy = watch("strategy") as FareStrategy;
  React.useEffect(() => setValue("destinationId", destinationId), [destinationId, setValue]);

  async function onSubmit(values: Values) {
    setError(null);
    try {
      const res = await post<{ rideGroupId: string; code: string }>("/api/rides", values);
      push({ tone: "success", title: `Ride ${res.code} created`, description: "Your group is live. Passengers on the same flight can now request a seat." });
      router.push(`/app/trips/${res.rideGroupId}`);
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "Could not create the ride";
      setError(message);
      push({ tone: "error", title: "Ride not created", description: message });
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="card p-4 sm:p-5" noValidate>
      <h2 className="text-[15px] font-semibold text-navy">Flight &amp; destination</h2>
      <div className="mt-3.5 grid gap-3.5 sm:grid-cols-2">
        <Field label="Flight number" htmlFor="flightNumber" error={errors.flightNumber?.message} required hint="Must exist in the BOM schedule for that date.">
          <div className="relative">
            <Plane className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
            <Input id="flightNumber" placeholder="AI 864" className="pl-9 uppercase" {...register("flightNumber")} />
          </div>
        </Field>
        <Field label="Arrival date" htmlFor="flightDate" error={errors.flightDate?.message} required>
          <Input id="flightDate" type="date" {...register("flightDate")} />
        </Field>
        <Field label="Destination" htmlFor="dest" error={errors.destinationId?.message} required className="sm:col-span-2">
          <DestinationPicker id="dest" destinations={destinations} value={destinationId} onChange={(v) => { setDestinationId(v); setValue("destinationId", v); }} />
        </Field>
      </div>

      <div className="mt-5 divider" />
      <h2 className="mt-4 text-[15px] font-semibold text-navy">Vehicle &amp; capacity</h2>
      <div className="mt-2.5 grid grid-cols-3 gap-2">
        {(Object.keys(capacity) as VehicleCategory[]).map((v) => (
          <label key={v} className={cn("cursor-pointer rounded-xl border p-2.5 text-center transition", vehicle === v ? "border-indigo bg-[#F7F6FF] ring-2 ring-indigo/10" : "border-line bg-white hover:border-[#C9CFDA]")}>
            <input type="radio" value={v} {...register("vehicleCategory")} className="sr-only" />
            <Car className={cn("mx-auto h-4 w-4", vehicle === v ? "text-indigo" : "text-ink-muted")} />
            <p className="mt-1 text-[12px] font-semibold text-navy">{VEHICLE_LABELS[v]}</p>
            <p className="text-[10px] text-ink-muted">{capacity[v].seats} seats · {capacity[v].luggage} bags</p>
          </label>
        ))}
      </div>

      <div className="mt-3.5 grid gap-3.5 sm:grid-cols-3">
        <Field label="Your passengers" htmlFor="pax">
          <div className="relative">
            <Users className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
            <Select id="pax" className="pl-9" {...register("passengerCount")}>
              {[1, 2, 3, 4].map((n) => <option key={n} value={n}>{n}</option>)}
            </Select>
          </div>
        </Field>
        <Field label="Your luggage" htmlFor="lug">
          <Select id="lug" {...register("luggageUnits")}>
            {[0, 1, 2, 3, 4, 5, 6].map((n) => <option key={n} value={n}>{n === 0 ? "Cabin only" : `${n} bag${n > 1 ? "s" : ""}`}</option>)}
          </Select>
        </Field>
        <Field label="Maximum wait" htmlFor="wait" hint="After landing + baggage.">
          <div className="relative">
            <Clock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
            <Select id="wait" className="pl-9" {...register("maxWaitMinutes")}>
              {[15, 20, 30, 40, 45, 60, 75, 90].map((n) => <option key={n} value={n}>{n} minutes</option>)}
            </Select>
          </div>
        </Field>
      </div>

      <div className="mt-5 divider" />
      <h2 className="mt-4 text-[15px] font-semibold text-navy">Fare split strategy</h2>
      <div className="mt-2.5 space-y-2">
        {(Object.keys(STRATEGY_LABELS) as FareStrategy[]).map((s) => (
          <label key={s} className={cn("flex cursor-pointer items-start gap-2.5 rounded-xl border p-3 transition", strategy === s ? "border-indigo bg-[#F7F6FF]" : "border-line bg-white hover:border-[#C9CFDA]")}>
            <input type="radio" value={s} {...register("strategy")} className="sr-only" />
            <span className={cn("mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full border-2", strategy === s ? "border-indigo" : "border-[#C7CBD6]")}>
              {strategy === s && <span className="h-2 w-2 rounded-full bg-indigo" />}
            </span>
            <span>
              <span className="block text-[12.5px] font-semibold text-navy">{STRATEGY_LABELS[s]}</span>
              <span className="block text-[11px] leading-relaxed text-ink-muted">{STRATEGY_HELP[s]}</span>
            </span>
          </label>
        ))}
      </div>

      <div className="mt-3.5">
        <Field label="Meeting point hint" htmlFor="meet" optional>
          <Input id="meet" placeholder="e.g. T2 Arrivals, Gate 3 by Pillar 14" {...register("meetPoint")} />
        </Field>
      </div>

      <p className="mt-3 flex items-start gap-1.5 rounded-lg bg-[#F9FAFD] px-3 py-2 text-[10.5px] leading-relaxed text-ink-muted">
        <Info className="mt-px h-3 w-3 shrink-0" />
        We will calculate a group estimate immediately and re-split it fairly each time a passenger is approved. Nothing is charged to you or
        to your passengers until a driver accepts and each passenger confirms.
      </p>

      {error && <div className="mt-3"><Alert tone="danger">{error}</Alert></div>}

      <Button type="submit" size="lg" className="mt-4 w-full" loading={isSubmitting} rightIcon={!isSubmitting ? <ArrowRight className="h-4 w-4" /> : undefined}>
        {isSubmitting ? "Creating ride…" : "Create ride group"}
      </Button>
    </form>
  );
}
