"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { AlertCircle, ArrowRight, CheckCircle2, Eye, EyeOff, Mail, Lock, User, Phone } from "lucide-react";
import { loginSchema, signupSchema, forgotPasswordSchema, resetPasswordSchema, type SignupInput } from "@/lib/validation/schemas";
import { Button } from "@/components/ui/button";
import { Alert, Field, Input, Checkbox, Badge } from "@/components/ui/primitives";
import { ApiError, post } from "@/lib/client/api";
import { cn } from "@/lib/utils";

const DEMO_ACCOUNTS = [
  { role: "Passenger", email: "aarav@demo.flightshare.app", password: "Demo@1234", note: "Has an active trip with a join request" },
  { role: "Driver", email: "driver@demo.flightshare.app", password: "Driver@1234", note: "Verified, 4 trips of earnings" },
  { role: "Admin", email: "admin@demo.flightshare.app", password: "Admin@1234", note: "Verification & pricing console" },
];

function PasswordInput({ id, ...props }: React.InputHTMLAttributes<HTMLInputElement> & { id: string }) {
  const [show, setShow] = React.useState(false);
  return (
    <div className="relative">
      <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
      <Input id={id} type={show ? "text" : "password"} className="pl-9 pr-10" {...props} />
      <button
        type="button"
        onClick={() => setShow((s) => !s)}
        className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1.5 text-ink-muted hover:bg-[#F2F4F9]"
        aria-label={show ? "Hide password" : "Show password"}
      >
        {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
      </button>
    </div>
  );
}

export function LoginForm({ next, message, googleEnabled }: { next?: string; message?: string; googleEnabled: boolean }) {
  const router = useRouter();
  const [error, setError] = React.useState<string | null>(null);
  const { register, handleSubmit, setValue, formState: { errors, isSubmitting } } = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "" },
  });

  async function onSubmit(values: z.infer<typeof loginSchema>) {
    setError(null);
    try {
      const res = await post<{ role: string; next: string }>("/api/auth/login", values);
      router.push(next || res.next);
      router.refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not sign in. Try again.");
    }
  }

  return (
    <>
      {message && <div className="mb-4"><Alert tone="success">{message}</Alert></div>}
      <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4" noValidate>
        <Field label="Email" htmlFor="email" error={errors.email?.message}>
          <div className="relative">
            <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
            <Input id="email" type="email" autoComplete="email" placeholder="you@example.com" className="pl-9" {...register("email")} aria-invalid={Boolean(errors.email)} />
          </div>
        </Field>
        <Field label="Password" htmlFor="password" error={errors.password?.message}>
          <PasswordInput id="password" autoComplete="current-password" placeholder="Your password" {...register("password")} />
        </Field>

        <div className="flex items-center justify-between">
          <label className="flex items-center gap-2 text-[12.5px] text-ink-soft">
            <Checkbox defaultChecked /> Keep me signed in for 7 days
          </label>
          <a href="/forgot-password" className="text-[12.5px] font-medium text-indigo hover:underline">Forgot password?</a>
        </div>

        {error && (
          <div className="flex items-start gap-2 rounded-xl border border-[#FBD5D1] bg-danger-soft px-3 py-2.5 text-[12.5px] text-[#912018]" role="alert">
            <AlertCircle className="mt-px h-4 w-4 shrink-0" />
            <div>
              {error}
              <button type="button" onClick={() => setError(null)} className="ml-1 underline">Dismiss</button>
            </div>
          </div>
        )}

        <Button type="submit" size="lg" className="w-full" loading={isSubmitting} rightIcon={!isSubmitting ? <ArrowRight className="h-4 w-4" /> : undefined}>
          {isSubmitting ? "Signing in…" : "Sign in"}
        </Button>
      </form>

      {googleEnabled ? (
        <a href="/api/auth/google" className="mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-line bg-white text-sm font-semibold text-ink transition hover:bg-[#F9FAFD]">
          <svg width="16" height="16" viewBox="0 0 24 24" aria-hidden><path fill="#4285F4" d="M23 12.2c0-.8-.1-1.6-.2-2.3H12v4.4h6.2a5.3 5.3 0 0 1-2.3 3.5v2.9h3.7c2.2-2 3.4-5 3.4-8.5Z"/><path fill="#34A853" d="M12 23.5c3.1 0 5.7-1 7.6-2.8l-3.7-2.9c-1 .7-2.3 1.1-3.9 1.1-3 0-5.6-2-6.5-4.8H1.7v3a11.5 11.5 0 0 0 10.3 6.4Z"/><path fill="#FBBC05" d="M5.5 14.1a7 7 0 0 1 0-4.4v-3H1.7a11.5 11.5 0 0 0 0 10.4l3.8-3Z"/><path fill="#EA4335" d="M12 4.7c1.7 0 3.2.6 4.4 1.7l3.3-3.3A11.5 11.5 0 0 0 1.7 6.7l3.8 3C6.4 6.9 9 4.7 12 4.7Z"/></svg>
          Continue with Google
        </a>
      ) : (
        <button
          type="button"
          disabled
          title="Google sign-in activates when GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET are configured"
          className="mt-3 flex h-11 w-full cursor-not-allowed items-center justify-center gap-2 rounded-xl border border-dashed border-line bg-[#FBFBFE] text-[13px] font-medium text-ink-muted"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" className="opacity-40" aria-hidden><path fill="currentColor" d="M23 12.2c0-.8-.1-1.6-.2-2.3H12v4.4h6.2a5.3 5.3 0 0 1-2.3 3.5v2.9h3.7c2.2-2 3.4-5 3.4-8.5Z"/></svg>
          Google sign-in — not configured
        </button>
      )}

      <div className="mt-6 rounded-xl border border-line bg-white p-3">
        <p className="mb-2 flex items-center gap-1.5 text-[10.5px] font-bold uppercase tracking-wide text-ink-muted">
          Demo accounts <Badge tone="amber" className="ml-auto">SAMPLE</Badge>
        </p>
        <div className="space-y-1">
          {DEMO_ACCOUNTS.map((a) => (
            <button
              key={a.email}
              type="button"
              onClick={() => { setValue("email", a.email); setValue("password", a.password); }}
              className="flex w-full items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-left transition hover:bg-[#F7F8FC]"
            >
              <span className="min-w-0">
                <span className="block text-[11.5px] font-semibold text-navy">{a.role}</span>
                <span className="block truncate text-[10.5px] text-ink-muted">{a.email}</span>
              </span>
              <span className="shrink-0 rounded bg-[#F4F3FF] px-1.5 py-0.5 text-[9.5px] font-bold text-indigo">USE</span>
            </button>
          ))}
        </div>
      </div>
    </>
  );
}

export function SignupForm({ defaultRole }: { defaultRole: "passenger" | "driver" }) {
  const router = useRouter();
  const [error, setError] = React.useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = React.useState<Record<string, string>>({});
  const [devVerifyUrl, setDevVerifyUrl] = React.useState<string | null>(null);
  const { register, handleSubmit, watch, formState: { errors, isSubmitting } } = useForm<SignupInput>({
    resolver: zodResolver(signupSchema),
    defaultValues: { name: "", email: "", phone: "", password: "", role: defaultRole, acceptTerms: false as unknown as true },
  });

  const password = watch("password") ?? "";
  const strength = [
    password.length >= 8,
    /[A-Za-z]/.test(password),
    /\d/.test(password),
    /[^A-Za-z0-9]/.test(password),
  ].filter(Boolean).length;

  async function onSubmit(values: SignupInput) {
    setError(null);
    setFieldErrors({});
    try {
      const res = await post<{ next: string; devVerifyUrl?: string }>("/api/auth/signup", values);
      if (res.devVerifyUrl) {
        setDevVerifyUrl(res.devVerifyUrl);
        router.push(res.devVerifyUrl);
      } else {
        router.push(res.next);
      }
      router.refresh();
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message);
        setFieldErrors(err.fieldErrors ?? {});
      } else setError("Could not create your account. Try again.");
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4" noValidate>
      <div className="grid grid-cols-2 gap-2">
        {(["passenger", "driver"] as const).map((r) => (
          <label key={r} className={cn("cursor-pointer rounded-xl border p-3 transition", watch("role") === r ? "border-indigo bg-[#F7F6FF] ring-2 ring-indigo/10" : "border-line bg-white hover:border-[#C9CFDA]")}>
            <input type="radio" value={r} {...register("role")} className="sr-only" />
            <p className="text-[12.5px] font-semibold capitalize text-navy">{r}</p>
            <p className="mt-0.5 text-[10.5px] leading-snug text-ink-muted">
              {r === "passenger" ? "Share airport rides" : "Drive and earn"}
            </p>
          </label>
        ))}
      </div>

      <Field label="Full name" htmlFor="name" error={errors.name?.message} required>
        <div className="relative">
          <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
          <Input id="name" autoComplete="name" placeholder="As on your ID" className="pl-9" {...register("name")} aria-invalid={Boolean(errors.name)} />
        </div>
      </Field>

      <Field label="Email" htmlFor="email" error={errors.email?.message} required>
        <div className="relative">
          <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
          <Input id="email" type="email" autoComplete="email" placeholder="you@example.com" className="pl-9" {...register("email")} aria-invalid={Boolean(errors.email)} />
        </div>
      </Field>

      <Field label="Mobile number" htmlFor="phone" error={errors.phone?.message} optional hint="Used only for trip updates. Never shown to other passengers.">
        <div className="relative">
          <Phone className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
          <Input id="phone" type="tel" inputMode="tel" autoComplete="tel" placeholder="+91 98200 11001" className="pl-9" {...register("phone")} />
        </div>
      </Field>

      <Field label="Password" htmlFor="password" error={errors.password?.message} required>
        <PasswordInput id="password" autoComplete="new-password" placeholder="At least 8 characters" {...register("password")} />
        <div className="mt-2 flex gap-1" aria-hidden>
          {[0, 1, 2, 3].map((i) => (
            <span key={i} className={cn("h-1 flex-1 rounded-full transition-colors", i < strength ? (strength <= 2 ? "bg-amber" : "bg-success") : "bg-[#EEF0F6]")} />
          ))}
        </div>
        <p className="mt-1 text-[10.5px] text-ink-muted">
          {strength <= 2 ? "Add length, a number and a symbol for a stronger password." : "Strong password."} Hashed with scrypt — never stored in plain text.
        </p>
      </Field>

      <label className="flex items-start gap-2.5 text-[12px] leading-relaxed text-ink-soft">
        <Checkbox className="mt-0.5" {...register("acceptTerms")} />
        <span>
          I agree to the <a href="/legal/terms" className="link">terms of use</a> and{" "}
          <a href="/legal/privacy" className="link">privacy policy</a>, and understand this is a demonstration environment where no real
          booking or payment takes place.
        </span>
      </label>
      {errors.acceptTerms && <p className="text-xs font-medium text-danger">{errors.acceptTerms.message}</p>}

      {error && (
        <div className="rounded-xl border border-[#FBD5D1] bg-danger-soft px-3 py-2.5 text-[12.5px] text-[#912018]" role="alert">
          {error}
          {Object.keys(fieldErrors).length > 0 && (
            <ul className="mt-1 list-inside list-disc text-[11.5px]">
              {Object.entries(fieldErrors).map(([k, v]) => <li key={k}>{v}</li>)}
            </ul>
          )}
        </div>
      )}

      <Button type="submit" size="lg" className="w-full" loading={isSubmitting}>
        {isSubmitting ? "Creating account…" : defaultRole === "driver" ? "Create driver account" : "Create account"}
      </Button>
      {devVerifyUrl && (
        <p className="text-center text-[11px] text-ink-muted">
          Demo mode: verification link <a className="link" href={devVerifyUrl}>open it here</a>.
        </p>
      )}
    </form>
  );
}

export function ForgotPasswordForm() {
  const [sent, setSent] = React.useState<{ devResetUrl?: string } | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<z.infer<typeof forgotPasswordSchema>>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: { email: "" },
  });

  async function onSubmit(values: z.infer<typeof forgotPasswordSchema>) {
    setError(null);
    try {
      const res = await post<{ devResetUrl?: string }>("/api/auth/forgot-password", values);
      setSent(res ?? {});
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not send the email. Try again.");
    }
  }

  if (sent) {
    return (
      <div className="mt-6">
        <Alert tone="success" title="Check your inbox">
          If an account exists for that address, a reset link is on its way. It expires in 60 minutes.
        </Alert>
        {sent.devResetUrl && (
          <div className="mt-3 rounded-xl border border-indigo-100 bg-[#F7F6FF] p-3">
            <p className="text-[11px] font-semibold text-indigo">Demo mode — no email provider configured</p>
            <a href={sent.devResetUrl} className="mt-1 block break-all text-[11.5px] text-ink-soft underline">{sent.devResetUrl}</a>
          </div>
        )}
        <Button variant="outline" className="mt-4 w-full" onClick={() => setSent(null)}>Use a different email</Button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4" noValidate>
      <Field label="Email" htmlFor="email" error={errors.email?.message}>
        <div className="relative">
          <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
          <Input id="email" type="email" autoComplete="email" placeholder="you@example.com" className="pl-9" {...register("email")} />
        </div>
      </Field>
      {error && <Alert tone="danger">{error}</Alert>}
      <Button type="submit" size="lg" className="w-full" loading={isSubmitting}>Send reset link</Button>
    </form>
  );
}

export function ResetPasswordForm({ token }: { token: string }) {
  const router = useRouter();
  const [error, setError] = React.useState<string | null>(null);
  const [done, setDone] = React.useState(false);
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<z.infer<typeof resetPasswordSchema>>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: { token, password: "" },
  });

  async function onSubmit(values: z.infer<typeof resetPasswordSchema>) {
    setError(null);
    try {
      await post("/api/auth/reset-password", values);
      setDone(true);
      setTimeout(() => router.push("/login?message=Password%20updated.%20Sign%20in%20with%20your%20new%20password."), 1400);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not reset your password.");
    }
  }

  if (done) {
    return <div className="mt-6"><Alert tone="success" title="Password updated">You have been signed out everywhere. Taking you to sign in…</Alert></div>;
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4" noValidate>
      <Field label="New password" htmlFor="password" error={errors.password?.message}>
        <PasswordInput id="password" autoComplete="new-password" placeholder="At least 8 characters" {...register("password")} />
      </Field>
      {error && <Alert tone="danger">{error}</Alert>}
      <Button type="submit" size="lg" className="w-full" loading={isSubmitting}>Update password</Button>
    </form>
  );
}

export function EmailVerifyPanel({ token }: { token?: string }) {
  const [state, setState] = React.useState<"idle" | "working" | "done" | "error">(token ? "working" : "idle");
  const [message, setMessage] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!token) return;
    (async () => {
      try {
        await post("/api/auth/verify-email", { token });
        setState("done");
      } catch (err) {
        setState("error");
        setMessage(err instanceof ApiError ? err.message : "This link is invalid.");
      }
    })();
  }, [token]);

  if (state === "working") return <div className="mt-5"><Alert tone="info">Checking your verification link…</Alert></div>;
  if (state === "done")
    return (
      <div className="mt-5 space-y-3">
        <Alert tone="success" title="Email verified">Your account is confirmed. You can now join rides and receive trip notifications.</Alert>
        <a href="/app" className="flex h-11 items-center justify-center gap-2 rounded-xl bg-indigo text-sm font-semibold text-white">
          <CheckCircle2 className="h-4 w-4" /> Open dashboard
        </a>
      </div>
    );
  if (state === "error")
    return (
      <div className="mt-5 space-y-3">
        <Alert tone="danger" title="We could not verify this link">{message}</Alert>
        <Button variant="outline" className="w-full" onClick={() => location.assign("/app/profile")}>Resend from your profile</Button>
      </div>
    );

  return (
    <div className="mt-5 space-y-3">
      <Alert tone="info" title="Open the link in your email">
        In demo mode the verification link is shown inline after signup. You can also resend it from your profile.
      </Alert>
      <a href="/app/profile" className="flex h-11 items-center justify-center rounded-xl border border-line bg-white text-sm font-semibold text-ink">Go to profile</a>
    </div>
  );
}
