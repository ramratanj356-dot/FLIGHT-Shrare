"use client";
import * as React from "react";
import { Check, ChevronsUpDown, MapPin, Search } from "lucide-react";
import { cn } from "@/lib/utils";

export interface PickerDestination {
  id: string;
  name: string;
  area: string;
  distanceKm: number;
  soloFarePaise: number;
}

export function DestinationPicker({
  destinations, value, onChange, placeholder = "Search a neighbourhood", id, invalid, compact,
}: {
  destinations: PickerDestination[];
  value: string;
  onChange: (id: string) => void;
  placeholder?: string;
  id?: string;
  invalid?: boolean;
  compact?: boolean;
}) {
  const [open, setOpen] = React.useState(false);
  const [query, setQuery] = React.useState("");
  const [cursor, setCursor] = React.useState(0);
  const wrapRef = React.useRef<HTMLDivElement>(null);
  const inputRef = React.useRef<HTMLInputElement>(null);

  const selected = destinations.find((d) => d.id === value);
  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return destinations;
    return destinations.filter((d) => `${d.name} ${d.area}`.toLowerCase().includes(q));
  }, [destinations, query]);

  React.useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  React.useEffect(() => setCursor(0), [query, open]);

  function choose(d: PickerDestination) {
    onChange(d.id);
    setQuery("");
    setOpen(false);
  }

  return (
    <div ref={wrapRef} className="relative">
      <button
        type="button"
        id={id}
        onClick={() => {
          setOpen((o) => !o);
          setTimeout(() => inputRef.current?.focus(), 20);
        }}
        aria-haspopup="listbox"
        aria-expanded={open}
        className={cn(
          "flex w-full items-center justify-between gap-2 rounded-xl border bg-white px-3.5 text-left text-sm transition-colors",
          compact ? "h-10" : "h-11",
          invalid ? "border-danger" : "border-line hover:border-[#C9CFDA]",
          open && "border-indigo ring-4 ring-indigo/10",
        )}
      >
        <span className="flex min-w-0 items-center gap-2">
          <MapPin className="h-4 w-4 shrink-0 text-indigo" />
          <span className={cn("truncate", selected ? "font-medium text-ink" : "text-[#98A2B3]")}>
            {selected ? selected.name : placeholder}
          </span>
        </span>
        <ChevronsUpDown className="h-4 w-4 shrink-0 text-ink-muted" />
      </button>

      {open && (
        <div className="absolute z-50 mt-1.5 w-full animate-slide-in overflow-hidden rounded-xl border border-line bg-white shadow-lift">
          <div className="flex items-center gap-2 border-b border-line px-3">
            <Search className="h-4 w-4 text-ink-muted" />
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "ArrowDown") { e.preventDefault(); setCursor((c) => Math.min(c + 1, filtered.length - 1)); }
                if (e.key === "ArrowUp") { e.preventDefault(); setCursor((c) => Math.max(0, c - 1)); }
                if (e.key === "Enter") { e.preventDefault(); if (filtered[cursor]) choose(filtered[cursor]); }
                if (e.key === "Escape") setOpen(false);
              }}
              placeholder="Type to filter…"
              className="h-10 w-full bg-transparent text-sm outline-none placeholder:text-[#98A2B3]"
              aria-label="Filter destinations"
            />
          </div>
          <ul role="listbox" className="max-h-64 overflow-auto py-1 scrollbar-thin">
            {filtered.length === 0 && (
              <li className="px-3 py-6 text-center text-sm text-ink-muted">No area matches “{query}”. Try Mulund, Thane or Powai.</li>
            )}
            {filtered.map((d, i) => (
              <li key={d.id}>
                <button
                  type="button"
                  role="option"
                  aria-selected={d.id === value}
                  onMouseEnter={() => setCursor(i)}
                  onClick={() => choose(d)}
                  className={cn(
                    "flex w-full items-center justify-between gap-3 px-3 py-2.5 text-left transition-colors",
                    i === cursor ? "bg-[#F5F4FF]" : "hover:bg-[#F9FAFD]",
                  )}
                >
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-medium text-ink">{d.name}</span>
                    <span className="block truncate text-[11px] text-ink-muted">{d.area} · {d.distanceKm} km from BOM</span>
                  </span>
                  {d.id === value ? <Check className="h-4 w-4 shrink-0 text-indigo" /> : <span className="shrink-0 text-[11px] text-ink-muted tabular">₹{Math.round(d.soloFarePaise / 100).toLocaleString("en-IN")}</span>}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
