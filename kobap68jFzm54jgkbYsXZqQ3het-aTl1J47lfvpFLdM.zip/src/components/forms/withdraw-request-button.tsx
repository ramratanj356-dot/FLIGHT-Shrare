"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Undo2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ApiError, post } from "@/lib/client/api";
import { useToast } from "@/components/ui/toast";

/**
 * Withdraws the signed-in passenger's pending join request.
 *
 * The join page tells people they can withdraw, so this control has to exist
 * and hit the server — the request, not the UI, is the source of truth.
 */
export function WithdrawRequestButton({
  requestId,
  redirectTo = "/app/trips",
  label = "Withdraw request",
  size = "md",
}: {
  requestId: string;
  redirectTo?: string;
  label?: string;
  size?: "sm" | "md" | "lg";
}) {
  const router = useRouter();
  const { push } = useToast();
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  async function onClick() {
    setLoading(true);
    setError(null);
    try {
      await post("/api/join/withdraw", { requestId });
      push({ tone: "success", title: "Request withdrawn", description: "The coordinator can no longer accept it." });
      router.push(redirectTo);
      router.refresh();
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "We could not withdraw the request. Check your connection and retry.";
      setError(message);
      push({ tone: "error", title: "Could not withdraw", description: message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <Button type="button" variant="secondary" size={size} loading={loading} onClick={onClick} leftIcon={!loading ? <Undo2 className="h-3.5 w-3.5" /> : undefined}>
        {label}
      </Button>
      {error && (
        <p className="mt-1.5 text-[11px] font-medium text-danger" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
