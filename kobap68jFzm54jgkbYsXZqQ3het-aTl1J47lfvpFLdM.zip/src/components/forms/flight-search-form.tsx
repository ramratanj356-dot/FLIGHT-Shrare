"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ArrowRight, CalendarDays, Plane, User, Briefcase } from "lucide-react";
import { flightSearchSchema, type FlightSearchInput } from "@/lib/validation/schemas";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/primitives";
import { DestinationPicker, type PickerDestination } from "./destination-picker";
import { cn } from "@/lib/utils";

interface Props {
  destinations: PickerDestination[];
  defaultDate: string;
  sampleFlight: string;
  variant?: "hero" | "page";
  initial?: Partial<{ flightNumber: string; date: string; destinationId: string; passengers: number; luggageUnits: number }>;
}

const AIRPORTS = [
  { id: "apt_bom", label: "Mumbai — BOM", sub: "Chhatrapati Shivaji Maharaj Intl." },
  { id: "apt_del", label: "Delhi — DEL", sub: "Coming soon", disabled: true },
  { id: "apt_blr", label: "Bengaluru — BLR", sub: "Coming soon", disabled: true },
];

export function FlightSearchForm({ destinations, defaultDate, sampleFlight, variant = "hero", initial }: Props) {
  const router = useRouter();
  const [submitting, setSubmitting] = React.useState(false);
  const [destinationId, setDestinationId] = React.useState(initial?.destinationId ?? "thane-w");

  const {
    register, handleSubmit, setValue, watch, formState: { errors },
  } = useForm<FlightSearchInput>({
    resolver: zodResolver(flightSearchSchema),
    defaultValues: {
      airportId: "apt_bom",
      flightNumber: initial?.flightNumber ?? "",
      date: initial?.date ?? defaultDate,
      destinationId,
      passengers: initial?.passengers ?? 1,
      luggageUnits: initial?.luggageUnits ?? 1,
    },
  });

  React.useEffect(() => setValue("destinationId", destinationId), [destinationId, setValue]);

  const onSubmit = (values: FlightSearchInput) => {
    setSubmitting(true);
    const params = new URLSearchParams({
      airport: values.airportId,
      flight: values.flightNumber,
      date: values.date,
      dest: values.destinationId,
      pax: String(values.passengers),
      luggage: String(values.luggageUnits),
    });
    router.push(`/rides?${params.toString()}`);
  };

  const fillSample = () => {
    setValue("flightNumber", sampleFlight);
    setValue("date", defaultDate);
    setDestinationId("thane-w");
    setValue("destinationId", "thane-w");
    setValue("passengers", 1);
    setValue("luggageUnits", 1);
  };

  const hero = variant === "hero";

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className={cn("card p-4 sm:p-5", hero ? "shadow-lift" : "shadow-card")}
      noValidate
      aria-label="Find a shared airport ride"
    >
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-12">
        <div className="lg:col-span-3">
          <Field label="Airport" htmlFor="airport">
            <Select id="airport" {...register("airportId")} aria-invalid={Boolean(errors.airportId)}>
              {AIRPORTS.map((a) => (
                <option key={a.id} value={a.id} disabled={a.disabled}>
                  {a.label} {a.disabled ? "· soon" : ""}
                </option>
              ))}
            </Select>
          </Field>
        </div>

        <div className="lg:col-span-3">
          <Field label="Flight number" htmlFor="flightNumber" error={errors.flightNumber?.message} hint={!hero ? "Airline code + number, e.g. AI 864" : undefined}>
            <div className="relative">
              <Plane className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
              <Input
                id="flightNumber"
                placeholder="AI 864"
                autoComplete="off"
                className="pl-9 uppercase"
                {...register("flightNumber")}
                aria-invalid={Boolean(errors.flightNumber)}
              />
            </div>
          </Field>
        </div>

        <div className="lg:col-span-3">
          <Field label="Arrival date" htmlFor="date" error={errors.date?.message}>
            <div className="relative">
              <CalendarDays className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
              <Input id="date" type="date" className="pl-9" {...register("date")} aria-invalid={Boolean(errors.date)} />
            </div>
          </Field>
        </div>

        <div className="lg:col-span-3">
          <Field label="Destination" htmlFor="destination" error={errors.destinationId?.message}>
            <DestinationPicker
              id="destination"
              destinations={destinations}
              value={destinationId}
              onChange={(id) => { setDestinationId(id); setValue("destinationId", id); }}
              placeholder="Where to?"
              invalid={Boolean(errors.destinationId)}
            />
          </Field>
        </div>

        <div className="lg:col-span-3">
          <Field label="Passengers" htmlFor="passengers" error={errors.passengers?.message}>
            <div className="relative">
              <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
              <Select id="passengers" className="pl-9" {...register("passengers")}>
                {[1, 2, 3, 4, 5, 6].map((n) => (
                  <option key={n} value={n}>{n} {n === 1 ? "passenger" : "passengers"}</option>
                ))}
              </Select>
            </div>
          </Field>
        </div>

        <div className="lg:col-span-3">
          <Field label="Luggage" htmlFor="luggage" error={errors.luggageUnits?.message}>
            <div className="relative">
              <Briefcase className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
              <Select id="luggage" className="pl-9" {...register("luggageUnits")}>
                <option value={0}>Cabin bag only</option>
                <option value={1}>1 checked bag</option>
                <option value={2}>2 checked bags</option>
                <option value={3}>Heavy (3 bags)</option>
                <option value={4}>Extra large (4+)</option>
              </Select>
            </div>
          </Field>
        </div>

        <div className="lg:col-span-3 lg:flex lg:items-end">
          <Button type="submit" size={hero ? "lg" : "md"} className="mt-1 w-full" loading={submitting} rightIcon={!submitting ? <ArrowRight className="h-4 w-4" /> : undefined}>
            {submitting ? "Searching…" : "Find My Ride"}
          </Button>
        </div>
      </div>

      <div className="mt-3.5 flex flex-wrap items-center gap-x-3 gap-y-1.5 border-t border-line pt-3 text-[11.5px] text-ink-muted">
        <span className="font-medium text-ink-soft">Demo mode:</span>
        <button type="button" onClick={fillSample} className="rounded-md bg-[#F4F3FF] px-2 py-1 font-semibold text-indigo transition hover:bg-indigo-100">
          Fill sample flight · {sampleFlight}
        </button>
        <span>Sample schedules, clearly labelled. No airline system is contacted.</span>
      </div>
    </form>
  );
}
