"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Car, IdCard, Save } from "lucide-react";
import { driverVerificationSchema } from "@/lib/validation/schemas";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Checkbox, Alert } from "@/components/ui/primitives";
import { ApiError, post } from "@/lib/client/api";
import { useToast } from "@/components/ui/toast";
import { VEHICLE_LABELS, type VehicleCategory } from "@/lib/config/pricing";

type Values = z.infer<typeof driverVerificationSchema>;

export function DriverVerificationForm({ initial, locked }: { initial: Partial<Values>; locked: boolean }) {
  const router = useRouter();
  const { push } = useToast();
  const [error, setError] = React.useState<string | null>(null);
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<Values>({
    resolver: zodResolver(driverVerificationSchema),
    defaultValues: {
      licenseNumber: initial.licenseNumber ?? "",
      vehicleModel: initial.vehicleModel ?? "",
      vehicleRegNumber: initial.vehicleRegNumber ?? "",
      category: (initial.category ?? "sedan") as VehicleCategory,
      seats: initial.seats ?? 4,
      luggageUnits: initial.luggageUnits ?? 3,
      fleetPartner: initial.fleetPartner ?? "",
      consent: false as unknown as true,
    },
  });

  async function onSubmit(values: Values) {
    setError(null);
    try {
      await post("/api/driver/verification", values);
      push({ tone: "success", title: "Submitted for review", description: "An administrator will review your documents in the demo console." });
      router.refresh();
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "Could not submit";
      setError(message);
      push({ tone: "error", title: "Submission failed", description: message });
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="card p-4 sm:p-5" noValidate>
      <h2 className="text-[15px] font-semibold text-navy">Documents &amp; vehicle</h2>
      <p className="mt-0.5 text-[11.5px] text-ink-muted">Only these fields are stored. No document images are uploaded in the demo.</p>

      <div className="mt-4 grid gap-3.5 sm:grid-cols-2">
        <Field label="Driving licence number" htmlFor="license" error={errors.licenseNumber?.message} required>
          <div className="relative">
            <IdCard className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
            <Input id="license" className="pl-9 uppercase" placeholder="MH02 20190012345" disabled={locked} {...register("licenseNumber")} />
          </div>
        </Field>
        <Field label="Fleet partner" htmlFor="fleet" optional hint="Leave blank if you drive independently.">
          <Input id="fleet" placeholder="e.g. Sahyadri Fleet Partners" disabled={locked} {...register("fleetPartner")} />
        </Field>
        <Field label="Vehicle model" htmlFor="model" error={errors.vehicleModel?.message} required>
          <div className="relative">
            <Car className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
            <Input id="model" className="pl-9" placeholder="Maruti Suzuki Ciaz" disabled={locked} {...register("vehicleModel")} />
          </div>
        </Field>
        <Field label="Registration number" htmlFor="reg" error={errors.vehicleRegNumber?.message} required>
          <Input id="reg" className="uppercase" placeholder="MH 02 DC 4417" disabled={locked} {...register("vehicleRegNumber")} />
        </Field>
        <Field label="Category" htmlFor="cat">
          <Select id="cat" disabled={locked} {...register("category")}>
            {(Object.keys(VEHICLE_LABELS) as VehicleCategory[]).map((v) => <option key={v} value={v}>{VEHICLE_LABELS[v]}</option>)}
          </Select>
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Seats" htmlFor="seats">
            <Select id="seats" disabled={locked} {...register("seats")}>
              {[2, 3, 4, 5, 6, 7, 8].map((n) => <option key={n} value={n}>{n}</option>)}
            </Select>
          </Field>
          <Field label="Bag space" htmlFor="bags">
            <Select id="bags" disabled={locked} {...register("luggageUnits")}>
              {[1, 2, 3, 4, 5, 6, 8, 10].map((n) => <option key={n} value={n}>{n}</option>)}
            </Select>
          </Field>
        </div>
      </div>

      <label className="mt-3.5 flex items-start gap-2.5 text-[11.5px] leading-relaxed text-ink-soft">
        <Checkbox className="mt-0.5" disabled={locked} {...register("consent")} />
        <span>I confirm these details are genuine and that I hold a valid commercial passenger permit and insurance for this vehicle. I understand misrepresentation results in suspension.</span>
      </label>
      {errors.consent && <p className="mt-1 text-[11px] font-medium text-danger">{errors.consent.message}</p>}

      {error && <div className="mt-3"><Alert tone="danger">{error}</Alert></div>}

      <Button type="submit" size="md" className="mt-4" loading={isSubmitting} disabled={locked} leftIcon={<Save className="h-4 w-4" />}>
        {locked ? "Already verified" : isSubmitting ? "Submitting…" : "Submit for review"}
      </Button>
    </form>
  );
}
