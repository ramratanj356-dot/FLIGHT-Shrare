"use client";
import * as React from "react";
import Link from "next/link";
import { CheckCircle2, Loader2, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea, Alert } from "@/components/ui/primitives";
import { ApiError, post } from "@/lib/client/api";

const VEHICLES = ["Sedan (4 seats)", "SUV (6 seats)", "MPV (6 seats)", "Multiple vehicles"];

export function DriverSignupForm({ signedIn }: { signedIn: boolean }) {
  const [state, setState] = React.useState<"idle" | "sending" | "sent">("idle");
  const [error, setError] = React.useState<string | null>(null);
  const [values, setValues] = React.useState({ name: "", email: "", phone: "", city: "Mumbai", vehicle: VEHICLES[0], message: "" });

  function set<K extends keyof typeof values>(k: K, v: string) {
    setValues((s) => ({ ...s, [k]: v }));
  }

  const valid = values.name.trim().length > 1 && /.+@.+\..+/.test(values.email) && values.phone.replace(/\D/g, "").length >= 10;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!valid || state === "sending") return;
    setState("sending");
    setError(null);
    try {
      await post("/api/support", {
        category: "driver",
        subject: `Driver application — ${values.city}`,
        body: [
          `Name: ${values.name}`,
          `Phone: ${values.phone}`,
          `City: ${values.city}`,
          `Vehicle: ${values.vehicle}`,
          signedIn ? "Signed in as an existing account" : "New applicant",
          values.message ? `Notes: ${values.message}` : "",
        ].filter(Boolean).join("\n"),
      });
      setState("sent");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not submit the application");
      setState("idle");
    }
  }

  if (state === "sent") {
    return (
      <div className="card p-6 text-center">
        <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-success-soft"><CheckCircle2 className="h-6 w-6 text-success" /></div>
        <h2 className="mt-3.5 text-[17px] font-bold text-navy">Application logged</h2>
        <p className="mx-auto mt-1.5 max-w-sm text-[12.5px] leading-relaxed text-ink-muted">
          Your details are in the demo support queue as a partnership ticket. In production this would trigger an onboarding email with document
          collection. Nothing is verified automatically.
        </p>
        <div className="mt-4 flex justify-center gap-2">
          <Button variant="outline" onClick={() => { setState("idle"); setValues({ name: "", email: "", phone: "", city: "Mumbai", vehicle: VEHICLES[0], message: "" }); }}>
            Submit another
          </Button>
          <Link href="/status" className="inline-flex h-10 items-center rounded-xl px-3 text-[12.5px] font-semibold text-indigo hover:underline">
            Integration status
          </Link>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="card p-5" noValidate>
      <h2 className="text-[15px] font-bold text-navy">Register as a driver</h2>
      <p className="mt-0.5 text-[11.5px] text-ink-muted">
        Two minutes to apply. Verification is a document review in this prototype — approval is not automatic.
      </p>

      <div className="mt-4 space-y-3">
        <Field label="Full name" htmlFor="dname"><Input id="dname" value={values.name} onChange={(e) => set("name", e.target.value)} placeholder="Ramesh Yadav" autoComplete="name" /></Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Email" htmlFor="demail"><Input id="demail" type="email" value={values.email} onChange={(e) => set("email", e.target.value)} placeholder="you@example.com" autoComplete="email" /></Field>
          <Field label="Mobile" htmlFor="dphone"><Input id="dphone" value={values.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+91 98200 11001" autoComplete="tel" /></Field>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="City" htmlFor="dcity"><Input id="dcity" value={values.city} onChange={(e) => set("city", e.target.value)} /></Field>
          <Field label="Vehicle" htmlFor="dvehicle">
            <Select id="dvehicle" value={values.vehicle} onChange={(e) => set("vehicle", e.target.value)}>
              {VEHICLES.map((v) => <option key={v} value={v}>{v}</option>)}
            </Select>
          </Field>
        </div>
        <Field label="Anything we should know" htmlFor="dmsg" optional>
          <Textarea id="dmsg" value={values.message} onChange={(e) => set("message", e.target.value)} placeholder="Fleet size, existing airport contracts, preferred corridors…" maxLength={400} />
        </Field>
      </div>

      {error && <div className="mt-3"><Alert tone="danger">{error}</Alert></div>}

      <Button type="submit" size="lg" className="mt-4 w-full" loading={state === "sending"} disabled={!valid} rightIcon={state !== "sending" ? <Send className="h-4 w-4" /> : undefined}>
        {state === "sending" ? "Submitting…" : "Apply for review"}
      </Button>
      <p className="mt-2 text-center text-[10px] leading-relaxed text-ink-muted">
        Submitting creates a support ticket record. We do not run background checks and do not issue permits.
      </p>
    </form>
  );
}
