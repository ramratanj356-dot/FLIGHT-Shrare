"use client";
import * as React from "react";
import { CheckCircle2, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea, Alert } from "@/components/ui/primitives";
import { ApiError, post } from "@/lib/client/api";

const CATEGORIES = [
  { v: "trip", l: "Flight search, matching or timing" },
  { v: "fare", l: "Fare, estimate or refund" },
  { v: "account", l: "Account access or profile" },
  { v: "safety", l: "Safety concern" },
  { v: "driver", l: "Driver or fleet partnership" },
  { v: "other", l: "Something else" },
];

export function SupportForm({ signedIn, email }: { signedIn: boolean; email?: string }) {
  const [state, setState] = React.useState<"idle" | "sending" | "sent">("idle");
  const [error, setError] = React.useState<string | null>(null);
  const [ref, setRef] = React.useState<string | null>(null);
  const [values, setValues] = React.useState({ email: email ?? "", category: "trip", subject: "", body: "" });

  function set<K extends keyof typeof values>(k: K, v: string) {
    setValues((s) => ({ ...s, [k]: v }));
  }

  const valid = /.+@.+\..+/.test(values.email) && values.subject.trim().length >= 4 && values.body.trim().length >= 20;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!valid || state === "sending") return;
    setState("sending");
    setError(null);
    try {
      const res = await post<{ ticketId?: string }>("/api/support", {
        category: values.category,
        subject: values.subject,
        body: signedIn ? values.body : `${values.body}\n\nContact email: ${values.email}`.slice(0, 2000),
      });
      setRef(res?.ticketId ?? null);
      setState("sent");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not open the ticket");
      setState("idle");
    }
  }

  if (state === "sent") {
    return (
      <div className="card p-6 text-center">
        <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-success-soft"><CheckCircle2 className="h-6 w-6 text-success" /></div>
        <h2 className="mt-3.5 text-[16px] font-bold text-navy">Ticket opened</h2>
        <p className="mx-auto mt-1.5 max-w-xs text-[12px] leading-relaxed text-ink-muted">
          Your message is in the demo support queue{ref ? ` as ${ref}` : ""}. An administrator can triage it from the admin console; no email is
          sent because email is not configured.
        </p>
        <Button variant="outline" className="mt-4" onClick={() => { setState("idle"); setValues({ email: email ?? "", category: "trip", subject: "", body: "" }); }}>
          Open another ticket
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="card p-5" noValidate>
      <h2 className="text-[15px] font-bold text-navy">Contact support</h2>
      <p className="mt-0.5 text-[11.5px] text-ink-muted">
        {signedIn ? "We reply in-app on your account." : "We reply to the email you enter. Sign in for ride-scoped help."}
      </p>

      <div className="mt-4 space-y-3">
        <Field label="Email" htmlFor="s-email" required>
          <Input id="s-email" type="email" value={values.email} onChange={(e) => set("email", e.target.value)} placeholder="you@example.com" autoComplete="email" />
        </Field>
        <Field label="Topic" htmlFor="s-cat">
          <Select id="s-cat" value={values.category} onChange={(e) => set("category", e.target.value)}>
            {CATEGORIES.map((c) => <option key={c.v} value={c.v}>{c.l}</option>)}
          </Select>
        </Field>
        <Field label="Subject" htmlFor="s-subject" required>
          <Input id="s-subject" value={values.subject} onChange={(e) => set("subject", e.target.value)} placeholder="Fare estimate changed after a third passenger" maxLength={120} />
        </Field>
        <Field label="What happened?" htmlFor="s-body" required>
          <Textarea id="s-body" value={values.body} onChange={(e) => set("body", e.target.value)} placeholder="Include the ride code (FS-…) and what you expected." maxLength={2000} rows={5} />
        </Field>
      </div>

      {error && <div className="mt-3"><Alert tone="danger">{error}</Alert></div>}

      <Button type="submit" size="lg" className="mt-4 w-full" loading={state === "sending"} disabled={!valid} rightIcon={state !== "sending" ? <Send className="h-4 w-4" /> : undefined}>
        {state === "sending" ? "Sending…" : "Open ticket"}
      </Button>
      <p className="mt-2 text-center text-[10px] leading-relaxed text-ink-muted">Rate-limited to 5 tickets per hour per account.</p>
    </form>
  );
}
