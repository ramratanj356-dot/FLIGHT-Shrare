"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Check, Loader2, Save } from "lucide-react";
import { profileSchema } from "@/lib/validation/schemas";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Checkbox, Alert } from "@/components/ui/primitives";
import { DestinationPicker } from "./destination-picker";
import { ApiError, patch, post } from "@/lib/client/api";
import { useToast } from "@/components/ui/toast";

type Values = z.infer<typeof profileSchema>;

export function ProfileForm({
  initial, destinations,
}: {
  initial: Values & { homeDestinationId?: string };
  destinations: { id: string; name: string; area: string; distanceKm: number; soloFarePaise: number }[];
}) {
  const router = useRouter();
  const { push } = useToast();
  const [home, setHome] = React.useState(initial.homeDestinationId ?? "thane-w");
  const [error, setError] = React.useState<string | null>(null);
  const [saved, setSaved] = React.useState(false);
  const [resending, setResending] = React.useState(false);
  const [verifyUrl, setVerifyUrl] = React.useState<string | null>(null);

  const { register, handleSubmit, setValue, watch, formState: { errors, isSubmitting, isDirty } } = useForm<Values>({
    resolver: zodResolver(profileSchema),
    defaultValues: { ...initial, homeDestinationId: home },
  });

  React.useEffect(() => setValue("homeDestinationId", home), [home, setValue]);

  async function onSubmit(values: Values) {
    setError(null);
    try {
      await patch("/api/profile", values);
      setSaved(true);
      push({ tone: "success", title: "Preferences saved", description: "Your matching defaults have been updated." });
      router.refresh();
      setTimeout(() => setSaved(false), 2600);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not save your profile");
    }
  }

  async function resendVerification() {
    setResending(true);
    try {
      const res = await post<{ alreadyVerified: boolean; devVerifyUrl?: string }>("/api/auth/resend-verification", {});
      if (res.alreadyVerified) push({ tone: "info", title: "Already verified" });
      else {
        setVerifyUrl(res.devVerifyUrl ?? null);
        push({ tone: "success", title: "Verification link created", description: "Demo mode shows the link inline instead of emailing it." });
      }
    } catch (err) {
      push({ tone: "error", title: "Could not resend", description: err instanceof ApiError ? err.message : "Try again" });
    } finally {
      setResending(false);
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="card p-4 sm:p-5" noValidate>
      <h2 className="text-[15px] font-semibold text-navy">Travel preferences</h2>
      <p className="mt-0.5 text-[11.5px] text-ink-muted">Used for matching and to brief your driver. Nothing here is shown to other passengers except bag size.</p>

      <div className="mt-4 grid gap-3.5 sm:grid-cols-2">
        <Field label="Full name" htmlFor="name" error={errors.name?.message} required>
          <Input id="name" {...register("name")} />
        </Field>
        <Field label="Mobile number" htmlFor="phone" error={errors.phone?.message} optional>
          <Input id="phone" type="tel" {...register("phone")} placeholder="+91 98200 11001" />
        </Field>

        <Field label="Usual destination" htmlFor="home">
          <DestinationPicker id="home" destinations={destinations} value={home} onChange={(v) => { setHome(v); setValue("homeDestinationId", v, { shouldDirty: true }); }} />
        </Field>

        <Field label="Typical luggage" htmlFor="luggage">
          <Select id="luggage" {...register("luggagePreference")}>
            <option value="cabin">Cabin bag only</option>
            <option value="one_checkin">1 checked bag</option>
            <option value="two_checkin">2 checked bags</option>
            <option value="heavy">Heavy / oversize</option>
          </Select>
        </Field>

        <Field label="Language for updates" htmlFor="lang">
          <Select id="lang" {...register("language")}>
            <option value="en">English</option>
            <option value="hi">हिन्दी (Hindi)</option>
            <option value="mr">मराठी (Marathi)</option>
          </Select>
        </Field>

        <Field label="Accessibility needs" htmlFor="access" optional hint="Shared only with the assigned driver.">
          <Input id="access" placeholder="e.g. foldable wheelchair, step-free access" {...register("accessibilityNeeds")} />
        </Field>

        <Field label="Emergency contact name" htmlFor="ecName" optional>
          <Input id="ecName" {...register("emergencyContactName")} />
        </Field>
        <Field label="Emergency contact phone" htmlFor="ecPhone" optional error={errors.emergencyContactPhone?.message}>
          <Input id="ecPhone" type="tel" {...register("emergencyContactPhone")} />
        </Field>
      </div>

      <label className="mt-3.5 flex items-start gap-2.5 text-[12px] leading-relaxed text-ink-soft">
        <Checkbox className="mt-0.5" {...register("quietRide")} />
        <span>Prefer a quiet ride — matched with passengers who also opt in where possible.</span>
      </label>

      {error && <div className="mt-3"><Alert tone="danger">{error}</Alert></div>}

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <Button type="submit" size="md" loading={isSubmitting} leftIcon={!isSubmitting && saved ? <Check className="h-4 w-4" /> : !isSubmitting ? <Save className="h-4 w-4" /> : undefined}>
          {isSubmitting ? "Saving…" : saved ? "Saved" : "Save preferences"}
        </Button>
        <Button type="button" variant="outline" size="md" onClick={resendVerification} loading={resending}>
          {resending ? "Sending…" : "Resend email verification"}
        </Button>
        {isDirty && !isSubmitting && <span className="text-[10.5px] text-amber-dark">Unsaved changes</span>}
      </div>
      {verifyUrl && (
        <p className="mt-2 text-[10.5px] text-ink-muted">
          Demo verification link: <a className="link" href={verifyUrl}>{verifyUrl}</a>
        </p>
      )}
    </form>
  );
}
