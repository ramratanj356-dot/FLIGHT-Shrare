import * as React from "react";
import { cn, initials, avatarTone } from "@/lib/utils";
import { AlertCircle, Info, CheckCircle2 } from "lucide-react";

// ── Field wrapper ───────────────────────────────────────────────────────────
export function Field({
  label, htmlFor, hint, error, required, children, className, optional,
}: {
  label?: string; htmlFor?: string; hint?: string; error?: string; required?: boolean;
  children: React.ReactNode; className?: string; optional?: boolean;
}) {
  return (
    <div className={cn("w-full", className)}>
      {label && (
        <label htmlFor={htmlFor} className="label flex items-center justify-between">
          <span>
            {label} {required && <span className="text-danger">*</span>}
            {optional && <span className="ml-1 text-xs font-normal text-ink-muted">optional</span>}
          </span>
        </label>
      )}
      {children}
      {error ? (
        <p className="mt-1.5 flex items-start gap-1.5 text-xs font-medium text-danger" role="alert">
          <AlertCircle className="mt-px h-3.5 w-3.5 shrink-0" /> {error}
        </p>
      ) : hint ? (
        <p className="hint">{hint}</p>
      ) : null}
    </div>
  );
}

const control =
  "w-full rounded-xl border border-line bg-white px-3.5 text-sm text-ink placeholder:text-[#98A2B3] transition-colors focus:border-indigo focus:outline-none focus:ring-4 focus:ring-indigo/10 disabled:bg-[#F7F8FC] disabled:text-ink-muted";

export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement> & { invalid?: boolean }>(
  function Input({ className, invalid, ...props }, ref) {
    return <input ref={ref} className={cn(control, "h-11", invalid && "border-danger focus:border-danger focus:ring-danger/10", className)} {...props} />;
  },
);

export const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement> & { invalid?: boolean }>(
  function Textarea({ className, invalid, ...props }, ref) {
    return <textarea ref={ref} className={cn(control, "min-h-[96px] py-2.5", invalid && "border-danger", className)} {...props} />;
  },
);

export const Select = React.forwardRef<HTMLSelectElement, React.SelectHTMLAttributes<HTMLSelectElement> & { invalid?: boolean }>(
  function Select({ className, invalid, children, ...props }, ref) {
    return (
      <select ref={ref} className={cn(control, "h-11 cursor-pointer appearance-none bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%2216%22%20height%3D%2216%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22%23667085%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%3E%3Cpath%20d%3D%22m6%209%206%206%206-6%22/%3E%3C/svg%3E')] bg-[right_0.85rem_center] bg-no-repeat pr-10", invalid && "border-danger", className)} {...props}>
        {children}
      </select>
    );
  },
);

export function Checkbox({ className, ...props }: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      type="checkbox"
      className={cn("h-4.5 w-4.5 rounded border-line text-indigo accent-indigo focus:ring-indigo/30", className)}
      {...props}
    />
  );
}

// ── Badge ───────────────────────────────────────────────────────────────────
type Tone = "indigo" | "success" | "amber" | "danger" | "muted" | "navy" | "white";
const tones: Record<Tone, string> = {
  indigo: "bg-indigo-50 text-indigo-700 border-indigo-100",
  success: "bg-success-soft text-success-dark border-[#BFE8D4]",
  amber: "bg-amber-soft text-amber-dark border-[#F8E2B0]",
  danger: "bg-danger-soft text-danger border-[#FBD5D1]",
  muted: "bg-[#F2F4F7] text-ink-soft border-line",
  navy: "bg-navy text-white border-navy",
  white: "bg-white/10 text-white border-white/20 backdrop-blur",
};

export function Badge({
  children, tone = "muted", className, icon,
}: { children: React.ReactNode; tone?: Tone; className?: string; icon?: React.ReactNode }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold leading-none tracking-wide", tones[tone], className)}>
      {icon}
      {children}
    </span>
  );
}

export function DemoBadge({ label = "SAMPLE DATA", className }: { label?: string; className?: string }) {
  return (
    <Badge tone="amber" className={className} icon={<Info className="h-3 w-3" />}>
      {label}
    </Badge>
  );
}

// ── Avatar ──────────────────────────────────────────────────────────────────
const avatarTones: Record<string, string> = {
  indigo: "bg-[#E8E5FF] text-[#4034E0]",
  green: "bg-[#DCF5E9] text-[#0E7A4E]",
  amber: "bg-[#FFF1D6] text-[#8A5A00]",
  rose: "bg-[#FFE4E8] text-[#B4235A]",
  sky: "bg-[#DFF1FF] text-[#0B5CAD]",
  violet: "bg-[#F1E4FF] text-[#6B2FB3]",
};

export function Avatar({
  name, size = "md", className, verified,
}: { name: string; size?: "xs" | "sm" | "md" | "lg" | "xl"; className?: string; verified?: boolean }) {
  const sizes = { xs: "h-6 w-6 text-[10px]", sm: "h-8 w-8 text-[11px]", md: "h-10 w-10 text-xs", lg: "h-12 w-12 text-sm", xl: "h-16 w-16 text-base" };
  const tone = avatarTones[avatarTone(name)];
  return (
    <span className={cn("relative inline-flex shrink-0 items-center justify-center rounded-full font-semibold", sizes[size], tone, className)} aria-hidden={false} title={name}>
      {initials(name)}
      {verified && (
        <span className="absolute -bottom-0.5 -right-0.5 grid h-4 w-4 place-items-center rounded-full bg-white">
          <CheckCircle2 className="h-4 w-4 text-indigo" />
        </span>
      )}
    </span>
  );
}

// ── Misc ────────────────────────────────────────────────────────────────────
export function ScoreRing({ score, size = 56 }: { score: number; size?: number }) {
  const r = (size - 6) / 2;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(100, score));
  const color = pct >= 85 ? "#16A36A" : pct >= 70 ? "#5145FF" : pct >= 55 ? "#F4B740" : "#98A2B3";
  return (
    <div className="relative inline-grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#EEF0F6" strokeWidth={4} />
        <circle
          cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={4} strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c - (pct / 100) * c}
          style={{ transition: "stroke-dashoffset 700ms cubic-bezier(0.16,1,0.3,1)" }}
        />
      </svg>
      <span className="absolute text-[13px] font-bold text-navy tabular">{score}</span>
    </div>
  );
}

export function EmptyState({
  icon, title, description, action, className,
}: { icon?: React.ReactNode; title: string; description: string; action?: React.ReactNode; className?: string }) {
  return (
    <div className={cn("flex flex-col items-center justify-center rounded-2xl border border-dashed border-[#D7DCE6] bg-[#FBFBFE] px-6 py-12 text-center", className)}>
      {icon && <div className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-white text-indigo shadow-card">{icon}</div>}
      <h3 className="text-base font-semibold text-navy">{title}</h3>
      <p className="mt-1.5 max-w-md text-sm text-ink-muted">{description}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("skeleton", className)} />;
}

export function SectionHeading({
  eyebrow, title, description, align = "left", className,
}: { eyebrow?: string; title: string; description?: string; align?: "left" | "center"; className?: string }) {
  return (
    <div className={cn(align === "center" && "mx-auto text-center", "max-w-2xl", className)}>
      {eyebrow && <p className="eyebrow mb-3">{eyebrow}</p>}
      <h2 className="text-display-md text-navy">{title}</h2>
      {description && <p className="mt-3 text-[15px] leading-relaxed text-ink-muted">{description}</p>}
    </div>
  );
}

export function Alert({
  tone = "info", title, children,
}: { tone?: "info" | "success" | "warning" | "danger"; title?: string; children: React.ReactNode }) {
  const map = {
    info: "bg-[#F4F3FF] border-indigo-100 text-[#3A2FBF]",
    success: "bg-success-soft border-[#BFE8D4] text-success-dark",
    warning: "bg-amber-soft border-[#F8E2B0] text-amber-dark",
    danger: "bg-danger-soft border-[#FBD5D1] text-[#912018]",
  };
  return (
    <div className={cn("rounded-xl border px-4 py-3 text-[13px] leading-relaxed", map[tone])} role="status">
      {title && <p className="mb-0.5 font-semibold">{title}</p>}
      <div className="opacity-90">{children}</div>
    </div>
  );
}
