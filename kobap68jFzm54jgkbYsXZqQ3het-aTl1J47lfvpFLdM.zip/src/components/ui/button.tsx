import * as React from "react";
import Link from "next/link";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "outline" | "ghost" | "success" | "danger" | "white";
type Size = "sm" | "md" | "lg" | "xl" | "icon";

const base =
  "inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition-all duration-200 disabled:cursor-not-allowed disabled:opacity-55 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo focus-visible:ring-offset-2 active:translate-y-px whitespace-nowrap";

const variants: Record<Variant, string> = {
  primary: "bg-indigo text-white shadow-[0_1px_2px_rgba(16,24,40,0.08),0_8px_20px_-8px_rgba(81,69,255,0.6)] hover:bg-indigo-700 hover:shadow-[0_2px_4px_rgba(16,24,40,0.1),0_14px_28px_-10px_rgba(81,69,255,0.55)]",
  secondary: "bg-navy text-white hover:bg-[#1D2939] shadow-[0_8px_20px_-10px_rgba(16,24,40,0.7)]",
  outline: "border border-line bg-white text-ink hover:border-[#C9CFDA] hover:bg-[#FBFBFE]",
  ghost: "text-ink-soft hover:bg-[#F2F4F9] hover:text-navy",
  success: "bg-success text-white hover:bg-success-dark shadow-[0_8px_20px_-10px_rgba(22,163,106,0.55)]",
  danger: "bg-danger text-white hover:bg-[#B42318]",
  white: "bg-white text-navy hover:bg-[#F7F7FF] shadow-[0_8px_24px_-12px_rgba(16,24,40,0.5)]",
};

const sizes: Record<Size, string> = {
  sm: "h-9 px-3.5 text-[13px]",
  md: "h-11 px-5 text-sm",
  lg: "h-12 px-6 text-[15px]",
  xl: "h-14 px-7 text-base",
  icon: "h-10 w-10",
};

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { className, variant = "primary", size = "md", loading, leftIcon, rightIcon, children, disabled, ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      className={cn(base, variants[variant], sizes[size], className)}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? <Spinner /> : leftIcon}
      {children}
      {!loading && rightIcon}
    </button>
  );
});

export function Spinner({ className }: { className?: string }) {
  return (
    <span
      className={cn("inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent opacity-80", className)}
      aria-hidden
    />
  );
}

interface LinkButtonProps extends React.ComponentProps<typeof Link> {
  variant?: Variant;
  size?: Size;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export function LinkButton({ className, variant = "primary", size = "md", leftIcon, rightIcon, children, ...props }: LinkButtonProps) {
  return (
    <Link className={cn(base, variants[variant], sizes[size], className)} {...props}>
      {leftIcon}
      {children}
      {rightIcon}
    </Link>
  );
}
