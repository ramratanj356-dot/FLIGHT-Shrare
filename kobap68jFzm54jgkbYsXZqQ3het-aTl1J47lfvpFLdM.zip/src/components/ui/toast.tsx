"use client";
import * as React from "react";
import { createPortal } from "react-dom";
import { CheckCircle2, AlertCircle, Info, X } from "lucide-react";
import { cn } from "@/lib/utils";

type ToastTone = "success" | "error" | "info";
interface Toast { id: number; title: string; description?: string; tone: ToastTone }

const ToastContext = React.createContext<{ push: (t: Omit<Toast, "id">) => void } | null>(null);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = React.useState<Toast[]>([]);
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => setMounted(true), []);

  const push = React.useCallback((t: Omit<Toast, "id">) => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { ...t, id }]);
    setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 5200);
  }, []);

  return (
    <ToastContext.Provider value={{ push }}>
      {children}
      {mounted &&
        createPortal(
          <div className="pointer-events-none fixed inset-x-0 bottom-4 z-[100] flex flex-col items-center gap-2 px-4 sm:bottom-auto sm:right-5 sm:top-5 sm:items-end sm:px-0">
            {toasts.map((t) => (
              <div
                key={t.id}
                className={cn(
                  "pointer-events-auto flex w-full max-w-sm animate-slide-in items-start gap-3 rounded-xl border bg-white p-3.5 shadow-lift",
                  t.tone === "success" && "border-[#BFE8D4]",
                  t.tone === "error" && "border-[#FBD5D1]",
                  t.tone === "info" && "border-indigo-100",
                )}
                role="status"
              >
                <span className="mt-0.5">
                  {t.tone === "success" ? <CheckCircle2 className="h-5 w-5 text-success" /> : t.tone === "error" ? <AlertCircle className="h-5 w-5 text-danger" /> : <Info className="h-5 w-5 text-indigo" />}
                </span>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-navy">{t.title}</p>
                  {t.description && <p className="mt-0.5 text-[13px] leading-snug text-ink-muted">{t.description}</p>}
                </div>
                <button onClick={() => setToasts((p) => p.filter((x) => x.id !== t.id))} className="rounded-md p-1 text-ink-muted hover:bg-[#F2F4F9]" aria-label="Dismiss">
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>,
          document.body,
        )}
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = React.useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used inside ToastProvider");
  return ctx;
}
