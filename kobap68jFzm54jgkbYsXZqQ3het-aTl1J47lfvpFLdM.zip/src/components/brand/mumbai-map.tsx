import { cn } from "@/lib/utils";
import { BOM_TERMINALS } from "@/lib/data/destinations";

export interface MapStop {
  id: string;
  name: string;
  lat: number;
  lng: number;
  distanceKm?: number;
}

const LAT_MIN = 18.88, LAT_MAX = 19.27, LNG_MIN = 72.79, LNG_MAX = 73.04;
const W = 460, H = 420, PAD = 26;

function project(lat: number, lng: number) {
  const x = PAD + ((lng - LNG_MIN) / (LNG_MAX - LNG_MIN)) * (W - PAD * 2);
  const y = PAD + ((LAT_MAX - lat) / (LAT_MAX - LAT_MIN)) * (H - PAD * 2);
  return { x, y };
}

const AIRPORT = project(BOM_TERMINALS[0].lat, BOM_TERMINALS[0].lng);

function curve(from: { x: number; y: number }, to: { x: number; y: number }, bend = 0.18) {
  const mx = (from.x + to.x) / 2;
  const my = (from.y + to.y) / 2;
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const cx = mx - dy * bend;
  const cy = my + dx * bend;
  return `M ${from.x} ${from.y} Q ${cx} ${cy} ${to.x} ${to.y}`;
}

export function MumbaiMap({
  stops, highlight = [], className, height = 420, caption = "Illustrative map · distances are estimates",
}: { stops: MapStop[]; highlight?: string[]; className?: string; height?: number; caption?: string }) {
  return (
    <figure className={cn("relative", className)}>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ height }} role="img" aria-label="Illustrative map of Mumbai destinations from the airport">
        <defs>
          <linearGradient id="mapFade" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FBFCFF" />
            <stop offset="100%" stopColor="#F4F6FC" />
          </linearGradient>
          <radialGradient id="airportGlow">
            <stop offset="0%" stopColor="#5145FF" stopOpacity="0.22" />
            <stop offset="100%" stopColor="#5145FF" stopOpacity="0" />
          </radialGradient>
          <pattern id="mapGrid" width="26" height="26" patternUnits="userSpaceOnUse">
            <circle cx="1" cy="1" r="1" fill="#DDE2EC" />
          </pattern>
        </defs>

        <rect width={W} height={H} rx="18" fill="url(#mapFade)" />
        <rect width={W} height={H} rx="18" fill="url(#mapGrid)" opacity="0.75" />

        {/* stylised coastline suggestion */}
        <path d="M -10 300 C 60 284, 96 320, 150 306 S 250 262, 300 288 S 380 320, 470 296 L 470 700 L -10 700 Z" fill="#EDF1FA" opacity="0.55" />
        <path d="M -10 300 C 60 284, 96 320, 150 306 S 250 262, 300 288 S 380 320, 470 296" fill="none" stroke="#D6DEF0" strokeWidth="1.5" />

        {stops.map((s) => {
          const p = project(s.lat, s.lng);
          const active = highlight.includes(s.id);
          return (
            <g key={s.id}>
              <path
                d={curve(AIRPORT, p)}
                fill="none"
                stroke={active ? "#5145FF" : "#C9D2E4"}
                strokeWidth={active ? 2.4 : 1.2}
                strokeDasharray={active ? "0" : "4 5"}
                opacity={active ? 0.95 : 0.75}
                strokeLinecap="round"
              />
            </g>
          );
        })}

        <circle cx={AIRPORT.x} cy={AIRPORT.y} r="46" fill="url(#airportGlow)" />
        <g>
          <circle cx={AIRPORT.x} cy={AIRPORT.y} r="8" fill="#5145FF" />
          <circle cx={AIRPORT.x} cy={AIRPORT.y} r="14" fill="none" stroke="#5145FF" strokeWidth="1.5" opacity="0.35" />
          <text x={AIRPORT.x + 20} y={AIRPORT.y + 4} fontSize="11" fontWeight="700" fill="#101828">BOM</text>
          <text x={AIRPORT.x + 20} y={AIRPORT.y + 17} fontSize="9" fill="#667085">Mumbai Airport</text>
        </g>

        {stops.map((s) => {
          const p = project(s.lat, s.lng);
          const active = highlight.includes(s.id);
          const right = p.x > W * 0.62;
          return (
            <g key={`dot-${s.id}`}>
              <circle cx={p.x} cy={p.y} r={active ? 5.5 : 4} fill="#fff" stroke={active ? "#5145FF" : "#98A2B3"} strokeWidth={active ? 2.5 : 1.5} />
              {active && <circle cx={p.x} cy={p.y} r="10" fill="#5145FF" opacity="0.12" />}
              <text
                x={right ? p.x - 10 : p.x + 10}
                y={p.y + 3.5}
                fontSize="9.5"
                fontWeight={active ? 700 : 500}
                fill={active ? "#101828" : "#667085"}
                textAnchor={right ? "end" : "start"}
              >
                {s.name}
              </text>
            </g>
          );
        })}

        <g opacity="0.55">
          <circle cx={W - 34} cy={34} r="12" fill="none" stroke="#98A2B3" strokeWidth="1" />
          <path d={`M ${W - 34} 25 L ${W - 31} 34 L ${W - 34} 31.5 L ${W - 37} 34 Z`} fill="#667085" />
          <text x={W - 34} y={53} fontSize="7.5" textAnchor="middle" fill="#667085" fontWeight="600">N</text>
        </g>
      </svg>
      <figcaption className="absolute bottom-2 left-3 rounded-md bg-white/85 px-2 py-1 text-[10px] font-medium text-ink-muted backdrop-blur-sm">
        {caption}
      </figcaption>
    </figure>
  );
}

export function RouteMap({
  stops, className, height = 260, highlightId,
}: { stops: MapStop[]; className?: string; height?: number; highlightId?: string }) {
  const airport = BOM_TERMINALS[0];
  const all = [{ lat: airport.lat, lng: airport.lng }, ...stops];

  // Auto-fit the viewport to this specific route so short hops stay legible.
  const pad = 0.085;
  const minLat = Math.min(...all.map((p) => p.lat)) - pad * 0.7;
  const maxLat = Math.max(...all.map((p) => p.lat)) + pad * 0.7;
  const minLng = Math.min(...all.map((p) => p.lng)) - pad;
  const maxLng = Math.max(...all.map((p) => p.lng)) + pad;
  const spanLat = Math.max(0.02, maxLat - minLat);
  const spanLng = Math.max(0.02, maxLng - minLng);
  // Keep a constant aspect so the illustration never squashes.
  const aspect = W / H;
  let vw = spanLng;
  let vh = spanLat;
  if (vw / vh > aspect) vh = vw / aspect;
  else vw = vh * aspect;
  const cx = (minLng + maxLng) / 2;
  const cy = (minLat + maxLat) / 2;

  const project2 = (lat: number, lng: number) => ({
    x: PAD + ((lng - (cx - vw / 2)) / vw) * (W - PAD * 2),
    y: PAD + (((cy + vh / 2) - lat) / vh) * (H - PAD * 2),
  });

  const a = project2(airport.lat, airport.lng);
  const ordered = [...stops]
    .map((s) => ({ ...s, ...project2(s.lat, s.lng) }))
    .sort((p, q) => (p.distanceKm ?? 0) - (q.distanceKm ?? 0));

  const path = ordered.reduce((acc, p, i, arr) => {
    if (i === 0) return `M ${a.x} ${a.y} Q ${(a.x + p.x) / 2 - (p.y - a.y) * 0.18} ${(a.y + p.y) / 2 + (p.x - a.x) * 0.18} ${p.x} ${p.y}`;
    const prev = arr[i - 1];
    return `${acc} Q ${(prev.x + p.x) / 2 - (p.y - prev.y) * 0.18} ${(prev.y + p.y) / 2 + (p.x - prev.x) * 0.18} ${p.x} ${p.y}`;
  }, "");

  return (
    <figure className={cn("relative overflow-hidden rounded-2xl border border-line bg-[#F8FAFE]", className)}>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ height }} role="img" aria-label="Shared route from the airport to drop-off points">
        <defs>
          <pattern id="routeGrid" width="20" height="20" patternUnits="userSpaceOnUse">
            <circle cx="1" cy="1" r="1" fill="#DFE5EF" />
          </pattern>
          <linearGradient id="routeLine" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#5145FF" />
            <stop offset="100%" stopColor="#16A36A" />
          </linearGradient>
        </defs>
        <rect width={W} height={H} fill="url(#routeGrid)" opacity="0.8" />
        <path d="M -10 330 C 70 312, 120 350, 190 332 S 300 288, 470 320 L 470 700 L -10 700 Z" fill="#EDF1FA" opacity="0.45" />

        <path d={path} fill="none" stroke="url(#routeLine)" strokeWidth="9" strokeLinecap="round" opacity="0.1" />
        <path d={path} fill="none" stroke="url(#routeLine)" strokeWidth="3.2" strokeLinecap="round" strokeDasharray="7 7" className="animate-dash" />

        <circle cx={a.x} cy={a.y} r="7" fill="#101828" />
        <circle cx={a.x} cy={a.y} r="14" fill="none" stroke="#101828" strokeOpacity="0.16" strokeWidth="1.5" />
        <text x={a.x + 14} y={a.y + 4} fontSize="10" fontWeight="700" fill="#101828">BOM</text>

        {ordered.map((s, i) => {
          const active = highlightId === s.id;
          return (
            <g key={s.id}>
              <circle cx={s.x} cy={s.y} r="15" fill="#fff" stroke={active ? "#16A36A" : "#5145FF"} strokeWidth="2.2" />
              <text x={s.x} y={s.y + 4} fontSize="9.5" fontWeight="700" textAnchor="middle" fill="#101828">{i + 1}</text>
              <text x={s.x + 22} y={s.y + 4} fontSize="10" fontWeight="600" fill="#344054">{s.name}</text>
            </g>
          );
        })}
      </svg>
      <figcaption className="absolute bottom-2 left-3 rounded-md bg-white/85 px-2 py-1 text-[10px] font-medium text-ink-muted backdrop-blur-sm">
        Illustrative route · actual driving path may differ
      </figcaption>
    </figure>
  );
}
