import { cn } from "@/lib/utils";

/** FlightShare mark: a fuselage formed by two opposing chevrons (share + direction). */
export function LogoMark({ className, tone = "indigo" }: { className?: string; tone?: "indigo" | "white" | "navy" }) {
  const bg = tone === "white" ? "#FFFFFF" : tone === "navy" ? "#101828" : "#5145FF";
  const fg = tone === "indigo" ? "#FFFFFF" : tone === "navy" ? "#FFFFFF" : "#5145FF";
  return (
    <svg viewBox="0 0 32 32" className={cn("h-8 w-8", className)} aria-hidden>
      <rect width="32" height="32" rx="9" fill={bg} />
      <path d="M9 20.4 16 8l7 12.4-3.1 5.2L16 15.3l-3.9 10.3L9 20.4Z" fill={fg} opacity="0.95" />
      <path d="M16 22.5 19.1 25.6 16 30 12.9 25.6 16 22.5Z" fill={fg} opacity="0.55" />
    </svg>
  );
}

export function Logo({ className, tone = "indigo", showTag = false }: { className?: string; tone?: "indigo" | "white" | "navy"; showTag?: boolean }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <LogoMark tone={tone} />
      <span className="flex flex-col leading-none">
        <span className={cn("text-[17px] font-bold tracking-[-0.02em]", tone === "white" ? "text-white" : "text-navy")}>
          Flight<span className={tone === "white" ? "text-[#C9C4FF]" : "text-indigo"}>Share</span>
        </span>
        {showTag && <span className={cn("mt-1 text-[10px] font-medium uppercase tracking-[0.16em]", tone === "white" ? "text-white/50" : "text-ink-muted")}>Same flight. Same direction.</span>}
      </span>
    </span>
  );
}
