import { Plane, ShieldCheck, Users, Wallet } from "lucide-react";
import { Avatar, Badge, ScoreRing } from "@/components/ui/primitives";
import { formatPaise } from "@/lib/money";
import { cn } from "@/lib/utils";

const PASSENGERS = [
  { name: "Aarav M.", destination: "Thane West", share: 39200, tone: "indigo" },
  { name: "Priya N.", destination: "Mulund", share: 36100, tone: "green" },
  { name: "Rohan D.", destination: "Thane West", share: 39200, tone: "amber" },
];

/** Hand-built product illustration: no external images, fully responsive. */
export function HeroVisual({ className }: { className?: string }) {
  return (
    <div className={cn("relative", className)}>
      <div className="pointer-events-none absolute -inset-6 rounded-[2rem] bg-[radial-gradient(60%_60%_at_70%_20%,rgba(81,69,255,0.14),transparent)]" />

      <div className="relative rounded-3xl border border-line bg-white p-3 shadow-lift">
        {/* flight strip */}
        <div className="flex items-center justify-between rounded-2xl bg-navy px-4 py-3 text-white">
          <div className="flex items-center gap-3">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-white/10">
              <Plane className="h-4 w-4 -rotate-45" />
            </span>
            <div>
              <p className="text-[13px] font-semibold leading-tight">AI 864 · Delhi → Mumbai</p>
              <p className="text-[11px] text-white/60">Landed 08:45 · Terminal 2 · Gate 3</p>
            </div>
          </div>
          <Badge tone="white" className="shrink-0">SAMPLE</Badge>
        </div>

        {/* route diagram */}
        <div className="relative mt-3 overflow-hidden rounded-2xl border border-line bg-[#FAFBFF]">
          <svg viewBox="0 0 420 190" className="w-full" aria-hidden>
            <defs>
              <linearGradient id="heroRoute" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#5145FF" />
                <stop offset="100%" stopColor="#16A36A" />
              </linearGradient>
            </defs>
            <g opacity="0.5">
              {Array.from({ length: 9 }).map((_, i) => (
                <line key={i} x1={i * 52} y1="0" x2={i * 52} y2="190" stroke="#EAEEF7" strokeWidth="1" />
              ))}
              {Array.from({ length: 4 }).map((_, i) => (
                <line key={i} x1="0" y1={i * 52} x2="420" y2={i * 52} stroke="#EAEEF7" strokeWidth="1" />
              ))}
            </g>
            <path d="M 62 128 C 130 128 140 62 226 58 S 320 74 372 50" fill="none" stroke="url(#heroRoute)" strokeWidth="2.5" strokeDasharray="6 6" className="animate-dash" strokeLinecap="round" />
            <circle cx="62" cy="128" r="7" fill="#101828" />
            <circle cx="62" cy="128" r="14" fill="none" stroke="#101828" strokeOpacity="0.15" />
            <circle cx="226" cy="58" r="5" fill="#fff" stroke="#5145FF" strokeWidth="2.5" />
            <circle cx="372" cy="50" r="5" fill="#fff" stroke="#16A36A" strokeWidth="2.5" />
            <circle cx="300" cy="66" r="5" fill="#fff" stroke="#98A2B3" strokeWidth="2" />
            <g className="animate-float">
              <rect x="140" y="76" width="34" height="24" rx="8" fill="#fff" stroke="#E4E7EC" />
              <path d="M151 92 L157 83 L163 92 L159.5 97 L157 89.5 L154.5 97 Z" fill="#5145FF" />
            </g>
            <text x="46" y="156" fontSize="9.5" fontWeight="700" fill="#101828">BOM</text>
            <text x="196" y="44" fontSize="9" fontWeight="600" fill="#5145FF">Mulund</text>
            <text x="356" y="36" fontSize="9" fontWeight="600" fill="#16A36A" textAnchor="end">Thane West</text>
            <text x="272" y="88" fontSize="8.5" fill="#667085">Powai</text>
          </svg>
          <div className="absolute bottom-3 right-3 rounded-lg border border-line bg-white/95 px-2 py-1 text-[10px] font-semibold text-ink-muted">
            3 passengers · 1 vehicle
          </div>
        </div>

        {/* passengers + split */}
        <div className="mt-3 space-y-2">
          {PASSENGERS.map((p) => (
            <div key={p.name} className="flex items-center justify-between rounded-xl border border-line bg-white px-3 py-2.5">
              <div className="flex min-w-0 items-center gap-2.5">
                <Avatar name={p.name} size="sm" verified />
                <div className="min-w-0">
                  <p className="truncate text-[12.5px] font-semibold text-navy">{p.name}</p>
                  <p className="truncate text-[10.5px] text-ink-muted">→ {p.destination}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-[13px] font-bold text-navy tabular">{formatPaise(p.share)}</p>
                <p className="text-[10px] text-success-dark">saves {formatPaise(115000 - p.share)}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-3 flex items-center justify-between rounded-2xl border border-indigo-100 bg-[#F7F6FF] px-4 py-3">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-white shadow-sm">
              <Wallet className="h-4 w-4 text-indigo" />
            </span>
            <div>
              <p className="text-[11px] font-medium text-ink-muted">Shared fare · split 3 ways</p>
              <p className="text-[15px] font-bold text-navy tabular">₹1,144 <span className="text-[11px] font-medium text-ink-muted">total</span></p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden text-right sm:block">
              <p className="text-[10px] font-medium uppercase tracking-wide text-ink-muted">Fare saved</p>
              <p className="text-[13px] font-bold text-success-dark tabular">₹2,136</p>
            </div>
            <ScoreRing score={92} size={48} />
          </div>
        </div>
      </div>

    </div>
  );
}
