"use client";
import * as React from "react";
import { ArrowDownRight, IndianRupee, Sparkles } from "lucide-react";
import { calculateSavings } from "@/lib/fares/calculator";
import { formatPaise, INR } from "@/lib/money";
import { cn } from "@/lib/utils";

function Slider({
  label, value, min, max, step, onChange, suffix,
}: { label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void; suffix?: string }) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between">
        <label className="text-[13px] font-medium text-ink-soft">{label}</label>
        <span className="text-sm font-bold text-navy tabular">
          {suffix === "%" ? `${value}%` : `₹${value.toLocaleString("en-IN")}`}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        aria-label={label}
        className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-[#E7EAF2] outline-none [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-white [&::-webkit-slider-thumb]:bg-indigo [&::-webkit-slider-thumb]:shadow-md [&::-moz-range-thumb]:h-4 [&::-moz-range-thumb]:w-4 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-2 [&::-moz-range-thumb]:border-white [&::-moz-range-thumb]:bg-indigo"
        style={{ background: `linear-gradient(to right, #5145FF ${pct}%, #E7EAF2 ${pct}%)` }}
      />
    </div>
  );
}

export function SavingsCalculator() {
  const [solo, setSolo] = React.useState(1150);
  const [shared, setShared] = React.useState(1250);
  const [passengers, setPassengers] = React.useState(3);
  const [feePct, setFeePct] = React.useState(8);

  const result = React.useMemo(
    () =>
      calculateSavings({
        soloFarePaise: INR(solo),
        sharedVehicleFarePaise: INR(shared),
        passengers,
        platformFeeBps: Math.round(feePct * 100),
        feeTaxBps: 1800,
      }),
    [solo, shared, passengers, feePct],
  );

  const maxBar = Math.max(solo, result.individualContributionPaise / 100);

  return (
    <div className="grid gap-6 lg:grid-cols-[1.05fr_1fr]">
      <div className="card p-5 sm:p-6">
        <div className="space-y-5">
          <Slider label="Your solo airport-cab fare" value={solo} min={200} max={3000} step={50} onChange={setSolo} />
          <Slider label="Estimated shared vehicle fare" value={shared} min={200} max={3000} step={50} onChange={setShared} />
          <div>
            <div className="mb-2 flex items-baseline justify-between">
              <label className="text-[13px] font-medium text-ink-soft">Passengers sharing</label>
              <span className="text-sm font-bold text-navy tabular">{passengers}</span>
            </div>
            <div className="flex gap-1.5" role="group" aria-label="Passengers sharing">
              {[1, 2, 3, 4, 5, 6].map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setPassengers(n)}
                  aria-pressed={passengers === n}
                  className={cn(
                    "h-9 flex-1 rounded-lg border text-[13px] font-semibold transition",
                    passengers === n ? "border-indigo bg-indigo text-white" : "border-line bg-white text-ink-soft hover:border-[#C9CFDA]",
                  )}
                >
                  {n}
                </button>
              ))}
            </div>
          </div>
          <Slider label="Platform service fee" value={feePct} min={0} max={20} step={1} onChange={setFeePct} suffix="%" />
        </div>
        <p className="mt-5 rounded-lg bg-[#F9FAFD] px-3 py-2.5 text-[11.5px] leading-relaxed text-ink-muted">
          Assumptions: {feePct}% platform fee on the vehicle fare, plus 18% tax on that fee. No tolls or parking in this estimate.
          These are planning estimates, not quotes.
        </p>
      </div>

      <div className="card relative overflow-hidden p-5 sm:p-6">
        <div className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-[#F0EEFF]" />
        <div className="relative">
          <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-indigo">
            <Sparkles className="h-3.5 w-3.5" /> Your estimated share
          </div>
          <p className="mt-3 text-[44px] font-bold leading-none tracking-tight text-navy tabular">
            {formatPaise(result.individualContributionPaise)}
          </p>
          <p className="mt-1.5 text-[13px] text-ink-muted">per passenger, including fees and tax</p>

          <div className="mt-6 space-y-3.5">
            <div>
              <div className="mb-1 flex items-center justify-between text-[11.5px] font-medium">
                <span className="text-ink-muted">Solo ride</span>
                <span className="text-ink-soft tabular">{formatPaise(INR(solo))}</span>
              </div>
              <div className="h-2.5 overflow-hidden rounded-full bg-[#EEF0F6]">
                <div className="h-full rounded-full bg-[#C7CBD6]" style={{ width: `${(solo / Math.max(maxBar, 1)) * 100}%` }} />
              </div>
            </div>
            <div>
              <div className="mb-1 flex items-center justify-between text-[11.5px] font-medium">
                <span className="text-ink-muted">Your shared share</span>
                <span className="text-indigo tabular">{formatPaise(result.individualContributionPaise)}</span>
              </div>
              <div className="h-2.5 overflow-hidden rounded-full bg-[#EEF0F6]">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-indigo to-[#7C71FF] transition-all duration-500"
                  style={{ width: `${(result.individualContributionPaise / 100 / Math.max(maxBar, 1)) * 100}%` }}
                />
              </div>
            </div>
          </div>

          {result.isCheaper ? (
            <div className="mt-6 flex items-center justify-between rounded-xl border border-[#BFE8D4] bg-success-soft px-3.5 py-3">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wide text-success-dark">You save</p>
                <p className="text-lg font-bold text-success-dark tabular">{formatPaise(result.savingsPerPassengerPaise)}</p>
              </div>
              <div className="flex items-center gap-1 rounded-full bg-white px-2.5 py-1 text-xs font-bold text-success-dark">
                <ArrowDownRight className="h-3.5 w-3.5" /> {result.savingsPct}%
              </div>
            </div>
          ) : (
            <div className="mt-6 rounded-xl border border-[#F8E2B0] bg-amber-soft px-3.5 py-3 text-[12.5px] leading-relaxed text-amber-dark">
              <strong>Sharing is not cheaper at these numbers.</strong> With {passengers} passenger{passengers > 1 ? "s" : ""},
              the shared total of {formatPaise(result.totalSharedPaise)} exceeds your solo fare. FlightShare shows this honestly rather than
              promising savings — try more passengers or a shorter trip.
            </div>
          )}

          <dl className="mt-5 space-y-2 border-t border-line pt-4 text-[12.5px]">
            <div className="flex justify-between"><dt className="text-ink-muted">Shared vehicle fare</dt><dd className="font-medium text-ink tabular">{formatPaise(result.sharedVehicleFarePaise)}</dd></div>
            <div className="flex justify-between"><dt className="text-ink-muted">Platform fee</dt><dd className="font-medium text-ink tabular">{formatPaise(result.platformFeePaise)}</dd></div>
            <div className="flex justify-between"><dt className="text-ink-muted">Tax on fee</dt><dd className="font-medium text-ink tabular">{formatPaise(result.taxPaise)}</dd></div>
            <div className="flex justify-between border-t border-line pt-2"><dt className="font-semibold text-navy">Total shared fare</dt><dd className="font-bold text-navy tabular">{formatPaise(result.totalSharedPaise)}</dd></div>
            <div className="flex justify-between"><dt className="text-ink-muted">Total group saving</dt><dd className="font-medium text-success-dark tabular">{formatPaise(Math.max(0, result.totalSavingPaise))}</dd></div>
          </dl>
          <p className="mt-3 flex items-start gap-1.5 text-[11px] text-ink-muted">
            <IndianRupee className="mt-px h-3 w-3 shrink-0" />
            All amounts in INR and calculated in paise, so shares always add up exactly.
          </p>
        </div>
      </div>
    </div>
  );
}
