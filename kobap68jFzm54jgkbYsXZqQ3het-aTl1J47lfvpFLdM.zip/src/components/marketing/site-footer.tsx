import Link from "next/link";
import { Logo } from "@/components/brand/logo";
import { Badge } from "@/components/ui/primitives";

const COLUMNS = [
  {
    title: "Product",
    links: [
      { href: "/search", label: "Find a shared ride" },
      { href: "/how-it-works", label: "How matching works" },
      { href: "/destinations", label: "Mumbai destinations" },
      { href: "/partners", label: "Drive with FlightShare" },
    ],
  },
  {
    title: "Trust",
    links: [
      { href: "/safety", label: "Safety & verification" },
      { href: "/legal/privacy", label: "Privacy policy" },
      { href: "/legal/terms", label: "Terms of use" },
      { href: "/help", label: "Help & contact" },
    ],
  },
  {
    title: "Platform",
    links: [
      { href: "/app", label: "Passenger dashboard" },
      { href: "/driver", label: "Driver portal" },
      { href: "/admin", label: "Admin console" },
      { href: "/status", label: "System status" },
    ],
  },
];

export function SiteFooter() {
  return (
    <footer className="border-t border-line bg-white">
      <div className="container-x py-14">
        <div className="grid gap-10 md:grid-cols-[1.4fr_repeat(3,1fr)]">
          <div>
            <Logo />
            <p className="mt-4 max-w-xs text-[13px] leading-relaxed text-ink-muted">
              Same flight. Same direction. One shared ride. FlightShare connects verified passengers landing at
              Mumbai&apos;s Chhatrapati Shivaji Maharaj International Airport so airport transfers cost less and put fewer cars on the road.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Badge tone="amber">Demo environment</Badge>
              <Badge tone="muted">Mumbai (BOM) only</Badge>
            </div>
          </div>
          {COLUMNS.map((col) => (
            <div key={col.title}>
              <h3 className="text-[11px] font-bold uppercase tracking-[0.14em] text-ink-muted">{col.title}</h3>
              <ul className="mt-3.5 space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.href}>
                    <Link href={l.href} className="text-[13px] text-ink-soft transition hover:text-indigo">{l.label}</Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 rounded-xl border border-[#F8E2B0] bg-amber-soft/60 px-4 py-3 text-[11.5px] leading-relaxed text-amber-dark">
          <strong>Prototype notice.</strong> FlightShare is an early-stage demonstration product. Flights, passengers, fares, payments and
          verification statuses shown are sample data unless an integration is explicitly configured. No booking is made with any airline,
          no payment is captured, and no transport is dispatched. Fares are estimates until a verified driver accepts a trip. Real-world
          launch requires legal review covering privacy, transport permits, taxation, payments and insurance.
        </div>

        <div className="mt-8 flex flex-col items-start justify-between gap-3 border-t border-line pt-6 text-[11.5px] text-ink-muted sm:flex-row sm:items-center">
          <p>© {new Date().getFullYear()} FlightShare Technologies (demo). Built for Mumbai.</p>
          <p className="flex items-center gap-3">
            <span>Prices include applicable fees where shown</span>
            <span className="hidden h-3 w-px bg-line sm:block" />
            <span>Made with care in India</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
