"use client";
import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X, LayoutDashboard, ChevronRight } from "lucide-react";
import { Logo } from "@/components/brand/logo";
import { LinkButton } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/how-it-works", label: "How it works" },
  { href: "/destinations", label: "Destinations" },
  { href: "/safety", label: "Safety" },
  { href: "/partners", label: "For drivers" },
];

export function SiteHeader({ user }: { user: { name: string; role: string } | null }) {
  const [open, setOpen] = React.useState(false);
  const pathname = usePathname();

  React.useEffect(() => setOpen(false), [pathname]);

  return (
    <header className="sticky top-0 z-50 border-b border-line/80 bg-white/85 backdrop-blur-lg">
      <div className="container-x flex h-[68px] items-center justify-between gap-4">
        <div className="flex items-center gap-8">
          <Link href="/" aria-label="FlightShare home">
            <Logo />
          </Link>
          <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "rounded-lg px-3 py-2 text-[13.5px] font-medium transition-colors",
                  pathname === item.href ? "bg-[#F4F3FF] text-indigo" : "text-ink-soft hover:bg-[#F7F8FC] hover:text-navy",
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>

        <div className="hidden items-center gap-2.5 lg:flex">
          {user ? (
            <>
              <LinkButton href="/app" variant="outline" size="sm" leftIcon={<LayoutDashboard className="h-4 w-4" />}>
                {user.name.split(" ")[0]}&apos;s dashboard
              </LinkButton>
              <LinkButton href="/search" size="sm">Find a ride</LinkButton>
            </>
          ) : (
            <>
              <Link href="/login" className="rounded-lg px-3 py-2 text-[13.5px] font-semibold text-ink-soft transition hover:text-navy">
                Sign in
              </Link>
              <LinkButton href="/search" size="sm" rightIcon={<ChevronRight className="h-4 w-4" />}>
                Find a ride
              </LinkButton>
            </>
          )}
        </div>

        <button
          onClick={() => setOpen((o) => !o)}
          className="grid h-10 w-10 place-items-center rounded-lg border border-line text-ink-soft lg:hidden"
          aria-expanded={open}
          aria-label={open ? "Close menu" : "Open menu"}
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {open && (
        <div className="border-t border-line bg-white lg:hidden">
          <nav className="container-x flex flex-col gap-1 py-3" aria-label="Mobile">
            {NAV.map((item) => (
              <Link key={item.href} href={item.href} className="rounded-lg px-3 py-2.5 text-sm font-medium text-ink-soft hover:bg-[#F7F8FC]">
                {item.label}
              </Link>
            ))}
            <div className="mt-2 flex gap-2 border-t border-line pt-3">
              {user ? (
                <LinkButton href="/app" className="flex-1" size="md">Open dashboard</LinkButton>
              ) : (
                <>
                  <LinkButton href="/login" variant="outline" className="flex-1" size="md">Sign in</LinkButton>
                  <LinkButton href="/search" className="flex-1" size="md">Find a ride</LinkButton>
                </>
              )}
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
