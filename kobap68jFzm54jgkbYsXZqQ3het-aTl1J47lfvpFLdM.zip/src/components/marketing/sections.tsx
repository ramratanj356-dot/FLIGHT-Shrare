import Link from "next/link";
import {
  ArrowRight, BadgeCheck, BaggageClaim, Building2, CalendarCheck, CarFront, CheckCircle2, ChevronRight,
  Clock, Coins, Fingerprint, Gauge, IndianRupee, Info, Leaf, Lock, MapPin, MessageSquare, Plane,
  Route, ShieldCheck, Sparkles, Split, Star, Users, Wallet,
} from "lucide-react";
import { Avatar, Badge, DemoBadge, SectionHeading } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";
import { MumbaiMap } from "@/components/brand/mumbai-map";
import { formatPaise } from "@/lib/money";
import { cn } from "@/lib/utils";
import type { DestinationRow } from "@/lib/db/queries";

// ── Fare comparison (illustrative, exactly as briefed) ──────────────────────
export function FareExampleStrip() {
  return (
    <div className="border-y border-line bg-white">
      <div className="container-x py-6">
        <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-between">
          <div className="flex items-center gap-2.5">
            <Badge tone="amber" icon={<Info className="h-3 w-3" />}>ILLUSTRATIVE EXAMPLE</Badge>
            <p className="text-[12.5px] text-ink-muted">Three passengers on one flight, heading the same way.</p>
          </div>
          <dl className="grid w-full grid-cols-3 gap-2 sm:w-auto sm:gap-6">
            <div className="text-center sm:text-left">
              <dt className="text-[10.5px] font-semibold uppercase tracking-[0.1em] text-ink-muted">Solo ride</dt>
              <dd className="text-xl font-bold text-navy line-through decoration-[#C7CBD6] decoration-2 tabular">₹1,200</dd>
            </div>
            <div className="text-center sm:text-left">
              <dt className="text-[10.5px] font-semibold uppercase tracking-[0.1em] text-ink-muted">Shared / person</dt>
              <dd className="text-xl font-bold text-indigo tabular">₹400</dd>
            </div>
            <div className="text-center sm:text-left">
              <dt className="text-[10.5px] font-semibold uppercase tracking-[0.1em] text-ink-muted">Potential saving</dt>
              <dd className="text-xl font-bold text-success-dark tabular">₹800</dd>
            </div>
          </dl>
        </div>
      </div>
    </div>
  );
}

// ── How it works ────────────────────────────────────────────────────────────
const STEPS = [
  {
    icon: Plane,
    title: "Enter your flight",
    body: "Airline, flight number, arrival date and your Mumbai destination. We check the flight against the schedule.",
    detail: "Takes about 30 seconds",
  },
  {
    icon: BadgeCheck,
    title: "Verify your booking",
    body: "A booking reference confirms you were actually on that flight, so groups are made of real fellow passengers.",
    detail: "Simulated in demo mode",
  },
  {
    icon: Users,
    title: "See compatible travellers",
    body: "Matches are scored on flight identity, destination proximity, luggage, seats and timing — with reasons you can read.",
    detail: "You choose, never auto-joined",
  },
  {
    icon: Wallet,
    title: "Join and split fairly",
    body: "Fares are split transparently and re-calculated when someone joins. Nothing is charged until a driver accepts.",
    detail: "Estimates until confirmed",
  },
];

export function HowItWorksSection() {
  return (
    <section id="how-it-works" className="py-20 sm:py-24">
      <div className="container-x">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <SectionHeading
            eyebrow="How it works"
            title="Built around one fact: you land together."
            description="Shared city cabs struggle with timing. Passengers on the same flight already arrive in the same window — FlightShare turns that into a fair, coordinated ride."
          />
          <LinkButton href="/how-it-works" variant="outline" size="sm" rightIcon={<ArrowRight className="h-4 w-4" />}>
            Read the full flow
          </LinkButton>
        </div>

        <ol className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((step, i) => (
            <li key={step.title} className="group relative">
              <div className="card h-full p-5 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lift">
                <div className="flex items-center justify-between">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-[#F4F3FF] text-indigo transition-colors group-hover:bg-indigo group-hover:text-white">
                    <step.icon className="h-5 w-5" />
                  </span>
                  <span className="text-[11px] font-bold tracking-[0.1em] text-[#C7CBD6]">0{i + 1}</span>
                </div>
                <h3 className="mt-4 text-[15px] font-semibold text-navy">{step.title}</h3>
                <p className="mt-1.5 text-[13px] leading-relaxed text-ink-muted">{step.body}</p>
                <p className="mt-3 inline-flex items-center gap-1.5 rounded-md bg-[#F7F8FC] px-2 py-1 text-[10.5px] font-medium text-ink-soft">
                  <Clock className="h-3 w-3" /> {step.detail}
                </p>
              </div>
              {i < STEPS.length - 1 && (
                <span className="absolute -right-2.5 top-1/2 z-10 hidden h-5 w-5 -translate-y-1/2 place-items-center rounded-full border border-line bg-white text-ink-muted lg:grid">
                  <ChevronRight className="h-3 w-3" />
                </span>
              )}
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

// ── Why FlightShare ─────────────────────────────────────────────────────────
const REASONS = [
  { icon: IndianRupee, title: "Lower estimated travel costs", body: "One vehicle, several fares replaced by one shared fare, split by rules you can inspect." },
  { icon: Plane, title: "Flight-based matching", body: "Matching starts from a shared arrival, not a hopeful pin on a map." },
  { icon: Fingerprint, title: "Verified passengers", body: "Booking reference and identity checks gate every seat — with honest demo labels." },
  { icon: Split, title: "Transparent splitting", body: "Equal, distance-weighted or hybrid. Every rupee is itemised and rounded in paise." },
  { icon: MapPin, title: "Convenient departures", body: "Shared meeting points inside the terminal, with a waiting window the group agrees to." },
  { icon: Leaf, title: "Fewer vehicles leaving BOM", body: "Three passengers in one cab instead of three cabs means less congestion and lower emissions." },
];

export function WhySection() {
  return (
    <section className="bg-white py-20 sm:py-24">
      <div className="container-x">
        <SectionHeading
          eyebrow="Why FlightShare"
          title="A fairer airport transfer, without the guesswork."
          description="We do not claim every shared ride is cheaper or faster. We show you the actual estimates for your flight and let you decide."
          align="center"
          className="mx-auto"
        />
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {REASONS.map((r) => (
            <div key={r.title} className="rounded-2xl border border-line bg-[#FCFCFE] p-5 transition-colors hover:bg-white hover:shadow-card">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-white text-indigo shadow-sm">
                <r.icon className="h-4.5 w-4.5" />
              </span>
              <h3 className="mt-4 text-[14.5px] font-semibold text-navy">{r.title}</h3>
              <p className="mt-1.5 text-[13px] leading-relaxed text-ink-muted">{r.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Popular destinations ────────────────────────────────────────────────────
export function DestinationsSection({ destinations }: { destinations: DestinationRow[] }) {
  const featured = destinations.filter((d) => ["thane-w", "mulund", "powai", "bandra-w", "vashi", "ghatkopar"].includes(d.id));
  return (
    <section className="py-20 sm:py-24">
      <div className="container-x">
        <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
          <div>
            <SectionHeading
              eyebrow="Mumbai, covered"
              title="Popular destinations from BOM"
              description="Curated pickup zones and neighbourhood coordinates for the routes passengers ask for most. Destination compatibility is scored on geography and road reality — Mulund and Thane share a corridor; Colaba and Borivali do not."
            />
            <div className="mt-7 grid grid-cols-2 gap-2.5">
              {featured.map((d) => (
                <Link
                  key={d.id}
                  href={`/rides?dest=${d.id}`}
                  className="group flex items-center justify-between rounded-xl border border-line bg-white px-3.5 py-3 transition hover:border-indigo-200 hover:shadow-card"
                >
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-semibold text-navy group-hover:text-indigo">{d.name}</p>
                    <p className="text-[11px] text-ink-muted">{d.distance_km} km · ~{d.drive_minutes} min</p>
                  </div>
                  <ChevronRight className="h-4 w-4 shrink-0 text-ink-muted transition group-hover:translate-x-0.5 group-hover:text-indigo" />
                </Link>
              ))}
            </div>
            <LinkButton href="/destinations" variant="outline" size="sm" className="mt-5" rightIcon={<ArrowRight className="h-4 w-4" />}>
              All {destinations.length} destinations
            </LinkButton>
          </div>
          <div className="card overflow-hidden p-2">
            <MumbaiMap
              stops={destinations.map((d) => ({ id: d.id, name: d.name, lat: d.lat, lng: d.lng, distanceKm: d.distance_km }))}
              highlight={["thane-w", "mulund", "powai", "bandra-w"]}
              height={420}
            />
          </div>
        </div>
      </div>
    </section>
  );
}

// ── Sample journey ──────────────────────────────────────────────────────────
const JOURNEY = [
  { time: "08:45", title: "AI 864 lands at T2", body: "Aarav, Priya and Rohan were on the same flight and matched before landing.", icon: Plane },
  { time: "09:02", title: "Baggage and group chat", body: "Priya's bag is on belt 7. The group chat shows everyone's readiness.", icon: BaggageClaim },
  { time: "09:18", title: "Meeting point confirmed", body: "Gate 3, by Pillar 14. The group waits up to 45 minutes — agreed in advance.", icon: Users },
  { time: "09:26", title: "Verified driver accepts", body: "Ramesh accepts the trip in a sedan. Fare locks from an estimate to a confirmed split.", icon: CarFront },
  { time: "09:41", title: "Two drop-offs, one cab", body: "Mulund first, then Thane West. Each passenger pays their calculated share.", icon: Route },
];

export function JourneySection() {
  return (
    <section className="bg-navy py-20 text-white sm:py-24">
      <div className="container-x">
        <div className="grid gap-12 lg:grid-cols-[0.85fr_1.15fr]">
          <div>
            <p className="eyebrow text-[#B7B1FF]">A sample journey</p>
            <h2 className="mt-3 text-display-md text-white">From touchdown to drop-off, coordinated in one thread.</h2>
            <p className="mt-4 max-w-md text-[14.5px] leading-relaxed text-white/60">
              This is the timeline a passenger sees on the trip screen. Readiness is confirmed by people, not inferred from the aircraft
              — because a plane landing is not the same as a passenger being ready.
            </p>
            <div className="mt-7 rounded-2xl border border-white/10 bg-white/[0.04] p-4">
              <div className="flex items-center justify-between text-[12px]">
                <span className="text-white/50">Group fare estimate</span>
                <span className="font-bold text-white tabular">₹1,144</span>
              </div>
              <div className="mt-2 flex items-center justify-between text-[12px]">
                <span className="text-white/50">Individual contributions</span>
                <span className="font-semibold text-[#8BE3B8] tabular">₹392 · ₹361 · ₹392</span>
              </div>
              <div className="mt-2 flex items-center justify-between text-[12px]">
                <span className="text-white/50">Combined saving</span>
                <span className="font-semibold text-[#8BE3B8] tabular">₹2,136</span>
              </div>
              <p className="mt-3 flex items-center gap-1.5 text-[10.5px] text-white/40">
                <Info className="h-3 w-3" /> Sample group · hybrid fare split · estimates, not charges
              </p>
            </div>
          </div>

          <ol className="relative space-y-1">
            <span className="absolute left-[27px] top-3 bottom-3 w-px bg-white/10" aria-hidden />
            {JOURNEY.map((j, i) => (
              <li key={j.title} className="relative flex gap-4 rounded-xl p-2.5 transition hover:bg-white/[0.03]">
                <span className="relative z-10 grid h-[34px] w-[34px] shrink-0 place-items-center rounded-full border border-white/15 bg-[#16203A]">
                  <j.icon className="h-3.5 w-3.5 text-[#B7B1FF]" />
                </span>
                <div className="min-w-0 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="rounded-md bg-white/10 px-1.5 py-0.5 text-[10.5px] font-bold text-white/80 tabular">{j.time}</span>
                    <h3 className="text-[13.5px] font-semibold text-white">{j.title}</h3>
                  </div>
                  <p className="mt-1 text-[12.5px] leading-relaxed text-white/50">{j.body}</p>
                </div>
                {i === 0 && <DemoBadge label="SAMPLE" className="ml-auto hidden shrink-0 self-start sm:inline-flex" />}
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}

// ── Safety ──────────────────────────────────────────────────────────────────
export function SafetySection() {
  return (
    <section className="py-20 sm:py-24">
      <div className="container-x">
        <div className="grid gap-10 lg:grid-cols-[1fr_1fr] lg:items-center">
          <div className="card p-6 sm:p-8">
            <div className="flex items-center gap-3">
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-success-soft text-success-dark">
                <ShieldCheck className="h-5 w-5" />
              </span>
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-success-dark">Trust, designed in</p>
                <h3 className="text-lg font-semibold text-navy">Verification you can see</h3>
              </div>
            </div>
            <ul className="mt-5 space-y-3.5">
              {[
                { icon: Plane, title: "Flight verification", body: "Booking references are checked against the flight before a group is considered verified.", status: "Simulated in this demo" },
                { icon: Fingerprint, title: "Identity checks", body: "Optional, provider-based checks attach a badge. Never shown as verified without a real result.", status: "Simulated in this demo" },
                { icon: Lock, title: "Privacy by default", body: "Phone numbers, booking references and documents are never shared with other passengers.", status: "Enforced in the data layer" },
                { icon: MessageSquare, title: "Reporting & blocking", body: "Every ride has a report control; trust & safety reviews reports in the admin console.", status: "Active" },
              ].map((item) => (
                <li key={item.title} className="flex gap-3">
                  <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-[#F7F8FC] text-ink-soft">
                    <item.icon className="h-4 w-4" />
                  </span>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-[13px] font-semibold text-navy">{item.title}</p>
                      <span className="rounded-md bg-[#F4F3FF] px-1.5 py-0.5 text-[9.5px] font-semibold uppercase tracking-wide text-indigo">{item.status}</span>
                    </div>
                    <p className="mt-0.5 text-[12.5px] leading-relaxed text-ink-muted">{item.body}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <SectionHeading
              eyebrow="Safety & privacy"
              title="Meet verified fellow travellers — not strangers from the internet."
              description="Every seat is tied to a flight and a person. The group chat is restricted to accepted passengers, and contact details stay private until you choose otherwise."
            />
            <div className="mt-6 grid grid-cols-2 gap-3">
              {[
                { label: "Accepted passengers only", icon: Users },
                { label: "No numbers shared by default", icon: Lock },
                { label: "Readiness confirmed by people", icon: CheckCircle2 },
                { label: "Admin-reviewed disputes", icon: Gauge },
              ].map((f) => (
                <div key={f.label} className="flex items-center gap-2.5 rounded-xl border border-line bg-white px-3 py-2.5">
                  <f.icon className="h-4 w-4 shrink-0 text-indigo" />
                  <span className="text-[12px] font-medium text-ink-soft">{f.label}</span>
                </div>
              ))}
            </div>
            <LinkButton href="/safety" variant="outline" size="sm" className="mt-5" rightIcon={<ArrowRight className="h-4 w-4" />}>
              How we handle safety
            </LinkButton>
          </div>
        </div>
      </div>
    </section>
  );
}

// ── FAQ ─────────────────────────────────────────────────────────────────────
const FAQS = [
  {
    q: "Is FlightShare a licensed taxi service?",
    a: "No. FlightShare is a matching and coordination layer in prototype stage. Rides are fulfilled by verified drivers and fleet partners who hold the required commercial permits. Before launch, the operating model must be reviewed by qualified counsel for transport permits, taxation, privacy and insurance.",
  },
  {
    q: "How are fares calculated and split?",
    a: "The vehicle fare is estimated from a base fare, a per-kilometre component on the shared route, an extra drop-off charge and any tolls. A platform fee and tax on that fee are added. The total is then split equally, by distance, or by a hybrid rule, in integer paise so the parts always add up exactly.",
  },
  {
    q: "What if my flight is delayed or baggage takes longer?",
    a: "Flight status and your expected kerb time feed the group's departure window. Each passenger confirms readiness — landed, collecting baggage, ready at the meeting point. Groups agree a maximum waiting window in advance, and coordinators can re-match if someone cannot make it.",
  },
  {
    q: "Do you verify that I was actually on the flight?",
    a: "The platform is built to verify a booking reference through an authorised provider. In this demo, that check is simulated and labelled as such everywhere it appears. We never claim access to airline passenger manifests.",
  },
  {
    q: "Is my personal information shared with other passengers?",
    a: "Other passengers see a shortened name, your destination area, luggage size and verification badges. Phone numbers, email addresses, booking references, payment details and documents are not exposed. All access is authorised on the server.",
  },
  {
    q: "Can sharing ever cost more than a solo cab?",
    a: "Yes — if a group is small, destinations diverge, or tolls add up. We show that honestly in the fare breakdown and the savings calculator instead of promising that sharing is always cheaper.",
  },
];

export function FaqSection() {
  return (
    <section className="bg-white py-20 sm:py-24">
      <div className="container-x grid gap-10 lg:grid-cols-[0.8fr_1.2fr]">
        <div>
          <SectionHeading eyebrow="FAQ" title="Questions passengers actually ask." />
          <p className="mt-4 text-[13.5px] leading-relaxed text-ink-muted">
            Still unsure? <Link href="/help" className="link">Talk to the team</Link> — or read the{" "}
            <Link href="/safety" className="link">safety model</Link>.
          </p>
        </div>
        <div className="divide-y divide-line border-y border-line">
          {FAQS.map((f) => (
            <details key={f.q} className="group py-4">
              <summary className="flex cursor-pointer list-none items-start justify-between gap-4 text-[14px] font-semibold text-navy [&::-webkit-details-marker]:hidden">
                {f.q}
                <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full border border-line text-ink-muted transition group-open:rotate-45 group-open:border-indigo group-open:text-indigo">
                  +
                </span>
              </summary>
              <p className="mt-2.5 max-w-2xl text-[13px] leading-relaxed text-ink-muted">{f.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Partner band ────────────────────────────────────────────────────────────
export function PartnerBand() {
  return (
    <section className="container-x py-6">
      <div className="relative overflow-hidden rounded-3xl bg-navy px-6 py-10 sm:px-10 sm:py-12">
        <div className="pointer-events-none absolute inset-0 opacity-[0.16]" style={{ backgroundImage: "radial-gradient(#8C82FF 0.5px, transparent 0.5px)", backgroundSize: "18px 18px" }} />
        <div className="relative grid gap-8 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
          <div>
            <Badge tone="white">For drivers & fleet partners</Badge>
            <h2 className="mt-4 text-display-md text-white">Fill the empty seats you were already driving past.</h2>
            <p className="mt-3 max-w-xl text-[14px] leading-relaxed text-white/60">
              Accept airport transfers with passenger counts, luggage and destinations known in advance. Transparent commission,
              a settlement ledger and document-based verification.
            </p>
            <div className="mt-6 flex flex-wrap gap-2.5">
              <LinkButton href="/partners" size="md" variant="white" rightIcon={<ArrowRight className="h-4 w-4" />}>
                Register as a driver
              </LinkButton>
              <LinkButton href="/driver" size="md" variant="outline" className="border-white/20 bg-white/5 text-white hover:bg-white/10 hover:border-white/30">
                Driver portal
              </LinkButton>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "Trips with known loads", value: "Pre-assigned", icon: CalendarCheck },
              { label: "Commission", value: "Transparent", icon: Coins },
              { label: "Verification", value: "Document-based", icon: BadgeCheck },
              { label: "Payout ledger", value: "Per trip", icon: Wallet },
            ].map((s) => (
              <div key={s.label} className="rounded-2xl border border-white/10 bg-white/[0.04] p-3.5">
                <s.icon className="h-4 w-4 text-[#B7B1FF]" />
                <p className="mt-2.5 text-[13px] font-semibold text-white">{s.value}</p>
                <p className="text-[10.5px] text-white/40">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// ── Final CTA ───────────────────────────────────────────────────────────────
export function FinalCta() {
  return (
    <section className="py-20 sm:py-24">
      <div className="container-x">
        <div className="relative overflow-hidden rounded-3xl border border-indigo-100 bg-gradient-to-br from-[#F7F6FF] via-white to-[#F4FBF7] px-6 py-14 text-center sm:px-10">
          <div className="pointer-events-none absolute -left-20 -top-20 h-56 w-56 rounded-full bg-[#E9E5FF] blur-3xl" />
          <div className="pointer-events-none absolute -bottom-24 -right-16 h-56 w-56 rounded-full bg-[#DDF5E9] blur-3xl" />
          <div className="relative mx-auto max-w-xl">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-indigo-100 bg-white px-3 py-1 text-[11px] font-semibold text-indigo">
              <Sparkles className="h-3 w-3" /> Same flight. Same direction. One shared ride.
            </span>
            <h2 className="mt-5 text-display-lg text-navy">Land together. Travel together.</h2>
            <p className="mx-auto mt-3.5 max-w-md text-[14.5px] leading-relaxed text-ink-muted">
              Find compatible passengers on your next flight into Mumbai and turn an expensive airport transfer into an affordable shared journey.
            </p>
            <div className="mt-7 flex flex-col items-center justify-center gap-2.5 sm:flex-row">
              <LinkButton href="/search" size="lg" rightIcon={<ArrowRight className="h-4 w-4" />}>Find my ride</LinkButton>
              <LinkButton href="/how-it-works" size="lg" variant="outline">See how it works</LinkButton>
            </div>
            <p className="mt-4 flex items-center justify-center gap-1.5 text-[11px] text-ink-muted">
              <Star className="h-3 w-3 text-amber" /> Demo data — no bookings, payments or dispatch occur.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
