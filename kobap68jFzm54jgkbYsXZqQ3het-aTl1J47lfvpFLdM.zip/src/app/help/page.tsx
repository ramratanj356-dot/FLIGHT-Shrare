import Link from "next/link";
import {
  BadgeCheck, Banknote, CalendarClock, CreditCard, HelpCircle, Luggage, Mail, MessageSquare,
  PlaneTakeoff, ShieldQuestion, Users, Wallet,
} from "lucide-react";
import { SiteHeader } from "@/components/marketing/site-header";
import { SiteFooter } from "@/components/marketing/site-footer";
import { getSessionUser } from "@/lib/auth/session";
import { Badge, DemoBadge, SectionHeading } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";
import { SupportForm } from "@/components/forms/support-form";

export const metadata = { title: "Help centre" };

const FAQS: { icon: typeof HelpCircle; q: string; a: string; tag?: string }[] = [
  {
    icon: PlaneTakeoff,
    q: "My flight number is not recognised. What do I do?",
    a: "The search accepts airline code plus digits (AI864, 6E5123, UK927). If your flight is outside the demo schedule — 14 days from today for BOM — you will see an explanation rather than an invented result. You can still create a group; it simply will not be matched to a sample flight until the schedule covers it.",
    tag: "Search",
  },
  {
    icon: Users,
    q: "Can I join a group whose destination is different from mine?",
    a: "Yes, if the compatibility threshold passes. Mulund and Thane West share a corridor, so a Thane group can take a Mulund passenger as a second stop. Colaba and Borivali are blocked — different direction, no shared road corridor.",
    tag: "Matching",
  },
  {
    icon: Wallet,
    q: "When do I actually pay?",
    a: "Never by clicking a match. Payment is collected only after the coordinator approves your request and the fare is confirmed. In demo mode no gateway is configured, so a booking is recorded as an estimate and nothing is charged.",
    tag: "Payments",
  },
  {
    icon: BadgeCheck,
    q: "Why is my verification marked 'simulated'?",
    a: "Because it is. The prototype has no flight-data or identity provider credentials, so verification outcomes are generated locally and labelled. A production deployment configures FLIGHT_API_KEY and VERIFICATION_API_KEY, at which point the same UI reports a real provider status.",
    tag: "Verification",
  },
  {
    icon: CalendarClock,
    q: "What happens if someone is late?",
    a: "Each group has a maximum wait agreed before joining. Readiness is explicit: not landed, landed, collecting baggage, ready, boarding, started. If someone stalls beyond the window the group is notified and the coordinator can depart, re-split the fare between remaining passengers, or cancel.",
    tag: "Coordination",
  },
  {
    icon: Luggage,
    q: "How is luggage counted?",
    a: "Cabin bag = 1 unit, one checked bag = 1 unit, two checked bags = 2, heavy = 3. The vehicle has a total unit capacity; a join is blocked if the group's remaining luggage space cannot cover you.",
    tag: "Capacity",
  },
  {
    icon: CreditCard,
    q: "The fare changed after another passenger joined. Why?",
    a: "Because sharing is dynamic. Adding a passenger usually lowers everyone's contribution, but a detour to a second drop-off can raise the vehicle fare. Every estimate shows the previous and current split, and no confirmed booking is silently repriced.",
    tag: "Fares",
  },
  {
    icon: ShieldQuestion,
    q: "Is my phone number visible to the group?",
    a: "No, not by default. Only your first name, initials avatar, verification badges and luggage count are shown. A coordinator can see contact details only after you explicitly share them post-approval.",
    tag: "Privacy",
  },
];

export default async function HelpPage() {
  const user = await getSessionUser();
  return (
    <>
      <SiteHeader user={user ? { name: user.name, role: user.role } : null} />
      <main id="main">
        <section className="border-b border-line bg-white">
          <div className="container-x py-12">
            <Badge tone="indigo" icon={<HelpCircle className="h-3 w-3" />}>Support</Badge>
            <h1 className="mt-3 text-[30px] font-bold tracking-[-0.03em] text-navy sm:text-[40px]">How can we help?</h1>
            <p className="mt-3 max-w-2xl text-[14px] leading-relaxed text-ink-muted">
              Short, honest answers — including the ones about what this prototype cannot do yet. If something is missing, open a ticket below;
              it lands in the admin support queue.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              {["Search", "Matching", "Fares", "Payments", "Coordination", "Verification", "Privacy", "Capacity"].map((t) => (
                <span key={t} className="rounded-lg border border-line bg-[#FBFBFE] px-2.5 py-1 text-[11px] font-medium text-ink-soft">{t}</span>
              ))}
            </div>
          </div>
        </section>

        <section className="py-10">
          <div className="container-x grid gap-8 lg:grid-cols-[1.4fr_1fr] lg:items-start">
            <div>
              <SectionHeading eyebrow="FAQ" title="Questions people actually ask" />
              <div className="mt-5 space-y-2.5">
                {FAQS.map((f) => (
                  <details key={f.q} className="group card overflow-hidden p-0">
                    <summary className="flex cursor-pointer list-none items-start gap-2.5 px-4 py-3.5">
                      <f.icon className="mt-0.5 h-4 w-4 shrink-0 text-indigo" />
                      <span className="flex-1 text-[13px] font-semibold text-navy">{f.q}</span>
                      <span className="mt-0.5 text-[10px] font-semibold uppercase tracking-wide text-ink-muted group-open:hidden">Open</span>
                      <span className="mt-0.5 hidden text-[10px] font-semibold uppercase tracking-wide text-indigo group-open:block">Close</span>
                    </summary>
                    <div className="border-t border-line px-4 pb-4 pt-3 text-[12px] leading-relaxed text-ink-muted">
                      {f.a}
                      {f.tag && <span className="ml-2 inline-block rounded bg-[#F2F4F7] px-1.5 py-0.5 text-[9.5px] font-semibold uppercase tracking-wide text-ink-soft">{f.tag}</span>}
                    </div>
                  </details>
                ))}
              </div>

              <div className="mt-6 grid gap-3 sm:grid-cols-3">
                {[
                  { icon: MessageSquare, t: "Report a problem in a ride", d: "Ride chat → Report. Categories include no-show, safety and fare dispute.", href: "/app/trips" },
                  { icon: Mail, t: "Email support", d: "support@flightshare.app (demo address, not monitored).", href: "/help" },
                  { icon: Banknote, t: "Refund questions", d: "Refunds require an admin review and a configured gateway.", href: "/legal/terms" },
                ].map((c) => (
                  <Link key={c.t} href={c.href} className="rounded-xl border border-line bg-white p-3.5 transition hover:border-indigo-200 hover:shadow-card">
                    <c.icon className="h-4 w-4 text-indigo" />
                    <p className="mt-1.5 text-[12px] font-semibold text-navy">{c.t}</p>
                    <p className="mt-0.5 text-[10.5px] leading-relaxed text-ink-muted">{c.d}</p>
                  </Link>
                ))}
              </div>
            </div>

            <aside className="lg:sticky lg:top-24">
              <SupportForm signedIn={Boolean(user)} email={user?.email} />
              <div className="mt-3 flex items-start gap-2 rounded-xl border border-line bg-white px-3.5 py-2.5 text-[10.5px] leading-relaxed text-ink-muted">
                <DemoBadge label="DEMO" />
                <span>Tickets are stored in this prototype database only. No support inbox receives them.</span>
              </div>
            </aside>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
