import Link from "next/link";
import {
  ArrowRight, ArrowUpRight, Bell, CalendarClock, CheckCircle2, ChevronRight, Compass, Info,
  MapPin, MessageSquare, Plus, Search, ShieldCheck, Sparkles, TrendingDown, Users, Wallet,
} from "lucide-react";
import { requireUser } from "@/lib/auth/guards";
import { listUserTrips, listOwnedJoinRequests, listNotifications, getPassengerProfile, listDestinations } from "@/lib/db/queries";
import { formatDateLong, formatTime, relativeTime } from "@/lib/utils";
import { formatPaise } from "@/lib/money";
import { Avatar, Badge, DemoBadge, EmptyState } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";
import { PageHeading } from "@/components/app/app-shell";
import { READINESS_LABELS, type ReadinessState } from "@/lib/config/pricing";
import { PassengerTripCard } from "@/components/app/trip-card";

export const dynamic = "force-dynamic";
export const metadata = { title: "Your dashboard" };

export default async function DashboardPage() {
  const user = await requireUser("/app");
  const trips = listUserTrips(user.id, "all");
  const upcoming = trips
    .filter((t) => ["open", "full", "confirmed", "in_progress"].includes(t.group.status))
    .sort((a, b) => String(a.group.flight.estimated_arrival).localeCompare(String(b.group.flight.estimated_arrival)));
  const soon = upcoming.filter((t) => {
    const when = new Date(String(t.group.flight.estimated_arrival)).getTime();
    return when < Date.now() + 72 * 3600_000;
  });
  const past = trips.filter((t) => ["completed", "cancelled"].includes(t.group.status));
  const requests = listOwnedJoinRequests(user.id);
  const notifications = listNotifications(user.id, 5);
  const profile = getPassengerProfile(user.id);
  const destinations = listDestinations();
  const homeDest = destinations.find((d) => d.id === profile?.home_destination_id);

  const savings = trips.reduce((s, t) => s + Math.max(0, t.mySavingsPaise), 0);
  const completedCount = past.filter((t) => t.group.status === "completed").length;

  return (
    <div>
      <PageHeading
        badge={<><DemoBadge label="DEMO DATA" /><span className="text-[11px] text-ink-muted">Sample rides in a prototype database</span></>}
        title={`Namaste, ${user.name.split(" ")[0]}`}
        description="Your airport rides, matches and coordination in one place."
        actions={
          <>
            <LinkButton href="/search" variant="outline" size="md" leftIcon={<Search className="h-4 w-4" />}>Find a ride</LinkButton>
            <LinkButton href="/app/rides/new" size="md" leftIcon={<Plus className="h-4 w-4" />}>Start a ride</LinkButton>
          </>
        }
      />

      {/* Profile completeness */}
      {!user.emailVerified && (
        <div className="mb-4 flex flex-col justify-between gap-2 rounded-xl border border-[#F8E2B0] bg-amber-soft px-4 py-3 sm:flex-row sm:items-center">
          <p className="flex items-start gap-2 text-[12.5px] leading-relaxed text-amber-dark">
            <Bell className="mt-0.5 h-4 w-4 shrink-0" />
            <span><strong>Verify your email</strong> to unlock joining rides and trip notifications.</span>
          </p>
          <LinkButton href="/app/profile" size="sm" variant="outline" className="shrink-0">Verify now</LinkButton>
        </div>
      )}

      {/* Stat strip */}
      <div className="grid grid-cols-2 gap-2.5 sm:gap-3 lg:grid-cols-4">
        {[
          { label: "Upcoming rides", value: String(soon.length), sub: "arriving in the next 72 hours", icon: Compass, tone: "indigo" },
          { label: "Completed trips", value: String(completedCount), sub: "in this demo account", icon: CheckCircle2, tone: "success" },
          { label: "Estimated savings", value: formatPaise(savings), sub: "across your rides", icon: TrendingDown, tone: "success" },
          { label: "Pending approvals", value: String(requests.length), sub: requests.length ? "waiting on you" : "nothing to review", icon: Users, tone: requests.length ? "amber" : "muted" },
        ].map((s) => (
          <div key={s.label} className="card p-4">
            <div className="flex items-start justify-between">
              <p className="text-[11.5px] font-medium text-ink-muted">{s.label}</p>
              <span className={`grid h-7 w-7 place-items-center rounded-lg ${s.tone === "success" ? "bg-success-soft text-success-dark" : s.tone === "amber" ? "bg-amber-soft text-amber-dark" : s.tone === "indigo" ? "bg-[#F4F3FF] text-indigo" : "bg-[#F2F4F7] text-ink-muted"}`}>
                <s.icon className="h-3.5 w-3.5" />
              </span>
            </div>
            <p className="mt-1.5 text-[22px] font-bold leading-none tracking-tight text-navy tabular">{s.value}</p>
            <p className="mt-1 text-[10.5px] text-ink-muted">{s.sub}</p>
          </div>
        ))}
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-[1fr_330px]">
        <div className="space-y-5">
          {/* Pending join requests (as coordinator) */}
          {requests.length > 0 && (
            <section className="card overflow-hidden">
              <div className="flex items-center justify-between border-b border-line px-4 py-3">
                <div className="flex items-center gap-2">
                  <span className="grid h-8 w-8 place-items-center rounded-lg bg-amber-soft text-amber-dark"><Users className="h-4 w-4" /></span>
                  <div>
                    <p className="text-[13px] font-semibold text-navy">Join requests waiting for you</p>
                    <p className="text-[10.5px] text-ink-muted">You coordinate these rides</p>
                  </div>
                </div>
                <Badge tone="amber">{requests.length}</Badge>
              </div>
              <ul className="divide-y divide-line">
                {requests.map((r) => (
                  <li key={r.id}>
                    <Link href={`/app/trips/${r.ride_group_id}`} className="flex items-center justify-between gap-3 px-4 py-3 transition hover:bg-[#FBFBFE]">
                      <div className="flex min-w-0 items-center gap-2.5">
                        <Avatar name={r.name} size="sm" verified={r.identity_status === "verified"} />
                        <div className="min-w-0">
                          <p className="truncate text-[12.5px] font-semibold text-navy">{r.name}</p>
                          <p className="truncate text-[10.5px] text-ink-muted">
                            {r.passenger_count} pax · {r.destination_name} · match {r.match_score ?? "—"}
                          </p>
                        </div>
                      </div>
                      <span className="flex shrink-0 items-center gap-1 text-[11.5px] font-semibold text-indigo">
                        Review <ChevronRight className="h-3.5 w-3.5" />
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {/* Upcoming trips */}
          <section>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-[15px] font-semibold text-navy">Upcoming rides</h2>
              <Link href="/app/trips" className="text-[12px] font-medium text-indigo hover:underline">All trips</Link>
            </div>
            {upcoming.length === 0 ? (
              <EmptyState
                icon={<Compass className="h-5 w-5" />}
                title="No upcoming rides yet"
                description={homeDest
                  ? `You usually head to ${homeDest.name}. Search your next flight into BOM and we'll show everyone going your way.`
                  : "Search your next flight into Mumbai and we'll show everyone heading your way."}
                action={<LinkButton href="/search" size="md" rightIcon={<ArrowRight className="h-4 w-4" />}>Find my ride</LinkButton>}
              />
            ) : (
              <div className="space-y-3">
                {upcoming.slice(0, 3).map((t) => <PassengerTripCard key={t.group.id} trip={t} />)}
              </div>
            )}
          </section>

          {/* Past */}
          {past.length > 0 && (
            <section>
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-[15px] font-semibold text-navy">Recent history</h2>
                <Link href="/app/trips?tab=past" className="text-[12px] font-medium text-indigo hover:underline">See all</Link>
              </div>
              <div className="card divide-y divide-line">
                {past.slice(0, 3).map((t) => (
                  <Link key={t.group.id} href={`/app/trips/${t.group.id}`} className="flex items-center justify-between gap-3 px-4 py-3 transition hover:bg-[#FBFBFE]">
                    <div className="flex min-w-0 items-center gap-2.5">
                      <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg ${t.group.status === "completed" ? "bg-success-soft text-success-dark" : "bg-[#F2F4F7] text-ink-muted"}`}>
                        {t.group.status === "completed" ? <CheckCircle2 className="h-4 w-4" /> : <Info className="h-4 w-4" />}
                      </span>
                      <div className="min-w-0">
                        <p className="truncate text-[12.5px] font-semibold text-navy">{t.group.destination.name}</p>
                        <p className="truncate text-[10.5px] text-ink-muted">{formatDateLong(t.group.flight.flight_date)} · {t.group.flight.flight_number} · {t.group.status}</p>
                      </div>
                    </div>
                    <div className="shrink-0 text-right">
                      <p className="text-[12.5px] font-bold text-navy tabular">{formatPaise(t.myContributionPaise)}</p>
                      {t.mySavingsPaise > 0 && <p className="text-[10px] font-medium text-success-dark">saved {formatPaise(t.mySavingsPaise)}</p>}
                    </div>
                  </Link>
                ))}
              </div>
            </section>
          )}
        </div>

        {/* Sidebar */}
        <aside className="space-y-4">
          <div className="card overflow-hidden">
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <p className="text-[12.5px] font-semibold text-navy">Notifications</p>
              <Link href="/app/notifications" className="text-[11px] font-medium text-indigo hover:underline">View all</Link>
            </div>
            {notifications.length === 0 ? (
              <p className="px-4 py-6 text-center text-[11.5px] text-ink-muted">No notifications yet.</p>
            ) : (
              <ul className="divide-y divide-line">
                {notifications.map((n) => (
                  <li key={n.id}>
                    <Link href={n.href ?? "/app"} className="block px-4 py-2.5 transition hover:bg-[#FBFBFE]">
                      <p className="flex items-start gap-1.5 text-[11.5px] font-semibold leading-snug text-navy">
                        {!n.read_at && <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-indigo" />}
                        {n.title}
                      </p>
                      <p className="mt-0.5 line-clamp-2 pl-3 text-[10.5px] leading-relaxed text-ink-muted">{n.body}</p>
                      <p className="mt-0.5 pl-3 text-[9.5px] text-[#98A2B3]">{relativeTime(n.created_at)}</p>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="card p-4">
            <p className="text-[12.5px] font-semibold text-navy">Your trust profile</p>
            <ul className="mt-2.5 space-y-2">
              {[
                { label: "Email verified", ok: user.emailVerified },
                { label: "Phone verified", ok: user.phoneVerified },
                { label: "Identity check (simulated)", ok: profile?.identity_status === "verified" },
                { label: "Home area saved", ok: Boolean(profile?.home_destination_id) },
              ].map((row) => (
                <li key={row.label} className="flex items-center justify-between text-[11.5px]">
                  <span className="text-ink-soft">{row.label}</span>
                  {row.ok ? <Badge tone="success">Done</Badge> : <Badge tone="muted">Pending</Badge>}
                </li>
              ))}
            </ul>
            <LinkButton href="/app/profile" variant="outline" size="sm" className="mt-3 w-full">Complete profile</LinkButton>
            <p className="mt-2 flex items-start gap-1 text-[10px] leading-relaxed text-ink-muted">
              <ShieldCheck className="mt-px h-3 w-3 shrink-0" /> Verified passengers earn a trust boost in match scores.
            </p>
          </div>

          <div className="rounded-xl border border-line bg-white p-4">
            <p className="flex items-center gap-1.5 text-[12px] font-semibold text-navy"><Sparkles className="h-3.5 w-3.5 text-indigo" /> Tip</p>
            <p className="mt-1.5 text-[11px] leading-relaxed text-ink-muted">
              Confirm your readiness as soon as you reach the meeting point — groups with everyone ready are matched to drivers first.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}
