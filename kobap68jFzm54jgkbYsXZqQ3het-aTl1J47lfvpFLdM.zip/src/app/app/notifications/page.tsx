import Link from "next/link";
import { Bell } from "lucide-react";
import { requireUser } from "@/lib/auth/guards";
import { listNotifications } from "@/lib/db/queries";
import { getDb } from "@/lib/db";
import { Badge, DemoBadge, EmptyState } from "@/components/ui/primitives";
import { PageHeading } from "@/components/app/app-shell";
import { relativeTime, formatDateTime } from "@/lib/utils";
import { MarkAllRead } from "@/components/app/mark-all-read";

export const dynamic = "force-dynamic";
export const metadata = { title: "Notifications" };

const ICONS: Record<string, string> = {
  join_request: "bg-amber-soft text-amber-dark",
  join_approved: "bg-success-soft text-success-dark",
  join_declined: "bg-[#F2F4F7] text-ink-muted",
  driver_assigned: "bg-[#F4F3FF] text-indigo",
  fare_updated: "bg-[#F4F3FF] text-indigo",
  departure_confirmed: "bg-success-soft text-success-dark",
  payment: "bg-success-soft text-success-dark",
  refund: "bg-[#F2F4F7] text-ink-muted",
  ride_cancelled: "bg-danger-soft text-danger",
  verification: "bg-[#F4F3FF] text-indigo",
  welcome: "bg-[#F4F3FF] text-indigo",
  group_ready: "bg-success-soft text-success-dark",
  trip_completed: "bg-[#F2F4F7] text-ink-muted",
  support: "bg-[#F2F4F7] text-ink-muted",
};

export default async function NotificationsPage() {
  const user = await requireUser("/app/notifications");
  const notifications = listNotifications(user.id, 60);
  const unread = notifications.filter((n) => !n.read_at).length;

  // Mark as read on open (the list is a read surface, the badge drives attention).
  if (unread > 0) {
    getDb().prepare("UPDATE notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL").run(new Date().toISOString(), user.id);
  }

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeading
        title="Notifications"
        description="Trip updates, fare changes, verification results and safety notices."
        actions={unread > 0 ? <MarkAllRead /> : undefined}
      />

      {notifications.length === 0 ? (
        <EmptyState
          icon={<Bell className="h-5 w-5" />}
          title="Nothing to show yet"
          description="When a coordinator answers your request, a fare is re-split or a driver is assigned, it lands here."
        />
      ) : (
        <div className="card divide-y divide-line">
          {notifications.map((n) => (
            <Link key={n.id} href={n.href ?? "/app"} className="flex gap-3 px-4 py-3.5 transition hover:bg-[#FBFBFE]">
              <span className={`mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg ${ICONS[n.type] ?? "bg-[#F2F4F7] text-ink-muted"}`}>
                <Bell className="h-3.5 w-3.5" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-[12.5px] font-semibold leading-snug text-navy">{n.title}</p>
                  <span className="shrink-0 text-[10px] text-ink-muted">{relativeTime(n.created_at)}</span>
                </div>
                <p className="mt-0.5 text-[11.5px] leading-relaxed text-ink-muted">{n.body}</p>
                <div className="mt-1 flex items-center gap-1.5">
                  <span className="text-[9.5px] text-[#98A2B3]">{formatDateTime(n.created_at)}</span>
                  {Boolean(n.is_demo) && <DemoBadge label="SIMULATED" />}
                  {!n.read_at && <Badge tone="indigo">New</Badge>}
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
