import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, MapPin, ShieldCheck, Users } from "lucide-react";
import { requireUser } from "@/lib/auth/guards";
import { listMessages, getTripDetail } from "@/lib/db/queries";
import { listConversationForUser } from "@/lib/services/chat";
import { GroupChat } from "@/components/app/group-chat";
import { Badge, DemoBadge } from "@/components/ui/primitives";
import { formatDateLong, formatTime } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function ConversationPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await requireUser(`/app/messages/${id}`);
  const detail = getTripDetail(id, user.id);
  if (!detail || !detail.isMember) notFound();
  const conversation = detail.conversationId ? listConversationForUser(detail.conversationId, user.id) : null;
  if (!conversation) notFound();

  const messages = listMessages(conversation.id, user.id);
  const readOnly = ["completed", "cancelled"].includes(detail.group.status);

  return (
    <div className="mx-auto max-w-3xl">
      <Link href="/app/messages" className="inline-flex items-center gap-1.5 text-[12px] font-medium text-ink-muted hover:text-indigo">
        <ArrowLeft className="h-3.5 w-3.5" /> All messages
      </Link>

      <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-1.5">
            <h1 className="text-[20px] font-bold tracking-[-0.02em] text-navy">{conversation.destination}</h1>
            <Badge tone="muted">{conversation.flight_number}</Badge>
            {detail.group.isDemo && <DemoBadge label="DEMO" />}
          </div>
          <p className="mt-0.5 text-[11.5px] text-ink-muted">
            {formatDateLong(conversation.flight_date)} · arrival {formatTime(conversation.departure_window_start)} · {conversation.code}
          </p>
        </div>
        <Link href={`/app/trips/${id}`} className="rounded-lg border border-line px-3 py-1.5 text-[11.5px] font-semibold text-ink-soft hover:border-indigo-200 hover:text-indigo">
          Open trip
        </Link>
      </div>

      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl border border-line bg-white px-3 py-2.5">
          <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-ink-muted"><MapPin className="h-3 w-3" /> Meeting point</p>
          <p className="mt-1 text-[11.5px] leading-relaxed text-navy">{conversation.meet_point}</p>
        </div>
        <div className="rounded-xl border border-line bg-white px-3 py-2.5">
          <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-ink-muted"><Users className="h-3 w-3" /> Group</p>
          <p className="mt-1 text-[11.5px] text-navy">
            {detail.group.members.length} travellers · waits up to {conversation.max_wait_minutes} min
          </p>
        </div>
      </div>

      <div className="mt-3">
        <GroupChat
          rideId={id}
          initialMessages={messages}
          currentUserId={user.id}
          conversationId={conversation.id}
          readOnly={readOnly}
        />
      </div>

      <p className="mt-3 flex items-start gap-1.5 text-[10.5px] leading-relaxed text-ink-muted">
        <ShieldCheck className="mt-px h-3 w-3 shrink-0" />
        Never share payment details or identity documents in chat. Use the report control on any message if something feels wrong.
      </p>
    </div>
  );
}
