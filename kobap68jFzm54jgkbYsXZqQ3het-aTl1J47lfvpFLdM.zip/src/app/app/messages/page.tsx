import Link from "next/link";
import { MessageSquare, Search } from "lucide-react";
import { requireUser } from "@/lib/auth/guards";
import { listUserConversations } from "@/lib/db/queries";
import { EmptyState, Badge } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";
import { PageHeading } from "@/components/app/app-shell";
import { relativeTime } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "Messages" };

export default async function MessagesPage() {
  const user = await requireUser("/app/messages");
  const conversations = listUserConversations(user.id);

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeading
        title="Messages"
        description="Ride-specific group chats. Only accepted passengers and the coordinator can read them."
        actions={<LinkButton href="/search" variant="outline" size="md" leftIcon={<Search className="h-4 w-4" />}>Find a ride</LinkButton>}
      />

      {conversations.length === 0 ? (
        <EmptyState
          icon={<MessageSquare className="h-5 w-5" />}
          title="No conversations yet"
          description="Once you join a ride, its group chat appears here — meeting-point instructions, readiness updates and driver assignment all land in the same thread."
          action={<LinkButton href="/search" size="md">Find a shared ride</LinkButton>}
        />
      ) : (
        <div className="card divide-y divide-line">
          {conversations.map((c) => (
            <Link key={c.id} href={`/app/messages/${c.ride_group_id}`} className="flex items-start gap-3 px-4 py-3.5 transition hover:bg-[#FBFBFE]">
              <span className="mt-0.5 grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#F4F3FF] text-indigo">
                <MessageSquare className="h-4 w-4" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-[13px] font-semibold text-navy">{c.destination} · {c.code}</p>
                  <span className="shrink-0 text-[10px] text-ink-muted">{c.last_at ? relativeTime(c.last_at) : "—"}</span>
                </div>
                <p className="mt-0.5 line-clamp-1 text-[11.5px] text-ink-muted">{c.last_body ?? "No messages yet"}</p>
                <div className="mt-1 flex items-center gap-1.5">
                  <Badge tone="muted">{c.flight_number}</Badge>
                  <Badge tone={c.status === "completed" ? "muted" : "success"} className="capitalize">{c.status}</Badge>
                  <span className="text-[10px] text-ink-muted">{c.message_count} messages</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
