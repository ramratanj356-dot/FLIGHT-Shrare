import Link from "next/link";
import { Compass, Search } from "lucide-react";
import { requireUser } from "@/lib/auth/guards";
import { listUserTrips } from "@/lib/db/queries";
import { EmptyState } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";
import { PageHeading } from "@/components/app/app-shell";
import { PassengerTripCard } from "@/components/app/trip-card";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "My trips" };

export default async function TripsPage({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const sp = await searchParams;
  const user = await requireUser("/app/trips");
  const tab = sp.tab === "past" ? "past" : sp.tab === "all" ? "all" : "upcoming";
  const trips = listUserTrips(user.id, tab as "upcoming" | "past" | "all");

  const TABS = [
    { key: "upcoming", label: "Upcoming" },
    { key: "past", label: "Past" },
    { key: "all", label: "All" },
  ];

  return (
    <div>
      <PageHeading
        title="My trips"
        description="Every ride you coordinate or join, with readiness, chat and pickup instructions."
        actions={<LinkButton href="/search" size="md" leftIcon={<Search className="h-4 w-4" />}>Find a ride</LinkButton>}
      />

      <div className="mb-4 flex gap-1 rounded-xl border border-line bg-white p-1 sm:w-fit" role="tablist">
        {TABS.map((t) => (
          <Link
            key={t.key}
            href={`/app/trips?tab=${t.key}`}
            role="tab"
            aria-selected={tab === t.key}
            className={cn(
              "flex-1 rounded-lg px-4 py-2 text-center text-[12.5px] font-semibold transition sm:flex-none",
              tab === t.key ? "bg-navy text-white" : "text-ink-muted hover:bg-[#F7F8FC]",
            )}
          >
            {t.label}
          </Link>
        ))}
      </div>

      {trips.length === 0 ? (
        <EmptyState
          icon={<Compass className="h-5 w-5" />}
          title={tab === "past" ? "No past trips yet" : "No trips here yet"}
          description={
            tab === "past"
              ? "Completed and cancelled rides will appear here with your final share and savings."
              : "Search a flight into Mumbai and join a ride group heading your way — or start one and let others request a seat."
          }
          action={<LinkButton href="/search" size="md">Find a shared ride</LinkButton>}
        />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {trips.map((t) => <PassengerTripCard key={t.group.id} trip={t} />)}
        </div>
      )}
    </div>
  );
}
