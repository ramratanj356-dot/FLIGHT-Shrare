import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft, ArrowRight, BadgeCheck, Bell, CarFront, CheckCircle2, Clock, CreditCard, Info,
  MapPin, MessageSquare, ShieldCheck, Users, XCircle,
} from "lucide-react";
import { requireUser } from "@/lib/auth/guards";
import { getPendingJoinRequest, getTripDetail } from "@/lib/db/queries";
import { listMessages } from "@/lib/db/queries";
import { getDb } from "@/lib/db";
import { computeDepartureWindow } from "@/lib/match/timing";
import { loadPricingRules } from "@/lib/db/pricing";
import { formatDateLong, formatDateTime, formatTime, relativeTime } from "@/lib/utils";
import { formatPaise } from "@/lib/money";
import { Avatar, Badge, DemoBadge, ScoreRing } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";
import { FareBreakdownCard } from "@/components/app/fare-breakdown";
import { GroupChat } from "@/components/app/group-chat";
import { ReadinessPanel } from "@/components/app/readiness-panel";
import { TripCoordinatorPanel } from "@/components/app/trip-coordinator-panel";
import { PaymentPanel } from "@/components/app/payment-panel";
import { RouteMap } from "@/components/brand/mumbai-map";
import { READINESS_LABELS, type ReadinessState } from "@/lib/config/pricing";
import { LiveStatus } from "@/components/app/live-status";
import { WithdrawRequestButton } from "@/components/forms/withdraw-request-button";

export const dynamic = "force-dynamic";

const STATUS_LABEL: Record<string, string> = {
  open: "Forming", full: "Full — awaiting driver", confirmed: "Driver assigned",
  in_progress: "On the way", completed: "Completed", cancelled: "Cancelled",
};

export default async function TripDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await requireUser(`/app/trips/${id}`);
  const detail = getTripDetail(id, user.id);
  if (!detail) notFound();
  if (!detail.isMember) {
    const pending = getPendingJoinRequest(id, user.id);
    if (pending) {
      return (
        <div className="mx-auto max-w-lg py-12">
          <div className="card p-6 text-center sm:p-8">
            <span className="mx-auto flex h-11 w-11 items-center justify-center rounded-full bg-[#F4F3FF] text-indigo">
              <Clock className="h-5 w-5" />
            </span>
            <h1 className="mt-3 text-lg font-semibold text-navy">Request sent — waiting on the coordinator</h1>
            <p className="mx-auto mt-1.5 max-w-sm text-[13px] leading-relaxed text-ink-muted">
              Your seat request is pending. Nothing has been charged and no seat is held yet. You&apos;ll get an
              in-app notification (and an email in a configured deployment) the moment it is reviewed.
            </p>
            <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
              <LinkButton href={`/rides/${id}`} size="md">View the ride</LinkButton>
              <WithdrawRequestButton requestId={pending.id} redirectTo="/app/trips" label="Withdraw request" size="md" />
            </div>
            <p className="mt-4 text-[11px] text-ink-muted">
              Requests expire if the group fills, the flight is cancelled, or the departure window closes.
            </p>
          </div>
        </div>
      );
    }
    return (
      <div className="mx-auto max-w-md py-16 text-center">
        <ShieldCheck className="mx-auto h-8 w-8 text-ink-muted" />
        <h1 className="mt-3 text-lg font-semibold text-navy">You&apos;re not in this ride</h1>
        <p className="mt-1.5 text-[13px] text-ink-muted">
          Trip details and chat are limited to accepted passengers. You can request a seat from the ride page.
        </p>
        <LinkButton href={`/rides/${id}`} className="mt-4" size="md">View the ride</LinkButton>
      </div>
    );
  }

  const { group, membership, isOwner, myFare, booking, payment, events, conversationId, joinRequests } = detail;
  const db = getDb();
  const rules = loadPricingRules(db);
  const messages = conversationId ? listMessages(conversationId, user.id) : [];
  const departureWindow = computeDepartureWindow({
    scheduledArrival: group.flight.scheduled_arrival,
    estimatedArrival: group.flight.estimated_arrival,
    status: group.flight.status,
    baggageClaimMinutes: rules.baggageClaimMinutes,
    maxWaitMinutes: group.maxWaitMinutes,
    members: group.members.map((m) => ({ readiness: m.readiness as ReadinessState, expectedReadyAt: m.expectedReadyAt ?? group.departureWindowStart })),
  });

  const readOnly = ["completed", "cancelled"].includes(group.status);
  const paymentLabel =
    booking?.payment_status === "captured" ? "Payment captured (demo)"
    : booking?.payment_status === "authorised" ? "Authorised — capture pending"
    : "Not paid";

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <Link href="/app/trips" className="inline-flex items-center gap-1.5 text-[12px] font-medium text-ink-muted hover:text-indigo">
          <ArrowLeft className="h-3.5 w-3.5" /> All trips
        </Link>
        <LiveStatus rideId={id} />
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_360px]">
        <div className="space-y-4">
          {/* Header */}
          <div className="card overflow-hidden">
            <div className="border-b border-line bg-[#FBFBFE] px-4 py-3.5">
              <div className="flex flex-wrap items-center gap-1.5">
                <Badge tone={group.status === "completed" ? "muted" : group.status === "cancelled" ? "danger" : group.status === "confirmed" || group.status === "in_progress" ? "success" : "indigo"}>
                  {STATUS_LABEL[group.status] ?? group.status}
                </Badge>
                <Badge tone="muted">{group.code}</Badge>
                {group.isDemo && <DemoBadge />}
                {isOwner && <Badge tone="navy">You coordinate</Badge>}
              </div>
              <h1 className="mt-2 text-[22px] font-bold tracking-[-0.02em] text-navy sm:text-[26px]">
                BOM → {group.destination.name}
              </h1>
              <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11.5px] text-ink-muted">
                <span>{formatDateLong(group.flight.flight_date)}</span>
                <span className="h-3 w-px bg-line" />
                <span>{group.flight.airline_code} {group.flight.flight_number} · lands {formatTime(group.flight.estimated_arrival)}</span>
                <span className="h-3 w-px bg-line" />
                <span>Terminal {group.flight.terminal ?? "T2"}</span>
              </p>
            </div>

            <div className="grid grid-cols-2 divide-x divide-y divide-line sm:grid-cols-4 sm:divide-y-0">
              <div className="px-4 py-3">
                <p className="text-[9.5px] font-semibold uppercase tracking-[0.1em] text-ink-muted">Your share</p>
                <p className="text-[15px] font-bold text-navy tabular">{formatPaise(myFare?.contributionPaise ?? 0)}</p>
                <p className="text-[10px] text-ink-muted">est. · {myFare?.savingsIsPositive ? `saves ${formatPaise(myFare.savingsPaise)}` : "see breakdown"}</p>
              </div>
              <div className="px-4 py-3">
                <p className="text-[9.5px] font-semibold uppercase tracking-[0.1em] text-ink-muted">Departure window</p>
                <p className="text-[15px] font-bold text-navy tabular">{formatTime(group.departureWindowStart)}</p>
                <p className="text-[10px] text-ink-muted">until {formatTime(group.departureWindowEnd)}</p>
              </div>
              <div className="px-4 py-3">
                <p className="text-[9.5px] font-semibold uppercase tracking-[0.1em] text-ink-muted">Group</p>
                <p className="text-[15px] font-bold text-navy">{group.members.length}/{group.seatsTotal}</p>
                <p className="text-[10px] text-ink-muted">{departureWindow.pendingMembers} not ready yet</p>
              </div>
              <div className="px-4 py-3">
                <p className="text-[9.5px] font-semibold uppercase tracking-[0.1em] text-ink-muted">Payment</p>
                <p className="text-[13px] font-bold text-navy">{paymentLabel}</p>
                <p className="text-[10px] text-ink-muted">{booking?.code ?? "no booking"}</p>
              </div>
            </div>
          </div>

          {/* Coordinator controls */}
          {isOwner && !readOnly && (
            <TripCoordinatorPanel
              rideId={id}
              status={group.status}
              driverAssigned={Boolean(group.driver)}
              hasDriver={Boolean(group.driver)}
              requests={joinRequests.map((r) => ({
                id: r.id, name: r.name, passengerCount: r.passenger_count, luggage: r.luggage_units,
                destination: r.destination_name, message: r.message, score: r.match_score,
                identityVerified: r.identity_status === "verified",
              }))}
              seatsAvailable={group.seatsAvailable}
              maxWaitMinutes={group.maxWaitMinutes}
            />
          )}

          {/* Member / driver panel */}
          <div className="grid gap-4 sm:grid-cols-2">
            <ReadinessPanel
              rideId={id}
              current={membership!.readiness as ReadinessState}
              disabled={readOnly}
              disabledReason={readOnly ? "This ride is closed." : undefined}
            />
            <div className="card p-4">
              <p className="flex items-center gap-1.5 text-[13px] font-semibold text-navy"><Users className="h-4 w-4 text-indigo" /> Group status</p>
              <ul className="mt-2.5 space-y-2">
                {group.members.map((m) => (
                  <li key={m.memberId} className="flex items-center justify-between gap-2">
                    <span className="flex min-w-0 items-center gap-1.5">
                      <Avatar name={m.firstName} size="xs" verified={m.identityVerified} />
                      <span className="truncate text-[11.5px] font-medium text-navy">{m.displayName}</span>
                    </span>
                    <Badge tone={m.readiness === "ready_at_meeting_point" ? "success" : m.readiness === "not_landed" ? "muted" : "amber"} className="shrink-0">
                      {READINESS_LABELS[m.readiness as ReadinessState]}
                    </Badge>
                  </li>
                ))}
              </ul>
              <div className="mt-3 rounded-lg bg-[#F9FAFD] px-2.5 py-2 text-[10px] leading-relaxed text-ink-muted">
                <Clock className="mr-1 inline h-3 w-3" />
                Group waits up to {group.maxWaitMinutes} min after landing + baggage. If someone can&apos;t make it, the coordinator can remove them and the group continues.
              </div>
            </div>
          </div>

          {/* Meeting point + driver */}
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="card p-4">
              <p className="flex items-center gap-1.5 text-[12.5px] font-semibold text-navy"><MapPin className="h-4 w-4 text-indigo" /> Meeting point</p>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-navy">{group.meetPoint ?? "To be confirmed by the coordinator"}</p>
              <p className="mt-1.5 text-[10.5px] text-ink-muted">Show your booking code {booking?.code} if asked.</p>
            </div>
            <div className="card p-4">
              <p className="flex items-center gap-1.5 text-[12.5px] font-semibold text-navy"><CarFront className="h-4 w-4 text-indigo" /> Vehicle</p>
              {group.driver ? (
                <>
                  <div className="mt-1.5 flex items-center gap-2">
                    <Avatar name={group.driver.name} size="sm" verified={group.driver.verified} />
                    <div>
                      <p className="text-[12.5px] font-semibold text-navy">{group.driver.name}</p>
                      <p className="text-[10.5px] text-ink-muted">{group.driver.vehicle}</p>
                    </div>
                  </div>
                  <p className="mt-2 text-[10.5px] text-ink-muted">Driver details are shared only after assignment.</p>
                </>
              ) : (
                <>
                  <p className="mt-1.5 text-[12px] text-ink-muted">No driver assigned yet. Your {group.vehicleCategory.toUpperCase()} request is open to verified fleet partners.</p>
                  <p className="mt-2 rounded-lg bg-[#F9FAFD] px-2.5 py-2 text-[10px] leading-relaxed text-ink-muted">
                    A ride group is not a confirmed transport booking until a driver accepts.
                  </p>
                </>
              )}
            </div>
          </div>

          {/* Chat */}
          <div id="chat">
            <GroupChat
              rideId={id}
              initialMessages={messages}
              currentUserId={user.id}
              conversationId={conversationId}
              readOnly={readOnly}
            />
          </div>

          {/* Timeline */}
          <div className="card p-4">
            <p className="text-[12.5px] font-semibold text-navy">Activity</p>
            <ol className="mt-2.5 space-y-2.5">
              {events.map((e) => (
                <li key={e.id} className="flex gap-2.5">
                  <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-[#C7CBD6]" />
                  <div>
                    <p className="text-[11.5px] font-medium capitalize text-ink-soft">{String(e.type).replace(/_/g, " ")}</p>
                    <p className="text-[10px] text-ink-muted">{formatDateTime(e.created_at)} · {relativeTime(e.created_at)}</p>
                  </div>
                </li>
              ))}
              {events.length === 0 && <p className="text-[11.5px] text-ink-muted">No activity recorded yet.</p>}
            </ol>
          </div>
        </div>

        {/* Sidebar */}
        <aside className="space-y-4">
          {group.fare && (
            <FareBreakdownCard
              fare={group.fare}
              viewerUserId={user.id}
              memberNames={Object.fromEntries(group.members.map((m) => [m.userId, m.displayName]))}
            />
          )}

          {booking && !readOnly && (
            <PaymentPanel
              bookingId={booking.id}
              bookingCode={booking.code}
              amountPaise={booking.amount_paise}
              paymentStatus={booking.payment_status}
              hasDriver={Boolean(group.driver)}
              rideId={id}
            />
          )}

          <div className="card p-3">
            <RouteMap
              stops={[
                { id: group.destination.id, name: group.destination.name, lat: group.destination.lat, lng: group.destination.lng, distanceKm: group.destination.distance_km },
                ...group.extraDestinations.map((d) => ({ id: d.id, name: d.name, lat: d.lat, lng: d.lng, distanceKm: d.distance_km })),
              ]}
              height={170}
              highlightId={group.destination.id}
            />
          </div>

          <div className="rounded-xl border border-line bg-white p-3.5">
            <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-ink-muted"><ShieldCheck className="h-3.5 w-3.5 text-success" /> Safety</p>
            <p className="mt-1.5 text-[11px] leading-relaxed text-ink-muted">
              Share your trip with someone you trust. If anything feels wrong, use the report control in chat or contact support.
            </p>
            <div className="mt-2 flex gap-1.5">
              <LinkButton href="/help" variant="outline" size="sm" className="flex-1">Get help</LinkButton>
              <LinkButton href="/safety" variant="outline" size="sm" className="flex-1">Safety</LinkButton>
            </div>
          </div>

          {booking && (
            <div className="rounded-xl border border-line bg-white p-3.5 text-[10.5px] leading-relaxed text-ink-muted">
              <p className="flex items-center gap-1.5 font-semibold text-ink-soft"><Info className="h-3 w-3" /> Fare status</p>
              <p className="mt-1">Estimated → confirmed when a driver accepts → captured after you pay. Cancelling before departure costs nothing.</p>
              <p className="mt-1.5 flex items-center gap-1"><CheckCircle2 className="h-3 w-3 text-success" /> No charge for requesting or joining.</p>
              <p className="mt-0.5 flex items-center gap-1"><XCircle className="h-3 w-3 text-ink-muted" /> Refunds reviewed within 3 business days.</p>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}
