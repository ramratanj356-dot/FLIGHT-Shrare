import Link from "next/link";
import { BadgeCheck, Fingerprint, Info, Lock, ShieldCheck, Smartphone, UserCircle2 } from "lucide-react";
import { requireUser } from "@/lib/auth/guards";
import { getPassengerProfile, listDestinations, getSessionAuditForUser } from "@/lib/db/queries";
import { PageHeading } from "@/components/app/app-shell";
import { ProfileForm } from "@/components/forms/profile-form";
import { IdentityPanel } from "@/components/app/identity-panel";
import { Avatar, Badge, Alert, DemoBadge } from "@/components/ui/primitives";
import { formatDateTime } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "Profile & preferences" };

export default async function ProfilePage() {
  const user = await requireUser("/app/profile");
  const profile = getPassengerProfile(user.id);
  const destinations = listDestinations();
  const sessions = getSessionAuditForUser(user.id);

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeading
        title="Profile & preferences"
        description="Your travel defaults help us match you better. Other passengers only ever see a shortened name and your verification badges."
      />

      <div className="grid gap-5 lg:grid-cols-[1fr_320px]">
        <div className="space-y-4">
          <div className="card p-4">
            <div className="flex items-center gap-3">
              <Avatar name={user.name} size="xl" verified={profile?.identity_status === "verified"} />
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-1.5">
                  <h2 className="truncate text-[17px] font-bold text-navy">{user.name}</h2>
                  {user.demoAccount && <DemoBadge label="DEMO ACCOUNT" />}
                </div>
                <p className="truncate text-[12px] text-ink-muted">{user.email}</p>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  <Badge tone={user.emailVerified ? "success" : "amber"} icon={<BadgeCheck className="h-2.5 w-2.5" />}>
                    {user.emailVerified ? "Email verified" : "Email unverified"}
                  </Badge>
                  <Badge tone={user.phoneVerified ? "success" : "muted"} icon={<Smartphone className="h-2.5 w-2.5" />}>
                    {user.phoneVerified ? "Phone verified" : "Phone unverified"}
                  </Badge>
                  <Badge tone={profile?.identity_status === "verified" ? "indigo" : "muted"} icon={<Fingerprint className="h-2.5 w-2.5" />}>
                    Identity: {profile?.identity_status ?? "unverified"}
                  </Badge>
                </div>
              </div>
            </div>
            <p className="mt-3 rounded-lg bg-[#F9FAFD] px-3 py-2 text-[10.5px] leading-relaxed text-ink-muted">
              <Info className="mr-1 inline h-3 w-3" />
              Display name to others: <strong className="text-ink-soft">{user.name.split(" ")[0]} {user.name.split(" ").slice(-1)[0]?.[0]}.</strong>{" "}
              Phone, email, booking references and documents are never shown to other passengers.
            </p>
          </div>

          <ProfileForm
            initial={{
              name: user.name,
              phone: user.phone ?? "",
              homeDestinationId: profile?.home_destination_id ?? "thane-w",
              luggagePreference: (profile?.luggage_preference ?? "one_checkin") as "cabin" | "one_checkin" | "two_checkin" | "heavy",
              accessibilityNeeds: profile?.accessibility_needs ?? "",
              language: (profile?.language ?? "en") as "en" | "hi" | "mr",
              quietRide: Boolean(profile?.quiet_ride),
              emergencyContactName: profile?.emergency_contact_name ?? "",
              emergencyContactPhone: profile?.emergency_contact_phone ?? "",
            }}
            destinations={destinations.map((d) => ({ id: d.id, name: d.name, area: d.area, distanceKm: d.distance_km, soloFarePaise: d.solo_fare_paise }))}
          />

          <IdentityPanel
            status={(profile?.identity_status ?? "unverified") as "unverified" | "pending" | "verified" | "rejected"}
            provider={profile?.identity_provider ?? null}
            verifiedAt={profile?.identity_verified_at ?? null}
          />
        </div>

        <aside className="space-y-4">
          <div className="card p-4">
            <p className="text-[12.5px] font-semibold text-navy">Your rating</p>
            <div className="mt-2 flex items-end gap-2">
              <p className="text-[28px] font-bold leading-none text-navy tabular">{(profile?.rating_avg ?? 0).toFixed(1)}</p>
              <p className="pb-1 text-[11px] text-ink-muted">from {profile?.rating_count ?? 0} rides</p>
            </div>
            <p className="mt-2 text-[10.5px] leading-relaxed text-ink-muted">
              Ratings are shown after a completed trip. Sample figures in this demo.
            </p>
          </div>

          <div className="card p-4">
            <p className="flex items-center gap-1.5 text-[12.5px] font-semibold text-navy"><Lock className="h-3.5 w-3.5 text-success" /> Active sessions</p>
            <ul className="mt-2 space-y-1.5">
              {sessions.slice(0, 3).map((s) => (
                <li key={s.id} className="text-[10.5px] leading-relaxed text-ink-muted">
                  <span className="block truncate text-ink-soft">{String(s.user_agent ?? "Unknown device").slice(0, 42)}</span>
                  last active {formatDateTime(s.last_seen_at)}
                </li>
              ))}
              {sessions.length === 0 && <li className="text-[10.5px] text-ink-muted">No active sessions found.</li>}
            </ul>
            <p className="mt-2 text-[10px] text-ink-muted">A password reset signs out every device.</p>
          </div>

          <div className="rounded-xl border border-line bg-white p-4">
            <p className="flex items-center gap-1.5 text-[12px] font-semibold text-navy"><ShieldCheck className="h-3.5 w-3.5 text-success" /> Your data</p>
            <p className="mt-1.5 text-[10.5px] leading-relaxed text-ink-muted">
              We collect the minimum needed to match a flight: your name, contact details, destination area and luggage size. Booking
              references are stored hashed and masked.
            </p>
            <Link href="/legal/privacy" className="mt-2 block text-[10.5px] font-medium text-indigo hover:underline">Read the privacy policy</Link>
          </div>
        </aside>
      </div>
    </div>
  );
}
