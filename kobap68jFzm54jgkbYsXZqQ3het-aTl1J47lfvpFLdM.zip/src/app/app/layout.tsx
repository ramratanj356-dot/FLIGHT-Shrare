import { requireUser } from "@/lib/auth/guards";
import { unreadNotificationCount, unreadMessageCount } from "@/lib/db/queries";
import { AppShell } from "@/components/app/app-shell";

export const dynamic = "force-dynamic";

export default async function PassengerLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser("/app");
  const unread = unreadNotificationCount(user.id);
  const unreadMessages = unreadMessageCount(user.id);

  return (
    <AppShell
      user={{ id: user.id, name: user.name, email: user.email, role: user.role, demoAccount: user.demoAccount, emailVerified: user.emailVerified }}
      unreadNotifications={unread}
      unreadMessages={unreadMessages}
      variant="passenger"
    >
      {children}
    </AppShell>
  );
}
