import { ArrowLeft } from "lucide-react";
import Link from "next/link";
import { requireUser } from "@/lib/auth/guards";
import { listDestinations, getDestination, getPricingRules } from "@/lib/db/queries";
import { PageHeading } from "@/components/app/app-shell";
import { CreateRideForm } from "@/components/forms/create-ride-form";
import { toDateKey } from "@/lib/utils";
import { Badge, Alert } from "@/components/ui/primitives";

export const dynamic = "force-dynamic";
export const metadata = { title: "Start a ride group" };

export default async function NewRidePage({ searchParams }: { searchParams: Promise<{ flight?: string; date?: string; dest?: string }> }) {
  const sp = await searchParams;
  const user = await requireUser("/app/rides/new");
  const destinations = listDestinations();
  const rules = getPricingRules();
  const dest = sp.dest ? getDestination(sp.dest) : undefined;

  return (
    <div className="mx-auto max-w-3xl">
      <Link href="/search" className="inline-flex items-center gap-1.5 text-[12px] font-medium text-ink-muted hover:text-indigo">
        <ArrowLeft className="h-3.5 w-3.5" /> Back to search
      </Link>
      <div className="mt-3">
        <PageHeading
          badge={<><Badge tone="indigo">Coordinator</Badge><Badge tone="amber">Demo data</Badge></>}
          title="Start a ride group"
          description="You set the vehicle, the waiting window and how the fare is split. Other passengers on your flight can request a seat, and you approve them."
        />
      </div>

      <div className="mb-4">
        <Alert tone="info" title="You become the coordinator">
          Coordinating is free. You approve join requests, confirm readiness and can cancel at no cost before departure. A ride is not a
          confirmed transport booking until a verified driver accepts.
        </Alert>
      </div>

      <CreateRideForm
        destinations={destinations.map((d) => ({ id: d.id, name: d.name, area: d.area, distanceKm: d.distance_km, soloFarePaise: d.solo_fare_paise }))}
        defaultFlight={sp.flight ?? ""}
        defaultDate={sp.date ?? toDateKey()}
        defaultDestinationId={dest?.id ?? "thane-w"}
        capacity={rules.vehicleCapacity}
        defaultMaxWait={rules.maxWaitMinutes}
        defaultStrategy={rules.defaultStrategy}
      />
    </div>
  );
}
