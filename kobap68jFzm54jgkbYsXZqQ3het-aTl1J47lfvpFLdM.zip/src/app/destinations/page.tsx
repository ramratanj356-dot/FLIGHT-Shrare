import Link from "next/link";
import { ArrowRight, Clock3, MapPin, Route, Sparkles } from "lucide-react";
import { SiteHeader } from "@/components/marketing/site-header";
import { SiteFooter } from "@/components/marketing/site-footer";
import { getSessionUser } from "@/lib/auth/session";
import { listDestinations, listPopularDestinationsWithGroups } from "@/lib/db/queries";
import { Badge, DemoBadge, SectionHeading } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";
import { MumbaiMap } from "@/components/brand/mumbai-map";
import { toDateKey } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = {
  title: "Mumbai destinations",
  description: "Drop-off areas served from Chhatrapati Shivaji Maharaj International Airport (BOM), grouped by corridor.",
};

const CORRIDOR_LABELS: Record<string, string> = {
  "western-suburbs": "Western suburbs",
  "central-suburbs": "Central suburbs",
  "thane-corridor": "Thane corridor",
  "harbour-corridor": "Harbour corridor",
  "south-mumbai": "South Mumbai",
};

export default async function DestinationsPage() {
  const user = await getSessionUser();
  const destinations = listDestinations();
  const live = listPopularDestinationsWithGroups(12);
  const byCorridor = destinations.reduce<Record<string, typeof destinations>>((acc, d) => {
    (acc[d.corridor] ??= []).push(d);
    return acc;
  }, {});
  const today = toDateKey();

  return (
    <>
      <SiteHeader user={user ? { name: user.name, role: user.role } : null} />
      <main id="main">
        <section className="border-b border-line bg-white">
          <div className="container-x grid gap-8 py-12 lg:grid-cols-[1.1fr_1fr] lg:items-center sm:py-14">
            <div>
              <Badge tone="indigo" icon={<MapPin className="h-3 w-3" />}>Mumbai (BOM)</Badge>
              <h1 className="mt-3 text-[32px] font-bold leading-[1.1] tracking-[-0.03em] text-navy sm:text-[42px]">
                Every corridor from T2, priced honestly.
              </h1>
              <p className="mt-3.5 max-w-lg text-[14.5px] leading-relaxed text-ink-muted">
                Drop-off areas are grouped by the corridor they actually belong to, not by postcode. Distances and solo-fare references are
                indicative estimates for planning — live pricing appears once a group is formed.
              </p>
              <div className="mt-6 flex flex-wrap gap-2.5">
                <LinkButton href="/search" size="lg" rightIcon={<ArrowRight className="h-4 w-4" />}>Search a flight</LinkButton>
                <LinkButton href="/how-it-works" size="lg" variant="outline">How splitting works</LinkButton>
              </div>
              <p className="mt-4 text-[10.5px] text-ink-muted">
                Extensible to other airports: destinations, corridors and airports are database rows, not hard-coded city logic.
              </p>
            </div>
            <div className="rounded-2xl border border-line bg-[#FBFBFE] p-3">
              <MumbaiMap
                stops={destinations.map((d) => ({ id: d.id, name: d.name, lat: d.lat, lng: d.lng, distanceKm: d.distance_km }))}
                highlight={destinations.slice(0, 6).map((d) => d.id)}
                height={380}
                caption="Illustrative map · curated coordinates, not live routing"
              />
              <p className="px-2 pb-1 pt-2 text-[10px] text-ink-muted">
                Schematic map using curated sample coordinates — not a live routing engine. Configure Mapbox to enable real routes.
              </p>
            </div>
          </div>
        </section>

        <section className="py-12">
          <div className="container-x">
            <SectionHeading
              eyebrow="Coverage"
              title="Where passengers go"
              description="Grouped by corridor. Adjacent corridors can share a ride when the direction and distance delta allow it."
            />
            <div className="mt-6 grid gap-4 lg:grid-cols-2">
              {Object.entries(byCorridor).map(([corridor, list]) => (
                <div key={corridor} className="card overflow-hidden">
                  <div className="flex items-center justify-between border-b border-line bg-[#FBFBFE] px-4 py-2.5">
                    <p className="flex items-center gap-1.5 text-[12.5px] font-semibold text-navy">
                      <Route className="h-3.5 w-3.5 text-indigo" /> {CORRIDOR_LABELS[corridor] ?? corridor}
                    </p>
                    <Badge tone="muted">{list.length} areas</Badge>
                  </div>
                  <ul className="divide-y divide-line">
                    {list.map((d) => (
                      <li key={d.id}>
                        <Link
                          href={`/rides?flight=AI864&date=${today}&dest=${d.id}&pax=1&luggage=1`}
                          className="group flex items-center justify-between gap-3 px-4 py-2.5 transition hover:bg-[#FBFBFE]"
                        >
                          <div className="min-w-0">
                            <p className="truncate text-[12.5px] font-medium text-navy group-hover:text-indigo">{d.name}</p>
                            <p className="text-[10.5px] text-ink-muted">{d.area} · {d.distance_km} km · ~{d.drive_minutes} min from T2</p>
                          </div>
                          <div className="shrink-0 text-right">
                            <p className="text-[12px] font-semibold text-navy tabular">₹{Math.round(d.solo_fare_paise / 100).toLocaleString("en-IN")}</p>
                            <p className="text-[9.5px] text-ink-muted">solo est.</p>
                          </div>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="border-t border-line bg-white py-12">
          <div className="container-x">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <SectionHeading eyebrow="Right now" title="Destinations with open groups" />
              <DemoBadge label="SAMPLE SCHEDULE" />
            </div>
            <div className="mt-5 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
              {live.map((d: { id: string; name: string; drive_minutes: number; groups: number }) => (
                <Link
                  key={d.id}
                  href={`/rides?flight=AI864&date=${today}&dest=${d.id}&pax=1&luggage=1`}
                  className="group flex items-center justify-between rounded-xl border border-line bg-white px-3.5 py-3 transition hover:border-indigo-200 hover:shadow-card"
                >
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-semibold text-navy group-hover:text-indigo">{d.name}</p>
                    <p className="flex items-center gap-2 text-[10.5px] text-ink-muted">
                      <span className="inline-flex items-center gap-1"><Clock3 className="h-3 w-3" />{d.drive_minutes} min</span>
                      <span>{d.groups} open group{d.groups === 1 ? "" : "s"}</span>
                    </p>
                  </div>
                  <span className="flex items-center gap-1 text-[10.5px] font-semibold text-indigo">
                    View <ArrowRight className="h-3 w-3 transition group-hover:translate-x-0.5" />
                  </span>
                </Link>
              ))}
            </div>
            {live.length === 0 && (
              <p className="mt-4 rounded-xl border border-line bg-[#FBFBFE] px-4 py-6 text-center text-[12px] text-ink-muted">
                No open groups in the sample schedule right now. Reset the demo database or pick another date.
              </p>
            )}
          </div>
        </section>

        <section className="py-12">
          <div className="container-x rounded-2xl border border-line bg-white px-6 py-9 text-center">
            <Sparkles className="mx-auto h-5 w-5 text-indigo" />
            <h2 className="mt-3 text-[22px] font-bold tracking-[-0.02em] text-navy">Not on the list?</h2>
            <p className="mx-auto mt-2 max-w-md text-[13px] leading-relaxed text-ink-muted">
              Create a group with your own drop-off and we will score it against groups on the same flight. Compatibility handles the
              neighbouring-area cases so a Thane group can still work for Mulund.
            </p>
            <div className="mt-5 flex justify-center gap-2.5">
              <LinkButton href="/signup" size="md">Create an account</LinkButton>
              <LinkButton href="/search" size="md" variant="outline">Search my flight</LinkButton>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
