import { Car, Clock, MapPin, Users } from "lucide-react";
import { requireRole } from "@/lib/auth/guards";
import { getDriverProfile, listDriverTrips } from "@/lib/db/queries";
import { PageHeading } from "@/components/app/app-shell";
import { Avatar, Badge, DemoBadge, EmptyState } from "@/components/ui/primitives";
import { TripStatusControls } from "@/components/app/driver-controls";
import { formatDateLong, formatTime } from "@/lib/utils";
import { formatPaise } from "@/lib/money";

export const dynamic = "force-dynamic";
export const metadata = { title: "My trips" };

export default async function DriverTripsPage() {
  const user = await requireRole(["driver", "admin"], "/driver/trips");
  const profile = getDriverProfile(user.id);
  const trips = profile ? listDriverTrips(profile.id) : [];

  return (
    <div>
      <PageHeading
        badge={<DemoBadge label="DEMO DATA" />}
        title="Assigned trips"
        description="Pickup zone, drop-off order, passenger count and luggage — known before you leave."
      />

      {trips.length === 0 ? (
        <EmptyState icon={<Car className="h-5 w-5" />} title="No trips assigned yet" description="Accept a ride request from the requests page and it will appear here with full pickup instructions." />
      ) : (
        <div className="space-y-3">
          {trips.map((t) => (
            <article key={t.id} className="card overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line bg-[#FBFBFE] px-4 py-2.5">
                <div className="flex items-center gap-1.5">
                  <Badge tone={t.status === "completed" ? "muted" : t.status === "in_progress" ? "success" : t.status === "cancelled" ? "danger" : "indigo"} className="capitalize">{t.status.replace(/_/g, " ")}</Badge>
                  <Badge tone="muted">{t.code}</Badge>
                  {t.isDemo && <DemoBadge label="DEMO" />}
                </div>
                <span className="text-[11px] text-ink-muted">{formatDateLong(t.flight.flight_date)} · {t.flight.airline_code} {t.flight.flight_number}</span>
              </div>

              <div className="grid gap-4 p-4 sm:grid-cols-[1fr_auto]">
                <div>
                  <p className="text-[15px] font-bold text-navy">BOM → {t.destination.name}</p>
                  <p className="mt-0.5 text-[11px] leading-relaxed text-ink-muted">
                    {t.extraDestinations.length > 0 ? `Drop-off order: ${t.destination.name}, then ${t.extraDestinations.map((d) => d.name).join(", ")}` : "Single drop-off"}
                  </p>
                  <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px] text-ink-muted">
                    <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" />{t.meetPoint}</span>
                    <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" />{formatTime(t.departureWindowStart)}–{formatTime(t.departureWindowEnd)}</span>
                    <span className="inline-flex items-center gap-1"><Users className="h-3 w-3" />{t.seatsTaken} pax</span>
                    <span className="inline-flex items-center gap-1">₹{Math.round((t.fare?.breakdown.vehicleFarePaise ?? 0) / 100).toLocaleString("en-IN")} fare</span>
                  </div>
                  <div className="mt-2.5 flex flex-wrap items-center gap-x-3 gap-y-1">
                    {t.members.map((m) => (
                      <span key={m.memberId} className="inline-flex items-center gap-1.5">
                        <Avatar name={m.firstName} size="xs" verified={m.identityVerified} />
                        <span className="text-[11px] text-ink-soft">{m.firstName} → {m.destinationName}</span>
                      </span>
                    ))}
                  </div>
                </div>
                {["confirmed", "in_progress"].includes(t.status) && <TripStatusControls rideId={t.id} status={t.status} />}
                {t.status === "completed" && (
                  <div className="text-right">
                    <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-muted">Recorded earning</p>
                    <p className="text-[15px] font-bold text-navy tabular">{formatPaise(t.fare?.breakdown.vehicleFarePaise ?? 0)}</p>
                  </div>
                )}
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
