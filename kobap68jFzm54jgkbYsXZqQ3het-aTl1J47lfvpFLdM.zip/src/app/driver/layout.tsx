import { requireRole } from "@/lib/auth/guards";
import { AppShell } from "@/components/app/app-shell";
import { unreadNotificationCount } from "@/lib/db/queries";

export const dynamic = "force-dynamic";

export default async function DriverLayout({ children }: { children: React.ReactNode }) {
  const user = await requireRole(["driver", "admin"], "/driver");
  return (
    <AppShell
      user={{ id: user.id, name: user.name, email: user.email, role: user.role, demoAccount: user.demoAccount, emailVerified: user.emailVerified }}
      unreadNotifications={unreadNotificationCount(user.id)}
      variant="driver"
    >
      {children}
    </AppShell>
  );
}
