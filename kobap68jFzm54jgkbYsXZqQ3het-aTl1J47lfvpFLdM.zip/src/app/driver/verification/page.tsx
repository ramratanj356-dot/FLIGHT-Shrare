import { AlertTriangle, BadgeCheck, FileCheck2, ShieldCheck } from "lucide-react";
import { requireRole } from "@/lib/auth/guards";
import { getDriverProfile } from "@/lib/db/queries";
import { PageHeading } from "@/components/app/app-shell";
import { DriverVerificationForm } from "@/components/forms/driver-verification-form";
import { Badge, Alert, DemoBadge } from "@/components/ui/primitives";

export const dynamic = "force-dynamic";
export const metadata = { title: "Driver verification" };

export default async function DriverVerificationPage() {
  const user = await requireRole(["driver", "admin"], "/driver/verification");
  const profile = getDriverProfile(user.id);
  const status = (profile?.verification_status ?? "pending") as "pending" | "in_review" | "verified" | "rejected" | "expired";

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeading
        badge={<><Badge tone={status === "verified" ? "success" : status === "rejected" ? "danger" : "amber"} className="capitalize">{status.replace(/_/g, " ")}</Badge><DemoBadge label="DEMO REVIEW" /></>}
        title="Verification & vehicle"
        description="An administrator reviews these details before you can accept trips. In production this workflow would also validate statutory permits and insurance."
      />

      <div className="mb-4">
        {status === "verified" ? (
          <Alert tone="success" title="Verified by an administrator">
            Your licence and vehicle details passed the demo review on {profile?.verified_at ? new Date(profile.verified_at).toLocaleDateString("en-IN") : "record"}. Passengers see your name and vehicle only after you accept a trip.
          </Alert>
        ) : status === "in_review" ? (
          <Alert tone="info" title="Under review">
            Your submission is queued for an administrator (see the admin console). You cannot accept trips until the review succeeds.
          </Alert>
        ) : status === "rejected" ? (
          <Alert tone="danger" title="Needs attention">
            {profile?.verification_notes ?? "Please re-submit clearer document details."}
          </Alert>
        ) : (
          <Alert tone="warning" title="Documents required">
            Submit your driving licence and vehicle registration to become eligible for airport trips.
          </Alert>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        {[
          { icon: FileCheck2, title: "1. Submit", body: "Licence number, vehicle model and registration." },
          { icon: ShieldCheck, title: "2. Review", body: "An administrator checks the details (demo workflow)." },
          { icon: BadgeCheck, title: "3. Accept trips", body: "Verified drivers see and accept ride requests." },
        ].map((s) => (
          <div key={s.title} className="rounded-xl border border-line bg-white p-3">
            <s.icon className="h-4 w-4 text-indigo" />
            <p className="mt-1.5 text-[12px] font-semibold text-navy">{s.title}</p>
            <p className="mt-0.5 text-[10.5px] leading-relaxed text-ink-muted">{s.body}</p>
          </div>
        ))}
      </div>

      <div className="mt-4">
        <DriverVerificationForm
          initial={{
            licenseNumber: profile?.license_number ?? "",
            vehicleModel: profile?.make_model ?? "",
            vehicleRegNumber: profile?.registration_number ?? "",
            category: (profile?.category ?? "sedan") as "sedan" | "suv" | "mpv",
            seats: profile?.seats ?? 4,
            luggageUnits: profile?.luggage_units ?? 3,
            fleetPartner: profile?.company_name ?? "",
          }}
          locked={status === "verified"}
        />
      </div>

      <p className="mt-4 flex items-start gap-1.5 text-[10.5px] leading-relaxed text-amber-dark">
        <AlertTriangle className="mt-px h-3.5 w-3.5 shrink-0" />
        This review confirms document details were provided — it is not a statutory permit, background or insurance check. Commercial passenger
        transport in India requires permits, fitness certificates and insurance that must be validated before operating.
      </p>
    </div>
  );
}
