import { Download, Info, Wallet } from "lucide-react";
import { requireRole } from "@/lib/auth/guards";
import { getDriverEarnings, getDriverProfile } from "@/lib/db/queries";
import { PageHeading } from "@/components/app/app-shell";
import { Badge, EmptyState, DemoBadge } from "@/components/ui/primitives";
import { formatDateTime } from "@/lib/utils";
import { formatPaise } from "@/lib/money";

export const dynamic = "force-dynamic";
export const metadata = { title: "Earnings" };

export default async function EarningsPage() {
  const user = await requireRole(["driver", "admin"], "/driver/earnings");
  const profile = getDriverProfile(user.id);
  const { rows, totals } = profile ? getDriverEarnings(profile.id) : { rows: [], totals: { gross: 0, commission: 0, net: 0, paid: 0, pending: 0 } };

  return (
    <div>
      <PageHeading
        badge={<DemoBadge label="DEMONSTRATION FIGURES" />}
        title="Earnings & settlements"
        description="Every completed trip produces a settlement record. In demo mode these figures come from seeded trips, not real bookings."
        actions={
          <button className="inline-flex h-11 items-center gap-2 rounded-xl border border-line bg-white px-4 text-sm font-semibold text-ink-soft" disabled title="Export is disabled until payments are configured">
            <Download className="h-4 w-4" /> Export CSV
          </button>
        }
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Gross fares", value: formatPaise(totals.gross), sub: "before platform commission" },
          { label: "Platform commission", value: formatPaise(totals.net > 0 ? totals.gross - totals.net : totals.commission), sub: "retained by FlightShare" },
          { label: "Net earnings", value: formatPaise(totals.net), sub: "your payable amount" },
          { label: "Pending payout", value: formatPaise(totals.pending), sub: "next settlement run" },
        ].map((s) => (
          <div key={s.label} className="card p-4">
            <p className="text-[11.5px] font-medium text-ink-muted">{s.label}</p>
            <p className="mt-1.5 text-[20px] font-bold leading-none tracking-tight text-navy tabular">{s.value}</p>
            <p className="mt-1 text-[10.5px] text-ink-muted">{s.sub}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 flex items-start gap-2 rounded-xl border border-indigo-100 bg-[#F7F6FF] px-4 py-3 text-[11.5px] leading-relaxed text-indigo-700">
        <Info className="mt-0.5 h-4 w-4 shrink-0" />
        <span>
          Settlement mechanics are modelled but not live: payouts require a configured payment gateway with merchant approval and a verified
          bank account. Amounts here are demonstration data and must not be treated as receivables.
        </span>
      </div>

      <section className="mt-6">
        <h2 className="mb-3 text-[15px] font-semibold text-navy">Trip history</h2>
        {rows.length === 0 ? (
          <EmptyState icon={<Wallet className="h-5 w-5" />} title="No settled trips yet" description="Complete a trip in the driver portal and its settlement record will appear here with gross fare, commission and net payout." />
        ) : (
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px] text-left">
                <thead className="border-b border-line bg-[#FBFBFE] text-[10.5px] uppercase tracking-wide text-ink-muted">
                  <tr>
                    <th className="px-4 py-2.5 font-semibold">Period</th>
                    <th className="px-4 py-2.5 font-semibold">Recorded</th>
                    <th className="px-4 py-2.5 text-right font-semibold">Gross</th>
                    <th className="px-4 py-2.5 text-right font-semibold">Deductions</th>
                    <th className="px-4 py-2.5 text-right font-semibold">Net</th>
                    <th className="px-4 py-2.5 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line text-[12px]">
                  {rows.map((r) => (
                    <tr key={r.id} className="hover:bg-[#FBFBFE]">
                      <td className="px-4 py-2.5 font-medium text-navy">{r.period ?? "—"}</td>
                      <td className="px-4 py-2.5 text-ink-muted">{formatDateTime(r.created_at)}</td>
                      <td className="px-4 py-2.5 text-right text-ink tabular">{formatPaise(r.gross_paise)}</td>
                      <td className="px-4 py-2.5 text-right text-ink-muted tabular">{formatPaise(r.deductions_paise)}</td>
                      <td className="px-4 py-2.5 text-right font-semibold text-navy tabular">{formatPaise(r.net_paise)}</td>
                      <td className="px-4 py-2.5">
                        <Badge tone={r.status === "paid" ? "success" : r.status === "pending" ? "amber" : "muted"} className="capitalize">{r.status}</Badge>
                        {r.payout_reference && <span className="ml-1.5 text-[10px] text-ink-muted">{r.payout_reference}</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
