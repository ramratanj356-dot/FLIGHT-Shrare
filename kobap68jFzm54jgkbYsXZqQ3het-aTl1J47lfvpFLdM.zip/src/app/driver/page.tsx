import Link from "next/link";
import {
  ArrowRight, BadgeCheck, Briefcase, Car, CheckCircle2, Clock, MapPin, ShieldAlert, Users, Wallet,
} from "lucide-react";
import { requireRole } from "@/lib/auth/guards";
import { getDriverProfile, listDriverRideRequests, listDriverTrips, getDriverEarnings } from "@/lib/db/queries";
import { PageHeading } from "@/components/app/app-shell";
import { Avatar, Badge, DemoBadge, EmptyState, Alert } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";
import { AcceptRideButton, TripStatusControls } from "@/components/app/driver-controls";
import { formatDateLong, formatTime, relativeTime } from "@/lib/utils";
import { formatPaise } from "@/lib/money";

export const dynamic = "force-dynamic";
export const metadata = { title: "Driver portal" };

export default async function DriverHomePage() {
  const user = await requireRole(["driver", "admin"], "/driver");
  const profile = getDriverProfile(user.id);

  if (!profile) {
    return (
      <div className="mx-auto max-w-lg py-10">
        <PageHeading title="Driver profile missing" description="This account has no driver profile attached." />
        <LinkButton href="/partners" size="md">Register as a driver</LinkButton>
      </div>
    );
  }

  const requests = listDriverRideRequests(profile.id);
  const trips = listDriverTrips(profile.id);
  const earnings = getDriverEarnings(profile.id);
  const verified = profile.verification_status === "verified";
  const assigned = trips.filter((t) => ["confirmed", "in_progress"].includes(t.status));
  const completed = trips.filter((t) => t.status === "completed");
  const unassigned = requests.filter((r) => !r.driver);

  return (
    <div>
      <PageHeading
        badge={<><Badge tone="indigo">Driver</Badge><DemoBadge label="DEMO DATA" /></>}
        title={`Namaste, ${user.name.split(" ")[0]}`}
        description="Accept airport transfers with known passenger counts, luggage and drop-off order."
        actions={<LinkButton href="/driver/earnings" variant="outline" size="md" leftIcon={<Wallet className="h-4 w-4" />}>Earnings</LinkButton>}
      />

      {!verified && (
        <div className="mb-4">
          <Alert tone="warning" title="Your verification is not complete">
            {profile.verification_status === "in_review"
              ? "Documents are under review by an administrator. You cannot accept trips until the review succeeds."
              : "Submit your licence and vehicle documents to become eligible for trips."}{" "}
            <Link href="/driver/verification" className="font-semibold underline">Open verification</Link>
          </Alert>
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Open requests", value: String(unassigned.length), sub: "unassigned groups", icon: Clock, tone: "indigo" },
          { label: "Assigned now", value: String(assigned.length), sub: "confirmed or en route", icon: Car, tone: "success" },
          { label: "Completed trips", value: String(completed.length), sub: "all time (demo)", icon: CheckCircle2, tone: "muted" },
          { label: "Net earnings", value: formatPaise(earnings.totals.net), sub: `${formatPaise(earnings.totals.pending)} pending payout`, icon: Wallet, tone: "success" },
        ].map((s) => (
          <div key={s.label} className="card p-4">
            <div className="flex items-start justify-between">
              <p className="text-[11.5px] font-medium text-ink-muted">{s.label}</p>
              <span className={`grid h-7 w-7 place-items-center rounded-lg ${s.tone === "success" ? "bg-success-soft text-success-dark" : s.tone === "indigo" ? "bg-[#F4F3FF] text-indigo" : "bg-[#F2F4F7] text-ink-muted"}`}>
                <s.icon className="h-3.5 w-3.5" />
              </span>
            </div>
            <p className="mt-1.5 text-[22px] font-bold leading-none tracking-tight text-navy tabular">{s.value}</p>
            <p className="mt-1 text-[10.5px] text-ink-muted">{s.sub}</p>
          </div>
        ))}
      </div>

      {assigned.length > 0 && (
        <section className="mt-6">
          <h2 className="mb-3 text-[15px] font-semibold text-navy">Your assigned trips</h2>
          <div className="space-y-3">
            {assigned.map((t) => (
              <div key={t.id} className="card overflow-hidden">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line bg-[#FBFBFE] px-4 py-2.5">
                  <div className="flex items-center gap-1.5">
                    <Badge tone={t.status === "in_progress" ? "success" : "indigo"}>{t.status === "in_progress" ? "On the way" : "Assigned"}</Badge>
                    <Badge tone="muted">{t.code}</Badge>
                    {t.isDemo && <DemoBadge label="DEMO" />}
                  </div>
                  <span className="text-[11px] text-ink-muted">{formatDateLong(t.flight.flight_date)} · {t.flight.flight_number}</span>
                </div>
                <div className="flex flex-col justify-between gap-3 p-4 sm:flex-row sm:items-center">
                  <div>
                    <p className="text-[15px] font-bold text-navy">BOM → {t.destination.name}</p>
                    <p className="mt-0.5 flex flex-wrap items-center gap-x-3 text-[11px] text-ink-muted">
                      <span className="inline-flex items-center gap-1"><Users className="h-3 w-3" />{t.seatsTaken} passenger{t.seatsTaken === 1 ? "" : "s"}</span>
                      <span className="inline-flex items-center gap-1"><Briefcase className="h-3 w-3" />{t.luggageTaken} bag{t.luggageTaken === 1 ? "" : "s"}</span>
                      <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" />{t.meetPoint?.split("—")[0]}</span>
                      <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" />{formatTime(t.departureWindowStart)}–{formatTime(t.departureWindowEnd)}</span>
                    </p>
                  </div>
                  <TripStatusControls rideId={t.id} status={t.status} />
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      <section className="mt-6">
        <div className="mb-3 flex items-end justify-between">
          <div>
            <h2 className="text-[15px] font-semibold text-navy">Eligible ride requests</h2>
            <p className="mt-0.5 text-[11.5px] text-ink-muted">
              {verified ? "Groups waiting for a driver. Accepting moves the ride to confirmed and notifies every passenger." : "Verification required before accepting."}
            </p>
          </div>
          <span className="text-[11px] text-ink-muted">{unassigned.length} open</span>
        </div>

        {unassigned.length === 0 ? (
          <EmptyState
            icon={<Car className="h-5 w-5" />}
            title="No unassigned requests right now"
            description="Groups appear here as passengers form rides. You can also accept a trip already assigned to you from the section above."
          />
        ) : (
          <div className="grid gap-3 lg:grid-cols-2">
            {unassigned.map((r) => (
              <article key={r.id} className="card p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <Badge tone="indigo">{r.vehicleCategory.toUpperCase()}</Badge>
                      <Badge tone={r.seatsAvailable > 0 ? "amber" : "muted"}>{r.seatsTaken} passenger{r.seatsTaken === 1 ? "" : "s"}</Badge>
                      {r.isDemo && <DemoBadge label="DEMO" />}
                    </div>
                    <h3 className="mt-1.5 truncate text-[15px] font-bold text-navy">BOM → {r.destination.name}</h3>
                    <p className="mt-0.5 text-[11px] text-ink-muted">
                      {r.flight.flight_number} · lands {formatTime(r.flight.estimated_arrival)} · {r.extraDestinations.length ? `then ${r.extraDestinations.map((d) => d.name).join(", ")}` : "direct drop-off"}
                    </p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-muted">You earn</p>
                    <p className="text-[15px] font-bold text-navy tabular">{formatPaise(r.fare?.breakdown.vehicleFarePaise ?? 0)}</p>
                    <p className="text-[9.5px] text-ink-muted">before deductions</p>
                  </div>
                </div>

                <div className="mt-2.5 flex items-center gap-1.5">
                  <div className="flex -space-x-1.5">
                    {r.members.slice(0, 3).map((m) => <Avatar key={m.memberId} name={m.firstName} size="xs" className="ring-2 ring-white" verified={m.identityVerified} />)}
                  </div>
                  <span className="text-[10.5px] text-ink-muted">{r.members.length} traveller{r.members.length === 1 ? "" : "s"} · {r.luggageTaken} bag{r.luggageTaken === 1 ? "" : "s"}</span>
                  <span className="ml-auto inline-flex items-center gap-1 text-[10px] text-ink-muted"><Clock className="h-3 w-3" /> waits {r.maxWaitMinutes} min</span>
                </div>

                <div className="mt-3 flex gap-2">
                  <AcceptRideButton rideId={r.id} disabled={!verified} />
                  <Link href={`/driver/trips`} className="flex h-11 items-center justify-center rounded-xl border border-line px-3 text-[12.5px] font-semibold text-ink-soft hover:border-indigo-200 hover:text-indigo">
                    Details
                  </Link>
                </div>
                {!verified && <p className="mt-1.5 text-[10px] text-amber-dark">Verify your documents to accept trips.</p>}
              </article>
            ))}
          </div>
        )}
      </section>

      <section className="mt-6 grid gap-4 lg:grid-cols-2">
        <div className="card p-4">
          <p className="flex items-center gap-1.5 text-[12.5px] font-semibold text-navy"><BadgeCheck className="h-4 w-4 text-success" /> Your vehicle &amp; verification</p>
          <dl className="mt-2.5 space-y-1.5 text-[11.5px]">
            {[
              ["Status", profile.verification_status],
              ["Vehicle", profile.make_model ? `${profile.make_model} · ${profile.registration_number}` : "Not submitted"],
              ["Category", profile.category ?? "—"],
              ["Capacity", profile.seats ? `${profile.seats} seats · ${profile.luggage_units} bags` : "—"],
              ["Fleet partner", profile.company_name ?? "Independent"],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-3">
                <dt className="text-ink-muted">{k}</dt>
                <dd className="truncate font-medium capitalize text-navy">{String(v)}</dd>
              </div>
            ))}
          </dl>
          <LinkButton href="/driver/verification" variant="outline" size="sm" className="mt-3 w-full">Manage documents</LinkButton>
        </div>

        <div className="card p-4">
          <p className="flex items-center gap-1.5 text-[12.5px] font-semibold text-navy"><Wallet className="h-4 w-4 text-indigo" /> Recent earnings</p>
          {earnings.rows.length === 0 ? (
            <p className="mt-2 text-[11.5px] text-ink-muted">No completed trips yet.</p>
          ) : (
            <ul className="mt-2 space-y-1.5">
              {earnings.rows.slice(0, 4).map((e) => (
                <li key={e.id} className="flex items-center justify-between gap-2 text-[11.5px]">
                  <span className="truncate text-ink-muted">{e.period} · {relativeTime(e.created_at)}</span>
                  <span className="shrink-0 font-semibold text-navy tabular">{formatPaise(e.net_paise)}</span>
                  <Badge tone={e.status === "paid" ? "success" : "amber"} className="shrink-0">{e.status}</Badge>
                </li>
              ))}
            </ul>
          )}
          <LinkButton href="/driver/earnings" variant="outline" size="sm" className="mt-3 w-full" rightIcon={<ArrowRight className="h-3.5 w-3.5" />}>
            Full earnings dashboard
          </LinkButton>
        </div>
      </section>

      <p className="mt-5 flex items-start gap-1.5 rounded-xl border border-line bg-white px-3.5 py-2.5 text-[10.5px] leading-relaxed text-ink-muted">
        <ShieldAlert className="mt-px h-3.5 w-3.5 shrink-0" />
        Demo mode: passenger names, fares and verification outcomes are sample records. No dispatch, permit or payment is real. Driver
        verification here is an administrator review workflow, not a statutory permit check.
      </p>
    </div>
  );
}
