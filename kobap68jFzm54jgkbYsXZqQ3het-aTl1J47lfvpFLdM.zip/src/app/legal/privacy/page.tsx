import Link from "next/link";
import { SiteHeader } from "@/components/marketing/site-header";
import { SiteFooter } from "@/components/marketing/site-footer";
import { getSessionUser } from "@/lib/auth/session";
import { Alert, Badge } from "@/components/ui/primitives";

export const metadata = { title: "Privacy policy" };

const SECTIONS: { id: string; h: string; body: React.ReactNode }[] = [
  {
    id: "scope",
    h: "1. Scope and status of this document",
    body: (
      <>
        <p>
          This policy describes how the FlightShare prototype handles personal data. It is written to reflect what the software actually does,
          not an aspirational future state. <strong>It has not been reviewed by Indian counsel</strong> and is not a substitute for a legally
          reviewed privacy notice under the Digital Personal Data Protection Act, 2023 (DPDP Act) or the Information Technology (Reasonable
          Security Practices and Procedures and Sensitive Personal Data or Information) Rules, 2011.
        </p>
        <p>Before any public launch, this document must be replaced by one reviewed against the DPDP Act, contractual obligations with payment and identity providers, and applicable state transport rules.</p>
      </>
    ),
  },
  {
    id: "collect",
    h: "2. What we collect",
    body: (
      <ul>
        <li><strong>Account data:</strong> name, email, phone (optional), hashed password, role, email-verification timestamp.</li>
        <li><strong>Travel data:</strong> flight number and date, arrival airport, destination preference, luggage count, accessibility notes you choose to add, emergency contact you choose to add.</li>
        <li><strong>Verification data:</strong> the outcome of a flight or identity check and, for booking references, a masked display value plus a hash. We do not store document images.</li>
        <li><strong>Ride data:</strong> ride groups, membership, readiness states, messages in ride-scoped group chat, ratings, reports.</li>
        <li><strong>Payment metadata:</strong> provider order and payment identifiers, amount, status, refund status. <em>No card number, CVV or UPI credential is ever stored or transmitted to our servers.</em></li>
        <li><strong>Technical data:</strong> session tokens (HttpOnly cookie), coarse request metadata used for rate limiting, and audit records of privileged actions.</li>
      </ul>
    ),
  },
  {
    id: "why",
    h: "3. Why we process it",
    body: (
      <ul>
        <li>To match you with passengers arriving on the same flight and heading in a compatible direction.</li>
        <li>To calculate and communicate fare splits, which requires destination distance and luggage counts.</li>
        <li>To coordinate a meeting point and waiting window, and to let your group contact you inside the ride.</li>
        <li>To screen for abuse (rate limiting, reports, audit logs) and to satisfy accounting and tax obligations once payments are live.</li>
        <li>To measure product performance (funnel events) — analytics are aggregated and can be disabled by consent settings.</li>
      </ul>
    ),
  },
  {
    id: "share",
    h: "4. What other passengers can see",
    body: (
      <>
        <p>Accepted members of a ride group can see, for each other member:</p>
        <ul>
          <li>First name and initials avatar; verification badges (flight verified, identity verified).</li>
          <li>Seat count, luggage unit count, drop-off destination and readiness state.</li>
          <li>Messages posted in the ride&rsquo;s group chat.</li>
        </ul>
        <p>
          They cannot see your email, phone number, booking reference, payment status, identity documents or exact live location. You may choose to
          share contact details in chat yourself; that is voluntary and visible to the group.
        </p>
      </>
    ),
  },
  {
    id: "processors",
    h: "5. Processors and integrations",
    body: (
      <>
        <p>
          Integrations are optional and configuration-driven. When enabled, the following categories of processor may receive data: a flight-data
          provider (flight number and date), an identity/KYC provider (document and selfie, retained by the provider per their terms), a payment
          gateway (amount, order reference, contact details), an email or SMS provider (contact details and message content), and a maps provider
          (coarse origin and destination for route geometry).
        </p>
        <p>
          In this prototype none of these are configured. The <Link href="/status" className="font-semibold text-indigo hover:underline">status page</Link>{" "}
          reports exactly which are live at any time.
        </p>
      </>
    ),
  },
  {
    id: "retention",
    h: "6. Retention and deletion",
    body: (
      <ul>
        <li>Account and ride records are retained while the account is active.</li>
        <li>Audit logs are intended to be retained for 24 months in production and are append-only.</li>
        <li>Booking references are stored hashed with a masked display value so that a leaked database does not expose full references.</li>
        <li>Account deletion removes or anonymises personal identifiers; financial records required for tax and dispute handling may be retained in a minimal, non-identifying form.</li>
        <li>You can request export or deletion from the profile page; in the prototype this is executed immediately within the demo database.</li>
      </ul>
    ),
  },
  {
    id: "security",
    h: "7. Security measures",
    body: (
      <ul>
        <li>Passwords hashed with scrypt and per-user salts; no plaintext credentials are written to the database or logs.</li>
        <li>Session cookies are HttpOnly, SameSite=Lax, and revocable server-side; suspension invalidates all sessions.</li>
        <li>Authorisation is enforced server-side on every route and service call, never only by hiding buttons.</li>
        <li>Input is validated with typed schemas; cross-origin state-changing requests are rejected.</li>
        <li>Rate limits apply per action and per account or IP as appropriate.</li>
        <li>Payment successes are verified server-side (signature + provider re-fetch); webhooks are deduplicated.</li>
      </ul>
    ),
  },
  {
    id: "rights",
    h: "8. Your choices",
    body: (
      <ul>
        <li><strong>Access and portability:</strong> request an export of your account data from the profile page.</li>
        <li><strong>Correction:</strong> edit your profile, luggage and accessibility preferences at any time.</li>
        <li><strong>Erasure:</strong> request account deletion; ride history is anonymised where legally permissible.</li>
        <li><strong>Withdrawing consent:</strong> disable optional analytics or decline verification; some features (e.g. joining a verified group) then become unavailable.</li>
        <li><strong>Grievance:</strong> in production, a grievance officer would be named here with contact details, per Indian requirements.</li>
      </ul>
    ),
  },
  {
    id: "children",
    h: "9. Age and children",
    body: (
      <p>
        The service is intended for people aged 18 and over. A child travelling with a guardian must be added as a passenger by the guardian, and
        the guardian accepts responsibility for the fare and conduct. We do not knowingly create accounts for minors.
      </p>
    ),
  },
];

export default async function PrivacyPage() {
  const user = await getSessionUser();
  return (
    <>
      <SiteHeader user={user ? { name: user.name, role: user.role } : null} />
      <main id="main">
        <section className="border-b border-line bg-white">
          <div className="container-x py-11">
            <Badge tone="muted">Legal · draft</Badge>
            <h1 className="mt-3 text-[30px] font-bold tracking-[-0.03em] text-navy sm:text-[38px]">Privacy policy</h1>
            <p className="mt-2 text-[12px] text-ink-muted">Last updated · prototype build · applies to demo data only</p>
          </div>
        </section>

        <section className="py-10">
          <div className="container-x grid gap-8 lg:grid-cols-[220px_1fr]">
            <nav className="hidden lg:block">
              <p className="text-[10.5px] font-bold uppercase tracking-wide text-ink-muted">On this page</p>
              <ul className="mt-2 space-y-1">
                {SECTIONS.map((s) => (
                  <li key={s.id}>
                    <a href={`#${s.id}`} className="block truncate rounded px-1 py-0.5 text-[11.5px] text-ink-muted hover:text-indigo">{s.h}</a>
                  </li>
                ))}
              </ul>
            </nav>

            <article className="max-w-[68ch]">
              <Alert tone="warning" title="Draft — not legal advice">
                This is a prototype document written to be accurate about the software&rsquo;s behaviour. It has not been reviewed by counsel and
                must not be relied on for compliance.
              </Alert>

              <div className="mt-6 space-y-7">
                {SECTIONS.map((s) => (
                  <section key={s.id} id={s.id} className="scroll-mt-24">
                    <h2 className="text-[16px] font-bold tracking-[-0.01em] text-navy">{s.h}</h2>
                    <div className="mt-2 space-y-2 text-[12.5px] leading-relaxed text-ink-soft [&_li]:ml-4 [&_li]:list-disc [&_li]:marker:text-ink-muted [&_li]:mt-1">
                      {s.body}
                    </div>
                  </section>
                ))}
              </div>

              <div className="mt-8 rounded-xl border border-line bg-white p-4 text-[12px] leading-relaxed text-ink-muted">
                Questions about this policy? <Link href="/help" className="font-semibold text-indigo hover:underline">Contact support</Link>. See also the{" "}
                <Link href="/legal/terms" className="font-semibold text-indigo hover:underline">terms of use</Link> and{" "}
                <Link href="/safety" className="font-semibold text-indigo hover:underline">safety model</Link>.
              </div>
            </article>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
