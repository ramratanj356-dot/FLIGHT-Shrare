import Link from "next/link";
import { SiteHeader } from "@/components/marketing/site-header";
import { SiteFooter } from "@/components/marketing/site-footer";
import { getSessionUser } from "@/lib/auth/session";
import { Alert, Badge } from "@/components/ui/primitives";

export const metadata = { title: "Terms of use" };

const SECTIONS: { id: string; h: string; body: React.ReactNode }[] = [
  {
    id: "status",
    h: "1. What this service is — and is not",
    body: (
      <>
        <p>
          FlightShare is a <strong>software prototype</strong> that helps passengers arriving on the same flight discover each other and agree a
          shared airport transfer. It is not a transport company, does not own or operate vehicles, and does not act as a tour operator or travel
          agent.
        </p>
        <p>
          No booking made in this prototype constitutes a confirmed transport contract. A ride becomes confirmed only when a verified driver accepts
          the group; until then the group is an intention between passengers to travel together.
        </p>
      </>
    ),
  },
  {
    id: "demo",
    h: "2. Demo data and simulated states",
    body: (
      <>
        <p>
          Flights, passengers, drivers, verification outcomes, fares, messages, notifications and earnings in the default deployment are seeded demo
          data, labelled with DEMO or SAMPLE DATA badges. Payments are not processed: no card data is collected and no money moves.
        </p>
        <p>
          Verification badges in demo mode are simulated. They do not indicate that an airline, government registry or identity provider confirmed
          anything. We do not have access to airline passenger manifests and never claim to.
        </p>
      </>
    ),
  },
  {
    id: "accounts",
    h: "3. Accounts and eligibility",
    body: (
      <ul>
        <li>You must be 18 or older and provide accurate details. One account per person.</li>
        <li>You are responsible for your password and for activity under your session.</li>
        <li>We may suspend accounts for abuse, fraudulent booking references, harassment or repeated no-shows.</li>
        <li>Role separation is enforced server-side: passenger, driver, support and admin capabilities are distinct.</li>
      </ul>
    ),
  },
  {
    id: "fares",
    h: "4. Fares, estimates and payments",
    body: (
      <ul>
        <li>All fares shown are estimates until confirmed by the group after approval. Estimates expire and may be re-quoted.</li>
        <li>Clicking a match, opening a ride or sending a join request never charges you.</li>
        <li>Fares are allocated in integer paise and presented rounded to whole rupees so that shares sum exactly to the allocated total.</li>
        <li>Where payments are enabled, they are captured by a payment gateway after confirmation, verified server-side, and refunded only through the reviewed refund process.</li>
        <li>Tolls, parking and airport levies may be added where applicable and are itemised in the breakdown.</li>
        <li>The platform service fee is disclosed separately from the vehicle fare, and tax is applied to the fee as stated in the breakdown.</li>
      </ul>
    ),
  },
  {
    id: "conduct",
    h: "5. Conduct in a shared ride",
    body: (
      <ul>
        <li>Confirm readiness honestly. A ride group depends on everyone&rsquo;s timing.</li>
        <li>Do not share another passenger&rsquo;s private information outside the ride chat.</li>
        <li>Reporting a safety or no-show issue is expected, not discouraged. False reports may lead to suspension.</li>
        <li>Drivers must hold the permits, fitness certificate and insurance required for commercial passenger transport in their jurisdiction.</li>
      </ul>
    ),
  },
  {
    id: "liability",
    h: "6. Liability and disclaimers",
    body: (
      <>
        <p>
          The prototype is provided &ldquo;as is&rdquo; without warranties of availability, accuracy of flight data, or fitness for a particular
          purpose. To the extent permitted by applicable law, FlightShare is not liable for indirect or consequential loss arising from use of the
          prototype.
        </p>
        <p>
          Third-party services (airlines, drivers, payment gateways, map providers) operate under their own terms. We do not control their
          availability.
        </p>
      </>
    ),
  },
  {
    id: "regulatory",
    h: "7. Regulatory position (India)",
    body: (
      <>
        <p>
          Aggregating passengers into a shared private hire vehicle is not automatically lawful in every Indian jurisdiction. Before launch, the
          following require professional review: state transport authority permits and contract-carriage rules, app-based aggregator licensing,
          GST treatment of the platform fee, insurance covering commercial passenger carriage, and compliance with the Motor Vehicles Act and
          Central Motor Vehicles Rules.
        </p>
        <p>This prototype makes no representation that these requirements have been satisfied.</p>
      </>
    ),
  },
  {
    id: "changes",
    h: "8. Changes and governing law",
    body: (
      <p>
        We may update these terms as the product changes; material changes would be communicated in-app. In production, governing law and
        jurisdiction clauses would be specified for the operating entity. This draft does not create a binding agreement.
      </p>
    ),
  },
];

export default async function TermsPage() {
  const user = await getSessionUser();
  return (
    <>
      <SiteHeader user={user ? { name: user.name, role: user.role } : null} />
      <main id="main">
        <section className="border-b border-line bg-white">
          <div className="container-x py-11">
            <Badge tone="muted">Legal · draft</Badge>
            <h1 className="mt-3 text-[30px] font-bold tracking-[-0.03em] text-navy sm:text-[38px]">Terms of use</h1>
            <p className="mt-2 text-[12px] text-ink-muted">Prototype build · not a binding agreement · not legal advice</p>
          </div>
        </section>

        <section className="py-10">
          <div className="container-x grid gap-8 lg:grid-cols-[220px_1fr]">
            <nav className="hidden lg:block">
              <p className="text-[10.5px] font-bold uppercase tracking-wide text-ink-muted">On this page</p>
              <ul className="mt-2 space-y-1">
                {SECTIONS.map((s) => (
                  <li key={s.id}>
                    <a href={`#${s.id}`} className="block truncate rounded px-1 py-0.5 text-[11.5px] text-ink-muted hover:text-indigo">{s.h}</a>
                  </li>
                ))}
              </ul>
            </nav>

            <article className="max-w-[68ch]">
              <Alert tone="warning" title="Prototype terms — read this first">
                These terms describe how the software behaves today. They have not been drafted or reviewed by a lawyer and must be replaced before
                any commercial launch.
              </Alert>

              <div className="mt-6 space-y-7">
                {SECTIONS.map((s) => (
                  <section key={s.id} id={s.id} className="scroll-mt-24">
                    <h2 className="text-[16px] font-bold tracking-[-0.01em] text-navy">{s.h}</h2>
                    <div className="mt-2 space-y-2 text-[12.5px] leading-relaxed text-ink-soft [&_li]:ml-4 [&_li]:list-disc [&_li]:marker:text-ink-muted [&_li]:mt-1">
                      {s.body}
                    </div>
                  </section>
                ))}
              </div>

              <div className="mt-8 rounded-xl border border-line bg-white p-4 text-[12px] leading-relaxed text-ink-muted">
                See also the <Link href="/legal/privacy" className="font-semibold text-indigo hover:underline">privacy policy</Link>,{" "}
                <Link href="/safety" className="font-semibold text-indigo hover:underline">safety model</Link> and{" "}
                <Link href="/help" className="font-semibold text-indigo hover:underline">help centre</Link>.
              </div>
            </article>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
