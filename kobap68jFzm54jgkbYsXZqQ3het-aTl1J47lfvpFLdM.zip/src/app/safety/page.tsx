import Link from "next/link";
import { AlertTriangle, BadgeCheck, Eye, FileLock2, Fingerprint, Handshake, Lock, ShieldCheck, Siren, UserCheck } from "lucide-react";
import { SiteHeader } from "@/components/marketing/site-header";
import { SiteFooter } from "@/components/marketing/site-footer";
import { getSessionUser } from "@/lib/auth/session";
import { Badge, Alert, DemoBadge, SectionHeading } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";

export const metadata = {
  title: "Safety & verification",
  description: "What FlightShare verifies, what it does not, and how privacy is protected.",
};

const CONTROLS = [
  {
    icon: BadgeCheck,
    title: "Flight verification, honestly described",
    body: "A booking reference can be validated through a configured flight-data provider. In this prototype no provider is connected, so verification is simulated and every badge says so. We never claim airline manifest access.",
    note: "Status: simulated in demo · provider integration implemented behind config",
  },
  {
    icon: UserCheck,
    title: "Identity verification",
    body: "Passengers can verify an ID through a KYC provider when one is configured. Only the verification outcome is stored — never the document image. Profiles show a status badge, not your documents.",
    note: "No document uploads in the prototype",
  },
  {
    icon: Handshake,
    title: "Consent before contact",
    body: "Phone numbers are hidden by default. A coordinator can only see a number after the passenger accepts a ride and explicitly shares it. Chat stays inside the ride.",
    note: "Ride-scoped chat restricted to accepted members",
  },
  {
    icon: Eye,
    title: "Data minimisation",
    body: "Booking references are masked in UI and stored hashed. Other passengers see your first name, initials avatar, verification badges and luggage count — nothing else.",
    note: "No precise live passenger location before boarding",
  },
  {
    icon: Siren,
    title: "Reporting and blocking",
    body: "Every ride chat supports reporting with a category and free-text detail. Reports land in an admin queue with an audited resolution; repeat subjects can be suspended.",
    note: "Reporter identity is never revealed to the subject",
  },
  {
    icon: Lock,
    title: "Account protection",
    body: "Passwords are hashed with scrypt and unique salts. Sessions are HttpOnly, SameSite cookies with server-side revocation. Sign-in and privileged actions are rate-limited and audited.",
    note: "Suspension revokes sessions immediately",
  },
];

export default async function SafetyPage() {
  const user = await getSessionUser();
  return (
    <>
      <SiteHeader user={user ? { name: user.name, role: user.role } : null} />
      <main id="main">
        <section className="border-b border-line bg-white">
          <div className="container-x py-12 sm:py-16">
            <div className="max-w-2xl">
              <Badge tone="success" icon={<ShieldCheck className="h-3 w-3" />}>Trust model</Badge>
              <h1 className="mt-3 text-[32px] font-bold leading-[1.1] tracking-[-0.03em] text-navy sm:text-[44px]">
                Safety is a set of decisions, not a badge.
              </h1>
              <p className="mt-4 text-[15px] leading-relaxed text-ink-muted">
                Sharing a cab with a stranger is a trust decision. FlightShare makes the inputs visible: who is verified and how, what the
                group has agreed to, where you meet, how long anyone waits, and what happens when something goes wrong.
              </p>
            </div>

            <div className="mt-7">
              <Alert tone="warning" title="Prototype disclosure">
                This is an early-stage demonstration. Verification outcomes, driver documents and payments shown in the app are sample data
                unless an integration is explicitly configured. FlightShare is not yet a licensed transport provider and no ride booked here is
                a confirmed transport contract.
              </Alert>
            </div>
          </div>
        </section>

        <section className="py-12">
          <div className="container-x">
            <SectionHeading eyebrow="Controls" title="What we actually do" description="Each control is implemented in the prototype — some depend on external providers to become production-grade." />
            <div className="mt-6 grid gap-3 md:grid-cols-2">
              {CONTROLS.map((c) => (
                <article key={c.title} className="card p-5">
                  <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#F4F3FF] text-indigo"><c.icon className="h-4.5 w-4.5" /></span>
                  <h2 className="mt-3 text-[14.5px] font-bold text-navy">{c.title}</h2>
                  <p className="mt-1.5 text-[12.5px] leading-relaxed text-ink-muted">{c.body}</p>
                  <p className="mt-2.5 inline-flex items-center gap-1.5 rounded-lg bg-[#F9FAFD] px-2 py-1 text-[10px] font-medium text-ink-soft">
                    <Fingerprint className="h-3 w-3" /> {c.note}
                  </p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="border-y border-line bg-white py-12">
          <div className="container-x grid gap-8 lg:grid-cols-2">
            <div>
              <SectionHeading eyebrow="Ground rules" title="The waiting window is a commitment" />
              <ul className="mt-4 space-y-2.5">
                {[
                  "The coordinator sets a maximum wait before the ride is created. Everyone sees it up front.",
                  "Readiness is confirmed explicitly — landed, baggage, ready, boarding, started. Silence is not consent to wait.",
                  "If someone stalls past the window, the group is notified and the coordinator can depart, re-split or cancel.",
                  "No driver is dispatched on landing. A driver accepts separately, and only then is transport confirmed.",
                ].map((t) => (
                  <li key={t} className="flex items-start gap-2 text-[12.5px] leading-relaxed text-ink-soft">
                    <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-success" /> {t}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <SectionHeading eyebrow="Limits" title="What this prototype does not do" />
              <ul className="mt-4 space-y-2.5">
                {[
                  ["Background checks", "We do not run criminal or driving-record checks. Driver verification is a document review workflow."],
                  ["Live tracking", "No real-time vehicle GPS, no continuous passenger location sharing, no SOS dispatch to authorities."],
                  ["Insurance", "No ride-level insurance is in force. Commercial passenger transport requires permits and insurance not modelled here."],
                  ["Guaranteed availability", "A formed group is an intention until a driver accepts. There is no availability guarantee."],
                ].map(([t, d]) => (
                  <li key={t} className="rounded-xl border border-line bg-[#FBFBFE] px-3.5 py-2.5">
                    <p className="flex items-center gap-1.5 text-[12px] font-semibold text-navy"><AlertTriangle className="h-3.5 w-3.5 text-amber-dark" /> {t}</p>
                    <p className="mt-0.5 text-[11px] leading-relaxed text-ink-muted">{d}</p>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <section className="py-12">
          <div className="container-x grid gap-4 lg:grid-cols-[1.4fr_1fr]">
            <div className="card p-6">
              <FileLock2 className="h-5 w-5 text-indigo" />
              <h2 className="mt-3 text-[20px] font-bold tracking-[-0.02em] text-navy">Privacy in one paragraph</h2>
              <p className="mt-2 text-[12.5px] leading-relaxed text-ink-muted">
                We collect the minimum needed to match a flight: your name, email, phone, flight details and destination preference. Booking
                references and identity outcomes are stored masked or hashed. Other passengers never see your phone, booking reference, payment
                data or documents. Administrators can act on an account but cannot read credit-card data because none is stored — a payment
                gateway tokenises it. You can export or delete your account from the profile page.
              </p>
              <div className="mt-4 flex flex-wrap gap-2.5">
                <LinkButton href="/legal/privacy" size="md" variant="outline">Privacy policy</LinkButton>
                <LinkButton href="/legal/terms" size="md" variant="outline">Terms of use</LinkButton>
              </div>
            </div>
            <div className="rounded-2xl border border-line bg-white p-6">
              <DemoBadge label="DEMO MODE" />
              <p className="mt-3 text-[13px] font-semibold text-navy">Every simulated status is labelled</p>
              <p className="mt-1 text-[11.5px] leading-relaxed text-ink-muted">
                Look for <span className="rounded bg-amber-soft px-1 py-0.5 text-[10px] font-semibold text-amber-dark">DEMO</span> and{" "}
                <span className="rounded bg-amber-soft px-1 py-0.5 text-[10px] font-semibold text-amber-dark">SAMPLE DATA</span> tags. If you see
                one, the record is seeded demo content. Integrations that are not configured say so in the app and in the health endpoint.
              </p>
              <Link href="/status" className="mt-3 inline-flex items-center gap-1 text-[11.5px] font-semibold text-indigo hover:underline">
                Check integration status →
              </Link>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
