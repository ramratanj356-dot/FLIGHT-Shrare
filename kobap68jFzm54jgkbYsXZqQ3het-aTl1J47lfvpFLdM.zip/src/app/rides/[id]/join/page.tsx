import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import {
  ArrowLeft, BadgeCheck, Briefcase, Clock, Info, MapPin, Plane, ShieldAlert, ShieldCheck, Users,
} from "lucide-react";
import { getSessionUser } from "@/lib/auth/session";
import { getDb } from "@/lib/db";
import { loadPricingRules } from "@/lib/db/pricing";
import { getTripDetail, getPendingJoinRequest, getPassengerProfile, listDestinations } from "@/lib/db/queries";
import { scoreGroupForViewer } from "@/lib/services/rides";
import { Badge, Alert, DemoBadge, Avatar, ScoreRing } from "@/components/ui/primitives";
import { JoinRideForm } from "@/components/forms/join-ride-form";
import { formatDateLong, formatTime } from "@/lib/utils";
import { formatPaise } from "@/lib/money";
import { destinationCompatibility } from "@/lib/match/geo";
import { WithdrawRequestButton } from "@/components/forms/withdraw-request-button";

export const dynamic = "force-dynamic";

export default async function JoinRidePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await getSessionUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(`/rides/${id}/join`)}`);

  const detail = getTripDetail(id, user.id);
  if (!detail) notFound();

  const { group, membership } = detail;
  const members = group.members;
  const viewerRequest = getPendingJoinRequest(id, user.id);
  const destinations = listDestinations();
  const profile = getPassengerProfile(user.id);

  if (membership) redirect(`/app/trips/${id}`);
  if (group.status !== "open" || group.seatsAvailable <= 0) {
    return (
      <Shell user={user}>
        <div className="mx-auto max-w-xl py-10">
          <Alert tone="warning" title="This group is no longer taking passengers">
            {group.status === "full"
              ? "Every seat is taken. Matches are refreshed as seats free up."
              : `The coordinator marked this ride ${group.status}.`}
          </Alert>
          <Link href={`/rides/${id}`} className="mt-4 inline-flex items-center gap-1.5 text-[13px] font-semibold text-indigo hover:underline">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to the ride
          </Link>
        </div>
      </Shell>
    );
  }

  // One canonical option list: every destination on (or adjacent to) this
  // ride's corridor, with its route-match score. The picker and the default
  // drop-off both read from it, so a passenger can never land on a drop-off
  // the server will reject.
  const destinationOptions = destinations.map((d) => ({
    id: d.id,
    name: d.name,
    area: d.area,
    distanceKm: d.distance_km,
    soloFarePaise: d.solo_fare_paise,
    compatibility: destinationCompatibility(
      { id: d.id, name: d.name, area: d.area, corridor: d.corridor as never, lat: d.lat, lng: d.lng, distanceKm: d.distance_km, driveMinutes: d.drive_minutes, soloFarePaise: d.solo_fare_paise, tollsPaise: d.tolls_paise, blurb: "" },
      { id: group.destination.id, name: group.destination.name, area: group.destination.area, corridor: group.destination.corridor as never, lat: group.destination.lat, lng: group.destination.lng, distanceKm: group.destination.distance_km, driveMinutes: group.destination.drive_minutes, soloFarePaise: group.destination.solo_fare_paise, tollsPaise: group.destination.tolls_paise, blurb: "" },
    ),
  }));
  // The server refuses anything below the configured proximity threshold, so the
  // page must not offer it either.
  const { destinationThreshold } = loadPricingRules(getDb());
  const joinableDestinations = destinationOptions.filter((d) => d.compatibility >= destinationThreshold);
  const defaultDestinationId =
    profile?.home_destination_id && joinableDestinations.some((d) => d.id === profile.home_destination_id)
      ? profile.home_destination_id
      : joinableDestinations.find((d) => d.id === group.destination.id)?.id ?? joinableDestinations[0]?.id ?? group.destination.id;

  const preview = scoreGroupForViewer(user, id, {
    destinationId: defaultDestinationId,
    passengers: 1,
    luggageUnits: 1,
  });
  // Indicative per-person share: the group's own allocation for the coordinator's
  // destination, scaled to one seat. Final figures are confirmed after approval.
  const own = group.fare?.members[0];
  const farePreview = {
    contributionPaise: own?.contributionPaise ?? group.destination.solo_fare_paise,
    soloFarePaise: own?.soloEstimatePaise ?? group.destination.solo_fare_paise,
    savingsPaise: own?.savingsPaise ?? 0,
  };

  return (
    <Shell user={user}>
      <div className="container-x py-8">
        <Link href={`/rides/${id}`} className="inline-flex items-center gap-1.5 text-[12.5px] font-semibold text-ink-muted hover:text-indigo">
          <ArrowLeft className="h-3.5 w-3.5" /> Back to ride details
        </Link>

        <div className="mt-4 grid gap-5 lg:grid-cols-[1.3fr_1fr]">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="indigo">{group.code}</Badge>
              <DemoBadge label="DEMO DATA" />
              {group.driver && <Badge tone="success" icon={<ShieldCheck className="h-3 w-3" />}>Driver assigned</Badge>}
            </div>
            <h1 className="mt-2.5 text-[26px] font-bold tracking-[-0.02em] text-navy sm:text-[32px]">
              Request to join · {group.destination.name}
            </h1>
            <p className="mt-1.5 text-[13px] leading-relaxed text-ink-muted">
              {group.flight.airline_code} {group.flight.flight_number} landing {formatTime(group.flight.estimated_arrival)} on{" "}
              {formatDateLong(group.flight.flight_date)}. The coordinator reviews every request — nothing is charged now.
            </p>

            <div className="mt-5 card p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="text-[10.5px] font-bold uppercase tracking-wide text-ink-muted">Group coordinator</p>
                  <div className="mt-1.5 flex items-center gap-2">
                    <Avatar name={members[0]?.firstName ?? "Coordinator"} size="sm" verified={members[0]?.identityVerified} />
                    <div>
                      <p className="text-[13px] font-semibold text-navy">{members[0]?.displayName ?? "Coordinator"}</p>
                      <p className="text-[10.5px] text-ink-muted">{members[0]?.rating ?? "New"} · {members.length} travelling</p>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <ScoreRing score={preview.score} size={52} />
                  <div>
                    <p className="text-[10.5px] font-bold uppercase tracking-wide text-ink-muted">Match</p>
                    <p className="text-[12px] font-semibold text-navy">{preview.eligible ? "Compatible route" : "Limited compatibility"}</p>
                  </div>
                </div>
              </div>

              <dl className="mt-4 grid grid-cols-2 gap-3 border-t border-line pt-3 text-[11.5px] sm:grid-cols-4">
                {[
                  { icon: MapPin, k: "Meeting", v: group.meetPoint?.split("—")[0] ?? "T2" },
                  { icon: Clock, k: "Window", v: `${formatTime(group.departureWindowStart)}–${formatTime(group.departureWindowEnd)}` },
                  { icon: Users, k: "Seats left", v: `${group.seatsAvailable}` },
                  { icon: Briefcase, k: "Bag space", v: `${group.luggageAvailable}` },
                ].map((x) => (
                  <div key={x.k}>
                    <dt className="flex items-center gap-1 text-[10px] uppercase tracking-wide text-ink-muted"><x.icon className="h-3 w-3" />{x.k}</dt>
                    <dd className="mt-0.5 font-semibold text-navy">{x.v}</dd>
                  </div>
                ))}
              </dl>

              {group.extraDestinations.length > 0 && (
                <p className="mt-3 rounded-lg bg-[#F9FAFD] px-2.5 py-2 text-[11px] text-ink-muted">
                  <Plane className="mr-1 inline h-3 w-3" /> Drop-off order: {group.destination.name}, then{" "}
                  {group.extraDestinations.map((d: { name: string }) => d.name).join(", ")}.
                </p>
              )}
            </div>

            <div className="mt-4 card p-4">
              <p className="text-[12.5px] font-semibold text-navy">Your fare preview</p>
              <p className="mt-0.5 text-[11px] text-ink-muted">
                Based on a single seat to the drop-off selected here. The coordinator may re-split after other passengers join.
              </p>
              <div className="mt-3 flex items-end justify-between rounded-xl bg-[#F7F8FC] px-3.5 py-3">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-wide text-ink-muted">Estimated per person</p>
                  <p className="text-[24px] font-bold leading-tight tracking-tight text-navy tabular">{formatPaise(farePreview.contributionPaise)}</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-bold uppercase tracking-wide text-ink-muted">Solo cab</p>
                  <p className="text-[13px] font-medium text-ink-muted tabular line-through">{formatPaise(farePreview.soloFarePaise)}</p>
                  <p className="text-[10.5px] font-semibold text-success-dark">save {formatPaise(farePreview.savingsPaise)}</p>
                </div>
              </div>
              <ul className="mt-3 space-y-1 text-[10.5px] text-ink-muted">
                <li>• Estimate only — final contribution is confirmed by the coordinator before any payment.</li>
                <li>• No card, UPI or wallet is charged by clicking join. Payment happens after approval.</li>
                <li>• Estimates expire; the app re-quotes if rules or the group change.</li>
              </ul>
            </div>

            <div className="mt-4 flex items-start gap-2 rounded-xl border border-line bg-white px-3.5 py-3 text-[10.5px] leading-relaxed text-ink-muted">
              <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              <span>
                Your phone number, booking reference and identity documents are never shown to other passengers. Only your first name,
                initials avatar, verification badges and luggage count are visible.
              </span>
            </div>

            {viewerRequest && (
              <div className="mt-4">
                <Alert tone="info" title={viewerRequest.status === "pending" ? "You already have a pending request" : `Your last request was ${viewerRequest.status}`}>
                  {viewerRequest.status === "pending" ? (
                    <div className="space-y-2">
                      <p>Withdraw it any time before the coordinator decides — withdrawing is free and immediate.</p>
                      <WithdrawRequestButton requestId={viewerRequest.id} redirectTo={`/rides/${id}`} label="Withdraw my request" size="sm" />
                    </div>
                  ) : (
                    "You may submit a new request once the coordinator reopens the group."
                  )}
                </Alert>
              </div>
            )}
          </div>

          <aside className="lg:sticky lg:top-24 lg:self-start">
            <JoinRideForm
              rideGroupId={id}
              destinations={joinableDestinations.map((d) => ({
                id: d.id,
                name: d.name,
                area: d.area,
                distanceKm: d.distanceKm,
                soloFarePaise: d.soloFarePaise,
                compatibility: d.compatibility,
              }))}
              defaultDestinationId={defaultDestinationId}
              maxSeats={group.seatsAvailable}
              maxLuggage={group.luggageAvailable}
              matchScore={preview.score}
              matchReasons={preview.reasons.map((r) => r.label)}
            />
          </aside>
        </div>
      </div>
    </Shell>
  );
}

// The /rides segment layout already renders the marketing header and footer.
function Shell({ children }: { user: { name: string; role: string }; children: React.ReactNode }) {
  return <div className="bg-canvas">{children}</div>;
}
