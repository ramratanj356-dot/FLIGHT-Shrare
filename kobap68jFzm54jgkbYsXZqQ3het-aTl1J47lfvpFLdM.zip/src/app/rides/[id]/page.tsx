import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft, ArrowRight, BadgeCheck, Briefcase, CalendarClock, CarFront, Clock, Info, Luggage,
  MapPin, MessageSquare, ShieldCheck, Users,
} from "lucide-react";
import { getSessionUser } from "@/lib/auth/session";
import { getRideGroup, getPendingJoinRequest, getGroupMembership, getDestination, listDestinations } from "@/lib/db/queries";
import { scoreGroupForViewer } from "@/lib/services/rides";
import { computeDepartureWindow } from "@/lib/match/timing";
import { getDb } from "@/lib/db";
import { loadPricingRules } from "@/lib/db/pricing";
import { formatDateLong, formatTime, cn } from "@/lib/utils";
import { formatPaise } from "@/lib/money";
import { Avatar, Badge, DemoBadge, ScoreRing } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";
import { FareBreakdownCard } from "@/components/app/fare-breakdown";
import { RouteMap } from "@/components/brand/mumbai-map";
import { READINESS_LABELS, type ReadinessState } from "@/lib/config/pricing";
import { airlineName } from "@/lib/validation/schemas";

export const dynamic = "force-dynamic";

export default async function RideDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await getSessionUser();
  const group = getRideGroup(id, user?.id ?? null);
  if (!group) notFound();

  const membership = user ? getGroupMembership(id, user.id) : undefined;
  const pendingRequest = user ? getPendingJoinRequest(id, user.id) : undefined;
  const rules = loadPricingRules(getDb());
  const destinations = listDestinations();

  const targetDestination = user ? getDestination(membership?.destination_id ?? group.destination.id) : getDestination(group.destination.id);
  const match = user && targetDestination
    ? scoreGroupForViewer(user, id, { destinationId: targetDestination.id, passengers: 1, luggageUnits: 1 })
    : null;

  const window = computeDepartureWindow({
    scheduledArrival: group.flight.scheduled_arrival,
    estimatedArrival: group.flight.estimated_arrival,
    status: group.flight.status,
    baggageClaimMinutes: rules.baggageClaimMinutes,
    maxWaitMinutes: group.maxWaitMinutes,
    members: group.members.map((m) => ({
      readiness: m.readiness as ReadinessState,
      expectedReadyAt: m.expectedReadyAt ?? group.departureWindowStart,
    })),
  });

  const canJoin = !membership && !pendingRequest && group.status === "open" && group.seatsAvailable > 0;
  const seatsFree = group.seatsAvailable;

  return (
    <div className="container-x py-6 sm:py-8">
      <Link href={`/rides?flight=${group.flight.flight_number}&date=${group.flight.flight_date}&dest=${group.destination.id}&pax=1&luggage=1`} className="inline-flex items-center gap-1.5 text-[12px] font-medium text-ink-muted hover:text-indigo">
        <ArrowLeft className="h-3.5 w-3.5" /> Back to matches
      </Link>

      <div className="mt-3 grid gap-6 lg:grid-cols-[1fr_368px]">
        <div className="space-y-4">
          {/* Header card */}
          <div className="card overflow-hidden">
            <div className="border-b border-line bg-[#FBFBFE] px-4 py-3.5 sm:px-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Badge tone="indigo">{group.code}</Badge>
                    {group.isDemo && <DemoBadge />}
                    <Badge tone={group.status === "open" ? "success" : group.status === "full" ? "amber" : "muted"} className="capitalize">
                      {group.status === "open" ? `${seatsFree} seat${seatsFree === 1 ? "" : "s"} free` : group.status}
                    </Badge>
                    {group.fare && <Badge tone="muted">{group.fare.breakdown.passengerCount} passenger{group.fare.breakdown.passengerCount === 1 ? "" : "s"}</Badge>}
                  </div>
                  <h1 className="mt-2 text-[24px] font-bold tracking-[-0.02em] text-navy sm:text-[28px]">
                    Mumbai (BOM) → {group.destination.name}
                  </h1>
                  <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[12px] text-ink-muted">
                    <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" />{group.destination.distance_km} km · ~{group.destination.drive_minutes} min</span>
                    {group.extraDestinations.length > 0 && (
                      <span className="inline-flex items-center gap-1"><ArrowRight className="h-3 w-3" />then {group.extraDestinations.map((d) => d.name).join(", ")}</span>
                    )}
                    <span className="inline-flex items-center gap-1"><CarFront className="h-3 w-3" />{group.vehicleCategory.toUpperCase()}</span>
                  </p>
                </div>
                {match && (
                  <div className="flex items-center gap-2.5 rounded-xl border border-line bg-white px-3 py-2">
                    <ScoreRing score={match.score} size={46} />
                    <div>
                      <p className="text-[10.5px] font-semibold uppercase tracking-wide text-ink-muted">Your match</p>
                      <p className="text-[12px] font-semibold text-navy">{match.eligible ? "Compatible" : "Not joinable"}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Flight strip */}
            <div className="grid gap-0 divide-y divide-line sm:grid-cols-4 sm:divide-x sm:divide-y-0">
              {[
                { label: "Flight", value: `${group.flight.airline_code} ${group.flight.flight_number}`, sub: airlineName(group.flight.airline_code) },
                { label: "Arrives", value: formatTime(group.flight.estimated_arrival), sub: formatDateLong(group.flight.flight_date) },
                { label: "Terminal", value: group.flight.terminal ?? "T2", sub: group.meetPoint ? "Meeting point set" : "Meeting point pending" },
                { label: "Status", value: group.flight.status.replace(/^\w/, (c) => c.toUpperCase()), sub: window.statusLabel },
              ].map((f) => (
                <div key={f.label} className="px-4 py-3">
                  <p className="text-[9.5px] font-semibold uppercase tracking-[0.1em] text-ink-muted">{f.label}</p>
                  <p className="mt-0.5 text-[14px] font-bold capitalize text-navy">{f.value}</p>
                  <p className="text-[10.5px] text-ink-muted">{f.sub}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Route map */}
          <div className="card p-3">
            <div className="mb-2 flex items-center justify-between px-1">
              <p className="text-[12.5px] font-semibold text-navy">Shared route & drop-off order</p>
              <span className="text-[10.5px] text-ink-muted">Mapbox not configured · schematic map</span>
            </div>
            <RouteMap
              stops={[
                { id: group.destination.id, name: group.destination.name, lat: group.destination.lat, lng: group.destination.lng, distanceKm: group.destination.distance_km },
                ...group.extraDestinations.map((d) => ({ id: d.id, name: d.name, lat: d.lat, lng: d.lng, distanceKm: d.distance_km })),
              ]}
              height={250}
            />
          </div>

          {/* Members + readiness */}
          <div className="card">
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <div className="flex items-center gap-2">
                <span className="grid h-8 w-8 place-items-center rounded-lg bg-[#F4F7FF] text-indigo"><Users className="h-4 w-4" /></span>
                <div>
                  <p className="text-[13px] font-semibold text-navy">Travellers in this ride</p>
                  <p className="text-[10.5px] text-ink-muted">Names shortened · contact details private</p>
                </div>
              </div>
              <span className="text-[11px] font-medium text-ink-muted">{group.members.length}/{group.seatsTotal} seats</span>
            </div>
            <ul className="divide-y divide-line">
              {group.members.map((m) => (
                <li key={m.memberId} className="flex items-center justify-between gap-3 px-4 py-3">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <Avatar name={m.firstName} size="md" verified={m.identityVerified} />
                    <div className="min-w-0">
                      <p className="flex items-center gap-1.5 truncate text-[13px] font-semibold text-navy">
                        {m.displayName}
                        {m.role === "owner" && <span className="rounded bg-[#F4F3FF] px-1 py-0.5 text-[9px] font-bold uppercase text-indigo">Coordinator</span>}
                      </p>
                      <p className="truncate text-[11px] text-ink-muted">
                        → {m.destinationName} · {m.seats} seat{m.seats > 1 ? "s" : ""} · {m.luggageUnits} bag{m.luggageUnits === 1 ? "" : "s"}
                      </p>
                    </div>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1">
                    <Badge tone={m.readiness === "ready_at_meeting_point" ? "success" : m.readiness === "not_landed" ? "muted" : "amber"}>
                      {READINESS_LABELS[m.readiness as ReadinessState] ?? m.readiness}
                    </Badge>
                    <span className={cn("inline-flex items-center gap-1 text-[10px]", m.flightVerified ? "text-success-dark" : "text-ink-muted")}>
                      <BadgeCheck className="h-3 w-3" /> {m.flightVerified ? "Flight verified" : "Verification pending"}
                    </span>
                  </div>
                </li>
              ))}
              {Array.from({ length: Math.max(0, group.seatsTotal - group.members.length) }).map((_, i) => (
                <li key={`empty-${i}`} className="flex items-center gap-2.5 px-4 py-3">
                  <span className="grid h-10 w-10 place-items-center rounded-full border border-dashed border-[#D7DCE6] text-[#B6BDC9]"><Users className="h-4 w-4" /></span>
                  <div>
                    <p className="text-[12.5px] font-medium text-ink-muted">Open seat</p>
                    <p className="text-[10.5px] text-[#98A2B3]">Available for a passenger on this flight</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          {/* Coordination */}
          <div className="card p-4">
            <p className="flex items-center gap-1.5 text-[13px] font-semibold text-navy">
              <CalendarClock className="h-4 w-4 text-indigo" /> Departure coordination
            </p>
            <div className="mt-3 grid gap-2.5 sm:grid-cols-3">
              <div className="rounded-xl border border-line bg-[#FBFBFE] p-2.5">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-muted">Group window</p>
                <p className="text-[13px] font-bold text-navy tabular">{formatTime(group.departureWindowStart)} – {formatTime(group.departureWindowEnd)}</p>
                <p className="text-[10px] text-ink-muted">agreed in advance</p>
              </div>
              <div className="rounded-xl border border-line bg-[#FBFBFE] p-2.5">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-muted">Max wait</p>
                <p className="text-[13px] font-bold text-navy">{group.maxWaitMinutes} min</p>
                <p className="text-[10px] text-ink-muted">after landing + baggage</p>
              </div>
              <div className="rounded-xl border border-line bg-[#FBFBFE] p-2.5">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-muted">Ready now</p>
                <p className="text-[13px] font-bold text-navy">{group.members.length - window.pendingMembers}/{group.members.length}</p>
                <p className="text-[10px] text-ink-muted">confirmed at the kerb</p>
              </div>
            </div>
            <div className="mt-3 flex items-start gap-2 rounded-lg bg-[#F9FAFD] px-3 py-2.5 text-[11px] leading-relaxed text-ink-muted">
              <Info className="mt-px h-3.5 w-3.5 shrink-0" />
              <span>
                Passengers confirm readiness themselves — landing, collecting baggage, or ready at the meeting point. The vehicle is never
                dispatched automatically just because a flight landed.
                {window.exceedsWait && <strong className="ml-1 text-amber-dark"> This group&apos;s window currently exceeds the agreed wait.</strong>}
              </span>
            </div>
            {group.meetPoint && (
              <div className="mt-3 rounded-xl border border-indigo-100 bg-[#F7F6FF] p-3">
                <p className="text-[10px] font-bold uppercase tracking-wide text-indigo">Meeting point</p>
                <p className="mt-1 text-[12.5px] font-medium text-navy">{group.meetPoint}</p>
                <p className="mt-1 text-[10.5px] text-ink-muted">Exact pickup bay is shared in the trip chat once a driver accepts.</p>
              </div>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <aside className="space-y-4">
          {group.fare && <FareBreakdownCard
              fare={group.fare}
              viewerUserId={user?.id}
              memberNames={Object.fromEntries(group.members.map((m) => [m.userId, m.displayName]))}
            />}

          {/* Actions */}
          <div className="card p-4">
            {membership ? (
              <>
                <p className="text-[13px] font-semibold text-navy">You&apos;re in this ride</p>
                <p className="mt-1 text-[11.5px] leading-relaxed text-ink-muted">
                  Open your trip to confirm readiness, chat with the group and see pickup instructions.
                </p>
                <LinkButton href={`/app/trips/${group.id}`} className="mt-3 w-full" size="md" rightIcon={<ArrowRight className="h-4 w-4" />}>
                  Open trip
                </LinkButton>
              </>
            ) : pendingRequest ? (
              <>
                <p className="text-[13px] font-semibold text-navy">Request pending</p>
                <p className="mt-1 text-[11.5px] leading-relaxed text-ink-muted">
                  The coordinator has your request. You&apos;ll get a notification when they decide. Nothing has been charged.
                </p>
                <LinkButton href="/app" variant="outline" className="mt-3 w-full" size="md">Back to dashboard</LinkButton>
              </>
            ) : canJoin ? (
              <>
                <div className="flex items-baseline justify-between">
                  <p className="text-[13px] font-semibold text-navy">Your estimated share</p>
                  <span className="rounded-md bg-amber-soft px-1.5 py-0.5 text-[9px] font-bold uppercase text-amber-dark">Estimate</span>
                </div>
                <p className="mt-1 text-[30px] font-bold leading-none tracking-tight text-navy tabular">
                  {formatPaise(group.fare?.breakdown.perPassengerAveragePaise ?? 0)}
                </p>
                <p className="mt-1 text-[11px] text-ink-muted">Re-split fairly if someone else joins. Nothing charged on request.</p>
                <LinkButton href={`/rides/${group.id}/join`} className="mt-3 w-full" size="lg" rightIcon={<ArrowRight className="h-4 w-4" />}>
                  Request to Join
                </LinkButton>
                <p className="mt-2 text-center text-[10.5px] text-ink-muted">
                  You confirm the final fare before any payment.
                </p>
              </>
            ) : (
              <>
                <p className="text-[13px] font-semibold text-navy">
                  {group.seatsAvailable === 0 ? "This ride is full" : "This ride isn't accepting passengers"}
                </p>
                <p className="mt-1 text-[11.5px] leading-relaxed text-ink-muted">
                  You can start your own group on the same flight; others heading your way can request to join.
                </p>
                <LinkButton
                  href={`/app/rides/new?flight=${group.flight.flight_number}&date=${group.flight.flight_date}&dest=${group.destination.id}`}
                  className="mt-3 w-full"
                  size="md"
                >
                  Start a ride group
                </LinkButton>
              </>
            )}
          </div>

          {/* Trust */}
          <div className="card p-4">
            <p className="flex items-center gap-1.5 text-[12.5px] font-semibold text-navy"><ShieldCheck className="h-4 w-4 text-success" /> What other passengers see</p>
            <ul className="mt-2 space-y-1.5 text-[11px] leading-relaxed text-ink-muted">
              <li className="flex gap-1.5"><Briefcase className="mt-px h-3 w-3 shrink-0" /> Luggage size only, never bag contents.</li>
              <li className="flex gap-1.5"><Luggage className="mt-px h-3 w-3 shrink-0" /> Destination area, not your home address.</li>
              <li className="flex gap-1.5"><MessageSquare className="mt-px h-3 w-3 shrink-0" /> Chat is limited to accepted passengers.</li>
              <li className="flex gap-1.5"><Clock className="mt-px h-3 w-3 shrink-0" /> Booking references and phone numbers stay private.</li>
            </ul>
          </div>

          {group.driver && (
            <div className="card p-4">
              <p className="text-[10px] font-bold uppercase tracking-wide text-ink-muted">Driver</p>
              <div className="mt-2 flex items-center gap-2.5">
                <Avatar name={group.driver.name} size="md" verified={group.driver.verified} />
                <div>
                  <p className="text-[13px] font-semibold text-navy">{group.driver.name}</p>
                  <p className="text-[11px] text-ink-muted">{group.driver.vehicle}</p>
                </div>
              </div>
            </div>
          )}

          <div className="rounded-xl border border-line bg-white p-3.5">
            <p className="text-[10.5px] font-semibold uppercase tracking-wide text-ink-muted">Destinations in this group</p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {[group.destination, ...group.extraDestinations].map((d) => (
                <span key={d.id} className="rounded-md bg-[#F7F8FC] px-2 py-1 text-[10.5px] font-medium text-ink-soft">{d.name}</span>
              ))}
              {destinations.length === 0 && <span className="text-[11px] text-ink-muted">—</span>}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
