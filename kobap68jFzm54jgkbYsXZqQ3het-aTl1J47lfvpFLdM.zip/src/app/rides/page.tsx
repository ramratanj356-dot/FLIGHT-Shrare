import Link from "next/link";
import { ArrowLeft, ArrowRight, CalendarX2, Filter, PlaneTakeoff, Search, ShieldAlert, Sparkles } from "lucide-react";
import { getSessionUser } from "@/lib/auth/session";
import { getDestination, getPricingRules, listDestinations, listGroupsForFlight, findFlight } from "@/lib/db/queries";
import { scoreGroupForViewer } from "@/lib/services/rides";
import { getDb } from "@/lib/db";
import { formatDateLong, formatTime, toDateKey } from "@/lib/utils";
import { Badge, DemoBadge, EmptyState } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";
import { MatchCard, type MatchCardData } from "@/components/app/match-card";
import { FlightSearchForm } from "@/components/forms/flight-search-form";
import { airlineName, normalizeFlight } from "@/lib/validation/schemas";
import { destinationCompatibility } from "@/lib/match/geo";

export const dynamic = "force-dynamic";

interface PageProps {
  searchParams: Promise<{
    flight?: string; date?: string; dest?: string; pax?: string; luggage?: string; airport?: string;
    minScore?: string; sort?: string;
  }>;
}

export async function generateMetadata({ searchParams }: PageProps) {
  const sp = await searchParams;
  return { title: sp.flight ? `Rides for ${sp.flight}` : "Find a shared ride" };
}

export default async function RidesPage({ searchParams }: PageProps) {
  const sp = await searchParams;
  const user = await getSessionUser();
  const destinations = listDestinations();
  const today = toDateKey();

  const flightNumber = (sp.flight ?? "").trim();
  const date = sp.date ?? today;
  const destinationId = sp.dest ?? "";
  const passengers = Math.max(1, Math.min(6, Number(sp.pax ?? 1) || 1));
  const luggage = Math.max(0, Math.min(8, Number(sp.luggage ?? 1) || 0));
  const minScore = Number(sp.minScore ?? 0);

  // ── No search yet: guide, don't show an empty shell ─────────────────
  if (!flightNumber || !destinationId) {
    return (
      <div className="container-x py-10 sm:py-14">
        <div className="mx-auto max-w-3xl">
          <Badge tone="indigo" icon={<Search className="h-3 w-3" />}>Find a ride</Badge>
          <h1 className="mt-3 text-[28px] font-bold tracking-[-0.02em] text-navy sm:text-[34px]">Where are you flying into?</h1>
          <p className="mt-2 max-w-xl text-[14px] leading-relaxed text-ink-muted">
            Enter your flight and destination. We will show you everyone on that flight heading the same way — with a match score, fare
            split and departure window for each group.
          </p>
          <div className="mt-6">
            <FlightSearchForm
              variant="page"
              destinations={destinations.map((d) => ({ id: d.id, name: d.name, area: d.area, distanceKm: d.distance_km, soloFarePaise: d.solo_fare_paise }))}
              defaultDate={today}
              sampleFlight="AI864"
            />
          </div>
          <div className="mt-6 grid gap-3 sm:grid-cols-3">
            {[
              { title: "Same flight", body: "Matching starts from a shared arrival, not a general city pool." },
              { title: "Route-aware", body: "Mulund matches Thane because they share a corridor — and we explain why." },
              { title: "Fair by design", body: "Every split is itemised to the paise, with rounding accounted for." },
            ].map((c) => (
              <div key={c.title} className="rounded-xl border border-line bg-white p-3.5">
                <p className="text-[12.5px] font-semibold text-navy">{c.title}</p>
                <p className="mt-1 text-[11.5px] leading-relaxed text-ink-muted">{c.body}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const normalized = normalizeFlight(flightNumber);
  const destination = getDestination(destinationId);
  const flight = normalized ? findFlight(sp.airport ?? "apt_bom", normalized.flightNumber, date) : undefined;
  const groups = flight ? listGroupsForFlight(flight.id, user?.id ?? null) : [];

  // Score every group for this passenger's intent.
  const scored = groups
    .map((g) => {
      let match;
      if (user) {
        try {
          match = scoreGroupForViewer(user, g.id, {
            destinationId, passengers, luggageUnits: luggage, flightNumber: normalized?.flightNumber, flightDate: date,
          });
        } catch {
          match = null;
        }
      }
      if (!match) match = fallbackScore(g, destinationId, passengers, luggage, getPricingRules());
      return { group: g, match };
    })
    .filter((s) => s.match.score >= minScore)
    .sort((a, b) => b.match.score - a.match.score);

  const eligible = scored.filter((s) => s.match.eligible);
  const ineligible = scored.filter((s) => !s.match.eligible);

  const sampleFlightLabel = flight && flight.source === "demo" ? "SAMPLE DATA" : undefined;

  return (
    <div className="bg-canvas">
      {/* summary bar */}
      <div className="border-b border-line bg-white">
        <div className="container-x py-5">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-center">
            <div>
              <Link href="/search" className="inline-flex items-center gap-1.5 text-[12px] font-medium text-ink-muted hover:text-indigo">
                <ArrowLeft className="h-3.5 w-3.5" /> Edit search
              </Link>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <h1 className="text-[21px] font-bold tracking-[-0.02em] text-navy">
                  {normalized?.flightNumber ?? flightNumber} · {destination?.name ?? "Your destination"}
                </h1>
                {sampleFlightLabel && <DemoBadge label={sampleFlightLabel} />}
              </div>
              <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[12px] text-ink-muted">
                <span>{formatDateLong(date)}</span>
                <span className="h-3 w-px bg-line" />
                <span>Mumbai (BOM)</span>
                <span className="h-3 w-px bg-line" />
                <span>{passengers} passenger{passengers > 1 ? "s" : ""}</span>
                <span className="h-3 w-px bg-line" />
                <span>{luggage} luggage unit{luggage === 1 ? "" : "s"}</span>
              </p>
            </div>

            {flight && (
              <div className="flex flex-wrap items-center gap-3 rounded-xl border border-line bg-[#FBFBFE] px-3.5 py-2.5">
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-muted">Flight</p>
                  <p className="text-[13px] font-semibold text-navy">{airlineName(flight.airline_code)} {flight.flight_number}</p>
                </div>
                <div className="h-8 w-px bg-line" />
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-muted">Arrival</p>
                  <p className="text-[13px] font-semibold text-navy tabular">
                    {formatTime(flight.estimated_arrival)}
                    {flight.status === "delayed" && <span className="ml-1.5 text-[10px] font-bold uppercase text-amber-dark">delayed</span>}
                  </p>
                </div>
                <div className="h-8 w-px bg-line" />
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-muted">Terminal</p>
                  <p className="text-[13px] font-semibold text-navy">{flight.terminal ?? "T2"}</p>
                </div>
                <div className="h-8 w-px bg-line" />
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-muted">Status</p>
                  <p className="text-[13px] font-semibold capitalize text-navy">{flight.status}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="container-x py-6">
        {/* Flight not found */}
        {!flight && (
          <div className="mx-auto max-w-2xl">
            <EmptyState
              icon={<PlaneTakeoff className="h-6 w-6" />}
              title="We don't have this flight in the schedule"
              description={`${normalized?.flightNumber ?? flightNumber} on ${formatDateLong(date)} is not in the BOM schedule we have access to. Double-check the flight number and date, or browse another sample flight.`}
              action={
                <div className="flex flex-wrap justify-center gap-2">
                  <LinkButton href={`/rides?flight=AI864&date=${today}&dest=${destinationId}&pax=${passengers}&luggage=${luggage}`} size="sm">
                    Try sample flight AI 864
                  </LinkButton>
                  <LinkButton href="/search" variant="outline" size="sm">Start a new search</LinkButton>
                </div>
              }
            />
          </div>
        )}

        {/* Flight found, no groups */}
        {flight && scored.length === 0 && (
          <div className="mx-auto max-w-2xl">
            <EmptyState
              icon={<CalendarX2 className="h-6 w-6" />}
              title="No compatible rides on this flight yet"
              description="Nobody has proposed a shared ride into this area for your flight so far. You can start a group and other passengers on the same flight will be able to join you."
              action={
                <div className="flex flex-wrap justify-center gap-2">
                  <LinkButton href={`/app/rides/new?flight=${normalized?.flightNumber}&date=${date}&dest=${destinationId}`} size="md">
                    Start a ride group
                  </LinkButton>
                  <LinkButton href={`/rides?flight=${normalized?.flightNumber}&date=${date}&dest=thane-w&pax=${passengers}&luggage=${luggage}`} variant="outline" size="md">
                    Try Thane West instead
                  </LinkButton>
                </div>
              }
            />
          </div>
        )}

        {scored.length > 0 && (
          <div className="grid gap-6 lg:grid-cols-[1fr_300px]">
            <div>
              <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
                <p className="text-[13px] text-ink-soft">
                  <strong className="text-navy">{eligible.length}</strong> compatible ride{eligible.length === 1 ? "" : "s"}
                  {ineligible.length > 0 && <span className="text-ink-muted"> · {ineligible.length} unavailable</span>}
                  <span className="ml-2 text-[11.5px] text-ink-muted">sorted by match score</span>
                </p>
                <div className="flex items-center gap-1.5">
                  <Filter className="h-3.5 w-3.5 text-ink-muted" />
                  {[0, 55, 70].map((s) => (
                    <Link
                      key={s}
                      href={`/rides?flight=${normalized?.flightNumber}&date=${date}&dest=${destinationId}&pax=${passengers}&luggage=${luggage}&minScore=${s}`}
                      className={`rounded-md border px-2 py-1 text-[11px] font-medium transition ${minScore === s ? "border-indigo bg-indigo-50 text-indigo" : "border-line text-ink-muted hover:border-[#C9CFDA]"}`}
                    >
                      {s === 0 ? "All" : `${s}+ score`}
                    </Link>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                {[...eligible, ...ineligible].map(({ group, match }, i) => {
                  const card = toCardData(group, match.eligible ? i + 1 : i + 1);
                  return <MatchCard key={group.id} data={card} match={match} rank={i + 1} authed={Boolean(user)} />;
                })}
              </div>

              {eligible.length === 0 && ineligible.length > 0 && (
                <div className="mt-4 flex items-start gap-2 rounded-xl border border-[#F8E2B0] bg-amber-soft px-4 py-3 text-[12.5px] leading-relaxed text-amber-dark">
                  <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />
                  <span>
                    Every group on this flight is currently full or outside your destination threshold. You can still start your own group —
                    we will match you automatically when others on the flight search.
                  </span>
                </div>
              )}
            </div>

            <aside className="space-y-3">
              <div className="card p-4">
                <p className="flex items-center gap-1.5 text-[12.5px] font-semibold text-navy">
                  <Sparkles className="h-3.5 w-3.5 text-indigo" /> How we ranked these
                </p>
                <ul className="mt-2.5 space-y-2 text-[11.5px] leading-relaxed text-ink-muted">
                  <li>Flight identity <span className="text-ink-soft">30%</span> — same airline and flight number.</li>
                  <li>Destination <span className="text-ink-soft">25%</span> — geographic and corridor compatibility.</li>
                  <li>Timing <span className="text-ink-soft">15%</span> — kerb-time versus departure window.</li>
                  <li>Capacity &amp; luggage <span className="text-ink-soft">15%</span> — seats and bag space left.</li>
                  <li>Route &amp; trust <span className="text-ink-soft">15%</span> — detour efficiency and verification.</li>
                </ul>
                <p className="mt-2.5 rounded-lg bg-[#F9FAFD] px-2.5 py-2 text-[10.5px] text-ink-muted">
                  Scores are advisory. You always choose whether to request a seat.
                </p>
              </div>

              <div className="card p-4">
                <p className="text-[12.5px] font-semibold text-navy">Nothing quite right?</p>
                <p className="mt-1 text-[11.5px] leading-relaxed text-ink-muted">
                  Start your own group. You set the vehicle, the waiting window and the fare strategy; others on your flight can request to join.
                </p>
                <LinkButton
                  href={`/app/rides/new?flight=${normalized?.flightNumber}&date=${date}&dest=${destinationId}`}
                  className="mt-3 w-full"
                  size="sm"
                  rightIcon={<ArrowRight className="h-3.5 w-3.5" />}
                >
                  Start a ride group
                </LinkButton>
              </div>

              <div className="rounded-xl border border-line bg-white p-4">
                <p className="text-[11px] font-semibold uppercase tracking-wide text-ink-muted">Fair-fare reminder</p>
                <p className="mt-1.5 text-[11.5px] leading-relaxed text-ink-muted">
                  All fares shown are <strong className="text-ink-soft">estimates</strong> calculated by the pricing engine. Nothing is charged
                  when you request a seat; a fare only becomes final after a verified driver accepts.
                </p>
              </div>
            </aside>
          </div>
        )}
      </div>
    </div>
  );
}

function toCardData(group: ReturnType<typeof listGroupsForFlight>[number], rank: number): MatchCardData {
  const total = group.fare?.breakdown.totalPaise ?? 0;
  const seats = Math.max(1, group.fare?.breakdown.seatCount ?? group.seatsTaken);
  const perPerson = Math.round(total / seats / 100) * 100; // whole-rupee average
  const solo = group.destination.solo_fare_paise;
  return {
    groupId: group.id,
    code: group.code,
    destinationName: group.destination.name,
    extraStops: group.extraDestinations.map((d) => d.name),
    distanceKm: group.destination.distance_km,
    driveMinutes: group.destination.drive_minutes,
    vehicleCategory: group.vehicleCategory,
    seatsAvailable: group.seatsAvailable,
    seatsTotal: group.seatsTotal,
    passengers: group.members.map((m) => ({ name: m.firstName, verified: m.flightVerified, identityVerified: m.identityVerified })),
    perPersonPaise: perPerson,
    totalPaise: total,
    soloPaise: solo,
    savingsPct: solo > 0 ? Math.round(((solo - perPerson) / solo) * 100) : 0,
    departureWindowStart: group.departureWindowStart,
    departureWindowEnd: group.departureWindowEnd,
    maxWaitMinutes: group.maxWaitMinutes,
    luggageAvailable: group.luggageAvailable,
    flightVerifiedCount: group.members.filter((m) => m.flightVerified).length,
    isDemo: group.isDemo,
  };
  void rank;
}

/** Anonymous visitors (or a failed personalisation) still get an honest score. */
function fallbackScore(
  group: ReturnType<typeof listGroupsForFlight>[number],
  destinationId: string,
  passengers: number,
  luggage: number,
  rules: ReturnType<typeof getPricingRules>,
) {
  const intentDest = getDestination(destinationId);
  if (!intentDest) {
    return { groupId: group.id, score: 0, components: {} as never, reasons: [], blockers: ["Destination unavailable"], eligible: false, seatsAvailable: group.seatsAvailable, luggageAvailable: group.luggageAvailable };
  }
  const compat = destinationCompatibility(
    { id: intentDest.id, name: intentDest.name, area: intentDest.area, corridor: intentDest.corridor as never, lat: intentDest.lat, lng: intentDest.lng, distanceKm: intentDest.distance_km, driveMinutes: intentDest.drive_minutes, soloFarePaise: intentDest.solo_fare_paise, tollsPaise: intentDest.tolls_paise, blurb: "" },
    { id: group.destination.id, name: group.destination.name, area: group.destination.area, corridor: group.destination.corridor as never, lat: group.destination.lat, lng: group.destination.lng, distanceKm: group.destination.distance_km, driveMinutes: group.destination.drive_minutes, soloFarePaise: group.destination.solo_fare_paise, tollsPaise: group.destination.tolls_paise, blurb: "" },
  );
  const blockers: string[] = [];
  if (group.seatsAvailable < passengers) blockers.push("Not enough seats left");
  if (group.luggageAvailable < luggage) blockers.push("Not enough luggage space");
  const score = Math.round(compat * 60 + 25 + (group.seatsAvailable > 0 ? 8 : 0));
  return {
    groupId: group.id,
    score: Math.min(96, score),
    components: { destination: compat, capacity: group.seatsAvailable > 0 ? 1 : 0, flight: 1, luggage: 0.8, timing: 0.8, route: 0.8, trust: 0.8 },
    reasons: [
      { tone: "positive" as const, dimension: "flight" as const, label: "Same flight", detail: "You are searching this flight." },
      ...(compat >= rules.destinationThreshold
        ? [{ tone: "positive" as const, dimension: "destination" as const, label: "Destinations are along a compatible route", detail: `${intentDest.name} is compatible with ${group.destination.name}.` }]
        : [{ tone: "warning" as const, dimension: "destination" as const, label: "Destinations diverge", detail: `${intentDest.name} is not on the ${group.destination.name} route.` }]),
    ],
    blockers,
    eligible: blockers.length === 0 && compat >= rules.destinationThreshold,
    seatsAvailable: group.seatsAvailable,
    luggageAvailable: group.luggageAvailable,
  };
}

export const runtime = "nodejs";
void getDb;
