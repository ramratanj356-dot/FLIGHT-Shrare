import Link from "next/link";
import {
  AlertTriangle, CheckCircle2, CreditCard, Database, KeyRound, Mail, Map as MapIcon,
  MessageSquare, Plane, ShieldCheck,
} from "lucide-react";
import { SiteHeader } from "@/components/marketing/site-header";
import { SiteFooter } from "@/components/marketing/site-footer";
import { getSessionUser } from "@/lib/auth/session";
import { integrations, DEMO_MODE } from "@/lib/config/features";
import { Badge, DemoBadge } from "@/components/ui/primitives";

export const dynamic = "force-dynamic";
export const metadata = { title: "System status" };

const ICONS: Record<string, typeof Plane> = {
  database: Database,
  auth: KeyRound,
  "flight-data": Plane,
  maps: MapIcon,
  payments: CreditCard,
  email: Mail,
  identity: ShieldCheck,
  realtime: MessageSquare,
};

const EFFECT: Record<string, { live: string; off: string }> = {
  database: { live: "Records persist across restarts.", off: "Records persist across restarts." },
  auth: { live: "Password sessions active; Google OAuth available.", off: "Password sessions active; Google button disabled." },
  "flight-data": { live: "Schedules and statuses fetched from the provider.", off: "Schedule comes from the labelled demo table." },
  maps: { live: "Real tiles and route geometry.", off: "Schematic map with curated coordinates." },
  payments: { live: "Live orders, verified signatures, refunds.", off: "Estimates only — nothing is charged." },
  email: { live: "Transactional email delivered.", off: "Notifications stay in-app and in server logs." },
  identity: { live: "Document checks via the provider.", off: "Verification simulated and labelled." },
  realtime: { live: "Ride chat and readiness update live.", off: "Ride chat and readiness update live." },
};

export default async function StatusPage() {
  const user = await getSessionUser();
  const list = integrations();
  const live = list.filter((i) => i.configured);
  const simulated = list.filter((i) => !i.configured);

  return (
    <>
      <SiteHeader user={user ? { name: user.name, role: user.role } : null} />
      <main id="main">
        <section className="border-b border-line bg-white">
          <div className="container-x py-12">
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="muted">Environment</Badge>
              {DEMO_MODE && <DemoBadge label="DEMO MODE" />}
            </div>
            <h1 className="mt-3 text-[30px] font-bold tracking-[-0.03em] text-navy sm:text-[38px]">What is real, what is simulated</h1>
            <p className="mt-3 max-w-2xl text-[14px] leading-relaxed text-ink-muted">
              Each row below is read from the same environment variables the server uses. Nothing claims to be live when it is not — if a
              credential is missing, the app says so here and behaves accordingly.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-lg border border-[#CFEFE1] bg-success-soft px-2.5 py-1.5 text-[11.5px] font-semibold text-success-dark">
                <CheckCircle2 className="h-3.5 w-3.5" /> {live.length} of {list.length} configured
              </span>
              <a href="/api/health" className="inline-flex items-center gap-1.5 rounded-lg border border-line px-2.5 py-1.5 text-[11.5px] font-semibold text-ink-soft hover:border-indigo-200 hover:text-indigo">
                Machine-readable health JSON →
              </a>
            </div>
          </div>
        </section>

        <section className="py-10">
          <div className="container-x">
            <div className="card overflow-hidden">
              <div className="hidden grid-cols-[1.7fr_1fr_1.2fr] gap-3 border-b border-line bg-[#FBFBFE] px-4 py-2.5 text-[10.5px] font-semibold uppercase tracking-wide text-ink-muted sm:grid">
                <span>Integration</span><span>Mode</span><span>Effect in the app</span>
              </div>
              <ul className="divide-y divide-line">
                {list.map((i) => {
                  const Icon = ICONS[i.key] ?? Database;
                  const effect = EFFECT[i.key];
                  return (
                    <li key={i.key} className="grid grid-cols-1 gap-2 px-4 py-3 sm:grid-cols-[1.7fr_1fr_1.2fr] sm:items-start sm:gap-3">
                      <div className="flex items-start gap-2.5">
                        <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg ${i.configured ? "bg-success-soft text-success-dark" : "bg-[#F2F4F7] text-ink-muted"}`}>
                          <Icon className="h-4 w-4" />
                        </span>
                        <div>
                          <p className="text-[12.5px] font-semibold text-navy">{i.name}</p>
                          <p className="mt-0.5 text-[10.5px] leading-relaxed text-ink-muted">{i.description}</p>
                          <p className="mt-1 font-mono text-[9.5px] text-[#98A2B3]">{i.envKeys.join(" · ")}</p>
                        </div>
                      </div>
                      <div>
                        <Badge tone={i.configured ? "success" : i.mode === "optional" ? "muted" : "amber"} className="capitalize">
                          {i.configured ? "configured" : i.mode === "optional" ? "optional" : "demo"}
                        </Badge>
                      </div>
                      <p className="flex items-start gap-1 text-[11px] leading-relaxed text-ink-muted">
                        {!i.configured && <AlertTriangle className="mt-px h-3 w-3 shrink-0 text-amber-dark" />}
                        {i.configured ? effect?.live : effect?.off}
                      </p>
                    </li>
                  );
                })}
              </ul>
            </div>

            <div className="mt-5 grid gap-3 sm:grid-cols-3">
              <div className="rounded-xl border border-line bg-white p-4">
                <p className="text-[12.5px] font-semibold text-navy">{live.length} configured</p>
                <p className="mt-1 text-[11px] leading-relaxed text-ink-muted">Backed by credentials verified server-side on each request.</p>
              </div>
              <div className="rounded-xl border border-line bg-white p-4">
                <p className="text-[12.5px] font-semibold text-navy">{simulated.length} simulated</p>
                <p className="mt-1 text-[11px] leading-relaxed text-ink-muted">Labelled with DEMO or SAMPLE DATA wherever they surface.</p>
              </div>
              <div className="rounded-xl border border-line bg-white p-4">
                <p className="text-[12.5px] font-semibold text-navy">Data store</p>
                <p className="mt-1 text-[11px] leading-relaxed text-ink-muted">
                  SQLite for the prototype; the schema and repository layer target PostgreSQL/Supabase in deployment.
                </p>
              </div>
            </div>

            <p className="mt-5 text-[11px] leading-relaxed text-ink-muted">
              Need help? <Link href="/help" className="font-semibold text-indigo hover:underline">Help centre</Link> ·{" "}
              <Link href="/safety" className="font-semibold text-indigo hover:underline">Safety model</Link> ·{" "}
              <Link href="/legal/terms" className="font-semibold text-indigo hover:underline">Terms</Link>
            </p>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
