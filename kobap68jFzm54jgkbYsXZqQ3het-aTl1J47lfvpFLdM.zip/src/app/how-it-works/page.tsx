import Link from "next/link";
import {
  ArrowRight, BadgeCheck, Briefcase, Calculator, CarFront, Clock3, CreditCard, MapPin, PlaneLanding,
  Radar, Route, ShieldCheck, Users, Wallet,
} from "lucide-react";
import { SiteHeader } from "@/components/marketing/site-header";
import { SiteFooter } from "@/components/marketing/site-footer";
import { getSessionUser } from "@/lib/auth/session";
import { Badge, DemoBadge, SectionHeading } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";
import { STRATEGY_HELP, STRATEGY_LABELS } from "@/lib/config/pricing";

export const metadata = {
  title: "How FlightShare works",
  description: "From landing to drop-off: matching, verification, fare splitting, coordination and payment.",
};

const STEPS = [
  {
    n: "01",
    icon: PlaneLanding,
    title: "Tell us your flight",
    body: "Enter the flight number, arrival date and your destination. We normalise the input, validate the date against the schedule and only search groups on that exact arrival.",
    detail: ["Airline + number parsing (AI 864 → AI864)", "Date and airport validation", "Past or unknown flights are rejected with a clear reason"],
  },
  {
    n: "02",
    icon: Radar,
    title: "See scored matches",
    body: "Every group on your flight is scored 0–100 on flight, destination proximity, timing, capacity, route efficiency, trust and luggage. Hard blockers (full, wrong date, incompatible drop-off) are shown explicitly.",
    detail: ["Transparent components — no black box", "Destination threshold blocks absurd pairings", "Compatibility shown as a percentage"],
  },
  {
    n: "03",
    icon: BadgeCheck,
    title: "Verify before you join",
    body: "A booking reference from the airline is checked against a flight-data provider when one is configured. Until then the check is clearly simulated and labelled — we never claim access to airline manifests.",
    detail: ["Verified badge, or pending/manual review", "Booking references stored masked and hashed", "No document uploads required to browse"],
  },
  {
    n: "04",
    icon: Calculator,
    title: "See the exact split",
    body: "Vehicle fare, extra stops, tolls and parking, platform fee and tax — then your share under equal, distance-weighted or hybrid allocation. Integer paise, rounded to whole rupees, summing exactly.",
    detail: ["Every line itemised", "Savings versus a solo cab", "No charge for viewing or requesting"],
  },
  {
    n: "05",
    icon: Clock3,
    title: "Coordinate on the ground",
    body: "Baggage claim, meeting point, departure window and maximum wait are agreed before landing. Everyone confirms readiness in five explicit states — no guessing, no silent waiting.",
    detail: ["Not landed → Landed → Baggage → Ready → Boarding", "Group chat scoped to accepted passengers", "Auto-rematch rules when someone stalls"],
  },
  {
    n: "06",
    icon: Wallet,
    title: "Pay only when confirmed",
    body: "Payment is captured after the coordinator approves and the estimate is confirmed. Razorpay order creation, server-side signature verification, idempotent webhooks and refunds are implemented for when a merchant account exists.",
    detail: ["Browser success alone is never trusted", "Duplicate webhooks are deduplicated", "Refunds tracked through every status"],
  },
];

export default async function HowItWorksPage() {
  const user = await getSessionUser();
  return (
    <>
      <SiteHeader user={user ? { name: user.name, role: user.role } : null} />
      <main id="main">
        <section className="border-b border-line bg-white">
          <div className="container-x py-12 sm:py-16">
            <div className="max-w-2xl">
              <Badge tone="indigo" icon={<Route className="h-3 w-3" />}>The mechanism</Badge>
              <h1 className="mt-3 text-[32px] font-bold leading-[1.1] tracking-[-0.03em] text-navy sm:text-[44px]">
                Same flight in. Same direction out. One fair split.
              </h1>
              <p className="mt-4 text-[15px] leading-relaxed text-ink-muted">
                Airport queues punish spontaneity: everyone lands together, everyone hails a separate cab, everyone pays the full fare.
                FlightShare groups passengers who are already on the same aircraft and heading the same way — with the arithmetic, the
                verification and the waiting rules written down.
              </p>
              <div className="mt-6 flex flex-wrap gap-2.5">
                <LinkButton href="/search" size="lg" rightIcon={<ArrowRight className="h-4 w-4" />}>Find my ride</LinkButton>
                <LinkButton href="/rides?flight=AI864" size="lg" variant="outline">Browse a sample flight</LinkButton>
              </div>
            </div>

            <div className="mt-10 grid gap-3 sm:grid-cols-3">
              {[
                { icon: Users, k: "2–6", v: "passengers per vehicle", s: "sedan, SUV or MPV" },
                { icon: MapPin, k: "0.6", v: "destination threshold", s: "configurable per corridor" },
                { icon: Clock3, k: "45 min", v: "default kerb wait", s: "owner-adjustable, disclosed up front" },
              ].map((x) => (
                <div key={x.v} className="rounded-xl border border-line bg-[#FBFBFE] p-4">
                  <x.icon className="h-4 w-4 text-indigo" />
                  <p className="mt-2 text-[20px] font-bold tracking-tight text-navy tabular">{x.k}</p>
                  <p className="text-[12px] font-medium text-ink-soft">{x.v}</p>
                  <p className="mt-0.5 text-[10.5px] text-ink-muted">{x.s}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-12 sm:py-16">
          <div className="container-x">
            <SectionHeading eyebrow="Six steps" title="What actually happens" description="Each step has a defined owner and a visible state — nothing happens invisibly." />
            <div className="mt-7 space-y-3">
              {STEPS.map((s) => (
                <article key={s.n} className="card grid gap-4 p-5 sm:grid-cols-[auto_1fr_1.1fr] sm:items-start">
                  <div className="flex items-center gap-3 sm:block">
                    <span className="grid h-10 w-10 place-items-center rounded-xl bg-[#F4F3FF] text-indigo"><s.icon className="h-5 w-5" /></span>
                    <span className="ml-2 text-[11px] font-bold tracking-wider text-ink-muted sm:ml-0 sm:mt-2 sm:block">{s.n}</span>
                  </div>
                  <div>
                    <h2 className="text-[16px] font-bold text-navy">{s.title}</h2>
                    <p className="mt-1.5 text-[12.5px] leading-relaxed text-ink-muted">{s.body}</p>
                  </div>
                  <ul className="space-y-1.5 rounded-xl bg-[#F9FAFD] px-3.5 py-3">
                    {s.detail.map((d) => (
                      <li key={d} className="flex items-start gap-1.5 text-[11.5px] text-ink-soft">
                        <ShieldCheck className="mt-px h-3.5 w-3.5 shrink-0 text-success" /> {d}
                      </li>
                    ))}
                  </ul>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="border-y border-line bg-white py-12">
          <div className="container-x grid gap-8 lg:grid-cols-2">
            <div>
              <SectionHeading eyebrow="Fare allocation" title="Three ways to split a shared cab" />
              <div className="mt-5 space-y-2.5">
                {(["equal", "distance", "hybrid"] as const).map((k) => (
                  <div key={k} className="rounded-xl border border-line p-3.5">
                    <p className="flex items-center gap-2 text-[13px] font-semibold text-navy">
                      <Calculator className="h-4 w-4 text-indigo" /> {STRATEGY_LABELS[k]}
                    </p>
                    <p className="mt-1 text-[12px] leading-relaxed text-ink-muted">{STRATEGY_HELP[k]}</p>
                  </div>
                ))}
              </div>
              <p className="mt-3 rounded-xl bg-[#F9FAFD] px-3.5 py-2.5 text-[11px] leading-relaxed text-ink-muted">
                Worked example: an AI864 sedan to Thane with a Mulund stop costs ₹1,144 in total. Solo that trip is ₹3,280 across three
                separate cabs. Split three ways the shares are ₹392, ₹392 and ₹360 — the shorter Mulund leg pays less under the hybrid rule.
                <span className="ml-1 font-semibold text-ink-soft">Example figures, not a quote.</span>
              </p>
            </div>
            <div>
              <SectionHeading eyebrow="Coordination" title="Waiting without guessing" />
              <ol className="mt-5 space-y-2">
                {[
                  ["Not landed", "Flight is still airborne or taxiing."],
                  ["Landed", "Aircraft on stand; doors opening."],
                  ["Collecting baggage", "At the belt; bag count known."],
                  ["Ready at meeting point", "Physically at the agreed pillar."],
                  ["Boarding vehicle", "Walking out with the driver confirmed."],
                  ["Trip started", "Odometer running; group chat stays open."],
                ].map(([t, d], i) => (
                  <li key={t} className="flex gap-3">
                    <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[#F4F3FF] text-[10px] font-bold text-indigo tabular">{i + 1}</span>
                    <div>
                      <p className="text-[12.5px] font-semibold text-navy">{t}</p>
                      <p className="text-[11px] text-ink-muted">{d}</p>
                    </div>
                  </li>
                ))}
              </ol>
              <div className="mt-4 flex items-start gap-2 rounded-xl border border-amber-100 bg-amber-soft px-3.5 py-2.5 text-[11px] leading-relaxed text-amber-dark">
                <Briefcase className="mt-px h-3.5 w-3.5 shrink-0" />
                We never auto-book or auto-dispatch on landing. The group coordinator confirms counts, and a driver accepts separately — until
                then the ride is an intention, not a confirmed transport contract.
              </div>
            </div>
          </div>
        </section>

        <section className="py-12">
          <div className="container-x flex flex-col items-center gap-4 rounded-2xl border border-line bg-white px-6 py-10 text-center">
            <CarFront className="h-6 w-6 text-indigo" />
            <h2 className="max-w-xl text-[24px] font-bold leading-tight tracking-[-0.02em] text-navy">Try the flow with sample data</h2>
            <p className="max-w-lg text-[13px] leading-relaxed text-ink-muted">
              The demo is fully clickable: search, score, request, approve, split the fare and coordinate. Every flight, passenger and payment
              is labelled as sample data.
            </p>
            <div className="flex flex-wrap justify-center gap-2.5">
              <LinkButton href="/search" size="lg">Find my ride</LinkButton>
              <LinkButton href="/signup" size="lg" variant="outline">Create an account</LinkButton>
            </div>
            <p className="flex items-center gap-1.5 text-[10.5px] text-ink-muted">
              <CreditCard className="h-3 w-3" /> No card details are collected in demo mode. <DemoBadge label="PROTOTYPE" />
            </p>
            <p className="text-[10.5px] text-ink-muted">
              Questions about coverage? <Link href="/help" className="font-semibold text-indigo hover:underline">Read the help centre</Link> or{" "}
              <Link href="/safety" className="font-semibold text-indigo hover:underline">safety model</Link>.
            </p>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
