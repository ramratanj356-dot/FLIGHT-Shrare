import Link from "next/link";
import { ArrowRight, Building2, CarFront, CheckCircle2, Handshake, Plane, Receipt, ShieldCheck, Users } from "lucide-react";
import { SiteHeader } from "@/components/marketing/site-header";
import { SiteFooter } from "@/components/marketing/site-footer";
import { getSessionUser } from "@/lib/auth/session";
import { Badge, DemoBadge, SectionHeading } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";
import { DriverSignupForm } from "@/components/forms/driver-signup-form";

export const metadata = {
  title: "For drivers & fleet partners",
  description: "Airport transfers with known passenger counts, luggage and drop-off order.",
};

export default async function PartnersPage() {
  const user = await getSessionUser();
  return (
    <>
      <SiteHeader user={user ? { name: user.name, role: user.role } : null} />
      <main id="main">
        <section className="border-b border-line bg-white">
          <div className="container-x grid gap-10 py-12 lg:grid-cols-[1.05fr_0.95fr] lg:items-start sm:py-14">
            <div>
              <Badge tone="indigo" icon={<Handshake className="h-3 w-3" />}>Fleet partners</Badge>
              <h1 className="mt-3 text-[32px] font-bold leading-[1.1] tracking-[-0.03em] text-navy sm:text-[42px]">
                Fewer trips. Full vehicles. Known destinations.
              </h1>
              <p className="mt-3.5 max-w-lg text-[14.5px] leading-relaxed text-ink-muted">
                Airport runs are the worst kind of dispatch: unknown baggage, unknown waiting time, one passenger paying for a whole car.
                FlightShare hands you a group that has already agreed its drop-off order and waiting window.
              </p>

              <ul className="mt-6 grid gap-2.5 sm:grid-cols-2">
                {[
                  { icon: Users, t: "Known passenger count", d: "Seats and luggage confirmed before you accept." },
                  { icon: Plane, t: "Flight-linked pickups", d: "Arrival time and terminal attached to every job." },
                  { icon: CarFront, t: "Drop-off order", d: "Primary destination plus extra stops, in sequence." },
                  { icon: Receipt, t: "Transparent settlement", d: "Gross, commission, deductions and net in one ledger." },
                ].map((x) => (
                  <li key={x.t} className="rounded-xl border border-line p-3.5">
                    <x.icon className="h-4 w-4 text-indigo" />
                    <p className="mt-1.5 text-[12.5px] font-semibold text-navy">{x.t}</p>
                    <p className="mt-0.5 text-[11px] leading-relaxed text-ink-muted">{x.d}</p>
                  </li>
                ))}
              </ul>

              <div className="mt-6 rounded-xl border border-line bg-[#FBFBFE] p-4">
                <p className="text-[11px] font-bold uppercase tracking-wide text-ink-muted">What we do not claim</p>
                <ul className="mt-2 space-y-1.5 text-[11.5px] leading-relaxed text-ink-soft">
                  {[
                    "No guaranteed trip volume — this is a demand aggregation product, not a corporate contract.",
                    "No live settlement until a gateway with merchant approval is configured.",
                    "Approval here is a document review, not a statutory permit or background check.",
                  ].map((t) => (
                    <li key={t} className="flex items-start gap-1.5"><ShieldCheck className="mt-px h-3.5 w-3.5 shrink-0 text-amber-dark" />{t}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="lg:sticky lg:top-24">
              <DriverSignupForm signedIn={Boolean(user)} />
            </div>
          </div>
        </section>

        <section className="py-12">
          <div className="container-x">
            <SectionHeading
              eyebrow="Three partner tracks"
              title="Where FlightShare fits commercially"
              description="Each track is modelled in the prototype; contractual pilots would start with a single airport corridor."
            />
            <div className="mt-6 grid gap-3 md:grid-cols-3">
              {[
                { icon: CarFront, t: "Independent drivers", d: "Own a sedan or SUV and want airport work without cruising the app. Verification review, then accept trips.", tag: "Commission per completed ride" },
                { icon: Building2, t: "Fleet operators", d: "Multiple vehicles and drivers. Assign a fleet manager, upload vehicles, receive grouped demand.", tag: "Fleet dashboards — roadmap" },
                { icon: Plane, t: "Airport & corporate", d: "Hotel and corporate travel desks can pre-announce arrivals so groups form before the aircraft lands.", tag: "Pilot programme" },
              ].map((p) => (
                <article key={p.t} className="card p-5">
                  <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#F4F3FF] text-indigo"><p.icon className="h-4.5 w-4.5" /></span>
                  <h3 className="mt-3 text-[14px] font-bold text-navy">{p.t}</h3>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-ink-muted">{p.d}</p>
                  <p className="mt-3 inline-flex items-center gap-1 rounded-lg bg-[#F9FAFD] px-2 py-1 text-[10px] font-medium text-ink-soft">{p.tag}</p>
                </article>
              ))}
            </div>

            <div className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-white px-5 py-4">
              <div>
                <p className="text-[13px] font-semibold text-navy">Already registered as a driver?</p>
                <p className="text-[11.5px] text-ink-muted">Sign in to see eligible requests and your settlement ledger.</p>
              </div>
              <div className="flex gap-2">
                <LinkButton href="/driver" size="md" rightIcon={<ArrowRight className="h-4 w-4" />}>Open driver portal</LinkButton>
                <LinkButton href="/login" size="md" variant="outline">Sign in</LinkButton>
              </div>
            </div>

            <p className="mt-4 text-[10.5px] leading-relaxed text-ink-muted">
              Commercial passenger transport in India requires permits, fitness certificates and insurance. FlightShare does not issue permits and
              does not verify statutory compliance. Fleet partners are responsible for their own regulatory standing.{" "}
              <Link href="/safety" className="font-semibold text-indigo hover:underline">Read the safety model</Link>.
            </p>
            <p className="mt-1 flex items-center gap-1.5 text-[10.5px] text-ink-muted">
              <CheckCircle2 className="h-3 w-3 text-success" /> Applications are stored as pending review — no applicant becomes verified automatically. <DemoBadge label="DEMO" />
            </p>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
