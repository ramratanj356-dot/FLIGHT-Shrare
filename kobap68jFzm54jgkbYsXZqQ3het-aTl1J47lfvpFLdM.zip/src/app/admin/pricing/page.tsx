import { Info } from "lucide-react";
import { requireRole } from "@/lib/auth/guards";
import { getPricingRules, listPricingRuleRows } from "@/lib/db/queries";
import { PageHeading } from "@/components/app/app-shell";
import { PricingForm } from "@/components/app/admin-actions";
import { Badge, Alert, DemoBadge } from "@/components/ui/primitives";
import { formatDateTime } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "Pricing configuration" };

export default async function AdminPricingPage() {
  const user = await requireRole(["admin", "support"], "/admin/pricing");
  const rules = getPricingRules();
  const rows = listPricingRuleRows();

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeading
        badge={<><Badge tone="navy">Admin</Badge><DemoBadge label="APPLIES LIVE" /></>}
        title="Pricing & commission"
        description="The fare engine reads these values for every new estimate. Existing estimates and bookings are never rewritten retroactively."
      />

      {user.role !== "admin" ? (
        <Alert tone="warning" title="Read-only for support accounts">Only administrators can change pricing. Values below are current.</Alert>
      ) : (
        <div className="mb-4">
          <Alert tone="info" title="Every change is audited">
            Updates are written to <code className="rounded bg-white px-1 py-0.5 text-[10.5px]">audit_logs</code> with your account, the before
            and after values, and a timestamp.
          </Alert>
        </div>
      )}

      {user.role === "admin" ? (
        <PricingForm
          initial={{
            baseFareRupees: rules.baseFarePaise / 100,
            perKmRupees: rules.perKmPaise / 100,
            extraStopRupees: rules.extraStopPaise / 100,
            platformFeePct: rules.platformFeeBps / 100,
            platformFeeMinRupees: rules.platformFeeMinPaise / 100,
            taxPct: rules.platformFeeTaxBps / 100,
            maxWaitMinutes: rules.maxWaitMinutes,
            destinationThreshold: rules.destinationThreshold,
          }}
        />
      ) : null}

      <section className="card mt-5 overflow-hidden">
        <div className="border-b border-line px-4 py-3">
          <p className="text-[13px] font-semibold text-navy">Stored rule values</p>
          <p className="text-[10.5px] text-ink-muted">Raw table contents — the engine falls back to safe defaults if a key is missing.</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[600px] text-left">
            <thead className="border-b border-line bg-[#FBFBFE] text-[10.5px] uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="px-4 py-2 font-semibold">Key</th>
                <th className="px-4 py-2 font-semibold">Value</th>
                <th className="px-4 py-2 font-semibold">Meaning</th>
                <th className="px-4 py-2 font-semibold">Updated</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line text-[11.5px]">
              {rows.map((r) => (
                <tr key={r.key}>
                  <td className="px-4 py-2 font-mono text-[10.5px] text-ink-soft">{r.key}</td>
                  <td className="px-4 py-2 font-semibold text-navy tabular">{r.value_json}</td>
                  <td className="px-4 py-2 text-ink-muted">{r.description}</td>
                  <td className="px-4 py-2 text-ink-muted">{formatDateTime(r.updated_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <p className="mt-4 flex items-start gap-1.5 text-[10.5px] leading-relaxed text-ink-muted">
        <Info className="mt-px h-3.5 w-3.5 shrink-0" />
        All money is stored in integer paise. Fare totals are rounded to whole rupees so passenger shares add up exactly, and the
        remainder distribution is disclosed on every breakdown.
      </p>
    </div>
  );
}
