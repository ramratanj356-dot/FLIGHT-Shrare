import Link from "next/link";
import {
  AlertTriangle, ArrowRight, BadgeCheck, Banknote, CalendarCheck, Car, ChevronRight, Flag,
  Percent, ShieldCheck, Ticket, TrendingDown, Users, Wallet,
} from "lucide-react";
import { requireRole } from "@/lib/auth/guards";
import { getAdminMetrics, listReports, listSupportTickets, listRefunds } from "@/lib/db/queries";
import { PageHeading } from "@/components/app/app-shell";
import { Badge, DemoBadge, Alert } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";
import { formatPaise } from "@/lib/money";
import { formatDateShort } from "@/lib/utils";
import { SUPPORT_ACCOUNT_HINT } from "@/lib/admin-hints";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin overview" };

export default async function AdminHomePage() {
  const user = await requireRole(["admin", "support"], "/admin");
  const m = getAdminMetrics();
  const reports = listReports();
  const tickets = listSupportTickets();
  const refunds = listRefunds();
  const maxRides = Math.max(1, ...m.byDay.map((d) => d.rides));

  return (
    <div>
      <PageHeading
        badge={<><Badge tone="navy">Admin</Badge><DemoBadge label="DEMO METRICS" /><Badge tone="muted" className="capitalize">{user.role}</Badge></>}
        title="Platform overview"
        description="Real records from this prototype database. In production these metrics read from live Postgres with row-level security."
        actions={<LinkButton href="/admin/verifications" size="md" leftIcon={<ShieldCheck className="h-4 w-4" />}>Review queue</LinkButton>}
      />

      {user.role === "support" && (
        <div className="mb-4"><Alert tone="info" title="Support role">{SUPPORT_ACCOUNT_HINT}</Alert></div>
      )}

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Registered users", value: String(m.totalUsers), sub: "active accounts", icon: Users },
          { label: "Active ride groups", value: String(m.activeGroups), sub: "open, full or confirmed", icon: Car },
          { label: "Completed rides", value: String(m.completed), sub: "in this dataset", icon: CheckIcon },
          { label: "Avg passengers / ride", value: String(m.avgPassengersPerRide), sub: "completed rides", icon: Users },
          { label: "Est. passenger savings", value: formatPaise(m.estimatedPassengerSavings), sub: "across all estimates", icon: TrendingDown },
          { label: "Platform revenue", value: formatPaise(m.platformRevenue), sub: "fees + tax on fees", icon: Percent },
          { label: "Driver earnings", value: formatPaise(m.driverEarnings), sub: "settled to drivers", icon: Wallet },
          { label: "Cancellation rate", value: `${m.cancellationRate}%`, sub: "of bookings", icon: AlertTriangle },
        ].map((s) => (
          <div key={s.label} className="card p-4">
            <div className="flex items-start justify-between">
              <p className="text-[11px] font-medium text-ink-muted">{s.label}</p>
              <span className="grid h-7 w-7 place-items-center rounded-lg bg-[#F4F7FF] text-indigo"><s.icon className="h-3.5 w-3.5" /></span>
            </div>
            <p className="mt-1.5 text-[20px] font-bold leading-none tracking-tight text-navy tabular">{s.value}</p>
            <p className="mt-1 text-[10px] text-ink-muted">{s.sub}</p>
          </div>
        ))}
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-[1.35fr_1fr]">
        <div className="card p-4">
          <div className="flex items-center justify-between">
            <p className="text-[13px] font-semibold text-navy">Rides by day</p>
            <DemoBadge label="SEEDED + LIVE" />
          </div>
          <div className="mt-4 flex h-40 items-end gap-2">
            {m.byDay.map((d) => (
              <div key={d.date} className="flex flex-1 flex-col items-center gap-1.5">
                <div className="flex w-full flex-col justify-end" style={{ height: 120 }}>
                  <div className="w-full rounded-t-md bg-gradient-to-t from-indigo to-[#8C82FF]" style={{ height: `${Math.max(6, (d.rides / maxRides) * 100)}%` }} title={`${d.rides} rides`} />
                </div>
                <span className="text-[9px] font-medium text-ink-muted">{formatDateShort(d.date)}</span>
                <span className="text-[9px] text-[#98A2B3] tabular">{d.rides}</span>
              </div>
            ))}
            {m.byDay.length === 0 && <p className="text-[12px] text-ink-muted">No ride activity in the window.</p>}
          </div>
          <p className="mt-2 text-[10px] text-ink-muted">Groups created per arrival date, including demo seeds. Not a revenue chart.</p>
        </div>

        <div className="space-y-3">
          {[
            { href: "/admin/verifications", label: "Passenger flight verifications", count: m.pendingVerifications, icon: BadgeCheck, tone: "amber" },
            { href: "/admin/verifications#drivers", label: "Driver verification reviews", count: m.pendingDriverReviews, icon: Car, tone: "amber" },
            { href: "/admin/support#reports", label: "Open safety reports", count: m.openReports, icon: Flag, tone: "danger" },
            { href: "/admin/support#refunds", label: "Refunds awaiting review", count: m.pendingRefunds, icon: Banknote, tone: "indigo" },
            { href: "/admin/support#tickets", label: "Support tickets", count: tickets.filter((t) => t.status !== "resolved" && t.status !== "closed").length, icon: Ticket, tone: "muted" },
          ].map((q) => (
            <Link key={q.href} href={q.href} className="flex items-center justify-between rounded-xl border border-line bg-white px-3.5 py-3 transition hover:border-indigo-200 hover:shadow-card">
              <span className="flex items-center gap-2.5">
                <span className={`grid h-8 w-8 place-items-center rounded-lg ${q.tone === "amber" ? "bg-amber-soft text-amber-dark" : q.tone === "danger" ? "bg-danger-soft text-danger" : q.tone === "indigo" ? "bg-[#F4F3FF] text-indigo" : "bg-[#F2F4F7] text-ink-muted"}`}>
                  <q.icon className="h-4 w-4" />
                </span>
                <span className="text-[12.5px] font-medium text-navy">{q.label}</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="rounded-full bg-[#F2F4F7] px-2 py-0.5 text-[10.5px] font-bold text-ink-soft tabular">{q.count}</span>
                <ChevronRight className="h-3.5 w-3.5 text-ink-muted" />
              </span>
            </Link>
          ))}
        </div>
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <div className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <p className="text-[13px] font-semibold text-navy">Recent reports</p>
            <Link href="/admin/support#reports" className="text-[11px] font-medium text-indigo hover:underline">Manage</Link>
          </div>
          <ul className="divide-y divide-line">
            {reports.slice(0, 4).map((r) => (
              <li key={r.id} className="px-4 py-2.5">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-[12px] font-medium capitalize text-navy">{String(r.category).replace(/_/g, " ")}</p>
                  <Badge tone={r.status === "open" ? "danger" : r.status === "resolved" ? "success" : "muted"}>{r.status}</Badge>
                </div>
                <p className="mt-0.5 line-clamp-1 text-[11px] text-ink-muted">{r.details}</p>
              </li>
            ))}
            {reports.length === 0 && <li className="px-4 py-6 text-center text-[11.5px] text-ink-muted">No reports filed.</li>}
          </ul>
        </div>

        <div className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <p className="text-[13px] font-semibold text-navy">Refunds pending</p>
            <Link href="/admin/support#refunds" className="text-[11px] font-medium text-indigo hover:underline">Review</Link>
          </div>
          <ul className="divide-y divide-line">
            {refunds.slice(0, 4).map((r) => (
              <li key={r.id} className="flex items-center justify-between gap-2 px-4 py-2.5">
                <div className="min-w-0">
                  <p className="truncate text-[12px] font-medium text-navy">{r.booking_code} · {r.requester_name ?? "system"}</p>
                  <p className="truncate text-[10.5px] text-ink-muted">{r.reason}</p>
                </div>
                <div className="shrink-0 text-right">
                  <p className="text-[12px] font-bold text-navy tabular">{formatPaise(r.amount_paise)}</p>
                  <Badge tone={r.status === "pending" ? "amber" : "success"}>{r.status}</Badge>
                </div>
              </li>
            ))}
            {refunds.length === 0 && <li className="px-4 py-6 text-center text-[11.5px] text-ink-muted">No refunds requested.</li>}
          </ul>
        </div>
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        {[
          { href: "/admin/pricing", title: "Pricing rules", body: "Base, per-km, fees, tax and matching thresholds — applied live.", icon: Percent },
          { href: "/admin/users", title: "User management", body: "Roles, suspension and account status.", icon: Users },
          { href: "/admin/audit", title: "Audit log", body: "Every privileged action, who did it and when.", icon: CalendarCheck },
        ].map((c) => (
          <Link key={c.href} href={c.href} className="card group flex items-start gap-3 p-4 transition hover:shadow-lift">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-[#F4F3FF] text-indigo"><c.icon className="h-4 w-4" /></span>
            <div>
              <p className="flex items-center gap-1 text-[12.5px] font-semibold text-navy">{c.title}<ArrowRight className="h-3 w-3 opacity-0 transition group-hover:opacity-100" /></p>
              <p className="mt-0.5 text-[10.5px] leading-relaxed text-ink-muted">{c.body}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

function CheckIcon({ className }: { className?: string }) {
  return <CalendarCheck className={className} />;
}
