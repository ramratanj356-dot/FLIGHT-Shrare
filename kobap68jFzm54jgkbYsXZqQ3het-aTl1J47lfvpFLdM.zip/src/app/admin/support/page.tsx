import { Banknote, Flag, Ticket } from "lucide-react";
import { requireRole } from "@/lib/auth/guards";
import { listReports, listRefunds, listSupportTickets } from "@/lib/db/queries";
import { PageHeading } from "@/components/app/app-shell";
import { Badge, EmptyState, DemoBadge } from "@/components/ui/primitives";
import { RefundDecision, ReportResolution, TicketStatusControl } from "@/components/app/admin-actions";
import { formatDateTime } from "@/lib/utils";
import { formatPaise } from "@/lib/money";

export const dynamic = "force-dynamic";
export const metadata = { title: "Support & disputes" };

export default async function AdminSupportPage() {
  const user = await requireRole(["admin", "support"], "/admin/support");
  const reports = listReports();
  const refunds = listRefunds();
  const tickets = listSupportTickets();
  const canRefund = user.role === "admin";

  return (
    <div>
      <PageHeading
        badge={<><Badge tone="navy">Admin</Badge><DemoBadge label="DEMO QUEUES" /></>}
        title="Support, disputes & refunds"
        description="Safety reports, refund reviews and passenger tickets. Refund actions are restricted to administrators."
      />

      <section id="reports" className="card overflow-hidden">
        <div className="flex items-center gap-2 border-b border-line px-4 py-3">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-danger-soft text-danger"><Flag className="h-4 w-4" /></span>
          <div>
            <p className="text-[13px] font-semibold text-navy">Safety & conduct reports</p>
            <p className="text-[10.5px] text-ink-muted">Reporters are never identified to the subject</p>
          </div>
        </div>
        {reports.length === 0 ? (
          <EmptyState className="m-4" icon={<Flag className="h-5 w-5" />} title="No reports" description="Reports filed from ride chat or the help centre appear here for triage." />
        ) : (
          <ul className="divide-y divide-line">
            {reports.map((r) => (
              <li key={r.id} className="flex flex-col justify-between gap-2 px-4 py-3 sm:flex-row sm:items-start">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Badge tone={r.priority === "high" || r.priority === "urgent" ? "danger" : "muted"} className="capitalize">{String(r.category).replace(/_/g, " ")}</Badge>
                    <Badge tone={r.status === "open" ? "amber" : r.status === "resolved" ? "success" : "muted"} className="capitalize">{r.status}</Badge>
                    <span className="text-[10px] text-ink-muted">{formatDateTime(r.created_at)}</span>
                  </div>
                  <p className="mt-1 text-[12px] leading-relaxed text-ink-soft">{r.details}</p>
                  <p className="mt-0.5 text-[10px] text-ink-muted">Reporter {r.reporter_name}{r.subject_name ? ` · about ${r.subject_name}` : ""}</p>
                </div>
                <div className="shrink-0"><ReportResolution reportId={r.id} status={r.status} /></div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section id="refunds" className="card mt-5 overflow-hidden">
        <div className="flex items-center justify-between border-b border-line px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-[#F4F3FF] text-indigo"><Banknote className="h-4 w-4" /></span>
            <div>
              <p className="text-[13px] font-semibold text-navy">Refund reviews</p>
              <p className="text-[10.5px] text-ink-muted">Approval updates payment + booking atomically</p>
            </div>
          </div>
          {!canRefund && <Badge tone="muted">Admin only</Badge>}
        </div>
        {refunds.length === 0 ? (
          <p className="px-4 py-6 text-center text-[11.5px] text-ink-muted">No refunds requested.</p>
        ) : (
          <ul className="divide-y divide-line">
            {refunds.map((r) => (
              <li key={r.id} className="flex flex-col justify-between gap-2 px-4 py-3 sm:flex-row sm:items-center">
                <div className="min-w-0">
                  <p className="text-[12px] font-medium text-navy">{r.booking_code} · {formatPaise(r.amount_paise)}</p>
                  <p className="truncate text-[11px] text-ink-muted">{r.reason}</p>
                  <p className="text-[10px] text-ink-muted">Requested by {r.requester_name ?? "system"} · {r.provider} · {formatDateTime(r.created_at)}</p>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <Badge tone={r.status === "pending" ? "amber" : r.status === "processed" ? "success" : "muted"} className="capitalize">{r.status}</Badge>
                  {r.status === "pending" && canRefund && <RefundDecision refundId={r.id} />}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section id="tickets" className="card mt-5 overflow-hidden">
        <div className="flex items-center gap-2 border-b border-line px-4 py-3">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-[#F2F4F7] text-ink-soft"><Ticket className="h-4 w-4" /></span>
          <div>
            <p className="text-[13px] font-semibold text-navy">Support tickets</p>
            <p className="text-[10.5px] text-ink-muted">Filed from the help centre</p>
          </div>
        </div>
        {tickets.length === 0 ? (
          <p className="px-4 py-6 text-center text-[11.5px] text-ink-muted">No tickets open.</p>
        ) : (
          <ul className="divide-y divide-line">
            {tickets.map((t) => (
              <li key={t.id} className="flex flex-col justify-between gap-2 px-4 py-3 sm:flex-row sm:items-start">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Badge tone={t.priority === "high" ? "danger" : "muted"} className="capitalize">{t.category}</Badge>
                    <Badge tone={t.status === "open" ? "amber" : t.status === "resolved" || t.status === "closed" ? "success" : "indigo"} className="capitalize">{String(t.status).replace(/_/g, " ")}</Badge>
                    <span className="text-[10px] text-ink-muted">{formatDateTime(t.created_at)}</span>
                  </div>
                  <p className="mt-1 text-[12px] font-medium text-navy">{t.subject}</p>
                  <p className="mt-0.5 line-clamp-2 text-[11px] leading-relaxed text-ink-muted">{t.body}</p>
                  <p className="mt-0.5 text-[10px] text-ink-muted">From {t.user_name} · {t.user_email}</p>
                </div>
                <div className="shrink-0"><TicketStatusControl ticketId={t.id} status={t.status} /></div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
