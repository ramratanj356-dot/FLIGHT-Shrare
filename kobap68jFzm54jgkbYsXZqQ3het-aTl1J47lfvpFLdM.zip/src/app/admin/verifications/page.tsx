import { BadgeCheck, Car, IdCard, ShieldCheck } from "lucide-react";
import { requireRole } from "@/lib/auth/guards";
import { listDriverVerificationQueue, listFlightVerificationQueue } from "@/lib/db/queries";
import { PageHeading } from "@/components/app/app-shell";
import { Avatar, Badge, EmptyState, DemoBadge } from "@/components/ui/primitives";
import { VerificationDecision } from "@/components/app/admin-actions";
import { formatDateTime } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "Verification reviews" };

export default async function AdminVerificationsPage() {
  const user = await requireRole(["admin", "support"], "/admin/verifications");
  const flights = listFlightVerificationQueue();
  const drivers = listDriverVerificationQueue();
  const canDecide = user.role === "admin";

  return (
    <div>
      <PageHeading
        badge={<><DemoBadge label="SIMULATED VERIFICATION" /><Badge tone="muted">{canDecide ? "Admin permissions" : "Read-only (support)"}</Badge></>}
        title="Verification reviews"
        description="Flight verifications and driver document reviews. In demo mode flight checks are simulated; no airline or government system is contacted."
      />

      <section className="card overflow-hidden">
        <div className="flex items-center justify-between border-b border-line px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-[#F4F3FF] text-indigo"><BadgeCheck className="h-4 w-4" /></span>
            <div>
              <p className="text-[13px] font-semibold text-navy">Passenger flight verifications</p>
              <p className="text-[10.5px] text-ink-muted">Booking references are stored masked and hashed</p>
            </div>
          </div>
          <Badge tone="amber">{flights.filter((f) => f.status === "pending").length} pending</Badge>
        </div>

        {flights.length === 0 ? (
          <EmptyState className="m-4" icon={<ShieldCheck className="h-5 w-5" />} title="Nothing in the queue" description="Passenger flight verifications appear here when someone submits a booking reference." />
        ) : (
          <ul className="divide-y divide-line">
            {flights.map((f) => (
              <li key={f.id} className="flex flex-col justify-between gap-3 px-4 py-3 sm:flex-row sm:items-center">
                <div className="flex min-w-0 items-center gap-2.5">
                  <Avatar name={f.name} size="sm" />
                  <div className="min-w-0">
                    <p className="truncate text-[12.5px] font-semibold text-navy">{f.name}</p>
                    <p className="truncate text-[10.5px] text-ink-muted">
                      {f.flight_number} · {f.flight_date} · ref {f.reference_masked ?? "—"} · {f.provider}
                    </p>
                    <p className="text-[9.5px] text-[#98A2B3]">submitted {formatDateTime(f.created_at)}</p>
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <Badge tone={f.status === "verified" ? "success" : f.status === "pending" ? "amber" : f.status === "rejected" ? "danger" : "muted"} className="capitalize">{f.status}</Badge>
                  {f.status === "pending" && canDecide && <VerificationDecision kind="flight" id={f.id} />}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section id="drivers" className="card mt-5 overflow-hidden">
        <div className="flex items-center justify-between border-b border-line px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-amber-soft text-amber-dark"><Car className="h-4 w-4" /></span>
            <div>
              <p className="text-[13px] font-semibold text-navy">Driver &amp; vehicle reviews</p>
              <p className="text-[10.5px] text-ink-muted">Approving enables the driver to accept trips</p>
            </div>
          </div>
          <Badge tone="amber">{drivers.filter((d) => ["pending", "in_review"].includes(d.verification_status)).length} waiting</Badge>
        </div>

        <ul className="divide-y divide-line">
          {drivers.map((d) => (
            <li key={d.id} className="flex flex-col justify-between gap-3 px-4 py-3 sm:flex-row sm:items-center">
              <div className="flex min-w-0 items-start gap-2.5">
                <Avatar name={d.name} size="sm" verified={d.verification_status === "verified"} />
                <div className="min-w-0">
                  <p className="truncate text-[12.5px] font-semibold text-navy">{d.name}</p>
                  <p className="truncate text-[10.5px] text-ink-muted">
                    <IdCard className="mr-1 inline h-3 w-3" />
                    {d.license_number ? `Licence ••••${String(d.license_number).slice(-3)}` : "No licence on file"} · {d.company_name ?? "Independent"}
                  </p>
                  <p className="truncate text-[10.5px] text-ink-muted">
                    {d.make_model ?? "No vehicle"} {d.registration_number ? `· ${d.registration_number}` : ""} {d.category ? `· ${d.category}` : ""}
                  </p>
                </div>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <Badge tone={d.verification_status === "verified" ? "success" : d.verification_status === "rejected" ? "danger" : "amber"} className="capitalize">
                  {String(d.verification_status).replace(/_/g, " ")}
                </Badge>
                {["pending", "in_review"].includes(d.verification_status) && canDecide && <VerificationDecision kind="driver" id={d.id} />}
              </div>
            </li>
          ))}
          {drivers.length === 0 && <li className="px-4 py-8 text-center text-[12px] text-ink-muted">No driver profiles.</li>}
        </ul>
      </section>
    </div>
  );
}
