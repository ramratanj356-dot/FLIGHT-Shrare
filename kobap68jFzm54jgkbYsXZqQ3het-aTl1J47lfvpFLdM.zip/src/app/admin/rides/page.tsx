import Link from "next/link";
import { ArrowRight, Car, Users } from "lucide-react";
import { requireRole } from "@/lib/auth/guards";
import { listAdminRides } from "@/lib/db/queries";
import { PageHeading } from "@/components/app/app-shell";
import { Badge, DemoBadge } from "@/components/ui/primitives";
import { formatDateShort, formatTime } from "@/lib/utils";
import { formatPaise } from "@/lib/money";

export const dynamic = "force-dynamic";
export const metadata = { title: "Ride groups" };

const TONE: Record<string, "success" | "indigo" | "amber" | "muted" | "danger"> = {
  open: "indigo", full: "amber", confirmed: "success", in_progress: "success", completed: "muted", cancelled: "danger",
};

export default async function AdminRidesPage() {
  await requireRole(["admin", "support"], "/admin/rides");
  const rides = listAdminRides(60);

  return (
    <div>
      <PageHeading
        badge={<><Badge tone="navy">Admin</Badge><DemoBadge label="LIVE DEMO RECORDS" /></>}
        title="Ride groups"
        description="Every group across flights and dates, newest activity first. Capacity is enforced by database constraints and atomic seat claims."
      />

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px] text-left">
            <thead className="border-b border-line bg-[#FBFBFE] text-[10.5px] uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="px-4 py-2.5 font-semibold">Group</th>
                <th className="px-4 py-2.5 font-semibold">Flight</th>
                <th className="px-4 py-2.5 font-semibold">Destination</th>
                <th className="px-4 py-2.5 font-semibold">Seats</th>
                <th className="px-4 py-2.5 text-right font-semibold">Group fare</th>
                <th className="px-4 py-2.5 font-semibold">Driver</th>
                <th className="px-4 py-2.5 font-semibold">Status</th>
                <th className="px-4 py-2.5" />
              </tr>
            </thead>
            <tbody className="divide-y divide-line text-[12px]">
              {rides.map((r) => (
                <tr key={r.id} className="hover:bg-[#FBFBFE]">
                  <td className="px-4 py-2.5">
                    <span className="font-medium text-navy">{r.code}</span>
                    {r.isDemo && <DemoBadge label="DEMO" className="ml-1.5" />}
                  </td>
                  <td className="px-4 py-2.5 text-ink-muted">
                    {r.flight.flight_number}<br />
                    <span className="text-[10px]">{formatDateShort(r.flight.flight_date)} · {formatTime(r.flight.estimated_arrival)}</span>
                  </td>
                  <td className="px-4 py-2.5 text-ink-muted">
                    {r.destination.name}
                    {r.extraDestinations.length > 0 && <span className="text-[10px]"> +{r.extraDestinations.length}</span>}
                  </td>
                  <td className="px-4 py-2.5 text-ink-muted">
                    <Users className="mr-1 inline h-3 w-3" />{r.seatsTaken}/{r.seatsTotal}
                  </td>
                  <td className="px-4 py-2.5 text-right font-medium text-navy tabular">{formatPaise(r.fare?.breakdown.totalPaise ?? 0)}</td>
                  <td className="px-4 py-2.5 text-ink-muted">{r.driver ? `${r.driver.name} · ${r.driver.vehicle.split("·")[0]}` : <span className="text-[10px]">unassigned</span>}</td>
                  <td className="px-4 py-2.5"><Badge tone={TONE[r.status] ?? "muted"} className="capitalize">{r.status.replace(/_/g, " ")}</Badge></td>
                  <td className="px-4 py-2.5 text-right">
                    <Link href={`/rides/${r.id}`} className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo hover:underline">
                      Inspect <ArrowRight className="h-3 w-3" />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <p className="mt-3 flex items-center gap-1.5 text-[10.5px] text-ink-muted">
        <Car className="h-3 w-3" /> Administrative inspection opens the public ride view — passenger contact details are never exposed, even to staff.
      </p>
    </div>
  );
}
