import { ScrollText } from "lucide-react";
import { requireRole } from "@/lib/auth/guards";
import { listAuditLogs } from "@/lib/db/queries";
import { PageHeading } from "@/components/app/app-shell";
import { Badge, DemoBadge } from "@/components/ui/primitives";
import { formatDateTime } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "Audit log" };

export default async function AuditPage() {
  await requireRole(["admin", "support"], "/admin/audit");
  const logs = listAuditLogs(80);

  return (
    <div>
      <PageHeading
        badge={<><Badge tone="navy">Admin</Badge><DemoBadge label="IMMUTABLE APPEND" /></>}
        title="Audit log"
        description="Append-only record of privileged and security-relevant actions. Writes never update or delete existing rows."
      />

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] text-left">
            <thead className="border-b border-line bg-[#FBFBFE] text-[10.5px] uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="px-4 py-2.5 font-semibold">When</th>
                <th className="px-4 py-2.5 font-semibold">Actor</th>
                <th className="px-4 py-2.5 font-semibold">Action</th>
                <th className="px-4 py-2.5 font-semibold">Entity</th>
                <th className="px-4 py-2.5 font-semibold">Change</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line text-[11.5px]">
              {logs.map((l) => (
                <tr key={l.id} className="align-top hover:bg-[#FBFBFE]">
                  <td className="whitespace-nowrap px-4 py-2 text-ink-muted">{formatDateTime(l.created_at)}</td>
                  <td className="px-4 py-2 text-navy">{l.actor_name ?? "system"}<span className="ml-1 text-[10px] text-ink-muted">{l.actor_role ?? ""}</span></td>
                  <td className="px-4 py-2"><span className="rounded bg-[#F4F3FF] px-1.5 py-0.5 font-mono text-[10px] text-indigo-700">{l.action}</span></td>
                  <td className="px-4 py-2 text-ink-muted">{l.entity_type}{l.entity_id ? <span className="block truncate font-mono text-[9.5px] text-[#98A2B3]">{l.entity_id}</span> : null}</td>
                  <td className="max-w-[280px] px-4 py-2">
                    <span className="line-clamp-2 break-all font-mono text-[9.5px] text-ink-muted">
                      {l.after_json ? String(l.after_json).slice(0, 140) : "—"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <p className="mt-3 flex items-center gap-1.5 text-[10.5px] text-ink-muted">
        <ScrollText className="h-3 w-3" /> Retention: 24 months in production. In Postgres this table is append-only via RLS (no UPDATE/DELETE policies).
      </p>
    </div>
  );
}
