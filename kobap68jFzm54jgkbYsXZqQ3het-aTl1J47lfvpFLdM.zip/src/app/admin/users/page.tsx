import { requireRole } from "@/lib/auth/guards";
import { listAllUsers } from "@/lib/db/queries";
import { PageHeading } from "@/components/app/app-shell";
import { Avatar, Badge, DemoBadge } from "@/components/ui/primitives";
import { UserStatusControl } from "@/components/app/admin-actions";
import { formatDateShort, relativeTime } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "Users" };

export default async function AdminUsersPage() {
  const user = await requireRole(["admin", "support"], "/admin/users");
  const users = listAllUsers(200);

  return (
    <div>
      <PageHeading
        badge={<><Badge tone="navy">Admin</Badge><DemoBadge label="DEMO ACCOUNTS INCLUDED" /></>}
        title="User management"
        description="Roles are enforced on the server for every request. Suspending an account revokes its sessions immediately."
      />

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[860px] text-left">
            <thead className="border-b border-line bg-[#FBFBFE] text-[10.5px] uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="px-4 py-2.5 font-semibold">User</th>
                <th className="px-4 py-2.5 font-semibold">Role</th>
                <th className="px-4 py-2.5 font-semibold">Email</th>
                <th className="px-4 py-2.5 font-semibold">Identity</th>
                <th className="px-4 py-2.5 font-semibold">Last login</th>
                <th className="px-4 py-2.5 font-semibold">Status</th>
                {user.role === "admin" && <th className="px-4 py-2.5 text-right font-semibold">Action</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-line text-[12px]">
              {users.map((u) => {
                const demo = String(u.email).endsWith("@demo.flightshare.app");
                return (
                  <tr key={u.id} className="hover:bg-[#FBFBFE]">
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <Avatar name={u.name} size="xs" />
                        <span className="font-medium text-navy">{u.name}</span>
                        {demo && <DemoBadge label="DEMO" />}
                      </div>
                    </td>
                    <td className="px-4 py-2.5"><Badge tone={u.role === "admin" ? "navy" : u.role === "driver" ? "indigo" : "muted"} className="capitalize">{u.role}</Badge></td>
                    <td className="px-4 py-2.5 text-ink-muted"><span className="inline-flex items-center gap-1.5">{u.email}{u.email_verified_at ? <Badge tone="success">verified</Badge> : <Badge tone="amber">unverified</Badge>}</span></td>
                    <td className="px-4 py-2.5 capitalize text-ink-muted">{u.identity_status ?? u.driver_status ?? "—"}</td>
                    <td className="px-4 py-2.5 text-ink-muted">{u.last_login_at ? relativeTime(u.last_login_at) : "never"}</td>
                    <td className="px-4 py-2.5"><Badge tone={u.status === "active" ? "success" : u.status === "suspended" ? "danger" : "muted"} className="capitalize">{u.status}</Badge></td>
                    {user.role === "admin" && (
                      <td className="px-4 py-2.5 text-right">
                        {u.role !== "admin" ? <UserStatusControl userId={u.id} status={u.status} /> : <span className="text-[10px] text-ink-muted">protected</span>}
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
      <p className="mt-3 text-[10.5px] text-ink-muted">
        Showing {users.length} accounts. Passwords are stored as scrypt hashes; no plaintext credential is ever written to the database or logs.
        {" "}Accounts created {formatDateShort(users[0]?.created_at ?? new Date())} or earlier.
      </p>
    </div>
  );
}
