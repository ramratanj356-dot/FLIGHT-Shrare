import Link from "next/link";
import { ArrowRight, Clock3, PlaneLanding, ShieldCheck, Sparkles, Users } from "lucide-react";
import { getSessionUser } from "@/lib/auth/session";
import { listDestinations, listFlightDates } from "@/lib/db/queries";
import { getDb } from "@/lib/db";
import { toDateKey, formatDateLong, formatTime } from "@/lib/utils";
import { SiteHeader } from "@/components/marketing/site-header";
import { SiteFooter } from "@/components/marketing/site-footer";
import { FlightSearchForm } from "@/components/forms/flight-search-form";
import { Badge, DemoBadge, SectionHeading } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";

export const dynamic = "force-dynamic";
export const metadata = { title: "Find a shared ride" };

export default async function SearchPage() {
  const user = await getSessionUser();
  const destinations = listDestinations();
  const today = toDateKey();
  const flightDates = listFlightDates();

  const sampleFlights = getDb()
    .prepare(
      `SELECT f.*, (SELECT COUNT(*) FROM ride_groups rg WHERE rg.flight_id = f.id AND rg.status='open' AND rg.seats_total > rg.seats_taken) AS open_groups
         FROM flights f WHERE f.flight_date = ? ORDER BY f.scheduled_arrival LIMIT 8`,
    )
    .all(today) as Record<string, any>[];

  return (
    <>
      <SiteHeader user={user ? { name: user.name, role: user.role } : null} />
      <main id="main">
        <section className="border-b border-line bg-white">
          <div className="container-x py-10 sm:py-14">
            <div className="mx-auto max-w-3xl text-center">
              <Badge tone="indigo" icon={<Sparkles className="h-3 w-3" />}>Flight-based matching</Badge>
              <h1 className="mt-3.5 text-[30px] font-bold tracking-[-0.03em] text-navy sm:text-[38px]">
                Which flight are you arriving on?
              </h1>
              <p className="mx-auto mt-3 max-w-xl text-[14.5px] leading-relaxed text-ink-muted">
                Enter your flight number and destination. We&apos;ll show every group on that flight heading the same way, with a match score
                and a full fare breakdown for each.
              </p>
            </div>

            <div className="mx-auto mt-7 max-w-4xl">
              <FlightSearchForm
                variant="page"
                destinations={destinations.map((d) => ({ id: d.id, name: d.name, area: d.area, distanceKm: d.distance_km, soloFarePaise: d.solo_fare_paise }))}
                defaultDate={today}
                sampleFlight="AI864"
              />
            </div>

            <ul className="mx-auto mt-5 flex max-w-3xl flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[11.5px] text-ink-muted">
              {[
                { icon: ShieldCheck, label: "Booking-verified passengers" },
                { icon: Clock3, label: "Agreed waiting window" },
                { icon: Users, label: "You approve, nothing auto-joins" },
                { icon: PlaneLanding, label: "Mumbai (BOM) today" },
              ].map((f) => (
                <li key={f.label} className="flex items-center gap-1.5"><f.icon className="h-3.5 w-3.5 text-success" />{f.label}</li>
              ))}
            </ul>
          </div>
        </section>

        <section className="py-12">
          <div className="container-x">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-[19px] font-bold tracking-[-0.02em] text-navy">Arriving today at BOM</h2>
                  <DemoBadge label="SAMPLE SCHEDULE" />
                </div>
                <p className="mt-1 text-[12.5px] text-ink-muted">Pick a flight to jump straight into its matches, or search your own.</p>
              </div>
              <LinkButton href="/destinations" variant="outline" size="sm" rightIcon={<ArrowRight className="h-3.5 w-3.5" />}>
                Browse destinations
              </LinkButton>
            </div>

            <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {sampleFlights.map((f) => {
                const openCount = Number(f.open_groups ?? 0);
                return (
                  <Link
                    key={f.id}
                    href={`/rides?airport=apt_bom&flight=${f.flight_number}&date=${f.flight_date}&dest=thane-w&pax=1&luggage=1`}
                    className="card group p-3.5 transition hover:-translate-y-0.5 hover:shadow-lift"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[13px] font-bold text-navy">{f.airline_code} {f.flight_number}</span>
                      <Badge tone={openCount > 0 ? "success" : "muted"}>{openCount > 0 ? `${openCount} open` : "no seats"}</Badge>
                    </div>
                    <p className="mt-1 truncate text-[11px] text-ink-muted">{f.origin_city}</p>
                    <p className="mt-2 flex items-center gap-1.5 text-[12px] font-semibold text-ink-soft">
                      <PlaneLanding className="h-3.5 w-3.5 text-indigo" /> {formatTime(f.estimated_arrival)}
                      <span className="text-[10px] font-normal text-ink-muted">· {f.terminal}</span>
                    </p>
                    <p className="mt-1.5 flex items-center gap-1 text-[11px] font-medium text-indigo opacity-0 transition group-hover:opacity-100">
                      View matches <ArrowRight className="h-3 w-3" />
                    </p>
                  </Link>
                );
              })}
            </div>

            {flightDates.length > 0 && (
              <div className="mt-8">
                <h3 className="text-[13px] font-semibold text-navy">Other dates with sample groups</h3>
                <div className="mt-2.5 flex flex-wrap gap-2">
                  {flightDates.slice(0, 8).map((d) => (
                    <Link
                      key={d.date}
                      href={`/rides?airport=apt_bom&flight=AI864&date=${d.date}&dest=thane-w&pax=1&luggage=1`}
                      className="rounded-lg border border-line bg-white px-2.5 py-1.5 text-[11.5px] font-medium text-ink-soft transition hover:border-indigo-200 hover:text-indigo"
                    >
                      {formatDateLong(d.date)} <span className="text-ink-muted">· {d.groups}</span>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        </section>

        <section className="border-t border-line bg-white py-12">
          <div className="container-x">
            <SectionHeading
              eyebrow="Popular right now"
              title="Where passengers are heading from BOM"
              description="Compatibility is scored on geography and road reality — Mulund pairs with Thane, Powai pairs with Ghatkopar, Colaba does not pair with Borivali."
            />
            <div className="mt-6 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
              {destinations.slice(0, 9).map((d) => (
                <Link
                  key={d.id}
                  href={`/rides?flight=AI864&date=${today}&dest=${d.id}&pax=1&luggage=1`}
                  className="group flex items-center justify-between rounded-xl border border-line bg-white px-3.5 py-3 transition hover:border-indigo-200 hover:shadow-card"
                >
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-semibold text-navy group-hover:text-indigo">{d.name}</p>
                    <p className="text-[11px] text-ink-muted">{d.distance_km} km · ~{d.drive_minutes} min · solo est. ₹{Math.round(d.solo_fare_paise / 100).toLocaleString("en-IN")}</p>
                  </div>
                  <ArrowRight className="h-4 w-4 shrink-0 text-ink-muted transition group-hover:translate-x-0.5 group-hover:text-indigo" />
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
