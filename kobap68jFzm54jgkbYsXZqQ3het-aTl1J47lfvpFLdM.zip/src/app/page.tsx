import Link from "next/link";
import { ArrowRight, Clock3, MapPin, PlaneLanding, ShieldCheck, Sparkles, Users } from "lucide-react";
import { getSessionUser } from "@/lib/auth/session";
import { listDestinations, listGroupsForFlight, findFlight } from "@/lib/db/queries";
import { toDateKey, formatTime } from "@/lib/utils";
import { formatPaise } from "@/lib/money";
import { SiteHeader } from "@/components/marketing/site-header";
import { SiteFooter } from "@/components/marketing/site-footer";
import { HeroVisual } from "@/components/marketing/hero-visual";
import { FlightSearchForm } from "@/components/forms/flight-search-form";
import { SavingsCalculator } from "@/components/marketing/savings-calculator";
import {
  DestinationsSection, FareExampleStrip, FaqSection, FinalCta, HowItWorksSection,
  JourneySection, PartnerBand, SafetySection, WhySection,
} from "@/components/marketing/sections";
import { Avatar, Badge, DemoBadge, SectionHeading } from "@/components/ui/primitives";
import { LinkButton } from "@/components/ui/button";

export const dynamic = "force-dynamic";

const SAMPLE_FLIGHT = "AI864";

export default async function HomePage() {
  const user = await getSessionUser();
  const destinations = listDestinations();
  const today = toDateKey();
  const flight = findFlight("apt_bom", SAMPLE_FLIGHT, today);
  const groups = flight ? listGroupsForFlight(flight.id).filter((g) => g.status === "open").slice(0, 3) : [];

  return (
    <>
      <SiteHeader user={user ? { name: user.name, role: user.role } : null} />
      <main id="main">
        {/* ── Hero ─────────────────────────────────────────────────── */}
        <section className="relative overflow-hidden border-b border-line bg-white">
          <div className="pointer-events-none absolute inset-0 bg-grid-faint bg-[size:52px_52px] opacity-[0.45] [mask-image:radial-gradient(80%_60%_at_50%_0%,black,transparent)]" />
          <div className="pointer-events-none absolute -right-40 -top-40 h-[520px] w-[520px] rounded-full bg-[radial-gradient(circle,rgba(81,69,255,0.10),transparent_65%)]" />
          <div className="pointer-events-none absolute -left-32 top-40 h-[360px] w-[360px] rounded-full bg-[radial-gradient(circle,rgba(22,163,106,0.08),transparent_65%)]" />

          <div className="container-x relative pb-10 pt-12 sm:pt-16 lg:pb-14 lg:pt-20">
            <div className="grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
              <div>
                <span className="inline-flex items-center gap-2 rounded-full border border-line bg-white px-3 py-1.5 shadow-sm">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full animate-pulse-ring rounded-full bg-success" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-success" />
                  </span>
                  <span className="text-[11.5px] font-semibold text-ink-soft">Now matching flights into Mumbai (BOM)</span>
                  <span className="h-3 w-px bg-line" />
                  <span className="text-[11.5px] font-medium text-ink-muted">Demo environment</span>
                </span>

                <h1 className="mt-6 text-[clamp(2.3rem,4.6vw,3.65rem)] font-bold leading-[1.06] tracking-[-0.035em] text-navy">
                  Your flight has landed.
                  <br />
                  <span className="whitespace-nowrap bg-[linear-gradient(transparent_78%,#E7E3FF_78%)] [box-decoration-break:clone]">
                    Your cab costs less.
                  </span>
                </h1>

                <p className="mt-5 max-w-xl text-[16px] leading-relaxed text-ink-muted">
                  Connect with verified passengers arriving on your flight, share a cab to nearby destinations, and split the fare fairly.
                </p>

                <div className="mt-8 flex flex-wrap items-center gap-3">
                  <LinkButton href="/search" size="xl" rightIcon={<ArrowRight className="h-4 w-4" />}>
                    Find My Ride
                  </LinkButton>
                  <LinkButton href="#how-it-works" size="xl" variant="outline">
                    See How It Works
                  </LinkButton>
                </div>

                <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2.5 text-[12.5px] text-ink-muted">
                  {[
                    { icon: ShieldCheck, label: "Booking-verified passengers" },
                    { icon: Users, label: "Seats you choose, never auto-joined" },
                    { icon: Clock3, label: "Agreed waiting window" },
                  ].map((f) => (
                    <li key={f.label} className="flex items-center gap-1.5">
                      <f.icon className="h-3.5 w-3.5 text-success" /> {f.label}
                    </li>
                  ))}
                </ul>
              </div>

              <HeroVisual className="animate-fade-up lg:pl-4" />
            </div>

            <div className="mt-12 lg:mt-14">
              <FlightSearchForm
                destinations={destinations.map((d) => ({
                  id: d.id, name: d.name, area: d.area, distanceKm: d.distance_km, soloFarePaise: d.solo_fare_paise,
                }))}
                defaultDate={today}
                sampleFlight={SAMPLE_FLIGHT}
              />
            </div>
          </div>
        </section>

        <FareExampleStrip />

        {/* ── Live sample matches from the database ────────────────── */}
        {groups.length > 0 && (
          <section className="py-16 sm:py-20">
            <div className="container-x">
              <div className="flex flex-wrap items-end justify-between gap-4">
                <div>
                  <div className="mb-2.5 flex items-center gap-2">
                    <DemoBadge />
                    <span className="text-[11.5px] text-ink-muted">
                      {flight?.flight_number} · {flight ? formatTime(flight.estimated_arrival) : ""} arrival · Terminal {flight?.terminal}
                    </span>
                  </div>
                  <h2 className="text-display-md text-navy">Rides forming on today&apos;s sample flight</h2>
                  <p className="mt-2 max-w-2xl text-[14px] text-ink-muted">
                    These are real records in the demo database, calculated with the live fare engine — open one to see the full breakdown,
                    route and passenger compatibility.
                  </p>
                </div>
                <LinkButton href={`/rides?airport=apt_bom&flight=${SAMPLE_FLIGHT}&date=${today}&dest=thane-w&pax=1&luggage=1`} variant="outline" size="sm" rightIcon={<ArrowRight className="h-4 w-4" />}>
                  Open search results
                </LinkButton>
              </div>

              <div className="mt-7 grid gap-4 md:grid-cols-3">
                {groups.map((g) => {
                  const perPerson = g.fare ? Math.round(g.fare.breakdown.totalPaise / Math.max(1, g.fare.breakdown.seatCount)) : 0;
                  const solo = g.destination.solo_fare_paise;
                  const savingPct = solo > 0 ? Math.round(((solo - perPerson) / solo) * 100) : 0;
                  return (
                    <Link
                      key={g.id}
                      href={`/rides/${g.id}`}
                      className="card group flex flex-col p-4 transition-all hover:-translate-y-0.5 hover:shadow-lift"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="text-[11px] font-medium uppercase tracking-wide text-ink-muted">Destination</p>
                          <h3 className="text-[17px] font-semibold text-navy group-hover:text-indigo">{g.destination.name}</h3>
                          <p className="mt-0.5 text-[11.5px] text-ink-muted">
                            {g.destination.distance_km} km · ~{g.destination.drive_minutes} min from BOM
                          </p>
                        </div>
                        <Badge tone={g.seatsAvailable > 0 ? "success" : "muted"}>
                          {g.seatsAvailable > 0 ? `${g.seatsAvailable} seat${g.seatsAvailable === 1 ? "" : "s"} left` : "Full"}
                        </Badge>
                      </div>

                      <div className="mt-3.5 flex items-center gap-1.5">
                        {g.members.slice(0, 3).map((m) => (
                          <Avatar key={m.memberId} name={m.firstName} size="xs" verified={m.identityVerified} />
                        ))}
                        <span className="ml-1 text-[11.5px] text-ink-muted">
                          {g.members.length} traveller{g.members.length === 1 ? "" : "s"} · {g.vehicleCategory}
                        </span>
                      </div>

                      <div className="mt-4 flex items-end justify-between rounded-xl bg-[#F9FAFD] px-3 py-2.5">
                        <div>
                          <p className="text-[10px] font-medium uppercase tracking-wide text-ink-muted">Est. per person</p>
                          <p className="text-lg font-bold text-navy tabular">{formatPaise(perPerson)}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-[10px] font-medium uppercase tracking-wide text-ink-muted">vs solo {formatPaise(solo)}</p>
                          <p className="text-[12.5px] font-bold text-success-dark tabular">{savingPct > 0 ? `${savingPct}% less` : "no saving"}</p>
                        </div>
                      </div>

                      <div className="mt-3 flex items-center justify-between border-t border-line pt-3 text-[11.5px] text-ink-muted">
                        <span className="flex items-center gap-1.5">
                          <MapPin className="h-3 w-3" /> {g.extraDestinations.map((d) => d.name).join(", ") || "Direct drop-off"}
                        </span>
                        <span className="flex items-center gap-1 font-semibold text-indigo">
                          View ride <ArrowRight className="h-3 w-3 transition group-hover:translate-x-0.5" />
                        </span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>
          </section>
        )}

        <HowItWorksSection />
        <WhySection />

        <section id="calculator" className="border-y border-line bg-white py-20 sm:py-24">
          <div className="container-x">
            <SectionHeading
              eyebrow="Savings calculator"
              title="Run the numbers yourself."
              description="Move the sliders to see how a shared fare splits — including the platform fee and tax. If sharing would cost more, we say so."
              align="center"
              className="mx-auto"
            />
            <div className="mt-10">
              <SavingsCalculator />
            </div>
          </div>
        </section>

        <DestinationsSection destinations={destinations} />
        <JourneySection />
        <SafetySection />
        <FaqSection />
        <PartnerBand />
        <FinalCta />
      </main>
      <SiteFooter />
    </>
  );
}
