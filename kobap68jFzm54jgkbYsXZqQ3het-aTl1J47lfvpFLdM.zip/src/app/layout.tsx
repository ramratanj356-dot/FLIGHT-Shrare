import type { Metadata, Viewport } from "next";
import "./globals.css";
import { ToastProvider } from "@/components/ui/toast";

export const metadata: Metadata = {
  title: {
    default: "FlightShare — Same flight. Same direction. One shared ride.",
    template: "%s · FlightShare",
  },
  description:
    "FlightShare connects verified passengers arriving on the same flight at Mumbai's BOM airport who are heading the same way, so airport cabs cost less and fewer cars leave the terminal.",
  keywords: ["airport cab pooling", "Mumbai airport taxi", "flight sharing", "BOM transfers", "ride sharing India"],
  openGraph: {
    title: "FlightShare — Same flight. Same direction. One shared ride.",
    description: "Share your airport cab with verified passengers from your own flight. Transparent fare splitting, coordinated departures.",
    type: "website",
  },
  robots: { index: false, follow: false }, // demo deployment
};

export const viewport: Viewport = {
  themeColor: "#101828",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[200] focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:shadow-lift">
          Skip to content
        </a>
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}
