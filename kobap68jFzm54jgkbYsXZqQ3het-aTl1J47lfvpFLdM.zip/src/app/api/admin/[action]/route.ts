import { assertSameOrigin, handleApiError, jsonError, jsonOk } from "@/lib/security/http";
import { requireApiUser } from "@/lib/auth/guards";
import {
  processRefund, resolveReport, reviewDriverVerification, reviewFlightVerification,
  updatePricingRules, updateSupportTicket, updateUserStatus,
} from "@/lib/services/admin";
import { pricingRulesSchema } from "@/lib/validation/schemas";
import { INR } from "@/lib/money";
import { z } from "zod";

export const runtime = "nodejs";

export async function POST(req: Request, ctx: { params: Promise<{ action: string }> }) {
  try {
    if (!assertSameOrigin(req)) return jsonError(403, "Cross-origin request blocked");
    // Admins only. Support agents are limited to tickets, enforced in the service.
    const user = await requireApiUser();
    if (!["admin", "support"].includes(user.role)) return jsonError(403, "Administrator access required");
    const { action } = await ctx.params;

    if (action === "flight-verification") {
      const input = z.object({
        id: z.string().min(1),
        status: z.enum(["verified", "rejected"]),
        note: z.string().max(280).optional(),
      }).parse(await req.json());
      return jsonOk(reviewFlightVerification(user, input.id, input.status, input.note));
    }

    if (action === "driver-verification") {
      const input = z.object({
        driverId: z.string().min(1),
        status: z.enum(["verified", "rejected"]),
        note: z.string().max(280).optional(),
      }).parse(await req.json());
      return jsonOk(reviewDriverVerification(user, input.driverId, input.status, input.note));
    }

    if (action === "pricing") {
      const input = pricingRulesSchema.parse(await req.json());
      return jsonOk(
        updatePricingRules(user, {
          base_fare_paise: INR(input.baseFareRupees),
          per_km_paise: INR(input.perKmRupees),
          extra_stop_paise: INR(input.extraStopRupees),
          platform_fee_bps: Math.round(input.platformFeePct * 100),
          platform_fee_min_paise: INR(input.platformFeeMinRupees),
          tax_bps: Math.round(input.taxPct * 100),
          max_wait_minutes: input.maxWaitMinutes,
          destination_threshold: input.destinationThreshold,
        }),
      );
    }

    if (action === "report") {
      const input = z.object({
        id: z.string().min(1),
        status: z.enum(["reviewing", "resolved", "dismissed"]),
        resolution: z.string().max(500).optional(),
      }).parse(await req.json());
      return jsonOk(resolveReport(user, input.id, input.status, input.resolution));
    }

    if (action === "refund") {
      const input = z.object({
        id: z.string().min(1),
        decision: z.enum(["processed", "failed"]),
        note: z.string().max(280).optional(),
      }).parse(await req.json());
      return jsonOk(processRefund(user, input.id, input.decision, input.note));
    }

    if (action === "user") {
      const input = z.object({
        userId: z.string().min(1),
        status: z.enum(["active", "suspended"]),
      }).parse(await req.json());
      return jsonOk(updateUserStatus(user, input.userId, input.status));
    }

    if (action === "ticket") {
      const input = z.object({
        id: z.string().min(1),
        status: z.enum(["open", "in_progress", "resolved", "closed"]),
      }).parse(await req.json());
      return jsonOk(updateSupportTicket(user, input.id, input.status));
    }

    return jsonError(404, "Unknown admin action");
  } catch (err) {
    return handleApiError(err);
  }
}
