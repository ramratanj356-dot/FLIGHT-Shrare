import { assertSameOrigin, handleApiError, jsonError, jsonOk } from "@/lib/security/http";
import { requireApiUser } from "@/lib/auth/guards";
import { withdrawJoinRequest } from "@/lib/services/rides";
import { z } from "zod";

export const runtime = "nodejs";
const schema = z.object({ requestId: z.string().min(1) });

export async function POST(req: Request) {
  try {
    if (!assertSameOrigin(req)) return jsonError(403, "Cross-origin request blocked");
    const user = await requireApiUser();
    const { requestId } = schema.parse(await req.json());
    return jsonOk(withdrawJoinRequest(user, requestId));
  } catch (err) {
    return handleApiError(err);
  }
}
