import { assertSameOrigin, handleApiError, jsonError, jsonOk } from "@/lib/security/http";
import { requireApiUser } from "@/lib/auth/guards";
import { clientKey, enforceRateLimit } from "@/lib/security/rateLimit";
import { requestToJoin } from "@/lib/services/rides";
import { joinRequestSchema } from "@/lib/validation/schemas";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    if (!assertSameOrigin(req)) return jsonError(403, "Cross-origin request blocked");
    const user = await requireApiUser();
    const limit = enforceRateLimit(`join:${user.id}`, 12, 600);
    if (!limit.ok) return jsonError(429, `Too many join requests. Try again in ${limit.retryAfter}s.`);

    const input = joinRequestSchema.parse(await req.json());
    const result = requestToJoin({
      viewer: user,
      rideGroupId: input.rideGroupId,
      passengerCount: input.passengerCount,
      luggageUnits: input.luggageUnits,
      destinationId: input.destinationId,
      bookingReference: input.bookingReference || undefined,
      message: input.message || undefined,
    });
    return jsonOk(result);
  } catch (err) {
    return handleApiError(err);
  }
}
