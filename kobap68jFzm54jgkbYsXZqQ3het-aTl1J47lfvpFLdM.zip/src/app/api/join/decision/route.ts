import { assertSameOrigin, handleApiError, jsonError, jsonOk } from "@/lib/security/http";
import { requireApiUser } from "@/lib/auth/guards";
import { decideJoinRequest } from "@/lib/services/rides";
import { decisionSchema } from "@/lib/validation/schemas";
import { clientKey, enforceRateLimit } from "@/lib/security/rateLimit";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    if (!assertSameOrigin(req)) return jsonError(403, "Cross-origin request blocked");
    const user = await requireApiUser();
    const limit = enforceRateLimit(clientKey(req, "decision"), 30, 300);
    if (!limit.ok) return jsonError(429, "Slow down a moment.");
    const input = decisionSchema.parse(await req.json());
    const result = decideJoinRequest({ viewer: user, requestId: input.requestId, decision: input.decision, note: input.note || undefined });
    return jsonOk(result);
  } catch (err) {
    return handleApiError(err);
  }
}
