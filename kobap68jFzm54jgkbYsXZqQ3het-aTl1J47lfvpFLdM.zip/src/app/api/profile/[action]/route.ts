import { assertSameOrigin, handleApiError, jsonError, jsonOk } from "@/lib/security/http";
import { requireApiUser } from "@/lib/auth/guards";
import { requestAccountDeletion, submitIdentityCheck } from "@/lib/services/auth";
import { destroySession } from "@/lib/auth/session";

export const runtime = "nodejs";

export async function POST(req: Request, ctx: { params: Promise<{ action: string }> }) {
  try {
    if (!assertSameOrigin(req)) return jsonError(403, "Cross-origin request blocked");
    const user = await requireApiUser();
    const { action } = await ctx.params;

    if (action === "identity") return jsonOk(submitIdentityCheck(user.id));
    if (action === "delete") {
      requestAccountDeletion(user.id);
      await destroySession();
      return jsonOk({ ok: true });
    }
    return jsonError(404, "Unknown profile action");
  } catch (err) {
    return handleApiError(err);
  }
}
