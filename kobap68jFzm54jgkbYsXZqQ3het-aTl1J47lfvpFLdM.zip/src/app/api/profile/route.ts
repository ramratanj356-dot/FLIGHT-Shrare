import { assertSameOrigin, handleApiError, jsonError, jsonOk } from "@/lib/security/http";
import { requireApiUser } from "@/lib/auth/guards";
import { updateProfile } from "@/lib/services/auth";
import { profileSchema } from "@/lib/validation/schemas";

export const runtime = "nodejs";

export async function PATCH(req: Request) {
  try {
    if (!assertSameOrigin(req)) return jsonError(403, "Cross-origin request blocked");
    const user = await requireApiUser();
    const input = profileSchema.parse(await req.json());
    updateProfile(user.id, input);
    return jsonOk({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}
