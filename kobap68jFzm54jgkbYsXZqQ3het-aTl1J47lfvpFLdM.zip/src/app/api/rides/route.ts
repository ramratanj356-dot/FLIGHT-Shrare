import { assertSameOrigin, handleApiError, jsonError, jsonOk } from "@/lib/security/http";
import { requireApiUser } from "@/lib/auth/guards";
import { createRideGroup } from "@/lib/services/rides";
import { createRideSchema } from "@/lib/validation/schemas";
import { clientKey, enforceRateLimit } from "@/lib/security/rateLimit";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    if (!assertSameOrigin(req)) return jsonError(403, "Cross-origin request blocked");
    const user = await requireApiUser();
    const limit = enforceRateLimit(clientKey(req, "create-ride"), 8, 3600);
    if (!limit.ok) return jsonError(429, "You have created several rides recently. Try again later.");

    const input = createRideSchema.parse(await req.json());
    const result = createRideGroup({
      viewer: user,
      flightNumber: input.flightNumber,
      flightDate: input.flightDate,
      airportId: input.airportId,
      destinationId: input.destinationId,
      vehicleCategory: input.vehicleCategory,
      maxWaitMinutes: input.maxWaitMinutes,
      strategy: input.strategy,
      passengerCount: input.passengerCount,
      luggageUnits: input.luggageUnits,
      meetPoint: input.meetPoint || undefined,
    });
    return jsonOk(result);
  } catch (err) {
    return handleApiError(err);
  }
}
