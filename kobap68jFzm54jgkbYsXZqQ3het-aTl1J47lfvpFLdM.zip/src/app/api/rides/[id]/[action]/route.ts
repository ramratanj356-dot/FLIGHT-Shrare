import { assertSameOrigin, handleApiError, jsonError, jsonOk } from "@/lib/security/http";
import { requireApiUser } from "@/lib/auth/guards";
import { cancelRide, confirmDeparture, updateReadiness } from "@/lib/services/rides";
import { getGroupMembership, getRideGroup, listMessages, unreadNotificationCount } from "@/lib/db/queries";
import { computeDepartureWindow } from "@/lib/match/timing";
import { getDb } from "@/lib/db";
import { loadPricingRules } from "@/lib/db/pricing";
import { z } from "zod";

export const runtime = "nodejs";

const readinessBody = z.object({
  readiness: z.enum(["not_landed", "landed", "collecting_baggage", "ready_at_meeting_point", "boarding_vehicle", "trip_started"]),
});

export async function POST(req: Request, ctx: { params: Promise<{ id: string; action: string }> }) {
  try {
    if (!assertSameOrigin(req)) return jsonError(403, "Cross-origin request blocked");
    const user = await requireApiUser();
    const { id, action } = await ctx.params;

    if (action === "readiness") {
      const body = readinessBody.parse(await req.json());
      return jsonOk(updateReadiness({ viewer: user, rideGroupId: id, readiness: body.readiness }));
    }
    if (action === "depart") return jsonOk(confirmDeparture(user, id));
    if (action === "cancel") {
      const body = await req.json().catch(() => ({}));
      const reason = typeof body.reason === "string" && body.reason.trim() ? body.reason.trim().slice(0, 240) : "Cancelled by the coordinator";
      return jsonOk(cancelRide(user, id, reason));
    }
    return jsonError(404, "Unknown ride action");
  } catch (err) {
    return handleApiError(err);
  }
}

/** Polling endpoint for readiness, ride state, chat and notification counts. */
export async function GET(_req: Request, ctx: { params: Promise<{ id: string; action: string }> }) {
  try {
    const user = await requireApiUser();
    const { id, action } = await ctx.params;
    if (action !== "state") return jsonError(404, "Unknown ride action");

    const membership = getGroupMembership(id, user.id);
    if (!membership) return jsonError(403, "You are not part of this ride");

    const group = getRideGroup(id, user.id);
    if (!group) return jsonError(404, "Ride not found");

    const db = getDb();
    const conversation = db.prepare("SELECT id FROM conversations WHERE ride_group_id = ?").get(id) as { id: string } | undefined;
    const messages = conversation ? listMessages(conversation.id, user.id) : [];

    const window = computeDepartureWindow({
      scheduledArrival: group.flight.scheduled_arrival,
      estimatedArrival: group.flight.estimated_arrival,
      status: group.flight.status,
      baggageClaimMinutes: loadPricingRules(db).baggageClaimMinutes,
      maxWaitMinutes: group.maxWaitMinutes,
      members: group.members.map((m) => ({ readiness: m.readiness as never, expectedReadyAt: m.expectedReadyAt ?? group.departureWindowStart })),
    });

    return jsonOk({
      status: group.status,
      members: group.members.map((m) => ({
        displayName: m.displayName, readiness: m.readiness, seats: m.seats, role: m.role, isYou: m.isYou,
      })),
      messages: messages.slice(-40),
      window,
      unreadNotifications: unreadNotificationCount(user.id),
      myReadiness: membership.readiness,
      serverTime: new Date().toISOString(),
    });
  } catch (err) {
    return handleApiError(err);
  }
}
