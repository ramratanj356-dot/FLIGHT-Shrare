import { NextResponse } from "next/server";
import { healthCheck } from "@/lib/db";
import { FLIGHT_PROVIDER_MODE, MAPS_MODE, PAYMENTS_MODE, EMAIL_MODE, VERIFICATION_MODE, AUTH_GOOGLE_MODE } from "@/lib/config/features";

export const runtime = "nodejs";

export async function GET() {
  const db = healthCheck();
  return NextResponse.json({
    ok: db.ok,
    service: "flightshare",
    version: "0.1.0",
    time: new Date().toISOString(),
    database: db,
    integrations: {
      flightData: FLIGHT_PROVIDER_MODE,
      maps: MAPS_MODE,
      payments: PAYMENTS_MODE,
      email: EMAIL_MODE,
      identity: VERIFICATION_MODE,
      googleAuth: AUTH_GOOGLE_MODE,
    },
  });
}
