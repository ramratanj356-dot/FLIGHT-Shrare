import type { NextRequest } from "next/server";
import { assertSameOrigin, handleApiError, jsonError, jsonOk } from "@/lib/security/http";
import { clientKey, enforceRateLimit } from "@/lib/security/rateLimit";
import { createSession, destroySession, getSessionUser } from "@/lib/auth/session";
import {
  login, requestPasswordReset, resendVerification, resetPassword, signup, verifyEmailToken,
} from "@/lib/services/auth";
import { loginSchema, forgotPasswordSchema, resetPasswordSchema, signupSchema } from "@/lib/validation/schemas";
import { z } from "zod";

export const runtime = "nodejs";

const verifySchema = z.object({ token: z.string().min(10) });

export async function POST(req: NextRequest, ctx: { params: Promise<{ action: string }> }) {
  try {
    if (!assertSameOrigin(req)) return jsonError(403, "Cross-origin request blocked");
    const { action } = await ctx.params;
    const ip = req.headers.get("x-forwarded-for") ?? "local";
    const userAgent = req.headers.get("user-agent");

    if (action === "signup") {
      const limit = enforceRateLimit(clientKey(req, "signup"), 6, 600);
      if (!limit.ok) return jsonError(429, `Too many sign-up attempts. Try again in ${limit.retryAfter}s.`);
      const input = signupSchema.parse(await req.json());
      const result = await signup({
        name: input.name, email: input.email, phone: input.phone || undefined,
        password: input.password, role: input.role,
      });
      await createSession(result.userId, { ip, userAgent });
      return jsonOk({ userId: result.userId, devVerifyUrl: result.devVerifyUrl, next: input.role === "driver" ? "/driver" : "/app" });
    }

    if (action === "login") {
      const limit = enforceRateLimit(clientKey(req, "login"), 10, 300);
      if (!limit.ok) return jsonError(429, `Too many sign-in attempts. Please wait ${limit.retryAfter}s.`);
      const input = loginSchema.parse(await req.json());
      const result = await login(input);
      await createSession(result.userId, { ip, userAgent });
      const next = result.role === "admin" ? "/admin" : result.role === "driver" ? "/driver" : "/app";
      return jsonOk({ role: result.role, next });
    }

    if (action === "logout") {
      await destroySession();
      return jsonOk({ ok: true });
    }

    if (action === "forgot-password") {
      const limit = enforceRateLimit(clientKey(req, "forgot"), 5, 600);
      if (!limit.ok) return jsonError(429, "Too many reset requests. Try again shortly.");
      const input = forgotPasswordSchema.parse(await req.json());
      const result = await requestPasswordReset(input.email);
      return jsonOk(result);
    }

    if (action === "reset-password") {
      const input = resetPasswordSchema.parse(await req.json());
      await resetPassword(input.token, input.password);
      return jsonOk({ ok: true });
    }

    if (action === "verify-email") {
      const input = verifySchema.parse(await req.json());
      verifyEmailToken(input.token);
      return jsonOk({ ok: true });
    }

    if (action === "resend-verification") {
      const user = await getSessionUser();
      if (!user) return jsonError(401, "Sign in to resend verification");
      const limit = enforceRateLimit(`resend:${user.id}`, 3, 600);
      if (!limit.ok) return jsonError(429, "Please wait before requesting another email.");
      const result = resendVerification(user.id, user.email);
      return jsonOk(result);
    }

    return jsonError(404, "Unknown auth action");
  } catch (err) {
    return handleApiError(err);
  }
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ action: string }> }) {
  const { action } = await ctx.params;
  if (action !== "session") return jsonError(404, "Unknown auth action");
  const user = await getSessionUser();
  return jsonOk({ user });
}
