import { assertSameOrigin, handleApiError, jsonError, jsonOk } from "@/lib/security/http";
import { requireApiRole } from "@/lib/auth/guards";
import { acceptRide, declineRide, submitDriverVerification, updateTripStatus } from "@/lib/services/driver";
import { driverVerificationSchema } from "@/lib/validation/schemas";
import { z } from "zod";

export const runtime = "nodejs";

export async function POST(req: Request, ctx: { params: Promise<{ action: string }> }) {
  try {
    if (!assertSameOrigin(req)) return jsonError(403, "Cross-origin request blocked");
    const user = await requireApiRole(["driver", "admin"]);
    const { action } = await ctx.params;

    if (action === "verification") {
      const input = driverVerificationSchema.parse(await req.json());
      return jsonOk(submitDriverVerification(user, input));
    }
    if (action === "accept") {
      const { rideGroupId } = z.object({ rideGroupId: z.string().min(1) }).parse(await req.json());
      return jsonOk(acceptRide(user, rideGroupId));
    }
    if (action === "decline") {
      const { rideGroupId } = z.object({ rideGroupId: z.string().min(1) }).parse(await req.json());
      return jsonOk(declineRide(user, rideGroupId));
    }
    if (action === "trip") {
      const input = z
        .object({ rideGroupId: z.string().min(1), status: z.enum(["arrived", "start", "complete"]) })
        .parse(await req.json());
      return jsonOk(updateTripStatus(user, input.rideGroupId, input.status));
    }
    return jsonError(404, "Unknown driver action");
  } catch (err) {
    return handleApiError(err);
  }
}
