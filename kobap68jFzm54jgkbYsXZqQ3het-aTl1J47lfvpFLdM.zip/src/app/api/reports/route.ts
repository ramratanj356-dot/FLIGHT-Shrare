import { assertSameOrigin, handleApiError, jsonError, jsonOk } from "@/lib/security/http";
import { requireApiUser } from "@/lib/auth/guards";
import { reportSchema } from "@/lib/validation/schemas";
import { createReport } from "@/lib/services/admin";
import { reportMessage } from "@/lib/services/chat";
import { enforceRateLimit } from "@/lib/security/rateLimit";
import { z } from "zod";

export const runtime = "nodejs";

/** Accepts either a message report (contextual) or a general passenger report. */
export async function POST(req: Request) {
  try {
    if (!assertSameOrigin(req)) return jsonError(403, "Cross-origin request blocked");
    const user = await requireApiUser();
    const limit = enforceRateLimit(`report:${user.id}`, 8, 3600);
    if (!limit.ok) return jsonError(429, "You have filed several reports recently. Support will follow up.");

    const body = await req.json();

    if (typeof body?.messageId === "string") {
      const parsed = z.object({ messageId: z.string().min(1), reason: z.string().max(400).optional() }).parse(body);
      return jsonOk(reportMessage(user, parsed.messageId, parsed.reason ?? "No reason given"));
    }

    const input = reportSchema.parse(body);
    return jsonOk(createReport(user.id, input));
  } catch (err) {
    return handleApiError(err);
  }
}
