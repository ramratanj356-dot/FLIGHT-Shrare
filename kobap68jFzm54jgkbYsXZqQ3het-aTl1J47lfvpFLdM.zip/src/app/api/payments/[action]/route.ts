import { assertSameOrigin, handleApiError, jsonError, jsonOk } from "@/lib/security/http";
import { requireApiUser } from "@/lib/auth/guards";
import { createPaymentOrder, verifyPayment } from "@/lib/services/payments";
import { z } from "zod";

export const runtime = "nodejs";

export async function POST(req: Request, ctx: { params: Promise<{ action: string }> }) {
  try {
    if (!assertSameOrigin(req)) return jsonError(403, "Cross-origin request blocked");
    const user = await requireApiUser();
    const { action } = await ctx.params;

    if (action === "order") {
      const { bookingId } = z.object({ bookingId: z.string().min(1) }).parse(await req.json());
      return jsonOk(await createPaymentOrder(user, bookingId));
    }

    if (action === "verify") {
      const input = z
        .object({
          paymentId: z.string().min(1),
          razorpayOrderId: z.string().optional(),
          razorpayPaymentId: z.string().optional(),
          razorpaySignature: z.string().optional(),
        })
        .parse(await req.json());
      return jsonOk(
        await verifyPayment(user, {
          paymentId: input.paymentId,
          providerOrderId: input.razorpayOrderId,
          providerPaymentId: input.razorpayPaymentId,
          signature: input.razorpaySignature,
        }),
      );
    }

    return jsonError(404, "Unknown payment action");
  } catch (err) {
    return handleApiError(err);
  }
}
