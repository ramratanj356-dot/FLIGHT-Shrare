import { NextResponse } from "next/server";
import { handlePaymentWebhook } from "@/lib/services/payments";

export const runtime = "nodejs";

/**
 * Razorpay webhook. The raw body is required for signature verification, so it
 * must never be parsed before HMAC comparison.
 */
export async function POST(req: Request) {
  const raw = await req.text();
  const result = await handlePaymentWebhook(raw, req.headers.get("x-razorpay-signature"));
  return NextResponse.json({ ok: result.ok, message: result.message }, { status: result.status });
}
