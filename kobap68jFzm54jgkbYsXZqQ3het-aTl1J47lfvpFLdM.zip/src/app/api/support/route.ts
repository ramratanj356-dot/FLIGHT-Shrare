import { assertSameOrigin, handleApiError, jsonError, jsonOk } from "@/lib/security/http";
import { getSessionUser } from "@/lib/auth/session";
import { supportTicketSchema } from "@/lib/validation/schemas";
import { createSupportTicket } from "@/lib/services/admin";
import { enforceRateLimit } from "@/lib/security/rateLimit";

export const runtime = "nodejs";

/** System account that owns contact-form tickets filed by signed-out visitors. */
const INTAKE_USER_ID = "usr_intake";

export async function POST(req: Request) {
  try {
    if (!assertSameOrigin(req)) return jsonError(403, "Cross-origin request blocked");
    // Signed-in passengers get account-scoped tickets. Visitors may still
    // contact us from the help centre; their submission is attached to the
    // system intake account and rate-limited per IP address.
    const user = await getSessionUser();
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
    const limitKey = user ? `support:${user.id}` : `support:ip:${ip}`;
    const limit = enforceRateLimit(limitKey, user ? 5 : 3, 3600);
    if (!limit.ok) return jsonError(429, "You have opened several tickets recently. We'll reply on the existing ones.");
    const input = supportTicketSchema.parse(await req.json());
    const actorId = user?.id ?? INTAKE_USER_ID;
    const body = user ? input.body : `${input.body}\n\n(Submitted from the public help centre.)`;
    return jsonOk(createSupportTicket(actorId, { ...input, body }));
  } catch (err) {
    return handleApiError(err);
  }
}
