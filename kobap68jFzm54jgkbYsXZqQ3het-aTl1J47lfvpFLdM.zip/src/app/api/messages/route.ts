import { assertSameOrigin, handleApiError, jsonError, jsonOk } from "@/lib/security/http";
import { requireApiUser } from "@/lib/auth/guards";
import { postMessage } from "@/lib/services/chat";
import { messageSchema } from "@/lib/validation/schemas";
import { enforceRateLimit } from "@/lib/security/rateLimit";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    if (!assertSameOrigin(req)) return jsonError(403, "Cross-origin request blocked");
    const user = await requireApiUser();
    const limit = enforceRateLimit(`msg:${user.id}`, 30, 60);
    if (!limit.ok) return jsonError(429, "You're sending messages too quickly.");
    const input = messageSchema.parse(await req.json());
    return jsonOk(postMessage(user, input.rideId, input.body));
  } catch (err) {
    return handleApiError(err);
  }
}
