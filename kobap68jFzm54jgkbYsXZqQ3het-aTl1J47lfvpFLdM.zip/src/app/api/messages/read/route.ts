import { assertSameOrigin, handleApiError, jsonError, jsonOk } from "@/lib/security/http";
import { requireApiUser } from "@/lib/auth/guards";
import { markConversationRead } from "@/lib/services/chat";
import { canAccessConversation } from "@/lib/db/queries";
import { z } from "zod";

export const runtime = "nodejs";
const schema = z.object({ conversationId: z.string().min(1) });

export async function POST(req: Request) {
  try {
    if (!assertSameOrigin(req)) return jsonError(403, "Cross-origin request blocked");
    const user = await requireApiUser();
    const { conversationId } = schema.parse(await req.json());
    if (!canAccessConversation(conversationId, user.id)) return jsonError(403, "You are not part of this conversation");
    return jsonOk(markConversationRead(conversationId, user.id));
  } catch (err) {
    return handleApiError(err);
  }
}
