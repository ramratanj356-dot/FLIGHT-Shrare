import { assertSameOrigin, handleApiError, jsonOk } from "@/lib/security/http";
import { requireApiUser } from "@/lib/auth/guards";
import { getDb } from "@/lib/db";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    if (!assertSameOrigin(req)) return new Response(null, { status: 403 });
    const user = await requireApiUser();
    const body = await req.json().catch(() => ({}));
    const db = getDb();
    const now = new Date().toISOString();
    if (typeof body.id === "string") {
      db.prepare("UPDATE notifications SET read_at = ? WHERE id = ? AND user_id = ?").run(now, body.id, user.id);
    } else {
      db.prepare("UPDATE notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL").run(now, user.id);
    }
    return jsonOk({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}
