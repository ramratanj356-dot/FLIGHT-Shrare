import { handleApiError, jsonOk } from "@/lib/security/http";
import { listFlightsForDate, listFlightDates } from "@/lib/db/queries";
import { getDb } from "@/lib/db";
import { FLIGHT_PROVIDER_MODE } from "@/lib/config/features";

export const runtime = "nodejs";

/**
 * Flight lookup. Returns records from the schedule table and states clearly
 * whether they come from a configured provider or the demo dataset.
 */
export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const date = url.searchParams.get("date");
    const airportId = url.searchParams.get("airport") ?? "apt_bom";

    if (!date) {
      return jsonOk({ dates: listFlightDates(airportId), source: FLIGHT_PROVIDER_MODE });
    }

    const flights = listFlightsForDate(airportId, date);
    const groups = getDb()
      .prepare(
        `SELECT f.flight_number, COUNT(rg.id) AS groups,
                SUM(CASE WHEN rg.seats_total > rg.seats_taken THEN 1 ELSE 0 END) AS with_seats
           FROM flights f LEFT JOIN ride_groups rg ON rg.flight_id = f.id AND rg.status IN ('open','full','confirmed')
          WHERE f.airport_id = ? AND f.flight_date = ? GROUP BY f.flight_number`,
      )
      .all(airportId, date) as { flight_number: string; groups: number; with_seats: number }[];

    return jsonOk({
      source: FLIGHT_PROVIDER_MODE,
      date,
      flights: flights.map((f) => {
        const g = groups.find((x) => x.flight_number === f.flight_number);
        return { ...f, groups: g?.groups ?? 0, groupsWithSeats: g?.with_seats ?? 0 };
      }),
    });
  } catch (err) {
    return handleApiError(err);
  }
}
