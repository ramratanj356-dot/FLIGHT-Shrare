import Link from "next/link";
import { LoginForm } from "@/components/forms/auth-forms";
import { DemoBadge } from "@/components/ui/primitives";
import { AUTH_GOOGLE_MODE } from "@/lib/config/features";

export const metadata = { title: "Sign in" };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string; message?: string }> }) {
  const sp = await searchParams;
  return (
    <div>
      <h1 className="text-[26px] font-bold tracking-[-0.02em] text-navy">Welcome back</h1>
      <p className="mt-1.5 text-[13.5px] text-ink-muted">Sign in to see your trips, matches and ride chats.</p>
      <LoginForm next={sp.next} message={sp.message} googleEnabled={AUTH_GOOGLE_MODE === "oauth"} />
      <p className="mt-6 text-center text-[13px] text-ink-muted">
        New to FlightShare? <Link href="/signup" className="link">Create an account</Link>
      </p>
      <div className="mt-8 rounded-xl border border-line bg-white p-3.5">
        <div className="flex items-center justify-between">
          <p className="text-[11px] font-bold uppercase tracking-wide text-ink-muted">Demo accounts</p>
          <DemoBadge label="PRE-FILLED" />
        </div>
        <p className="mt-1.5 text-[11px] leading-relaxed text-ink-muted">
          One click fills the form. These accounts exist only in this demo database.
        </p>
      </div>
    </div>
  );
}
