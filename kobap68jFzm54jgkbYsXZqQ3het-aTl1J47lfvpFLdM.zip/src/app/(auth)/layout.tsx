import Link from "next/link";
import { ArrowLeft, ShieldCheck } from "lucide-react";
import { Logo } from "@/components/brand/logo";
import { Badge } from "@/components/ui/primitives";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-canvas lg:grid lg:grid-cols-[1fr_0.95fr]">
      <div className="flex min-h-screen flex-col px-5 py-7 sm:px-8 lg:px-12">
        <div className="flex items-center justify-between">
          <Link href="/" aria-label="FlightShare home"><Logo /></Link>
          <Link href="/" className="inline-flex items-center gap-1.5 text-[12.5px] font-medium text-ink-muted hover:text-indigo">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to site
          </Link>
        </div>
        <div className="flex flex-1 items-center justify-center py-10">
          <div className="w-full max-w-[404px]">{children}</div>
        </div>
        <p className="text-center text-[11px] text-ink-muted">
          Prototype environment · demo accounts available on the sign-in screen
        </p>
      </div>

      <aside className="relative hidden overflow-hidden bg-navy lg:block">
        <div className="pointer-events-none absolute inset-0 opacity-[0.14]" style={{ backgroundImage: "radial-gradient(#9C93FF 0.6px, transparent 0.6px)", backgroundSize: "20px 20px" }} />
        <div className="pointer-events-none absolute -right-20 top-1/4 h-96 w-96 rounded-full bg-[radial-gradient(circle,rgba(81,69,255,0.45),transparent_65%)]" />
        <div className="relative flex h-full flex-col justify-between p-12">
          <Badge tone="white" className="w-fit">Same flight. Same direction. One shared ride.</Badge>

          <div>
            <h2 className="max-w-sm text-[34px] font-bold leading-[1.1] tracking-[-0.03em] text-white">
              Land together.
              <br />
              Travel together.
            </h2>
            <p className="mt-4 max-w-sm text-[14px] leading-relaxed text-white/55">
              Verified passengers from your own flight, heading your way. Transparent fare splitting, coordinated departures,
              and a group chat limited to the people actually in your cab.
            </p>

            <div className="mt-9 space-y-3">
              {[
                { label: "Three passengers, one vehicle", value: "₹1,144 total" },
                { label: "Each traveller pays", value: "₹392 · ₹360 · ₹392" },
                { label: "Combined saving vs solo cabs", value: "₹2,136" },
              ].map((row) => (
                <div key={row.label} className="flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3">
                  <span className="text-[12px] text-white/50">{row.label}</span>
                  <span className="text-[13px] font-semibold text-white tabular">{row.value}</span>
                </div>
              ))}
            </div>
            <p className="mt-3 text-[10.5px] text-white/35">Sample group · estimates, not charges</p>
          </div>

          <div className="flex items-start gap-2.5 rounded-xl border border-white/10 bg-white/[0.04] p-3.5">
            <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#8BE3B8]" />
            <p className="text-[11px] leading-relaxed text-white/50">
              Passwords are hashed with scrypt. Sessions are HttpOnly cookies. Every protected action is authorised on the server —
              never by a hidden button.
            </p>
          </div>
        </div>
      </aside>
    </div>
  );
}
