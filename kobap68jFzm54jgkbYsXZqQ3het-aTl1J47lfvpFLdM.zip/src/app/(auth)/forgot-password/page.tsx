import Link from "next/link";
import { ForgotPasswordForm } from "@/components/forms/auth-forms";

export const metadata = { title: "Reset your password" };

export default function ForgotPasswordPage() {
  return (
    <div>
      <h1 className="text-[26px] font-bold tracking-[-0.02em] text-navy">Reset your password</h1>
      <p className="mt-1.5 text-[13.5px] leading-relaxed text-ink-muted">
        Enter the email on your account and we&apos;ll send a reset link. The link expires in one hour and signs out all other sessions.
      </p>
      <ForgotPasswordForm />
      <p className="mt-6 text-center text-[13px] text-ink-muted">
        <Link href="/login" className="link">Back to sign in</Link>
      </p>
    </div>
  );
}
