import Link from "next/link";
import { SignupForm } from "@/components/forms/auth-forms";

export const metadata = { title: "Create your account" };

export default async function SignupPage({ searchParams }: { searchParams: Promise<{ role?: string }> }) {
  const sp = await searchParams;
  const role = sp.role === "driver" ? "driver" : "passenger";
  return (
    <div>
      <h1 className="text-[26px] font-bold tracking-[-0.02em] text-navy">
        {role === "driver" ? "Join as a driver" : "Create your account"}
      </h1>
      <p className="mt-1.5 text-[13.5px] leading-relaxed text-ink-muted">
        {role === "driver"
          ? "Register your vehicle and documents. An administrator reviews verification before you can accept trips."
          : "Free to join. You only ever pay a share of a ride you confirm."}
      </p>
      <SignupForm defaultRole={role} />
      <p className="mt-6 text-center text-[13px] text-ink-muted">
        Already have an account? <Link href="/login" className="link">Sign in</Link>
      </p>
    </div>
  );
}
