import Link from "next/link";
import { EmailVerifyPanel } from "@/components/forms/auth-forms";

export const metadata = { title: "Verify your email" };

export default async function VerifyEmailPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const sp = await searchParams;
  return (
    <div>
      <h1 className="text-[26px] font-bold tracking-[-0.02em] text-navy">Verify your email</h1>
      <p className="mt-1.5 text-[13.5px] leading-relaxed text-ink-muted">
        Verifying your email unlocks joining rides and receiving trip updates.
      </p>
      <EmailVerifyPanel token={sp.token} />
      <p className="mt-6 text-center text-[13px] text-ink-muted">
        <Link href="/app" className="link">Go to dashboard</Link>
      </p>
    </div>
  );
}
