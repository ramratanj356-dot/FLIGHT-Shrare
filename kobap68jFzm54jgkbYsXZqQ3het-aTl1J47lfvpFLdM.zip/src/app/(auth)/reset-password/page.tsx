import { ResetPasswordForm } from "@/components/forms/auth-forms";
import { Alert } from "@/components/ui/primitives";

export const metadata = { title: "Choose a new password" };

export default async function ResetPasswordPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const sp = await searchParams;
  if (!sp.token) {
    return (
      <div>
        <h1 className="text-[26px] font-bold tracking-[-0.02em] text-navy">Reset link missing</h1>
        <div className="mt-4">
          <Alert tone="warning" title="This link is incomplete">
            Open the reset link from your email exactly as sent, or request a new one from the{" "}
            <a className="underline" href="/forgot-password">forgot password</a> page.
          </Alert>
        </div>
      </div>
    );
  }
  return (
    <div>
      <h1 className="text-[26px] font-bold tracking-[-0.02em] text-navy">Choose a new password</h1>
      <p className="mt-1.5 text-[13.5px] text-ink-muted">Use at least 8 characters with a letter and a number.</p>
      <ResetPasswordForm token={sp.token} />
    </div>
  );
}
