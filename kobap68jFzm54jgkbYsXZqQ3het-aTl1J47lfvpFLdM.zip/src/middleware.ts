import { NextResponse, type NextRequest } from "next/server";

/**
 * Edge-level gate for authenticated sections. This is a *fast fail* only:
 * it checks for the presence of a session cookie, not its validity.
 * Every page and API route independently re-verifies the session, role and
 * resource ownership server-side (see `lib/auth/guards.ts` and the services),
 * so a forged or expired cookie still cannot reach protected data.
 */

const SESSION_COOKIE = "fs_session";

const ROLE_PREFIX: { prefix: string; roles: string[]; login: string }[] = [
  { prefix: "/admin", roles: ["admin", "support"], login: "/login?next=/admin" },
  { prefix: "/driver", roles: ["driver", "admin"], login: "/login?next=/driver" },
  { prefix: "/app", roles: ["passenger", "driver", "admin", "support"], login: "/login?next=/app" },
];

const AUTH_PAGES = ["/login", "/signup", "/forgot-password"];

export function middleware(req: NextRequest) {
  const { pathname, search } = req.nextUrl;
  const hasSession = Boolean(req.cookies.get(SESSION_COOKIE)?.value);

  // Signed-in users shouldn't sit on the login/signup screens.
  if (hasSession && AUTH_PAGES.includes(pathname)) {
    return NextResponse.redirect(new URL("/app", req.url));
  }

  const rule = ROLE_PREFIX.find((r) => pathname === r.prefix || pathname.startsWith(`${r.prefix}/`));
  if (!rule) return NextResponse.next();

  if (!hasSession) {
    const target = new URL(rule.login, req.url);
    // Preserve the intended destination so login can bounce the user back.
    target.searchParams.set("next", `${pathname}${search}`);
    const res = NextResponse.redirect(target);
    res.headers.set("x-flightshare-auth", "missing-session");
    return res;
  }

  const res = NextResponse.next();
  // Role is deliberately NOT trusted from the cookie here — the layout guard
  // enforces it against the database on every render.
  res.headers.set("x-flightshare-auth", "present");
  return res;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|fonts|icons).*)"],
};
