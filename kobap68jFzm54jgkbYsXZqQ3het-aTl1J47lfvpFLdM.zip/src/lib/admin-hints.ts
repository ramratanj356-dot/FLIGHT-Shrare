export const SUPPORT_ACCOUNT_HINT =
  "Support accounts can triage tickets and view ride status, but cannot change pricing, verify drivers or process refunds. Those actions require the admin role and are enforced on the server.";
