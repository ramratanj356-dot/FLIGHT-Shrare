import { READINESS_ORDER, type PricingRules, type ReadinessState } from "@/lib/config/pricing";

export type FlightStatusCode = "scheduled" | "enroute" | "landed" | "delayed" | "cancelled";

export interface TimingInput {
  scheduledArrival: string | Date;
  estimatedArrival: string | Date;
  status: FlightStatusCode;
  /** Minutes an average passenger needs from landing to kerb. */
  baggageClaimMinutes: number;
  /** Hard ceiling the group will wait at the kerb. */
  maxWaitMinutes: number;
  /** Each accepted member's current readiness + their own expected-ready estimate. */
  members: { readiness: ReadinessState; expectedReadyAt: string | Date }[];
  now?: Date;
}

export interface DepartureWindow {
  earliestReadyAt: Date;
  latestReadyAt: Date;
  recommendedDepartureAt: Date;
  /** Minutes between the earliest and latest ready times. */
  spreadMinutes: number;
  /** Members still not at the meeting point. */
  pendingMembers: number;
  /** True when the group window exceeds the configured wait ceiling. */
  exceedsWait: boolean;
  statusLabel: string;
}

export function expectedReadyAt(
  estimatedArrival: string | Date,
  baggageClaimMinutes: number,
  bufferMinutes = 10,
) {
  return new Date(new Date(estimatedArrival).getTime() + (baggageClaimMinutes + bufferMinutes) * 60_000);
}

export function computeDepartureWindow(input: TimingInput): DepartureWindow {
  const now = input.now ?? new Date();
  const arrival = new Date(input.estimatedArrival);
  const readyTimes = input.members.map((m) =>
    m.readiness === "ready_at_meeting_point" || READINESS_ORDER[m.readiness] >= READINESS_ORDER.ready_at_meeting_point
      ? now
      : new Date(m.expectedReadyAt),
  );

  const baseline = expectedReadyAt(arrival, input.baggageClaimMinutes);
  const earliest = new Date(Math.max(baseline.getTime(), now.getTime()));
  const latest = readyTimes.length ? new Date(Math.max(...readyTimes.map((d) => d.getTime()))) : baseline;
  const recommended = new Date(Math.max(earliest.getTime(), latest.getTime()));

  const spreadMinutes = Math.max(0, Math.round((latest.getTime() - earliest.getTime()) / 60_000));
  const exceedsWait = spreadMinutes > input.maxWaitMinutes;

  let statusLabel = "Waiting for arrival";
  if (input.status === "cancelled") statusLabel = "Flight cancelled";
  else if (input.status === "delayed") statusLabel = "Flight delayed";
  else if (now < arrival) statusLabel = "Flight not landed";
  else if (exceedsWait) statusLabel = "Waiting beyond window";
  else if (latest > now) statusLabel = "Collecting baggage";
  else statusLabel = "Ready to depart";

  return {
    earliestReadyAt: earliest,
    latestReadyAt: latest,
    recommendedDepartureAt: recommended,
    spreadMinutes,
    pendingMembers: input.members.filter((m) => READINESS_ORDER[m.readiness] < READINESS_ORDER.ready_at_meeting_point)
      .length,
    exceedsWait,
    statusLabel,
  };
}

/** Minutes between a passenger's own readiness and the group's recommended departure. */
export function timingGapMinutes(passengerReadyAt: string | Date, groupDepartureAt: string | Date) {
  return Math.abs(new Date(passengerReadyAt).getTime() - new Date(groupDepartureAt).getTime()) / 60_000;
}

/** Readiness for a arriving flight as of `now` (used by the tracking UI). */
export function inferReadiness(
  estimatedArrival: string | Date,
  baggageClaimMinutes: number,
  explicit: ReadinessState | null,
  now = new Date(),
): ReadinessState {
  if (explicit) return explicit;
  const arrival = new Date(estimatedArrival);
  if (now < arrival) return "not_landed";
  const ready = expectedReadyAt(arrival, baggageClaimMinutes, 0);
  if (now < new Date(arrival.getTime() + 5 * 60_000)) return "landed";
  if (now < ready) return "collecting_baggage";
  return "ready_at_meeting_point";
}

export function waitPolicy(maxWaitMinutes: number, rules: PricingRules) {
  return {
    maxWaitMinutes,
    graceMinutes: rules.readinessGraceMinutes,
    cancellationRule: `If a confirmed member is not at the meeting point within ${maxWaitMinutes} minutes of the group window, the coordinator can remove them and the group continues with the remaining passengers.`,
    rematchRule: `If fewer than half the members are ready after ${maxWaitMinutes + rules.readinessGraceMinutes} minutes, the ride returns to matching and each passenger is re-offered alternatives.`,
  };
}
