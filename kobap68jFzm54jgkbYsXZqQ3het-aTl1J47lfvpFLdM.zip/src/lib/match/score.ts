import type { DestinationSeed } from "@/lib/data/destinations";
import type { PricingRules, VehicleCategory } from "@/lib/config/pricing";
import { destinationCompatibility, routeEfficiency } from "./geo";

export type MatchReasonTone = "positive" | "neutral" | "warning";

export interface MatchReason {
  tone: MatchReasonTone;
  label: string;
  detail: string;
  /** Which scoring dimension produced this reason. */
  dimension: keyof PricingRules["weights"];
}

export interface SearchIntent {
  airportId: string;
  airlineCode: string;
  flightNumber: string;
  flightDate: string; // yyyy-mm-dd
  destination: DestinationSeed;
  passengers: number;
  luggageUnits: number;
  expectedReadyAt: string | Date;
}

export interface RideGroupSnapshot {
  id: string;
  airportId: string;
  airlineCode: string;
  flightNumber: string;
  flightDate: string;
  scheduledArrival: string | Date;
  estimatedArrival: string | Date;
  flightStatus: "scheduled" | "enroute" | "landed" | "delayed" | "cancelled";
  destination: DestinationSeed;
  additionalStops: DestinationSeed[];
  vehicleCategory: VehicleCategory;
  seatsTotal: number;
  seatsTaken: number;
  luggageTotal: number;
  luggageTaken: number;
  departureWindowStart: string | Date;
  members: {
    readiness: string;
    expectedReadyAt: string | Date;
    flightVerified: boolean;
    identityVerified: boolean;
  }[];
}

export interface MatchResult {
  groupId: string;
  score: number;
  components: Record<keyof PricingRules["weights"], number>;
  reasons: MatchReason[];
  /** Hard failures that make joining impossible regardless of score. */
  blockers: string[];
  eligible: boolean;
  seatsAvailable: number;
  luggageAvailable: number;
}

const clamp01 = (n: number) => Math.min(1, Math.max(0, n));

function normalizeFlightNumber(v: string) {
  return v.replace(/\s+/g, "").toUpperCase();
}

export function scoreMatch(
  intent: SearchIntent,
  group: RideGroupSnapshot,
  rules: PricingRules,
): MatchResult {
  const blockers: string[] = [];
  const reasons: MatchReason[] = [];

  // ── Hard gates ────────────────────────────────────────────────
  if (intent.airportId !== group.airportId) blockers.push("Different arrival airport");
  if (intent.flightDate !== group.flightDate) blockers.push("Different travel date");

  const sameFlight =
    normalizeFlightNumber(intent.flightNumber) === normalizeFlightNumber(group.flightNumber) &&
    intent.airlineCode === group.airlineCode;

  const arrivalDeltaMin = Math.abs(
    new Date(intent.expectedReadyAt).getTime() - new Date(group.departureWindowStart).getTime(),
  ) / 60_000;

  const seatsAvailable = Math.max(0, group.seatsTotal - group.seatsTaken);
  const luggageAvailable = Math.max(0, group.luggageTotal - group.luggageTaken);

  if (seatsAvailable < intent.passengers) {
    blockers.push(
      seatsAvailable === 0
        ? "This ride group is full"
        : `Only ${seatsAvailable} seat${seatsAvailable === 1 ? "" : "s"} left for ${intent.passengers} passenger${intent.passengers === 1 ? "" : "s"}`,
    );
  }
  if (luggageAvailable < intent.luggageUnits) {
    blockers.push(
      luggageAvailable === 0 ? "No luggage space left in this vehicle" : `Luggage space is tight — ${luggageAvailable} unit${luggageAvailable === 1 ? "" : "s"} left`,
    );
  }
  if (group.flightStatus === "cancelled") blockers.push("The group's flight is cancelled");

  // ── Component scores (0..1) ───────────────────────────────────
  const flightScore = sameFlight ? 1 : intent.airlineCode === group.airlineCode && arrivalDeltaMin <= 90 ? 0.45 : 0.1;

  const destinationScore = destinationCompatibility(intent.destination, group.destination);

  const capacityScore = seatsAvailable <= 0 ? 0 : clamp01(seatsAvailable / Math.max(intent.passengers, 1) / 2 + 0.5);

  const luggageScore =
    luggageAvailable <= 0 ? 0 : clamp01((luggageAvailable - intent.luggageUnits) / Math.max(group.luggageTotal, 1) + 0.55);

  const timingScore = clamp01(1 - arrivalDeltaMin / Math.max(rules.maxWaitMinutes, 15));

  const routeScore = routeEfficiency([group.destination, ...group.additionalStops]);

  const verifiedMembers = group.members.filter((m) => m.flightVerified).length;
  const trustScore = group.members.length ? clamp01(0.4 + 0.6 * (verifiedMembers / group.members.length)) : 0.6;

  const components = {
    flight: flightScore,
    destination: destinationScore,
    capacity: capacityScore,
    luggage: luggageScore,
    timing: timingScore,
    route: routeScore,
    trust: trustScore,
  };

  const weightTotal = Object.values(rules.weights).reduce((a, b) => a + b, 0) || 100;
  const weighted = (Object.keys(components) as (keyof typeof components)[]).reduce(
    (sum, key) => sum + components[key] * rules.weights[key],
    0,
  );
  let score = Math.round((weighted / weightTotal) * 100);

  if (blockers.length) score = Math.min(score, 45);

  // ── Human-readable explanations ───────────────────────────────
  if (sameFlight) {
    reasons.push({
      tone: "positive",
      dimension: "flight",
      label: "Same verified flight",
      detail: `Both bookings are on ${group.airlineCode} ${group.flightNumber} arriving ${group.flightDate}.`,
    });
  } else if (flightScore >= 0.4) {
    reasons.push({
      tone: "neutral",
      dimension: "flight",
      label: "Same airline, nearby arrival",
      detail: "A different flight number but an arrival within 90 minutes of this group's window.",
    });
  } else {
    reasons.push({
      tone: "warning",
      dimension: "flight",
      label: "Different flight",
      detail: "This group is on a separate flight. Timing is less predictable.",
    });
  }

  if (destinationScore >= 0.85) {
    reasons.push({
      tone: "positive",
      dimension: "destination",
      label: "Same neighbourhood",
      detail: `${intent.destination.name} and ${group.destination.name} are minutes apart.`,
    });
  } else if (destinationScore >= rules.destinationThreshold) {
    reasons.push({
      tone: "positive",
      dimension: "destination",
      label: "Destinations are along a compatible route",
      detail: `${intent.destination.name} sits close to the ${group.destination.name} corridor, so one drop-off sequence works.`,
    });
  } else {
    reasons.push({
      tone: "warning",
      dimension: "destination",
      label: "Destinations diverge",
      detail: `${intent.destination.name} is not on the ${group.destination.name} route; expect a longer detour.`,
    });
  }

  reasons.push(
    seatsAvailable >= intent.passengers
      ? {
          tone: "positive",
          dimension: "capacity",
          label: "Vehicle has enough available seats",
          detail: `${seatsAvailable} of ${group.seatsTotal} seats free in a ${group.vehicleCategory.toUpperCase()}.`,
        }
      : {
          tone: "warning",
          dimension: "capacity",
          label: "Not enough seats",
          detail: `${seatsAvailable} seat${seatsAvailable === 1 ? "" : "s"} available, ${intent.passengers} needed.`,
        },
  );

  reasons.push(
    arrivalDeltaMin <= rules.maxWaitMinutes / 2
      ? {
          tone: "positive",
          dimension: "timing",
          label: "Departure times are compatible",
          detail: `Your expected kerb time is ${Math.round(arrivalDeltaMin)} minutes from the group window.`,
        }
      : {
          tone: arrivalDeltaMin <= rules.maxWaitMinutes ? "neutral" : "warning",
          dimension: "timing",
          label: "Timing is workable but tight",
          detail: `About ${Math.round(arrivalDeltaMin)} minutes apart; the group waits up to ${rules.maxWaitMinutes} minutes.`,
        },
  );

  if (trustScore >= 0.9) {
    reasons.push({
      tone: "positive",
      dimension: "trust",
      label: "All members flight-verified",
      detail: "Every accepted passenger has a verified booking reference for this flight.",
    });
  }

  return {
    groupId: group.id,
    score,
    components,
    reasons,
    blockers,
    eligible: blockers.length === 0 && destinationScore >= rules.destinationThreshold,
    seatsAvailable,
    luggageAvailable,
  };
}

export function scoreBand(score: number) {
  if (score >= 85) return { label: "Excellent match", tone: "success" as const };
  if (score >= 70) return { label: "Strong match", tone: "indigo" as const };
  if (score >= 55) return { label: "Possible match", tone: "amber" as const };
  return { label: "Weak match", tone: "muted" as const };
}
