import { affinityKey, AFFINITY, type DestinationSeed, type Corridor } from "@/lib/data/destinations";
import { BOM_TERMINALS } from "@/lib/data/destinations";

/** Great-circle km between two coordinates. */
export function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const lat1 = (a.lat * Math.PI) / 180;
  const lat2 = (b.lat * Math.PI) / 180;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/** Compass bearing from `a` to `b`, degrees 0–360. */
export function bearingDeg(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const y = Math.sin(toRad(b.lng - a.lng)) * Math.cos(toRad(b.lat));
  const x =
    Math.cos(toRad(a.lat)) * Math.sin(toRad(b.lat)) -
    Math.sin(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.cos(toRad(b.lng - a.lng));
  return ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;
}

const ADJACENT: Record<Corridor, Corridor[]> = {
  "western-suburbs": ["central-suburbs", "south-mumbai"],
  "central-suburbs": ["western-suburbs", "thane-corridor", "harbour-corridor", "south-mumbai"],
  "thane-corridor": ["central-suburbs", "harbour-corridor"],
  "harbour-corridor": ["central-suburbs", "thane-corridor"],
  "south-mumbai": ["western-suburbs", "central-suburbs"],
};

/**
 * Destination compatibility, 0..1.
 *
 * Order of precedence:
 *  1. identical destination  → 1
 *  2. curated affinity table → curated value (encodes local road reality)
 *  3. same corridor          → high, adjusted by distance delta
 *  4. adjacent corridor      → moderate, penalised by direction divergence
 *  5. anything else          → low
 */
export function destinationCompatibility(a: DestinationSeed, b: DestinationSeed) {
  if (a.id === b.id) return 1;

  const curated = AFFINITY[affinityKey(a.id, b.id)];
  if (curated !== undefined) return curated;

  const airport = BOM_TERMINALS[0];
  const distDelta = Math.abs(a.distanceKm - b.distanceKm) / Math.max(a.distanceKm, b.distanceKm, 1);
  const theta = Math.abs(bearingDeg(airport, a) - bearingDeg(airport, b));
  const angleDiff = Math.min(theta, 360 - theta); // 0..180
  const directionFactor = 1 - Math.min(1, angleDiff / 110); // ~same heading → 1

  // Travelling in opposite directions from the airport is never a shared route,
  // no matter how similar the distances are (e.g. Colaba vs Borivali).
  const opposite = directionFactor < 0.25 ? 0.35 : 1;

  if (a.corridor === b.corridor) {
    return round3((0.62 + 0.3 * (1 - distDelta) * directionFactor) * opposite);
  }
  if (ADJACENT[a.corridor].includes(b.corridor)) {
    return round3((0.4 + 0.26 * (1 - distDelta) * directionFactor) * opposite);
  }
  return round3((0.1 + 0.12 * directionFactor) * opposite);
}

const round3 = (n: number) => Math.round(Math.min(1, Math.max(0, n)) * 1000) / 1000;

/** Straight-line route overlap used for the route-efficiency score. */
export function routeEfficiency(destinations: DestinationSeed[]) {
  if (destinations.length <= 1) return 1;
  const longest = Math.max(...destinations.map((d) => d.distanceKm));
  const pairs = destinations.length - 1;
  const detour = pairs * 2.4;
  const naive = destinations.reduce((s, d) => s + d.distanceKm, 0);
  const shared = longest + detour;
  return round3(Math.min(1, Math.max(0, 1 - (shared - longest) / Math.max(naive, 1)) ));
}
