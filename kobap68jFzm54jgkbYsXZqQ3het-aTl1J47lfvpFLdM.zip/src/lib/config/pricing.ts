/**
 * Pricing and operational rules.
 *
 * Values live in the `pricing_rules` table and are loaded per-request so
 * operations can change them without a deploy. These constants are the
 * defaults used to seed the table and the safe fallback if a key is missing.
 *
 * All money is integer paise.
 */
export type FareStrategy = "equal" | "distance" | "hybrid";

export interface PricingRules {
  /** Fixed flag-fall for an airport transfer. */
  baseFarePaise: number;
  /** Per-kilometre component applied to the shared route distance. */
  perKmPaise: number;
  /** Detour added to the route for every additional drop-off. */
  detourKmPerStop: number;
  /** Surcharge for each additional drop-off beyond the first. */
  extraStopPaise: number;
  /** Platform service fee in basis points of the vehicle fare (800 = 8%). */
  platformFeeBps: number;
  /** Floor for the platform fee. */
  platformFeeMinPaise: number;
  /** Tax applied on the platform fee only (18% GST on the service). */
  platformFeeTaxBps: number;
  /** Default allocation strategy. */
  defaultStrategy: FareStrategy;
  /** Fare estimates are only valid for this long. */
  estimateTtlMinutes: number;
  /** How long a group is willing to wait at the airport after landing. */
  maxWaitMinutes: number;
  /** Minutes assumed between "landed" and "baggage collected + at kerb". */
  baggageClaimMinutes: number;
  /** Minimum destination-compatibility score (0..1) required to match. */
  destinationThreshold: number;
  /** Matching weights — must sum to 100. */
  weights: {
    flight: number;
    destination: number;
    capacity: number;
    luggage: number;
    timing: number;
    route: number;
    trust: number;
  };
  /** A group auto-rematches when a member is not ready by this many minutes. */
  readinessGraceMinutes: number;
  /** Maximum passengers per shared vehicle, by category. */
  vehicleCapacity: Record<VehicleCategory, { seats: number; luggage: number }>;
}

export type VehicleCategory = "sedan" | "suv" | "mpv";

export const DEFAULT_PRICING_RULES: PricingRules = {
  baseFarePaise: 24_000,
  perKmPaise: 2_500,
  detourKmPerStop: 2.4,
  extraStopPaise: 5_000,
  platformFeeBps: 800,
  platformFeeMinPaise: 2_500,
  platformFeeTaxBps: 1800,
  defaultStrategy: "hybrid",
  estimateTtlMinutes: 45,
  maxWaitMinutes: 45,
  baggageClaimMinutes: 30,
  destinationThreshold: 0.6,
  weights: { flight: 30, destination: 25, capacity: 10, luggage: 5, timing: 15, route: 10, trust: 5 },
  readinessGraceMinutes: 20,
  vehicleCapacity: {
    sedan: { seats: 4, luggage: 3 },
    suv: { seats: 6, luggage: 5 },
    mpv: { seats: 6, luggage: 6 },
  },
};

export const VEHICLE_LABELS: Record<VehicleCategory, string> = {
  sedan: "Sedan",
  suv: "SUV",
  mpv: "MPV",
};

export const STRATEGY_LABELS: Record<FareStrategy, string> = {
  equal: "Equal split",
  distance: "Distance-weighted",
  hybrid: "Hybrid split",
};

export const STRATEGY_HELP: Record<FareStrategy, string> = {
  equal: "The shared fare is divided equally among seats. Simplest to explain, best for similar destinations.",
  distance: "Each passenger pays in proportion to the distance of their drop-off along the shared route.",
  hybrid: "Half of the shared fare is split equally; half is weighted by distance. A pragmatic default.",
};

export const READINESS_STATES = [
  "not_landed",
  "landed",
  "collecting_baggage",
  "ready_at_meeting_point",
  "boarding_vehicle",
  "trip_started",
] as const;
export type ReadinessState = (typeof READINESS_STATES)[number];

export const READINESS_LABELS: Record<ReadinessState, string> = {
  not_landed: "Flight not landed",
  landed: "Flight landed",
  collecting_baggage: "Collecting baggage",
  ready_at_meeting_point: "Ready at meeting point",
  boarding_vehicle: "Boarding vehicle",
  trip_started: "Trip started",
};

export const READINESS_ORDER: Record<ReadinessState, number> = {
  not_landed: 0, landed: 1, collecting_baggage: 2, ready_at_meeting_point: 3, boarding_vehicle: 4, trip_started: 5,
};

/** Merge DB overrides onto defaults without letting a bad value break pricing. */
export function withOverrides(overrides: Partial<PricingRules>): PricingRules {
  return {
    ...DEFAULT_PRICING_RULES,
    ...overrides,
    weights: { ...DEFAULT_PRICING_RULES.weights, ...(overrides.weights ?? {}) },
    vehicleCapacity: { ...DEFAULT_PRICING_RULES.vehicleCapacity, ...(overrides.vehicleCapacity ?? {}) },
  };
}
