/**
 * Integration readiness. The UI reads these flags to tell the user, honestly,
 * whether a dependency is live or simulated. Nothing here is a secret.
 */
export interface IntegrationStatus {
  key: string;
  name: string;
  configured: boolean;
  mode: "live" | "demo" | "optional";
  description: string;
  envKeys: string[];
  docsUrl?: string;
}

export const PAYMENTS_MODE: "demo" | "razorpay" =
  process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET ? "razorpay" : "demo";

export const FLIGHT_PROVIDER_MODE: "demo" | "provider" =
  process.env.FLIGHT_API_KEY && process.env.FLIGHT_API_PROVIDER ? "provider" : "demo";

export const MAPS_MODE: "demo" | "mapbox" = process.env.NEXT_PUBLIC_MAPBOX_TOKEN ? "mapbox" : "demo";

export const AUTH_GOOGLE_MODE: "demo" | "oauth" =
  process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET ? "oauth" : "demo";

export const EMAIL_MODE: "demo" | "provider" = process.env.EMAIL_API_KEY ? "provider" : "demo";

export const VERIFICATION_MODE: "simulated" | "provider" =
  process.env.VERIFICATION_API_KEY ? "provider" : "simulated";

export function integrations(): IntegrationStatus[] {
  return [
    {
      key: "database",
      name: "Database",
      configured: true,
      mode: "live",
      description:
        "Running on the bundled SQLite adapter with the production schema mirrored in PostgreSQL. Data persists across restarts.",
      envKeys: ["DATABASE_PATH"],
    },
    {
      key: "auth",
      name: "Authentication",
      configured: true,
      mode: "live",
      description:
        "Email + password sessions with scrypt hashing, HttpOnly cookies and server-side role checks. Google sign-in activates when OAuth credentials are added.",
      envKeys: ["AUTH_SECRET", "GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET"],
    },
    {
      key: "flight-data",
      name: "Flight data",
      configured: FLIGHT_PROVIDER_MODE === "provider",
      mode: FLIGHT_PROVIDER_MODE === "provider" ? "live" : "demo",
      description:
        FLIGHT_PROVIDER_MODE === "provider"
          ? "A flight-data provider is configured for schedules and status."
          : "Schedules and statuses come from the demo schedule table and are labelled SAMPLE DATA throughout.",
      envKeys: ["FLIGHT_API_PROVIDER", "FLIGHT_API_KEY"],
    },
    {
      key: "maps",
      name: "Maps & routing",
      configured: MAPS_MODE === "mapbox",
      mode: MAPS_MODE === "mapbox" ? "live" : "demo",
      description:
        MAPS_MODE === "mapbox"
          ? "Mapbox token detected for tiles and route geometry."
          : "An illustrative schematic map is used. Distances are curated estimates, not live routing.",
      envKeys: ["NEXT_PUBLIC_MAPBOX_TOKEN"],
    },
    {
      key: "payments",
      name: "Payments",
      configured: PAYMENTS_MODE === "razorpay",
      mode: PAYMENTS_MODE === "razorpay" ? "live" : "demo",
      description:
        PAYMENTS_MODE === "razorpay"
          ? "Razorpay keys detected. Orders are created server-side and signatures verified on every callback and webhook."
          : "Payment sandbox is inactive. Bookings are recorded as ESTIMATES ONLY — no money moves.",
      envKeys: ["RAZORPAY_KEY_ID", "RAZORPAY_KEY_SECRET", "RAZORPAY_WEBHOOK_SECRET"],
    },
    {
      key: "email",
      name: "Email",
      configured: EMAIL_MODE === "provider",
      mode: EMAIL_MODE === "provider" ? "live" : "demo",
      description:
        EMAIL_MODE === "provider"
          ? "Transactional email provider configured."
          : "Emails are written to the in-app notification centre and the server log instead of being sent.",
      envKeys: ["EMAIL_PROVIDER", "EMAIL_API_KEY", "EMAIL_FROM"],
    },
    {
      key: "identity",
      name: "Identity verification",
      configured: VERIFICATION_MODE === "provider",
      mode: VERIFICATION_MODE === "provider" ? "live" : "demo",
      description:
        VERIFICATION_MODE === "provider"
          ? "An identity provider is connected for document checks."
          : "Verification is SIMULATED and always labelled as such. No document is reviewed by a human or a provider.",
      envKeys: ["VERIFICATION_PROVIDER", "VERIFICATION_API_KEY"],
    },
    {
      key: "realtime",
      name: "Realtime",
      configured: true,
      mode: "live",
      description:
        "Ride chat, readiness and notifications stream over a low-latency polling channel confined to ride participants. Swap in Supabase Realtime by replacing the transport in useRealtime().",
      envKeys: ["NEXT_PUBLIC_SUPABASE_URL", "NEXT_PUBLIC_SUPABASE_ANON_KEY"],
    },
  ];
}

export const DEMO_MODE = FLIGHT_PROVIDER_MODE === "demo" || PAYMENTS_MODE === "demo";
