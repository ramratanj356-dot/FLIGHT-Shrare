import "server-only";
import { getDb, id, transaction } from "@/lib/db";
import type { SessionUser } from "@/lib/auth/session";
import { loadPricingRules } from "@/lib/db/pricing";
import { getDestination, getRideGroup, getGroupMembership, findFlight } from "@/lib/db/queries";
import { scoreMatch, type RideGroupSnapshot } from "@/lib/match/score";
import { computeDepartureWindow } from "@/lib/match/timing";
import { destinationCompatibility } from "@/lib/match/geo";
import { notify, audit, systemMessage, trackEvent } from "./audit";
import { recomputeGroupFare } from "./fares";
import { formatPaise } from "@/lib/money";
import type { DestinationSeed } from "@/lib/data/destinations";

import { ServiceError } from "@/lib/security/errors";
export { ServiceError };

const toSeed = (d: ReturnType<typeof getDestination>): DestinationSeed => ({
  id: d!.id,
  name: d!.name,
  area: d!.area,
  corridor: d!.corridor as DestinationSeed["corridor"],
  lat: d!.lat,
  lng: d!.lng,
  distanceKm: d!.distance_km,
  driveMinutes: d!.drive_minutes,
  soloFarePaise: d!.solo_fare_paise,
  tollsPaise: d!.tolls_paise,
  blurb: d!.blurb ?? "",
});

export function buildSnapshot(group: NonNullable<ReturnType<typeof getRideGroup>>): RideGroupSnapshot {
  return {
    id: group.id,
    airportId: group.flight.airport_id,
    airlineCode: group.flight.airline_code,
    flightNumber: group.flight.flight_number,
    flightDate: group.flight.flight_date,
    scheduledArrival: group.flight.scheduled_arrival,
    estimatedArrival: group.flight.estimated_arrival,
    flightStatus: group.flight.status,
    destination: toSeed(getDestination(group.destination.id)),
    additionalStops: group.extraDestinations.map((d) => toSeed(getDestination(d.id))),
    vehicleCategory: group.vehicleCategory,
    seatsTotal: group.seatsTotal,
    seatsTaken: group.seatsTaken,
    luggageTotal: group.luggageTotal,
    luggageTaken: group.luggageTaken,
    departureWindowStart: group.departureWindowStart,
    members: group.members.map((m) => ({
      readiness: m.readiness,
      expectedReadyAt: m.expectedReadyAt ?? group.departureWindowStart,
      flightVerified: m.flightVerified,
      identityVerified: m.identityVerified,
    })),
  };
}

/** Real-time match score for a viewer + a group. Used by results, join page and API. */
export function scoreGroupForViewer(
  viewer: SessionUser,
  groupId: string,
  intent: { destinationId: string; passengers: number; luggageUnits: number; flightNumber?: string; flightDate?: string; expectedReadyAt?: string },
) {
  const group = getRideGroup(groupId, viewer.id);
  if (!group) throw new ServiceError(404, "Ride group not found");
  const destination = getDestination(intent.destinationId);
  if (!destination) throw new ServiceError(400, "Choose a valid destination");
  const rules = loadPricingRules(getDb());

  return scoreMatch(
    {
      airportId: group.flight.airport_id,
      airlineCode: intent.flightNumber ? intent.flightNumber.replace(/[^A-Z0-9]/gi, "").replace(/\d+$/, "").toUpperCase() : group.flight.airline_code,
      flightNumber: intent.flightNumber ?? group.flight.flight_number,
      flightDate: intent.flightDate ?? group.flight.flight_date,
      destination: toSeed(destination),
      passengers: intent.passengers,
      luggageUnits: intent.luggageUnits,
      expectedReadyAt: intent.expectedReadyAt ?? group.departureWindowStart,
    },
    buildSnapshot(group),
    rules,
  );
}

// ── Join requests ───────────────────────────────────────────────────────────
export interface JoinRequestArgs {
  viewer: SessionUser;
  rideGroupId: string;
  passengerCount: number;
  luggageUnits: number;
  destinationId: string;
  bookingReference?: string;
  message?: string;
}

export function requestToJoin(args: JoinRequestArgs) {
  const db = getDb();
  const rules = loadPricingRules(db);

  return transaction((tx) => {
    const group = tx.prepare("SELECT * FROM ride_groups WHERE id = ?").get(args.rideGroupId) as Record<string, any> | undefined;
    if (!group) throw new ServiceError(404, "This ride group no longer exists");
    if (!["open", "full"].includes(group.status)) {
      throw new ServiceError(409, "This ride is not accepting new passengers right now", "group_closed");
    }
    if (group.created_by_user_id === args.viewer.id) {
      throw new ServiceError(409, "You already coordinate this ride", "already_owner");
    }

    const existingMember = tx
      .prepare("SELECT id FROM ride_members WHERE ride_group_id = ? AND user_id = ? AND status = 'accepted'")
      .get(args.rideGroupId, args.viewer.id);
    if (existingMember) throw new ServiceError(409, "You are already in this ride", "already_member");

    const existingRequest = tx
      .prepare("SELECT id, status FROM join_requests WHERE ride_group_id = ? AND user_id = ?")
      .get(args.rideGroupId, args.viewer.id) as { id: string; status: string } | undefined;
    if (existingRequest?.status === "pending") {
      throw new ServiceError(409, "Your request is already waiting for the coordinator", "duplicate_request");
    }

    const destination = getDestination(args.destinationId);
    if (!destination) throw new ServiceError(400, "Choose a valid destination");
    const groupDestination = getDestination(group.destination_id)!;
    const compatibility = destinationCompatibility(
      { ...toSeed(groupDestination) },
      { ...toSeed(destination) },
    );
    if (compatibility < rules.destinationThreshold) {
      throw new ServiceError(
        422,
        `${destination.name} is not on the ${groupDestination.name} route for this ride. Try a closer match or create your own ride.`,
        "incompatible_destination",
      );
    }

    const seatsLeft = group.seats_total - group.seats_taken;
    if (args.passengerCount > seatsLeft) {
      throw new ServiceError(
        409,
        seatsLeft === 0
          ? "This ride group just filled up. Try another group on the same flight."
          : `Only ${seatsLeft} seat${seatsLeft === 1 ? "" : "s"} left in this ride.`,
        "capacity",
      );
    }
    const luggageLeft = group.luggage_total - group.luggage_taken;
    if (args.luggageUnits > luggageLeft) {
      throw new ServiceError(409, `This vehicle has luggage space for ${luggageLeft} more unit(s).`, "luggage");
    }

    const flight = tx.prepare("SELECT * FROM flights WHERE id = ?").get(group.flight_id) as Record<string, any>;

    // Match score at the moment of requesting (stored for the coordinator's context).
    const summary = getRideGroup(args.rideGroupId, args.viewer.id);
    if (!summary) throw new ServiceError(404, "Ride group not found");
    const snapshot = buildSnapshot(summary);

    const score = scoreMatch(
      {
        airportId: flight.airport_id,
        airlineCode: flight.airline_code,
        flightNumber: flight.flight_number,
        flightDate: flight.flight_date,
        destination: toSeed(destination),
        passengers: args.passengerCount,
        luggageUnits: args.luggageUnits,
        expectedReadyAt: group.departure_window_start,
      },
      snapshot,
      rules,
    );

    const requestId = id("jr");
    const reference = args.bookingReference?.trim() || null;

    tx.prepare(
      `INSERT INTO join_requests (id, ride_group_id, user_id, passenger_count, luggage_units, destination_id, message, match_score, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)
       ON CONFLICT(ride_group_id, user_id) DO UPDATE SET
         passenger_count = excluded.passenger_count, luggage_units = excluded.luggage_units,
         destination_id = excluded.destination_id, message = excluded.message,
         match_score = excluded.match_score, status = 'pending', created_at = excluded.created_at`,
    ).run(
      requestId, args.rideGroupId, args.viewer.id, args.passengerCount, args.luggageUnits,
      args.destinationId, args.message?.trim() || null, score.score, new Date().toISOString(),
    );

    // Booking reference → flight verification (simulated unless a provider is configured).
    if (reference) {
      const existing = tx
        .prepare("SELECT id FROM flight_verifications WHERE user_id = ? AND flight_id = ?")
        .get(args.viewer.id, flight.id);
      const masked = `${"•".repeat(Math.max(2, reference.length - 2))}${reference.slice(-2)}`;
      const hash = Buffer.from(reference).toString("base64").slice(0, 12);
      if (existing) {
        tx.prepare("UPDATE flight_verifications SET status='pending', reference_masked=?, reference_hash=? WHERE id=?")
          .run(masked, hash, (existing as { id: string }).id);
      } else {
        tx.prepare(
          `INSERT INTO flight_verifications (id, user_id, flight_id, method, status, reference_masked, reference_hash, provider, notes, created_at)
           VALUES (?, ?, ?, 'booking_reference', 'pending', ?, ?, 'demo', 'Simulated check — no airline system was contacted.', ?)`,
        ).run(id("fv"), args.viewer.id, flight.id, masked, hash, new Date().toISOString());
      }
    }

    const ownerId = group.created_by_user_id;
    notify(tx, {
      userId: ownerId,
      type: "join_request",
      title: `${args.viewer.name.split(" ")[0]} wants to join ${group.code}`,
      body: `${args.passengerCount} passenger${args.passengerCount > 1 ? "s" : ""} heading to ${destination.name}. Match score ${score.score}/100. Review the request in your trip.`,
      rideGroupId: args.rideGroupId,
      href: `/app/trips/${args.rideGroupId}`,
      isDemo: true,
    });
    systemMessage(tx, {
      rideGroupId: args.rideGroupId,
      body: `${args.viewer.name.split(" ")[0]} requested to join (${args.passengerCount} passenger${args.passengerCount > 1 ? "s" : ""} → ${destination.name}).`,
    });

    audit(tx, {
      actorUserId: args.viewer.id,
      actorRole: args.viewer.role,
      action: "join_request.created",
      entityType: "join_requests",
      entityId: requestId,
      after: { rideGroupId: args.rideGroupId, seats: args.passengerCount, score: score.score },
    });
    trackEvent(tx, { userId: args.viewer.id, name: "join_request_submitted", props: { rideGroupId: args.rideGroupId, score: score.score } });

    return { requestId, score, requiresApproval: true, seatsLeft };
  });
}

export function decideJoinRequest(args: {
  viewer: SessionUser;
  requestId: string;
  decision: "approved" | "declined";
  note?: string;
}) {
  const db = getDb();
  const rules = loadPricingRules(db);

  return transaction((tx) => {
    const request = tx
      .prepare(
        `SELECT jr.*, rg.code, rg.destination_id AS group_destination, rg.status AS group_status,
                rg.seats_total, rg.seats_taken, rg.luggage_total, rg.luggage_taken, rg.created_by_user_id,
                rg.vehicle_category, rg.fare_strategy
           FROM join_requests jr JOIN ride_groups rg ON rg.id = jr.ride_group_id
          WHERE jr.id = ?`,
      )
      .get(args.requestId) as Record<string, any> | undefined;
    if (!request) throw new ServiceError(404, "Join request not found");
    if (request.status !== "pending") throw new ServiceError(409, "This request was already handled", "stale");

    // Ownership is enforced server-side, never by hiding the button.
    const isOwner = request.created_by_user_id === args.viewer.id;
    const isAdmin = args.viewer.role === "admin" || args.viewer.role === "support";
    if (!isOwner && !isAdmin) throw new ServiceError(403, "Only the ride coordinator can decide this request");

    const now = new Date().toISOString();

    if (args.decision === "declined") {
      tx.prepare("UPDATE join_requests SET status='declined', decided_by=?, decided_at=?, decision_note=? WHERE id=?")
        .run(args.viewer.id, now, args.note ?? null, args.requestId);
      notify(tx, {
        userId: request.user_id,
        type: "join_declined",
        title: `Your request for ${request.code} was declined`,
        body: args.note?.trim() || "The coordinator could not take another passenger this time. Other groups on the same flight may still have seats.",
        rideGroupId: request.ride_group_id,
        href: `/rides?flight=${request.code}`,
        isDemo: true,
      });
      audit(tx, { actorUserId: args.viewer.id, action: "join_request.declined", entityType: "join_requests", entityId: args.requestId });
      return { status: "declined" as const };
    }

    if (request.group_status === "cancelled") throw new ServiceError(409, "This ride was cancelled");

    // Atomic capacity claim. The WHERE clause makes concurrent joins safe:
    // the second writer simply updates zero rows.
    const claim = tx
      .prepare(
        `UPDATE ride_groups
            SET seats_taken = seats_taken + ?, luggage_taken = luggage_taken + ?, updated_at = ?
          WHERE id = ? AND seats_taken + ? <= seats_total AND luggage_taken + ? <= luggage_total`,
      )
      .run(
        request.passenger_count, request.luggage_units, now, request.ride_group_id,
        request.passenger_count, request.luggage_units,
      );

    if (claim.changes === 0) {
      // Report the actual reason instead of a generic "full": seats and luggage
      // space are separate constraints and passengers need to know which one bit.
      const seatsLeft = Math.max(0, Number(request.seats_total) - Number(request.seats_taken));
      const luggageLeft = Math.max(0, Number(request.luggage_total) - Number(request.luggage_taken));
      const seatsBlocked = seatsLeft < Number(request.passenger_count);
      const luggageBlocked = luggageLeft < Number(request.luggage_units);
      if (seatsBlocked) {
        throw new ServiceError(409, "This ride filled up before the request was approved. Nothing was charged.", "overbooked");
      }
      if (luggageBlocked) {
        throw new ServiceError(
          409,
          `Not enough luggage space left in this vehicle (${luggageLeft} unit${luggageLeft === 1 ? "" : "s"} free, ${request.luggage_units} requested). Ask the passenger to travel lighter or start a second group.`,
          "luggage",
        );
      }
      throw new ServiceError(409, "This ride can no longer fit the request. Nothing was charged.", "capacity");
    }

    const memberId = id("rm");
    tx.prepare(
      `INSERT INTO ride_members (id, ride_group_id, user_id, join_request_id, seat_count, luggage_units, destination_id,
         readiness, expected_ready_at, status, role, joined_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'landed', ?, 'accepted', 'member', ?)`,
    ).run(
      memberId, request.ride_group_id, request.user_id, request.id, request.passenger_count,
      request.luggage_units, request.destination_id, request.group_status === "open" ? now : now, now,
    );

    tx.prepare("UPDATE join_requests SET status='approved', decided_by=?, decided_at=?, decision_note=? WHERE id=?")
      .run(args.viewer.id, now, args.note ?? null, args.requestId);

    // Once the last seat is gone the group must stop appearing as joinable.
    tx.prepare(
      `UPDATE ride_groups
          SET status = CASE WHEN seats_taken >= seats_total AND status = 'open' THEN 'full' ELSE status END,
              updated_at = ?
        WHERE id = ?`,
    ).run(now, request.ride_group_id);

    const bookingId = id("bk");
    tx.prepare(
      `INSERT INTO bookings (id, code, ride_group_id, user_id, status, payment_status, amount_paise, created_at)
       VALUES (?, ?, ?, ?, 'pending', 'unpaid', 0, ?)`,
    ).run(bookingId, `BK${bookingId.slice(-7).toUpperCase()}`, request.ride_group_id, request.user_id, now);

    // Re-split the fare for everyone, then update this booking's amount.
    const result = recomputeGroupFare({
      db: tx, rideGroupId: request.ride_group_id, rules, actorUserId: args.viewer.id, reason: "member_joined",
    });

    const myFare = result?.fare.members.find((m) => m.userId === request.user_id);
    notify(tx, {
      userId: request.user_id,
      type: "join_approved",
      title: `You're in — ${request.code}`,
      body: myFare
        ? `Your estimated contribution is ${formatPaise(myFare.contributionPaise)} for ${myFare.destinationId.replace(/-/g, " ")}. Confirm readiness when you reach the meeting point. This is an estimate, not a charge.`
        : "Your seat is confirmed. Open the trip to confirm readiness.",
      rideGroupId: request.ride_group_id,
      href: `/app/trips/${request.ride_group_id}`,
      isDemo: true,
    });
    systemMessage(tx, {
      rideGroupId: request.ride_group_id,
      body: `${request.code} — a new passenger joined. The fare has been re-split fairly.`,
    });

    audit(tx, {
      actorUserId: args.viewer.id, action: "join_request.approved", entityType: "join_requests",
      entityId: args.requestId, after: { memberId, bookingId },
    });
    trackEvent(tx, { userId: request.user_id, name: "booking_confirmed", props: { rideGroupId: request.ride_group_id } });

    return { status: "approved" as const, memberId, bookingId, contributionPaise: myFare?.contributionPaise ?? 0 };
  });
}

export function withdrawJoinRequest(viewer: SessionUser, requestId: string) {
  const db = getDb();
  const request = db.prepare("SELECT * FROM join_requests WHERE id = ? AND user_id = ?").get(requestId, viewer.id) as
    | { id: string; status: string }
    | undefined;
  if (!request) throw new ServiceError(404, "Request not found");
  if (request.status !== "pending") throw new ServiceError(409, "Only pending requests can be withdrawn");
  db.prepare("UPDATE join_requests SET status='withdrawn', decided_at=? WHERE id=?").run(new Date().toISOString(), requestId);
  audit(db, { actorUserId: viewer.id, action: "join_request.withdrawn", entityType: "join_requests", entityId: requestId });
  return { status: "withdrawn" as const };
}

// ── Readiness ───────────────────────────────────────────────────────────────
export function updateReadiness(args: { viewer: SessionUser; rideGroupId: string; readiness: string }) {
  const db = getDb();
  return transaction((tx) => {
    const membership = tx
      .prepare("SELECT * FROM ride_members WHERE ride_group_id = ? AND user_id = ? AND status = 'accepted'")
      .get(args.rideGroupId, args.viewer.id) as Record<string, any> | undefined;
    if (!membership) throw new ServiceError(403, "You are not part of this ride");

    const now = new Date().toISOString();
    tx.prepare("UPDATE ride_members SET readiness = ?, readiness_updated_at = ?, expected_ready_at = ? WHERE id = ?")
      .run(args.readiness, now, now, membership.id);

    const members = tx
      .prepare(
        `SELECT rm.readiness, rm.expected_ready_at, u.name, rm.user_id FROM ride_members rm
           JOIN users u ON u.id = rm.user_id WHERE rm.ride_group_id = ? AND rm.status='accepted'`,
      )
      .all(args.rideGroupId) as Record<string, any>[];
    const group = tx.prepare("SELECT * FROM ride_groups WHERE id = ?").get(args.rideGroupId) as Record<string, any>;
    const flight = tx.prepare("SELECT estimated_arrival, status FROM flights WHERE id = ?").get(group.flight_id) as Record<string, any>;

    const window = computeDepartureWindow({
      scheduledArrival: flight.estimated_arrival,
      estimatedArrival: flight.estimated_arrival,
      status: flight.status,
      baggageClaimMinutes: loadPricingRules(tx).baggageClaimMinutes,
      maxWaitMinutes: group.max_wait_minutes,
      members: members.map((m) => ({
        readiness: m.readiness,
        expectedReadyAt: m.expected_ready_at ?? flight.estimated_arrival,
      })),
    });

    tx.prepare(
      `INSERT INTO ride_status_events (id, ride_group_id, actor_user_id, type, payload_json, created_at)
       VALUES (?, ?, ?, 'readiness_updated', ?, ?)`,
    ).run(id("rse"), args.rideGroupId, args.viewer.id, JSON.stringify({ readiness: args.readiness }), now);

    if (window.pendingMembers === 0) {
      for (const m of members) {
        notify(tx, {
          userId: m.user_id,
          type: "group_ready",
          title: `${group.code}: everyone is at the meeting point`,
          body: "The whole group has confirmed readiness. The coordinator can confirm the departure window.",
          rideGroupId: args.rideGroupId,
          href: `/app/trips/${args.rideGroupId}`,
          isDemo: true,
        });
      }
      systemMessage(tx, {
        rideGroupId: args.rideGroupId,
        kind: "readiness",
        body: "Everyone in the group is ready at the meeting point.",
      });
    }

    trackEvent(tx, { userId: args.viewer.id, name: "readiness_updated", props: { rideGroupId: args.rideGroupId, readiness: args.readiness } });
    return { readiness: args.readiness, window, pendingMembers: window.pendingMembers };
  });
}

// ── Coordination ────────────────────────────────────────────────────────────
export function confirmDeparture(viewer: SessionUser, rideGroupId: string) {
  const db = getDb();
  return transaction((tx) => {
    const group = tx.prepare("SELECT * FROM ride_groups WHERE id = ?").get(rideGroupId) as Record<string, any> | undefined;
    if (!group) throw new ServiceError(404, "Ride not found");
    const membership = tx
      .prepare("SELECT role FROM ride_members WHERE ride_group_id = ? AND user_id = ? AND status='accepted'")
      .get(rideGroupId, viewer.id) as { role: string } | undefined;
    if (membership?.role !== "owner" && viewer.role !== "admin") {
      throw new ServiceError(403, "Only the coordinator can confirm departure");
    }
    if (!["open", "full"].includes(group.status)) throw new ServiceError(409, "This ride is not in a state that can depart");

    const now = new Date().toISOString();
    const nextStatus = group.driver_id ? "in_progress" : "confirmed";
    tx.prepare("UPDATE ride_groups SET status = ?, updated_at = ? WHERE id = ?").run(nextStatus, now, rideGroupId);
    tx.prepare(
      `INSERT INTO ride_status_events (id, ride_group_id, actor_user_id, type, from_status, to_status, created_at)
       VALUES (?, ?, ?, 'departure_confirmed', ?, ?, ?)`,
    ).run(id("rse"), rideGroupId, viewer.id, group.status, nextStatus, now);

    const members = tx.prepare("SELECT user_id FROM ride_members WHERE ride_group_id = ? AND status='accepted'").all(rideGroupId) as {
      user_id: string;
    }[];
    for (const m of members) {
      notify(tx, {
        userId: m.user_id,
        type: "departure_confirmed",
        title: `${group.code}: departure confirmed`,
        body: group.driver_id
          ? "Your driver has been assigned. Head to the meeting point now."
          : "The departure window is confirmed. A driver is still being matched — you will be notified the moment one accepts.",
        rideGroupId,
        href: `/app/trips/${rideGroupId}`,
        isDemo: true,
      });
    }
    systemMessage(tx, { rideGroupId, body: "Departure confirmed by the coordinator." });
    audit(tx, { actorUserId: viewer.id, action: "ride.departure_confirmed", entityType: "ride_groups", entityId: rideGroupId, after: { status: nextStatus } });
    return { status: nextStatus };
  });
}

export function cancelRide(viewer: SessionUser, rideGroupId: string, reason: string) {
  const db = getDb();
  return transaction((tx) => {
    const group = tx.prepare("SELECT * FROM ride_groups WHERE id = ?").get(rideGroupId) as Record<string, any> | undefined;
    if (!group) throw new ServiceError(404, "Ride not found");
    const membership = tx
      .prepare("SELECT role FROM ride_members WHERE ride_group_id = ? AND user_id = ? AND status='accepted'")
      .get(rideGroupId, viewer.id) as { role: string } | undefined;
    if (membership?.role !== "owner" && viewer.role !== "admin") {
      throw new ServiceError(403, "Only the coordinator can cancel this ride");
    }
    if (["completed", "cancelled"].includes(group.status)) throw new ServiceError(409, "This ride is already closed");

    const now = new Date().toISOString();
    // No money has moved in this flow: bookings return to 'cancelled' with no refund owed.
    tx.prepare("UPDATE ride_groups SET status='cancelled', updated_at=? WHERE id=?").run(now, rideGroupId);
    tx.prepare(
      "UPDATE bookings SET status='cancelled', cancelled_at=?, cancel_reason=? WHERE ride_group_id=? AND status IN ('pending','confirmed')",
    ).run(now, reason, rideGroupId);

    const members = tx.prepare("SELECT user_id FROM ride_members WHERE ride_group_id = ? AND status='accepted'").all(rideGroupId) as {
      user_id: string;
    }[];
    for (const m of members) {
      notify(tx, {
        userId: m.user_id,
        type: "ride_cancelled",
        title: `${group.code} was cancelled`,
        body: `${reason} No payment was taken. You can join another group on the same flight.`,
        rideGroupId,
        href: "/rides",
        isDemo: true,
      });
    }
    audit(tx, { actorUserId: viewer.id, action: "ride.cancelled", entityType: "ride_groups", entityId: rideGroupId, after: { reason } });
    trackEvent(tx, { userId: viewer.id, name: "ride_cancelled", props: { rideGroupId, reason } });
    return { status: "cancelled" as const };
  });
}

// ── Create a ride group ─────────────────────────────────────────────────────
export function createRideGroup(args: {
  viewer: SessionUser;
  flightNumber: string;
  flightDate: string;
  airportId: string;
  destinationId: string;
  vehicleCategory: "sedan" | "suv" | "mpv";
  maxWaitMinutes: number;
  strategy: "equal" | "distance" | "hybrid";
  passengerCount: number;
  luggageUnits: number;
  meetPoint?: string;
}) {
  const db = getDb();
  const rules = loadPricingRules(db);
  const flight = findFlight(args.airportId, args.flightNumber, args.flightDate);
  if (!flight) throw new ServiceError(404, "That flight is not in the schedule for this date", "flight_not_found");
  const destination = getDestination(args.destinationId);
  if (!destination) throw new ServiceError(400, "Choose a valid destination");

  return transaction((tx) => {
    const capacity = rules.vehicleCapacity[args.vehicleCategory];
    const groupId = id("rg");
    const now = new Date().toISOString();
    const windowStart = new Date(new Date(flight.estimated_arrival).getTime() + rules.baggageClaimMinutes * 60_000);
    const windowEnd = new Date(windowStart.getTime() + args.maxWaitMinutes * 60_000);

    tx.prepare(
      `INSERT INTO ride_groups (id, code, flight_id, created_by_user_id, destination_id, vehicle_category, fare_strategy,
         seats_total, seats_taken, luggage_total, luggage_taken, meet_point, departure_window_start, departure_window_end,
         max_wait_minutes, status, is_demo_origin, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 0, ?, ?, ?, ?, 'open', ?, ?, ?)`,
    ).run(
      groupId, `FS-${groupId.slice(-6).toUpperCase()}`, flight.id, args.viewer.id, args.destinationId,
      args.vehicleCategory, args.strategy, capacity.seats, capacity.luggage,
      args.meetPoint || "Arrivals kerb — exact gate will be shared in the trip chat",
      windowStart.toISOString(), windowEnd.toISOString(), args.maxWaitMinutes,
      flight.source === "demo" ? 1 : 0, now, now,
    );

    // Creator becomes owner + first member, atomically within the seat claim.
    tx.prepare(
      `INSERT INTO ride_members (id, ride_group_id, user_id, seat_count, luggage_units, destination_id, readiness,
         expected_ready_at, status, role, joined_at)
       VALUES (?, ?, ?, ?, ?, ?, 'not_landed', ?, 'accepted', 'owner', ?)`,
    ).run(id("rm"), groupId, args.viewer.id, args.passengerCount, args.luggageUnits, args.destinationId, windowStart.toISOString(), now);

    tx.prepare("UPDATE ride_groups SET seats_taken = ?, luggage_taken = ? WHERE id = ?").run(
      args.passengerCount, Math.min(capacity.luggage, args.luggageUnits), groupId,
    );

    tx.prepare("INSERT INTO conversations (id, ride_group_id, created_at) VALUES (?, ?, ?)").run(id("cnv"), groupId, now);

    const bookingId = id("bk");
    tx.prepare(
      `INSERT INTO bookings (id, code, ride_group_id, user_id, status, payment_status, amount_paise, created_at)
       VALUES (?, ?, ?, ?, 'pending', 'unpaid', 0, ?)`,
    ).run(bookingId, `BK${bookingId.slice(-7).toUpperCase()}`, groupId, args.viewer.id, now);

    recomputeGroupFare({ db: tx, rideGroupId: groupId, rules, actorUserId: args.viewer.id, reason: "initial" });

    tx.prepare(
      `INSERT INTO ride_status_events (id, ride_group_id, actor_user_id, type, to_status, payload_json, created_at)
       VALUES (?, ?, ?, 'group_created', 'open', ?, ?)`,
    ).run(id("rse"), groupId, args.viewer.id, JSON.stringify({ seats: capacity.seats, destination: destination.name }), now);

    audit(tx, {
      actorUserId: args.viewer.id, action: "ride.created", entityType: "ride_groups", entityId: groupId,
      after: { flight: flight.flight_number, destination: args.destinationId },
    });
    trackEvent(tx, { userId: args.viewer.id, name: "ride_group_formed", props: { rideGroupId: groupId, destination: args.destinationId } });

    return { rideGroupId: groupId, code: `FS-${groupId.slice(-6).toUpperCase()}` };
  });
}
