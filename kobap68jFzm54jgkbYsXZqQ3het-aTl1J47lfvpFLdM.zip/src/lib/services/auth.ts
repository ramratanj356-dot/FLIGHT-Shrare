import "server-only";
import { createHash } from "node:crypto";
import { getDb, id, transaction } from "@/lib/db";
import { createOpaqueToken, hashPassword, verifyPassword } from "@/lib/auth/password";
import { revokeAllSessions } from "@/lib/auth/session";
import { audit, notify } from "./audit";
import { ServiceError } from "./rides";
import { EMAIL_MODE } from "@/lib/config/features";

const hash = (t: string) => createHash("sha256").update(t).digest("hex");
const nowIso = () => new Date().toISOString();

function isDev() {
  return process.env.NODE_ENV !== "production" && EMAIL_MODE === "demo";
}

export interface SignupArgs {
  name: string;
  email: string;
  phone?: string;
  password: string;
  role: "passenger" | "driver";
}

export async function signup(args: SignupArgs) {
  const db = getDb();
  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(args.email) as { id: string } | undefined;
  if (existing) throw new ServiceError(409, "An account with this email already exists. Try signing in instead.");

  const passwordHash = await hashPassword(args.password);
  const userId = id("usr");
  const verificationToken = createOpaqueToken();
  const now = nowIso();

  transaction((tx) => {
    tx.prepare(
      `INSERT INTO users (id, email, password_hash, role, name, phone, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    ).run(userId, args.email, passwordHash, args.role, args.name, args.phone || null, now, now);

    if (args.role === "passenger") {
      tx.prepare(
        `INSERT INTO passenger_profiles (user_id, identity_status, identity_provider, luggage_preference, created_at, updated_at)
         VALUES (?, 'unverified', 'simulated', 'one_checkin', ?, ?)`,
      ).run(userId, now, now);
    } else {
      const driverId = id("drv");
      tx.prepare(
        `INSERT INTO driver_profiles (id, user_id, verification_status, created_at, updated_at)
         VALUES (?, ?, 'pending', ?, ?)`,
      ).run(driverId, userId, now, now);
    }

    tx.prepare(
      `INSERT INTO email_verifications (id, user_id, token_hash, expires_at, created_at) VALUES (?, ?, ?, ?, ?)`,
    ).run(id("ev"), userId, hash(verificationToken), new Date(Date.now() + 24 * 3600_000).toISOString(), now);

    notify(tx, {
      userId,
      type: "welcome",
      title: "Welcome to FlightShare",
      body: "Verify your email to unlock joining rides. Your identity check is optional but earns a verified badge.",
      href: "/app/profile",
      isDemo: true,
    });

    audit(tx, { actorUserId: userId, actorRole: args.role, action: "user.signup", entityType: "users", entityId: userId });
  });

  return {
    userId,
    verificationToken,
    // Surfaced only in demo/local mode; production sends this by email instead.
    devVerifyUrl: isDev() ? `/verify-email?token=${verificationToken}` : undefined,
  };
}

export async function login(args: { email: string; password: string }) {
  const db = getDb();
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(args.email) as
    | { id: string; password_hash: string | null; status: string; role: string; email_verified_at: string | null }
    | undefined;

  // Constant-ish response regardless of which factor failed.
  const ok = user ? await verifyPassword(args.password, user.password_hash) : false;
  if (!user || !ok) throw new ServiceError(401, "Email or password is incorrect");
  if (user.status !== "active") throw new ServiceError(403, "This account is suspended. Contact support.");

  db.prepare("UPDATE users SET last_login_at = ?, updated_at = ? WHERE id = ?").run(nowIso(), nowIso(), user.id);
  audit(db, { actorUserId: user.id, actorRole: user.role, action: "user.login", entityType: "users", entityId: user.id });

  return { userId: user.id, role: user.role, emailVerified: Boolean(user.email_verified_at) };
}

export async function requestPasswordReset(email: string) {
  const db = getDb();
  const user = db.prepare("SELECT id FROM users WHERE email = ?").get(email) as { id: string } | undefined;
  // Always report success — never disclose whether an email is registered.
  if (!user) return { sent: true as const };

  const token = createOpaqueToken();
  db.prepare("INSERT INTO password_resets (id, user_id, token_hash, expires_at) VALUES (?, ?, ?, ?)").run(
    id("pr"), user.id, hash(token), new Date(Date.now() + 3600_000).toISOString(),
  );
  audit(db, { actorUserId: user.id, action: "user.password_reset_requested", entityType: "password_resets" });
  return { sent: true as const, devResetUrl: isDev() ? `/reset-password?token=${token}` : undefined };
}

export async function resetPassword(token: string, password: string) {
  const db = getDb();
  const row = db
    .prepare("SELECT * FROM password_resets WHERE token_hash = ? AND used_at IS NULL")
    .get(hash(token)) as { id: string; user_id: string; expires_at: string } | undefined;
  if (!row) throw new ServiceError(400, "This reset link is invalid or has already been used");
  if (new Date(row.expires_at).getTime() < Date.now()) throw new ServiceError(400, "This reset link has expired. Request a new one.");

  const passwordHash = await hashPassword(password);
  db.prepare("UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?").run(passwordHash, nowIso(), row.user_id);
  db.prepare("UPDATE password_resets SET used_at = ? WHERE id = ?").run(nowIso(), row.id);
  await revokeAllSessions(row.user_id); // sign out everywhere after a reset
  audit(db, { actorUserId: row.user_id, action: "user.password_reset", entityType: "users", entityId: row.user_id });
  return { ok: true };
}

export function verifyEmailToken(token: string) {
  const db = getDb();
  const row = db
    .prepare("SELECT * FROM email_verifications WHERE token_hash = ? AND used_at IS NULL")
    .get(hash(token)) as { id: string; user_id: string; expires_at: string } | undefined;
  if (!row) throw new ServiceError(400, "This verification link is invalid or already used");
  if (new Date(row.expires_at).getTime() < Date.now()) throw new ServiceError(400, "This verification link expired. Request a new one from your profile.");

  const now = nowIso();
  db.prepare("UPDATE users SET email_verified_at = ?, updated_at = ? WHERE id = ?").run(now, now, row.user_id);
  db.prepare("UPDATE email_verifications SET used_at = ? WHERE id = ?").run(now, row.id);
  audit(db, { actorUserId: row.user_id, action: "user.email_verified", entityType: "users", entityId: row.user_id });
  return { ok: true };
}

export function resendVerification(userId: string, email: string) {
  const db = getDb();
  const user = db.prepare("SELECT email_verified_at FROM users WHERE id = ?").get(userId) as
    | { email_verified_at: string | null }
    | undefined;
  if (!user) throw new ServiceError(404, "Account not found");
  if (user.email_verified_at) return { alreadyVerified: true as const };

  const token = createOpaqueToken();
  db.prepare("INSERT INTO email_verifications (id, user_id, token_hash, expires_at) VALUES (?, ?, ?, ?)").run(
    id("ev"), userId, hash(token), new Date(Date.now() + 24 * 3600_000).toISOString(),
  );
  console.info(`[flightshare] verification email for ${email}: /verify-email?token=${token}`);
  return { alreadyVerified: false as const, devVerifyUrl: isDev() ? `/verify-email?token=${token}` : undefined };
}

export function updateProfile(userId: string, data: Record<string, unknown>) {
  const db = getDb();
  const now = nowIso();
  return transaction((tx) => {
    tx.prepare("UPDATE users SET name = ?, phone = ?, updated_at = ? WHERE id = ?").run(
      String(data.name), data.phone ? String(data.phone) : null, now, userId,
    );
    tx.prepare(
      `UPDATE passenger_profiles SET home_destination_id = ?, luggage_preference = ?, accessibility_needs = ?,
              language = ?, quiet_ride = ?, emergency_contact_name = ?, emergency_contact_phone = ?, updated_at = ?
        WHERE user_id = ?`,
    ).run(
      (data.homeDestinationId as string) || null,
      (data.luggagePreference as string) || "one_checkin",
      (data.accessibilityNeeds as string) || null,
      (data.language as string) || "en",
      data.quietRide ? 1 : 0,
      (data.emergencyContactName as string) || null,
      (data.emergencyContactPhone as string) || null,
      now, userId,
    );
    audit(tx, { actorUserId: userId, action: "user.profile_updated", entityType: "users", entityId: userId });
    return { ok: true };
  });
}

/** Simulated identity check — clearly labelled, never claims real verification. */
export function submitIdentityCheck(userId: string) {
  const db = getDb();
  const now = nowIso();
  // In demo mode we mark this as a *simulated* pass after a short review window.
  db.prepare(
    `UPDATE passenger_profiles SET identity_status='verified', identity_provider='simulated', identity_verified_at=?, updated_at=? WHERE user_id=?`,
  ).run(now, now, userId);
  notify(db, {
    userId,
    type: "identity",
    title: "Identity check marked verified (simulated)",
    body: "Demo mode: no document was reviewed by a provider. In production this requires an authorised identity provider.",
    href: "/app/profile",
    isDemo: true,
  });
  audit(db, { actorUserId: userId, action: "identity.simulated_verified", entityType: "passenger_profiles", entityId: userId });
  return { status: "verified" as const, simulated: true };
}

export function requestAccountDeletion(userId: string) {
  const db = getDb();
  db.prepare("UPDATE users SET status='deleted', deleted_at=? WHERE id=?").run(nowIso(), userId);
  const memberships = db
    .prepare("SELECT ride_group_id FROM ride_members WHERE user_id = ? AND status='accepted'")
    .all(userId) as { ride_group_id: string }[];
  db.prepare("UPDATE ride_members SET status='left', readiness='not_landed' WHERE user_id = ?").run(userId);
  audit(db, { actorUserId: userId, action: "user.deletion_requested", entityType: "users", entityId: userId, after: { memberships } });
  return { ok: true };
}
