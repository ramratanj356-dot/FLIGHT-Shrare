import "server-only";
import { getDb, id, transaction } from "@/lib/db";
import type { SessionUser } from "@/lib/auth/session";
import { ServiceError } from "./rides";
import { audit, notify } from "./audit";
import { savePricingRules } from "@/lib/db/pricing";

function assertAdmin(viewer: SessionUser) {
  if (viewer.role !== "admin") throw new ServiceError(403, "Administrator access required");
}

export function reviewFlightVerification(viewer: SessionUser, verificationId: string, status: "verified" | "rejected", note?: string) {
  assertAdmin(viewer);
  const db = getDb();
  return transaction((tx) => {
    const row = tx
      .prepare("SELECT fv.*, f.flight_number FROM flight_verifications fv JOIN flights f ON f.id = fv.flight_id WHERE fv.id = ?")
      .get(verificationId) as Record<string, any> | undefined;
    if (!row) throw new ServiceError(404, "Verification not found");
    const now = new Date().toISOString();
    tx.prepare("UPDATE flight_verifications SET status=?, reviewed_by=?, notes=?, verified_at=? WHERE id=?")
      .run(status, viewer.id, note ?? null, status === "verified" ? now : null, verificationId);
    notify(tx, {
      userId: row.user_id,
      type: "verification",
      title: status === "verified" ? `Flight ${row.flight_number} verified` : `Flight ${row.flight_number} verification rejected`,
      body: status === "verified"
        ? "Your booking reference matched this flight. Your match score now includes a verified-flight boost."
        : note || "We could not match your booking reference. You can submit it again from the trip screen.",
      href: "/app",
      isDemo: true,
    });
    audit(tx, { actorUserId: viewer.id, actorRole: "admin", action: `flight_verification.${status}`, entityType: "flight_verifications", entityId: verificationId, after: { note } });
    return { status };
  });
}

export function reviewDriverVerification(viewer: SessionUser, driverId: string, status: "verified" | "rejected", note?: string) {
  assertAdmin(viewer);
  const db = getDb();
  return transaction((tx) => {
    const row = tx.prepare("SELECT * FROM driver_profiles WHERE id = ?").get(driverId) as Record<string, any> | undefined;
    if (!row) throw new ServiceError(404, "Driver not found");
    const now = new Date().toISOString();
    tx.prepare("UPDATE driver_profiles SET verification_status=?, verification_notes=?, verified_at=?, updated_at=? WHERE id=?")
      .run(status, note ?? null, status === "verified" ? now : null, now, driverId);
    tx.prepare("UPDATE vehicles SET verification_status=? WHERE driver_id=?").run(status === "verified" ? "verified" : "rejected", driverId);
    notify(tx, {
      userId: row.user_id,
      type: "verification",
      title: status === "verified" ? "Driver account verified" : "Driver verification rejected",
      body: status === "verified"
        ? "You can now accept airport ride requests. Vehicle details are shown to passengers only after assignment."
        : note || "Please re-submit your licence and vehicle documents with clearer details.",
      href: "/driver",
      isDemo: true,
    });
    audit(tx, { actorUserId: viewer.id, actorRole: "admin", action: `driver.${status}`, entityType: "driver_profiles", entityId: driverId, after: { note } });
    return { status };
  });
}

export function updatePricingRules(viewer: SessionUser, patch: Record<string, unknown>) {
  assertAdmin(viewer);
  const db = getDb();
  const before = db.prepare("SELECT key, value_json FROM pricing_rules").all();
  savePricingRules(db, patch, viewer.id);
  audit(db, { actorUserId: viewer.id, actorRole: "admin", action: "pricing.updated", entityType: "pricing_rules", before, after: patch });
  return { ok: true };
}

export function resolveReport(viewer: SessionUser, reportId: string, status: "reviewing" | "resolved" | "dismissed", resolution?: string) {
  assertAdmin(viewer);
  const db = getDb();
  const now = new Date().toISOString();
  const row = db.prepare("SELECT * FROM reports WHERE id = ?").get(reportId) as Record<string, any> | undefined;
  if (!row) throw new ServiceError(404, "Report not found");
  db.prepare("UPDATE reports SET status=?, resolution=?, resolved_at=? WHERE id=?")
    .run(status, resolution ?? null, status === "resolved" ? now : null, reportId);
  notify(db, {
    userId: row.reporter_user_id,
    type: "support",
    title: `Your report is ${status}`,
    body: resolution || "Our trust & safety team reviewed your report.",
    href: "/help",
    isDemo: true,
  });
  audit(db, { actorUserId: viewer.id, actorRole: "admin", action: `report.${status}`, entityType: "reports", entityId: reportId, after: { resolution } });
  return { status };
}

export function processRefund(viewer: SessionUser, refundId: string, decision: "processed" | "failed", note?: string) {
  assertAdmin(viewer);
  const db = getDb();
  return transaction((tx) => {
    const refund = tx
      .prepare(
        `SELECT rf.*, p.id AS payment_id, p.booking_id, p.provider, p.status AS payment_status, b.user_id, b.ride_group_id
           FROM refunds rf JOIN payment_records p ON p.id = rf.payment_id JOIN bookings b ON b.id = p.booking_id
          WHERE rf.id = ?`,
      )
      .get(refundId) as Record<string, any> | undefined;
    if (!refund) throw new ServiceError(404, "Refund not found");
    if (refund.status !== "pending") throw new ServiceError(409, "This refund was already handled");

    const now = new Date().toISOString();
    tx.prepare("UPDATE refunds SET status=?, approved_by=?, processed_at=?, reason=? WHERE id=?")
      .run(decision, viewer.id, now, note || refund.reason, refundId);

    if (decision === "processed") {
      tx.prepare("UPDATE payment_records SET status='refunded', updated_at=? WHERE id=?").run(now, refund.payment_id);
      tx.prepare("UPDATE bookings SET payment_status='refunded' WHERE id=?").run(refund.booking_id);
      notify(tx, {
        userId: refund.user_id, type: "refund",
        title: "Refund processed",
        body: `${(refund.amount_paise / 100).toFixed(2)} INR was marked refunded on your booking. In demo mode no banking movement occurred.`,
        rideGroupId: refund.ride_group_id, href: `/app/trips/${refund.ride_group_id}`, isDemo: true,
      });
    }
    audit(tx, { actorUserId: viewer.id, actorRole: "admin", action: `refund.${decision}`, entityType: "refunds", entityId: refundId, after: { note } });
    return { status: decision };
  });
}

export function updateUserStatus(viewer: SessionUser, userId: string, status: "active" | "suspended") {
  assertAdmin(viewer);
  const db = getDb();
  db.prepare("UPDATE users SET status=?, updated_at=? WHERE id=?").run(status, new Date().toISOString(), userId);
  if (status === "suspended") db.prepare("UPDATE sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL").run(new Date().toISOString(), userId);
  audit(db, { actorUserId: viewer.id, actorRole: "admin", action: `user.${status}`, entityType: "users", entityId: userId });
  return { status };
}

export function updateSupportTicket(viewer: SessionUser, ticketId: string, status: "open" | "in_progress" | "resolved" | "closed") {
  if (!["admin", "support"].includes(viewer.role)) throw new ServiceError(403, "Support access required");
  const db = getDb();
  db.prepare("UPDATE support_tickets SET status=?, updated_at=?, assigned_to=COALESCE(assigned_to, ?) WHERE id=?")
    .run(status, new Date().toISOString(), viewer.id, ticketId);
  audit(db, { actorUserId: viewer.id, actorRole: viewer.role, action: `ticket.${status}`, entityType: "support_tickets", entityId: ticketId });
  return { status };
}

export function reseedDemoData(viewer: SessionUser) {
  assertAdmin(viewer);
  const db = getDb();
  const { ensureDemoData } = require("@/lib/demo/seed") as typeof import("@/lib/demo/seed");
  ensureDemoData(db);
  audit(db, { actorUserId: viewer.id, actorRole: "admin", action: "demo.reseed", entityType: "system" });
  return { ok: true };
}

export function createSupportTicket(userId: string, input: { subject: string; category: string; body: string }) {
  const db = getDb();
  const ticketId = id("tkt");
  db.prepare(
    `INSERT INTO support_tickets (id, user_id, subject, category, body, status, priority, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, 'open', 'normal', ?, ?)`,
  ).run(ticketId, userId, input.subject, input.category, input.body, new Date().toISOString(), new Date().toISOString());
  audit(db, { actorUserId: userId, action: "support_ticket.created", entityType: "support_tickets", entityId: ticketId });
  return { ticketId };
}

export function createReport(userId: string, input: { subjectUserId?: string; rideGroupId?: string; category: string; details: string }) {
  const db = getDb();
  const reportId = id("rep");
  db.prepare(
    `INSERT INTO reports (id, reporter_user_id, subject_user_id, ride_group_id, category, details, status, priority, created_at)
     VALUES (?, ?, ?, ?, ?, ?, 'open', 'high', ?)`,
  ).run(reportId, userId, input.subjectUserId ?? null, input.rideGroupId ?? null, input.category, input.details, new Date().toISOString());
  return { reportId };
}
