import "server-only";
import { getDb, id } from "@/lib/db";
import type { SessionUser } from "@/lib/auth/session";
import { ServiceError } from "./rides";
import { trackEvent } from "./audit";

export function postMessage(viewer: SessionUser, rideGroupId: string, body: string) {
  const db = getDb();
  const member = db
    .prepare("SELECT 1 AS ok FROM ride_members WHERE ride_group_id = ? AND user_id = ? AND status='accepted'")
    .get(rideGroupId, viewer.id);
  if (!member) throw new ServiceError(403, "Only accepted passengers can post in this ride chat");

  const conversation = db.prepare("SELECT id FROM conversations WHERE ride_group_id = ?").get(rideGroupId) as
    | { id: string }
    | undefined;
  if (!conversation) throw new ServiceError(404, "This ride has no conversation yet");

  const messageId = id("msg");
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO messages (id, conversation_id, sender_user_id, body, kind, created_at) VALUES (?, ?, ?, ?, 'text', ?)`,
  ).run(messageId, conversation.id, viewer.id, body.trim(), now);
  db.prepare("INSERT OR IGNORE INTO message_reads (message_id, user_id) VALUES (?, ?)").run(messageId, viewer.id);

  trackEvent(db, { userId: viewer.id, name: "message_sent", props: { rideGroupId } });
  return { messageId, createdAt: now };
}

export function markConversationRead(conversationId: string, userId: string) {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT m.id FROM messages m WHERE m.conversation_id = ? AND m.sender_user_id != ?
        AND NOT EXISTS (SELECT 1 FROM message_reads r WHERE r.message_id = m.id AND r.user_id = ?)`,
    )
    .all(conversationId, userId, userId) as { id: string }[];
  const stmt = db.prepare("INSERT OR IGNORE INTO message_reads (message_id, user_id) VALUES (?, ?)");
  const tx = db.transaction(() => rows.forEach((r) => stmt.run(r.id, userId)));
  tx();
  return { marked: rows.length };
}

export function reportMessage(viewer: SessionUser, messageId: string, reason: string) {
  const db = getDb();
  const msg = db
    .prepare(
      `SELECT m.*, c.ride_group_id FROM messages m JOIN conversations c ON c.id = m.conversation_id WHERE m.id = ?`,
    )
    .get(messageId) as Record<string, any> | undefined;
  if (!msg) throw new ServiceError(404, "Message not found");
  const member = db
    .prepare("SELECT 1 AS ok FROM ride_members WHERE ride_group_id = ? AND user_id = ? AND status='accepted'")
    .get(msg.ride_group_id, viewer.id);
  if (!member) throw new ServiceError(403, "You are not part of this ride");

  db.prepare(
    `INSERT INTO reports (id, reporter_user_id, subject_user_id, ride_group_id, category, details, status, priority, created_at)
     VALUES (?, ?, ?, ?, 'harassment', ?, 'open', 'high', ?)`,
  ).run(id("rep"), viewer.id, msg.sender_user_id, msg.ride_group_id, `Message reported: "${reason}". Content: ${String(msg.body).slice(0, 240)}`, new Date().toISOString());
  return { ok: true };
}

export function listConversationForUser(conversationId: string, userId: string) {
  const db = getDb();
  const row = db
    .prepare(
      `SELECT c.id, c.ride_group_id, rg.code, rg.status, d.name AS destination, f.flight_number, f.flight_date,
              f.terminal, rg.meet_point, rg.departure_window_start, rg.max_wait_minutes
         FROM conversations c
         JOIN ride_groups rg ON rg.id = c.ride_group_id
         JOIN destinations d ON d.id = rg.destination_id
         JOIN flights f ON f.id = rg.flight_id
         JOIN ride_members rm ON rm.ride_group_id = rg.id AND rm.user_id = ? AND rm.status='accepted'
        WHERE c.id = ?`,
    )
    .get(userId, conversationId) as Record<string, any> | undefined;
  return row ?? null;
}
