import "server-only";
import type { DB } from "@/lib/db";
import { id } from "@/lib/db";

export function audit(
  db: DB,
  args: {
    actorUserId: string | null;
    actorRole?: string | null;
    action: string;
    entityType: string;
    entityId?: string | null;
    before?: unknown;
    after?: unknown;
  },
) {
  db.prepare(
    `INSERT INTO audit_logs (id, actor_user_id, actor_role, action, entity_type, entity_id, before_json, after_json, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    id("aud"),
    args.actorUserId,
    args.actorRole ?? null,
    args.action,
    args.entityType,
    args.entityId ?? null,
    args.before ? JSON.stringify(args.before) : null,
    args.after ? JSON.stringify(args.after) : null,
    new Date().toISOString(),
  );
}

export function trackEvent(db: DB, args: { userId?: string | null; name: string; props?: Record<string, unknown> }) {
  db.prepare(`INSERT INTO analytics_events (id, user_id, name, props_json, created_at) VALUES (?, ?, ?, ?, ?)`).run(
    id("ev"),
    args.userId ?? null,
    args.name,
    args.props ? JSON.stringify(args.props) : null,
    new Date().toISOString(),
  );
}

export function notify(
  db: DB,
  args: {
    userId: string;
    type: string;
    title: string;
    body: string;
    rideGroupId?: string | null;
    href?: string | null;
    isDemo?: boolean;
  },
) {
  db.prepare(
    `INSERT INTO notifications (id, user_id, type, title, body, ride_group_id, href, is_demo, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    id("ntf"),
    args.userId,
    args.type,
    args.title,
    args.body,
    args.rideGroupId ?? null,
    args.href ?? null,
    args.isDemo ? 1 : 0,
    new Date().toISOString(),
  );
}

export function systemMessage(db: DB, args: { rideGroupId: string; body: string; kind?: string }) {
  const conversation = db.prepare("SELECT id FROM conversations WHERE ride_group_id = ?").get(args.rideGroupId) as
    | { id: string }
    | undefined;
  if (!conversation) return;
  const owner = db
    .prepare("SELECT user_id FROM ride_members WHERE ride_group_id = ? AND role = 'owner' LIMIT 1")
    .get(args.rideGroupId) as { user_id: string } | undefined;
  if (!owner) return;
  db.prepare(
    `INSERT INTO messages (id, conversation_id, sender_user_id, body, kind, created_at) VALUES (?, ?, ?, ?, ?, ?)`,
  ).run(id("msg"), conversation.id, owner.user_id, args.body, args.kind ?? "system", new Date().toISOString());
}
