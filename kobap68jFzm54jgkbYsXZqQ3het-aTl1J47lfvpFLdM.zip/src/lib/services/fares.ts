import "server-only";
import type { DB } from "@/lib/db";
import { id } from "@/lib/db";
import { computeGroupFare, type GroupFareMember } from "@/lib/fares/group";
import type { PricingRules } from "@/lib/config/pricing";
import { notify, systemMessage } from "./audit";
import { formatPaise } from "@/lib/money";

interface RecomputeArgs {
  db: DB;
  rideGroupId: string;
  rules: PricingRules;
  actorUserId?: string | null;
  reason?: "member_joined" | "member_removed" | "initial" | "admin_adjustment";
}

/**
 * Recomputes the fare for the group's current membership, writes a new
 * immutable estimate + allocation rows and tells every member what changed.
 * Runs inside the caller's transaction.
 */
export function recomputeGroupFare({ db, rideGroupId, rules, actorUserId, reason = "initial" }: RecomputeArgs) {
  const group = db
    .prepare(
      `SELECT rg.*, d.tolls_paise, d.solo_fare_paise, d.distance_km
         FROM ride_groups rg JOIN destinations d ON d.id = rg.destination_id WHERE rg.id = ?`,
    )
    .get(rideGroupId) as Record<string, any> | undefined;
  if (!group) throw new Error("Ride group not found");

  const memberRows = db
    .prepare(
      `SELECT rm.id, rm.user_id, rm.destination_id, rm.seat_count, d.distance_km, d.solo_fare_paise
         FROM ride_members rm JOIN destinations d ON d.id = rm.destination_id
        WHERE rm.ride_group_id = ? AND rm.status = 'accepted'`,
    )
    .all(rideGroupId) as Record<string, any>[];

  if (!memberRows.length) return null;

  const members: GroupFareMember[] = memberRows.map((m) => ({
    id: m.id,
    userId: m.user_id,
    destinationId: m.destination_id,
    distanceKm: m.distance_km,
    seatCount: m.seat_count,
    soloFarePaise: m.solo_fare_paise,
  }));

  const strategy = (group.fare_strategy ?? rules.defaultStrategy) as "equal" | "distance" | "hybrid";
  const fare = computeGroupFare({
    members,
    vehicleCategory: group.vehicle_category,
    strategy,
    rules,
    tollsPaise: group.tolls_paise,
  });

  const previous = db
    .prepare("SELECT id, total_paise, breakdown_json FROM fare_estimates WHERE ride_group_id = ? ORDER BY created_at DESC LIMIT 1")
    .get(rideGroupId) as { id: string; total_paise: number; breakdown_json: string } | undefined;

  const estimateId = id("fe");
  const now = new Date();
  const expires = new Date(now.getTime() + rules.estimateTtlMinutes * 60_000);

  db.prepare(
    `INSERT INTO fare_estimates (id, ride_group_id, strategy, vehicle_category, breakdown_json, total_paise,
       vehicle_fare_paise, fee_paise, tax_paise, solo_total_paise, savings_paise, expires_at, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    estimateId, rideGroupId, strategy, group.vehicle_category, JSON.stringify(fare),
    fare.breakdown.totalPaise, fare.breakdown.vehicleFarePaise, fare.breakdown.platformFeePaise,
    fare.breakdown.taxPaise, fare.breakdown.soloTotalPaise, fare.breakdown.totalSavingsPaise,
    expires.toISOString(), now.toISOString(),
  );

  const insertAlloc = db.prepare(
    `INSERT INTO fare_allocations (id, fare_estimate_id, ride_group_id, user_id, destination_id, distance_km, weight,
       vehicle_share_paise, fee_paise, tax_paise, contribution_paise, solo_fare_paise, savings_paise, savings_pct, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  for (const m of fare.members) {
    insertAlloc.run(
      id("fa"), estimateId, rideGroupId, m.userId, m.destinationId, m.distanceKm, m.weight,
      m.vehicleSharePaise, m.platformFeePaise, m.taxPaise, m.contributionPaise,
      m.soloEstimatePaise, m.savingsPaise, m.savingsPct, now.toISOString(),
    );

    db.prepare(
      `UPDATE bookings SET fare_estimate_id = ?, amount_paise = ?
        WHERE ride_group_id = ? AND user_id = ? AND status IN ('pending','confirmed')`,
    ).run(estimateId, m.contributionPaise, rideGroupId, m.userId);
  }

  db.prepare("UPDATE ride_groups SET fare_estimate_id = ?, updated_at = ? WHERE id = ?").run(
    estimateId, now.toISOString(), rideGroupId,
  );

  // Tell members when a join changes their share.
  if (previous && reason === "member_joined") {
    const before = new Map(
      fare.members.map((m) => [m.userId, previous ? m.contributionPaise : 0]),
    );
    void before;
    for (const m of fare.members) {
      notify(db, {
        userId: m.userId,
        type: "fare_updated",
        title: `Fare estimate updated — ${formatPaise(m.contributionPaise)}`,
        body: `A passenger joined your ride, so the shared fare was split again. Your estimated contribution is now ${formatPaise(m.contributionPaise)}. All figures remain estimates until a driver accepts.`,
        rideGroupId,
        href: `/app/trips/${rideGroupId}`,
        isDemo: true,
      });
    }
    systemMessage(db, {
      rideGroupId,
      kind: "fare_update",
      body: `A passenger joined. Fare re-split — the estimate is now ${formatPaise(fare.breakdown.totalPaise)} in total.`,
    });
  }

  return { estimateId, fare, previous };
}
