import "server-only";
import { createHmac, timingSafeEqual } from "node:crypto";
import { getDb, id, transaction } from "@/lib/db";
import type { SessionUser } from "@/lib/auth/session";
import { ServiceError } from "./rides";
import { audit, notify, trackEvent } from "./audit";
import { PAYMENTS_MODE } from "@/lib/config/features";
import { formatPaise } from "@/lib/money";

const RZP_KEY_ID = process.env.RAZORPAY_KEY_ID ?? "";
const RZP_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET ?? "";
const RZP_WEBHOOK_SECRET = process.env.RAZORPAY_WEBHOOK_SECRET ?? "";

/**
 * Order creation. The browser never decides the amount — it is read from the
 * booking row that the server itself wrote.
 */
export async function createPaymentOrder(viewer: SessionUser, bookingId: string) {
  const db = getDb();
  const booking = db
    .prepare(
      `SELECT b.*, rg.code, rg.status AS group_status
         FROM bookings b JOIN ride_groups rg ON rg.id = b.ride_group_id
        WHERE b.id = ? AND b.user_id = ?`,
    )
    .get(bookingId, viewer.id) as Record<string, any> | undefined;
  if (!booking) throw new ServiceError(404, "Booking not found");
  if (booking.status === "cancelled") throw new ServiceError(409, "This booking was cancelled");
  if (booking.payment_status === "captured") throw new ServiceError(409, "This booking is already paid");
  if (booking.amount_paise <= 0) throw new ServiceError(409, "The fare estimate is not ready yet. Refresh the trip.");

  const existing = db
    .prepare("SELECT * FROM payment_records WHERE booking_id = ? AND status IN ('created','authorised') ORDER BY created_at DESC")
    .get(bookingId) as Record<string, any> | undefined;
  if (existing) {
    return {
      mode: PAYMENTS_MODE,
      paymentId: existing.id,
      providerOrderId: existing.provider_order_id,
      amountPaise: existing.amount_paise,
      keyId: PAYMENTS_MODE === "razorpay" ? RZP_KEY_ID : null,
      reused: true,
    };
  }

  const paymentId = id("pay");
  const now = new Date().toISOString();

  if (PAYMENTS_MODE === "demo") {
    db.prepare(
      `INSERT INTO payment_records (id, booking_id, provider, provider_order_id, amount_paise, status, idempotency_key, created_at, updated_at)
       VALUES (?, ?, 'demo', ?, ?, 'created', ?, ?, ?)`,
    ).run(paymentId, bookingId, `demo_order_${paymentId.slice(-8)}`, booking.amount_paise, `order:${bookingId}`, now, now);
    audit(db, { actorUserId: viewer.id, action: "payment.order_created", entityType: "payment_records", entityId: paymentId, after: { mode: "demo", amount: booking.amount_paise } });
    return { mode: "demo" as const, paymentId, providerOrderId: `demo_order_${paymentId.slice(-8)}`, amountPaise: booking.amount_paise, keyId: null, reused: false };
  }

  const res = await fetch("https://api.razorpay.com/v1/orders", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Basic ${Buffer.from(`${RZP_KEY_ID}:${RZP_KEY_SECRET}`).toString("base64")}`,
    },
    body: JSON.stringify({
      amount: booking.amount_paise,
      currency: "INR",
      receipt: booking.code,
      notes: { bookingId, rideGroupId: booking.ride_group_id },
    }),
  });
  if (!res.ok) {
    const detail = await res.text();
    throw new ServiceError(502, `Payment provider rejected the order: ${detail.slice(0, 180)}`);
  }
  const order = (await res.json()) as { id: string; amount: number };
  db.prepare(
    `INSERT INTO payment_records (id, booking_id, provider, provider_order_id, amount_paise, status, idempotency_key, created_at, updated_at)
     VALUES (?, ?, 'razorpay', ?, ?, 'created', ?, ?, ?)`,
  ).run(paymentId, bookingId, order.id, order.amount, `order:${bookingId}`, now, now);
  audit(db, { actorUserId: viewer.id, action: "payment.order_created", entityType: "payment_records", entityId: paymentId, after: { mode: "razorpay" } });
  return { mode: "razorpay" as const, paymentId, providerOrderId: order.id, amountPaise: order.amount, keyId: RZP_KEY_ID, reused: false };
}

function safeEqual(a: string, b: string) {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  return ab.length === bb.length && timingSafeEqual(ab, bb);
}

/**
 * Callback verification. Never trust a client-declared "success" — the
 * HMAC comes from Razorpay's order/payment pair and is checked here with the
 * server-only secret. Demo mode marks records as DEMO, not as real captures.
 */
export async function verifyPayment(
  viewer: SessionUser,
  args: { paymentId: string; providerOrderId?: string; providerPaymentId?: string; signature?: string },
) {
  const db = getDb();
  const payment = db.prepare("SELECT * FROM payment_records WHERE id = ?").get(args.paymentId) as Record<string, any> | undefined;
  if (!payment) throw new ServiceError(404, "Payment record not found");
  const booking = db.prepare("SELECT * FROM bookings WHERE id = ? AND user_id = ?").get(payment.booking_id, viewer.id) as
    | Record<string, any>
    | undefined;
  if (!booking) throw new ServiceError(403, "This payment does not belong to you");
  if (payment.status === "captured") return { status: "captured", alreadyProcessed: true, demo: payment.provider === "demo" };

  const now = new Date().toISOString();

  if (payment.provider === "demo") {
    return transaction((tx) => {
      tx.prepare("UPDATE payment_records SET status='captured', method='demo_card', captured_at=?, updated_at=? WHERE id=? AND status != 'captured'")
        .run(now, now, payment.id);
      tx.prepare("UPDATE bookings SET payment_status='captured', confirmed_at=? WHERE id=?").run(now, booking.id);
      notify(tx, {
        userId: viewer.id,
        type: "payment",
        title: "Demo payment recorded — no money moved",
        body: `A simulated capture of ${formatPaise(payment.amount_paise)} was stored so you can see the full flow. Nothing was charged.`,
        rideGroupId: booking.ride_group_id,
        href: `/app/trips/${booking.ride_group_id}`,
        isDemo: true,
      });
      audit(tx, { actorUserId: viewer.id, action: "payment.demo_captured", entityType: "payment_records", entityId: payment.id, after: { amount: payment.amount_paise } });
      trackEvent(tx, { userId: viewer.id, name: "payment_completed", props: { demo: true, amount: payment.amount_paise } });
      return { status: "captured", demo: true as const };
    });
  }

  if (!args.providerOrderId || !args.providerPaymentId || !args.signature) {
    throw new ServiceError(400, "Missing payment verification fields");
  }
  const expected = createHmac("sha256", RZP_KEY_SECRET).update(`${args.providerOrderId}|${args.providerPaymentId}`).digest("hex");
  if (!safeEqual(expected, args.signature)) {
    db.prepare("UPDATE payment_records SET status='failed', failure_reason='Signature mismatch', updated_at=? WHERE id=?").run(now, payment.id);
    audit(db, { actorUserId: viewer.id, action: "payment.signature_failed", entityType: "payment_records", entityId: payment.id });
    throw new ServiceError(400, "Payment signature verification failed");
  }

  // Confirm with the provider what actually happened before recording money.
  const res = await fetch(`https://api.razorpay.com/v1/payments/${args.providerPaymentId}`, {
    headers: { authorization: `Basic ${Buffer.from(`${RZP_KEY_ID}:${RZP_KEY_SECRET}`).toString("base64")}` },
  });
  if (!res.ok) throw new ServiceError(502, "Could not confirm the payment with Razorpay. Try again in a moment.");
  const remote = (await res.json()) as { status: string; amount: number; order_id: string; method?: string };

  if (remote.order_id !== payment.provider_order_id) throw new ServiceError(400, "Payment does not belong to this order");
  if (remote.amount !== payment.amount_paise) throw new ServiceError(400, "Paid amount does not match the booking");
  if (remote.status !== "captured" && remote.status !== "authorized") {
    db.prepare("UPDATE payment_records SET status='failed', failure_reason=?, updated_at=? WHERE id=?").run(remote.status, now, payment.id);
    throw new ServiceError(402, `Payment was not completed (${remote.status})`);
  }

  return transaction((tx) => {
    const updated = tx.prepare(
      `UPDATE payment_records SET status='captured', provider_payment_id=?, method=?, captured_at=?, updated_at=?
        WHERE id=? AND status != 'captured'`,
    ).run(args.providerPaymentId, remote.method ?? null, now, now, payment.id);
    if (updated.changes === 0) return { status: "captured", alreadyProcessed: true, demo: false };
    tx.prepare("UPDATE bookings SET payment_status='captured', confirmed_at=? WHERE id=?").run(now, booking.id);
    notify(tx, {
      userId: viewer.id,
      type: "payment",
      title: "Payment captured",
      body: `${formatPaise(payment.amount_paise)} confirmed by the payment provider for ${booking.code}.`,
      rideGroupId: booking.ride_group_id,
      href: `/app/trips/${booking.ride_group_id}`,
    });
    audit(tx, { actorUserId: viewer.id, action: "payment.captured", entityType: "payment_records", entityId: payment.id });
    trackEvent(tx, { userId: viewer.id, name: "payment_completed", props: { amount: payment.amount_paise } });
    return { status: "captured", demo: false as const };
  });
}

/** Raw-body webhook handler with signature verification + event de-duplication. */
export async function handlePaymentWebhook(rawBody: string, signature: string | null) {
  const db = getDb();
  if (!RZP_WEBHOOK_SECRET) {
    return { ok: false, status: 503, message: "Webhook secret is not configured" };
  }
  if (!signature) return { ok: false, status: 400, message: "Missing signature" };
  const expected = createHmac("sha256", RZP_WEBHOOK_SECRET).update(rawBody).digest("hex");
  if (!safeEqual(expected, signature)) return { ok: false, status: 401, message: "Invalid signature" };

  const event = JSON.parse(rawBody) as {
    event: string;
    payload?: { payment?: { entity?: { id: string; order_id: string; amount: number; status: string } } };
    id?: string;
  };
  const entity = event.payload?.payment?.entity;
  const eventId = `${event.event}:${entity?.id ?? event.id ?? "unknown"}`;

  const seen = db.prepare("SELECT 1 AS ok FROM payment_records WHERE provider_event_id = ?").get(eventId);
  if (seen) return { ok: true, status: 200, message: "Duplicate event ignored" };

  if (!entity) return { ok: true, status: 200, message: "Unhandled event" };

  return transaction((tx) => {
    const payment = tx.prepare("SELECT * FROM payment_records WHERE provider_order_id = ?").get(entity.order_id) as
      | Record<string, any>
      | undefined;
    if (!payment) return { ok: true, status: 200, message: "Unknown order" };

    const now = new Date().toISOString();
    if (event.event === "payment.captured" && payment.status !== "captured") {
      tx.prepare(
        `UPDATE payment_records SET status='captured', provider_payment_id=?, captured_at=?, provider_event_id=?, updated_at=? WHERE id=?`,
      ).run(entity.id, now, eventId, now, payment.id);
      tx.prepare("UPDATE bookings SET payment_status='captured', confirmed_at=? WHERE id=?").run(now, payment.booking_id);
      audit(tx, { actorUserId: null, action: "payment.webhook_captured", entityType: "payment_records", entityId: payment.id });
    } else if (event.event === "payment.failed") {
      tx.prepare(
        `UPDATE payment_records SET status='failed', failure_reason='Provider reported failure', provider_event_id=?, updated_at=? WHERE id=?`,
      ).run(eventId, now, payment.id);
      tx.prepare("UPDATE bookings SET payment_status='failed' WHERE id=? AND payment_status != 'captured'").run(payment.booking_id);
    } else {
      tx.prepare("UPDATE payment_records SET provider_event_id = ? WHERE id = ?").run(eventId, payment.id);
    }
    return { ok: true, status: 200, message: "Processed" };
  });
}
