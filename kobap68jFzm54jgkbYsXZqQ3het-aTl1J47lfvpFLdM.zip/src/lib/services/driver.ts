import "server-only";
import { getDb, id, transaction } from "@/lib/db";
import type { SessionUser } from "@/lib/auth/session";
import { ServiceError } from "./rides";
import { audit, notify, systemMessage, trackEvent } from "./audit";
import { formatPaise } from "@/lib/money";

function driverForUser(userId: string) {
  const row = getDb()
    .prepare(
      `SELECT dp.*, v.id AS vehicle_id, v.category, v.seats, v.luggage_units
         FROM driver_profiles dp LEFT JOIN vehicles v ON v.driver_id = dp.id AND v.is_active = 1
        WHERE dp.user_id = ?`,
    )
    .get(userId) as Record<string, any> | undefined;
  if (!row) throw new ServiceError(403, "No driver profile found for this account");
  return row;
}

export function submitDriverVerification(
  viewer: SessionUser,
  data: {
    licenseNumber: string;
    vehicleModel: string;
    vehicleRegNumber: string;
    category: "sedan" | "suv" | "mpv";
    seats: number;
    luggageUnits: number;
    fleetPartner?: string;
  },
) {
  const db = getDb();
  const driver = driverForUser(viewer.id);
  const now = new Date().toISOString();
  const reg = data.vehicleRegNumber.replace(/\s+/g, " ").trim().toUpperCase();

  return transaction((tx) => {
    tx.prepare(
      `UPDATE driver_profiles SET company_name = ?, license_number = ?, verification_status = 'in_review', updated_at = ?
        WHERE id = ?`,
    ).run(data.fleetPartner || null, data.licenseNumber, now, driver.id);

    if (driver.vehicle_id) {
      tx.prepare(
        `UPDATE vehicles SET category = ?, make_model = ?, registration_number = ?, seats = ?, luggage_units = ?, verification_status = 'pending'
          WHERE id = ?`,
      ).run(data.category, data.vehicleModel, reg, data.seats, data.luggageUnits, driver.vehicle_id);
    } else {
      tx.prepare(
        `INSERT INTO vehicles (id, driver_id, category, make_model, registration_number, seats, luggage_units, verification_status, is_active, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', 1, ?)`,
      ).run(id("veh"), driver.id, data.category, data.vehicleModel, reg, data.seats, data.luggageUnits, now);
    }

    audit(tx, {
      actorUserId: viewer.id, action: "driver.verification_submitted", entityType: "driver_profiles", entityId: driver.id,
      after: { license: "••••" + data.licenseNumber.slice(-3), vehicle: reg, category: data.category },
    });
    return { status: "in_review" as const };
  });
}

export function acceptRide(viewer: SessionUser, rideGroupId: string) {
  const db = getDb();
  const driver = driverForUser(viewer.id);
  if (driver.verification_status !== "verified" || !driver.vehicle_id) {
    throw new ServiceError(403, "Your driver account is not verified yet. An administrator must approve your documents first.");
  }

  return transaction((tx) => {
    const group = tx
      .prepare(
        `SELECT rg.*, d.name AS destination_name, f.flight_number, f.estimated_arrival
           FROM ride_groups rg JOIN destinations d ON d.id = rg.destination_id
           JOIN flights f ON f.id = rg.flight_id WHERE rg.id = ?`,
      )
      .get(rideGroupId) as Record<string, any> | undefined;
    if (!group) throw new ServiceError(404, "Ride request not found");
    if (group.driver_id && group.driver_id !== driver.id) throw new ServiceError(409, "Another driver already accepted this trip");
    if (["completed", "cancelled", "expired"].includes(group.status)) throw new ServiceError(409, "This ride is no longer available");

    const now = new Date().toISOString();
    tx.prepare(
      `UPDATE ride_groups SET driver_id = ?, vehicle_id = ?, status = 'confirmed', updated_at = ? WHERE id = ? AND (driver_id IS NULL OR driver_id = ?)`,
    ).run(driver.id, driver.vehicle_id, now, rideGroupId, driver.id);

    tx.prepare(
      `INSERT INTO ride_status_events (id, ride_group_id, actor_user_id, type, from_status, to_status, created_at)
       VALUES (?, ?, ?, 'driver_accepted', ?, 'confirmed', ?)`,
    ).run(id("rse"), rideGroupId, viewer.id, group.status, now);

    const members = tx.prepare("SELECT user_id FROM ride_members WHERE ride_group_id = ? AND status='accepted'").all(rideGroupId) as {
      user_id: string;
    }[];
    for (const m of members) {
      notify(tx, {
        userId: m.user_id,
        type: "driver_assigned",
        title: `Driver assigned for ${group.code}`,
        body: `${viewer.name} will pick you up in a ${String(driver.category)} (${driver.seats} seats). Head to the meeting point when you're ready.`,
        rideGroupId,
        href: `/app/trips/${rideGroupId}`,
        isDemo: true,
      });
    }
    systemMessage(tx, { rideGroupId, kind: "driver_assigned", body: "A verified driver accepted this trip and is on the way." });

    audit(tx, { actorUserId: viewer.id, action: "driver.accepted_ride", entityType: "ride_groups", entityId: rideGroupId });
    trackEvent(tx, { userId: viewer.id, name: "driver_accepted", props: { rideGroupId } });
    return { status: "confirmed" as const };
  });
}

export function declineRide(viewer: SessionUser, rideGroupId: string) {
  const db = getDb();
  audit(db, { actorUserId: viewer.id, action: "driver.declined_ride", entityType: "ride_groups", entityId: rideGroupId });
  return { ok: true };
}

export function updateTripStatus(viewer: SessionUser, rideGroupId: string, action: "arrived" | "start" | "complete") {
  const db = getDb();
  const driver = driverForUser(viewer.id);

  return transaction((tx) => {
    const group = tx.prepare("SELECT * FROM ride_groups WHERE id = ?").get(rideGroupId) as Record<string, any> | undefined;
    if (!group) throw new ServiceError(404, "Trip not found");
    if (group.driver_id !== driver.id) throw new ServiceError(403, "This trip is assigned to another driver");

    const now = new Date().toISOString();
    const members = tx.prepare("SELECT user_id FROM ride_members WHERE ride_group_id = ? AND status='accepted'").all(rideGroupId) as {
      user_id: string;
    }[];

    if (action === "arrived") {
      tx.prepare("UPDATE ride_members SET readiness='boarding_vehicle' WHERE ride_group_id = ? AND status='accepted'").run(rideGroupId);
      for (const m of members) {
        notify(tx, {
          userId: m.user_id, type: "driver_arrived", title: "Your driver has arrived",
          body: "The vehicle is at the pickup zone. Confirm boarding in the trip screen.",
          rideGroupId, href: `/app/trips/${rideGroupId}`, isDemo: true,
        });
      }
      systemMessage(tx, { rideGroupId, body: "Driver has arrived at the pickup zone." });
      return { status: group.status };
    }

    if (action === "start") {
      tx.prepare("UPDATE ride_groups SET status='in_progress', updated_at=? WHERE id=?").run(now, rideGroupId);
      tx.prepare("UPDATE ride_members SET readiness='trip_started' WHERE ride_group_id=? AND status='accepted'").run(rideGroupId);
      tx.prepare(
        `INSERT INTO ride_status_events (id, ride_group_id, actor_user_id, type, from_status, to_status, created_at)
         VALUES (?, ?, ?, 'trip_started', ?, 'in_progress', ?)`,
      ).run(id("rse"), rideGroupId, viewer.id, group.status, now);
      systemMessage(tx, { rideGroupId, body: "Trip started. Safe travels." });
      return { status: "in_progress" as const };
    }

    // complete
    tx.prepare("UPDATE ride_groups SET status='completed', updated_at=? WHERE id=?").run(now, rideGroupId);
    tx.prepare("UPDATE bookings SET status='completed' WHERE ride_group_id=? AND status IN ('pending','confirmed')").run(rideGroupId);

    const fare = tx
      .prepare("SELECT * FROM fare_estimates WHERE ride_group_id = ? ORDER BY created_at DESC LIMIT 1")
      .get(rideGroupId) as Record<string, any> | undefined;
    const earningsId = id("ern");
    tx.prepare(
      `INSERT INTO driver_earnings (id, driver_id, ride_group_id, gross_paise, commission_paise, deductions_paise, net_paise, status, period, created_at)
       VALUES (?, ?, ?, ?, ?, 0, ?, 'pending', ?, ?)`,
    ).run(
      earningsId, driver.id, rideGroupId,
      fare?.vehicle_fare_paise ?? 0, fare?.fee_paise ?? 0, fare?.vehicle_fare_paise ?? 0,
      now.slice(0, 10), now,
    );

    for (const m of members) {
      notify(tx, {
        userId: m.user_id, type: "trip_completed", title: "Trip completed",
        body: `You arrived. Your final share was ${formatPaise(fare?.total_paise ?? 0)} in total across the group. Leave a rating to help the next passengers.`,
        rideGroupId, href: `/app/trips/${rideGroupId}`, isDemo: true,
      });
    }
    tx.prepare(
      `INSERT INTO ride_status_events (id, ride_group_id, actor_user_id, type, from_status, to_status, created_at)
       VALUES (?, ?, ?, 'trip_completed', ?, 'completed', ?)`,
    ).run(id("rse"), rideGroupId, viewer.id, group.status, now);

    audit(tx, { actorUserId: viewer.id, action: "driver.trip_completed", entityType: "ride_groups", entityId: rideGroupId });
    trackEvent(tx, { userId: viewer.id, name: "ride_completed", props: { rideGroupId } });
    return { status: "completed" as const };
  });
}
