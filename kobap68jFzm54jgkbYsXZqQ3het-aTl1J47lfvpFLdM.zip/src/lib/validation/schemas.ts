import { z } from "zod";

const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

export const AIRLINE_CODES = [
  { code: "AI", name: "Air India" },
  { code: "6E", name: "IndiGo" },
  { code: "UK", name: "Air India Express Connect" },
  { code: "SG", name: "SpiceJet" },
  { code: "QP", name: "Akasa Air" },
  { code: "IX", name: "Air India Express" },
] as const;

export const airlineName = (code: string) =>
  AIRLINE_CODES.find((a) => a.code === code.toUpperCase())?.name ?? code.toUpperCase();

/** "ai 864" → { airlineCode: "AI", flightNumber: "AI864", number: "864" } */
export function normalizeFlight(raw: string) {
  const cleaned = raw.replace(/[\s-]/g, "").toUpperCase();
  const m = cleaned.match(/^([A-Z0-9]{2})(\d{2,5})$/);
  if (!m) return null;
  return { airlineCode: m[1], number: m[2], flightNumber: `${m[1]}${m[2]}` };
}

export const flightNumberSchema = z
  .string()
  .trim()
  .min(3, "Enter a flight number, e.g. AI 864")
  .transform((v) => v.replace(/[\s-]/g, "").toUpperCase())
  .refine((v) => /^[A-Z0-9]{2}\d{2,5}$/.test(v), "Use the airline code and number, e.g. AI 864 or 6E5123");

export const dateSchema = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "Pick a travel date")
  .refine((v) => !Number.isNaN(new Date(`${v}T00:00:00+05:30`).getTime()), "That date is not valid")
  .refine((v) => v >= today(), "Travel date cannot be in the past")
  .refine(
    (v) => v <= new Date(Date.now() + 60 * 864e5).toISOString().slice(0, 10),
    "Choose a date within the next 60 days",
  );

export const flightSearchSchema = z.object({
  airportId: z.string().min(2, "Select an airport"),
  flightNumber: flightNumberSchema,
  date: dateSchema,
  destinationId: z.string().min(1, "Choose where you are heading"),
  passengers: z.coerce.number().int().min(1, "At least 1 passenger").max(6, "Max 6 passengers per booking"),
  luggageUnits: z.coerce.number().int().min(0).max(8, "Max 8 luggage units"),
});
export type FlightSearchInput = z.infer<typeof flightSearchSchema>;

export const calculatorSchema = z.object({
  soloFareRupees: z.coerce.number().min(50, "Minimum ₹50").max(20000),
  sharedFareRupees: z.coerce.number().min(50, "Minimum ₹50").max(20000),
  passengers: z.coerce.number().int().min(1).max(6),
  platformFeePct: z.coerce.number().min(0).max(25),
});

export const passwordSchema = z
  .string()
  .min(8, "Use at least 8 characters")
  .max(128, "That password is too long")
  .refine((v) => /[A-Za-z]/.test(v), "Include at least one letter")
  .refine((v) => /\d/.test(v), "Include at least one number");

export const signupSchema = z.object({
  name: z.string().trim().min(2, "Tell us your name").max(80, "That name is too long"),
  email: z.string().trim().toLowerCase().email("Enter a valid email address"),
  phone: z
    .string()
    .trim()
    .regex(/^(\+91[\s-]?)?[6-9]\d{9}$/, "Enter a valid Indian mobile number")
    .optional()
    .or(z.literal("")),
  password: passwordSchema,
  role: z.enum(["passenger", "driver"]).default("passenger"),
  acceptTerms: z.literal(true, { errorMap: () => ({ message: "Please accept the terms to continue" }) }),
});
export type SignupInput = z.infer<typeof signupSchema>;

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("Enter a valid email address"),
  password: z.string().min(1, "Enter your password"),
});

export const forgotPasswordSchema = z.object({
  email: z.string().trim().toLowerCase().email("Enter a valid email address"),
});

export const resetPasswordSchema = z.object({
  token: z.string().min(10, "This reset link is invalid"),
  password: passwordSchema,
});

export const profileSchema = z.object({
  name: z.string().trim().min(2, "Tell us your name").max(80),
  phone: z
    .string()
    .trim()
    .regex(/^(\+91[\s-]?)?[6-9]\d{9}$/, "Enter a valid Indian mobile number")
    .optional()
    .or(z.literal("")),
  homeDestinationId: z.string().optional(),
  luggagePreference: z.enum(["cabin", "one_checkin", "two_checkin", "heavy"]).optional(),
  accessibilityNeeds: z.string().max(240).optional().or(z.literal("")),
  language: z.enum(["en", "hi", "mr"]).optional(),
  quietRide: z.coerce.boolean().optional(),
  emergencyContactName: z.string().max(80).optional().or(z.literal("")),
  emergencyContactPhone: z
    .string()
    .trim()
    .regex(/^(\+91[\s-]?)?[6-9]\d{9}$/, "Enter a valid Indian mobile number")
    .optional()
    .or(z.literal("")),
});

export const bookingReferenceSchema = z
  .string()
  .trim()
  .toUpperCase()
  .min(5, "Enter the 6-character booking reference from your ticket")
  .max(8, "Booking references are 6–8 characters")
  .regex(/^[A-Z0-9]{5,8}$/, "Use letters and numbers only");

export const joinRequestSchema = z.object({
  rideGroupId: z.string().min(1),
  passengerCount: z.coerce.number().int().min(1).max(6),
  luggageUnits: z.coerce.number().int().min(0).max(8),
  destinationId: z.string().min(1),
  bookingReference: bookingReferenceSchema.optional().or(z.literal("")),
  message: z.string().trim().max(280, "Keep it under 280 characters").optional().or(z.literal("")),
});
export type JoinRequestInput = z.infer<typeof joinRequestSchema>;

export const createRideSchema = z.object({
  flightNumber: z.string().min(3),
  flightDate: dateSchema,
  airportId: z.string().min(2),
  destinationId: z.string().min(1),
  vehicleCategory: z.enum(["sedan", "suv", "mpv"]),
  maxWaitMinutes: z.coerce.number().int().min(15).max(90),
  strategy: z.enum(["equal", "distance", "hybrid"]),
  passengerCount: z.coerce.number().int().min(1).max(4),
  luggageUnits: z.coerce.number().int().min(0).max(6),
  meetPoint: z.string().trim().max(120).optional().or(z.literal("")),
});

export const readinessSchema = z.object({
  rideId: z.string().min(1),
  readiness: z.enum([
    "not_landed",
    "landed",
    "collecting_baggage",
    "ready_at_meeting_point",
    "boarding_vehicle",
    "trip_started",
  ]),
});

export const messageSchema = z.object({
  rideId: z.string().min(1),
  body: z.string().trim().min(1, "Write a message").max(1000, "Messages are limited to 1000 characters"),
});

export const decisionSchema = z.object({
  requestId: z.string().min(1),
  decision: z.enum(["approved", "declined"]),
  note: z.string().trim().max(280).optional().or(z.literal("")),
});

export const pricingRulesSchema = z.object({
  baseFareRupees: z.coerce.number().min(0).max(5000),
  perKmRupees: z.coerce.number().min(1).max(200),
  extraStopRupees: z.coerce.number().min(0).max(2000),
  platformFeePct: z.coerce.number().min(0).max(25),
  platformFeeMinRupees: z.coerce.number().min(0).max(500),
  taxPct: z.coerce.number().min(0).max(28),
  maxWaitMinutes: z.coerce.number().int().min(10).max(120),
  destinationThreshold: z.coerce.number().min(0).max(1),
});

export const driverVerificationSchema = z.object({
  licenseNumber: z.string().trim().min(5, "Enter your driving licence number").max(24),
  vehicleModel: z.string().trim().min(2, "Enter the vehicle model").max(40),
  vehicleRegNumber: z
    .string()
    .trim()
    .toUpperCase()
    .regex(/^[A-Z]{2}[\s-]?\d{1,2}[\s-]?[A-Z]{1,3}[\s-]?\d{3,4}$/, "Enter a registration like MH 02 AB 1234"),
  category: z.enum(["sedan", "suv", "mpv"]),
  seats: z.coerce.number().int().min(2).max(8),
  luggageUnits: z.coerce.number().int().min(1).max(10),
  fleetPartner: z.string().trim().max(80).optional().or(z.literal("")),
  consent: z.literal(true, { errorMap: () => ({ message: "Confirm the documents are genuine" }) }),
});

export const supportTicketSchema = z.object({
  subject: z.string().trim().min(4, "Add a short subject").max(120),
  category: z.enum(["fare", "trip", "safety", "account", "driver", "other"]),
  body: z.string().trim().min(20, "Add a little more detail (20+ characters)").max(3000),
});

export const reportSchema = z.object({
  subjectUserId: z.string().optional(),
  rideGroupId: z.string().optional(),
  category: z.enum(["safety", "harassment", "no_show", "fare_dispute", "fake_booking", "other"]),
  details: z.string().trim().min(15, "Describe what happened").max(1500),
});
