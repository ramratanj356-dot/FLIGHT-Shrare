export const IST_OFFSET_MINUTES = 330;
export const APP_TIMEZONE = "Asia/Kolkata";
