/**
 * Domain error shared by every service. Lives outside the service modules so
 * the HTTP layer can map it to a status code without importing a service
 * (which would pull the database into the error handler).
 */
export class ServiceError extends Error {
  constructor(
    public status: number,
    message: string,
    public code?: string,
  ) {
    super(message);
    this.name = "ServiceError";
  }
}

/** True when `err` is a domain error with an HTTP status attached. */
export function isServiceError(err: unknown): err is ServiceError {
  return (
    err instanceof ServiceError ||
    (typeof err === "object" && err !== null && typeof (err as { status?: unknown }).status === "number" && err instanceof Error && (err as { name?: string }).name === "ServiceError")
  );
}
