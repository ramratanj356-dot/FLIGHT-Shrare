import "server-only";
import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { AuthError } from "@/lib/auth/guards";
import { ServiceError } from "@/lib/security/errors";

export const jsonOk = <T,>(data: T, init?: ResponseInit) =>
  NextResponse.json({ ok: true, data }, { status: 200, ...init });

export const jsonError = (status: number, message: string, extra?: Record<string, unknown>) =>
  NextResponse.json({ ok: false, error: message, ...extra }, { status });

/** Uniform error translation for every API route. */
export function handleApiError(err: unknown) {
  if (err instanceof AuthError) return jsonError(err.status, err.message);
  // Domain errors carry their own status (404 not found, 409 overbooked,
  // 403 not the coordinator, 429 rate limited, …) plus an optional code the
  // client can branch on. They are expected conditions, so no stack logged.
  if (err instanceof ServiceError) return jsonError(err.status, err.message, err.code ? { code: err.code } : undefined);
  if (err instanceof ZodError) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of err.issues) fieldErrors[issue.path.join(".") || "_"] = issue.message;
    return jsonError(422, "Please check the highlighted fields", { fieldErrors });
  }
  const status = (err as { status?: unknown } | null)?.status;
  const message = err instanceof Error ? err.message : "Something went wrong";
  if (typeof status === "number" && status >= 400 && status < 500) return jsonError(status, message);
  console.error("[api]", err);
  return jsonError(500, "Something went wrong. Please try again.");
}

/**
 * Same-origin enforcement for state-changing requests. Cookies are already
 * SameSite=Lax; this is belt-and-braces against cross-site form posts.
 */
export function assertSameOrigin(req: Request) {
  const origin = req.headers.get("origin");
  if (!origin) return true; // same-origin fetches from the app always send Origin
  const host = req.headers.get("host");
  try {
    const originHost = new URL(origin).host;
    return originHost === host;
  } catch {
    return false;
  }
}

export async function readJson(req: Request) {
  try {
    return await req.json();
  } catch {
    throw Object.assign(new Error("Request body must be valid JSON"), { status: 400 });
  }
}
