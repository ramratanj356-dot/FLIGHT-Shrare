import "server-only";
import { getDb } from "@/lib/db";

/**
 * Fixed-window limiter backed by the database so it survives multiple
 * processes. Swap for Redis/Upstash when horizontally scaling.
 */
export function enforceRateLimit(key: string, limit: number, windowSeconds: number) {
  const db = getDb();
  const now = Date.now();
  const windowStart = new Date(now - windowSeconds * 1000).toISOString();

  const row = db.prepare("SELECT count, window_start FROM rate_limits WHERE key = ?").get(key) as
    | { count: number; window_start: string }
    | undefined;

  if (!row || row.window_start < windowStart) {
    db.prepare(
      `INSERT INTO rate_limits (key, count, window_start) VALUES (?, 1, ?)
       ON CONFLICT(key) DO UPDATE SET count = 1, window_start = excluded.window_start`,
    ).run(key, new Date(now).toISOString());
    return { ok: true, remaining: limit - 1, retryAfter: 0 };
  }

  if (row.count >= limit) {
    const retryAfter = Math.ceil((new Date(row.window_start).getTime() + windowSeconds * 1000 - now) / 1000);
    return { ok: false, remaining: 0, retryAfter: Math.max(1, retryAfter) };
  }

  db.prepare("UPDATE rate_limits SET count = count + 1 WHERE key = ?").run(key);
  return { ok: true, remaining: limit - row.count - 1, retryAfter: 0 };
}

export function clientKey(req: Request, scope: string) {
  const h = req.headers;
  const ip =
    h.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    h.get("x-real-ip") ??
    "local";
  return `${scope}:${ip}`;
}
