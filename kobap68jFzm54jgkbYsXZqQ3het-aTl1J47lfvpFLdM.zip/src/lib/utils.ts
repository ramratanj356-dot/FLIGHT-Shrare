import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? "")
    .join("");
}

/** Deterministic avatar palette index from a string (no random colours per render). */
export function avatarTone(seed: string) {
  const tones = ["indigo", "green", "amber", "rose", "sky", "violet"] as const;
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return tones[h % tones.length];
}

const IST = "Asia/Kolkata";

export function formatDateLong(d: Date | string | number) {
  const date = new Date(d);
  return new Intl.DateTimeFormat("en-IN", {
    weekday: "short", day: "numeric", month: "short", timeZone: IST,
  }).format(date);
}

export function formatDateShort(d: Date | string | number) {
  return new Intl.DateTimeFormat("en-IN", { day: "2-digit", month: "short", timeZone: IST }).format(new Date(d));
}

export function formatTime(d: Date | string | number) {
  return new Intl.DateTimeFormat("en-IN", {
    hour: "2-digit", minute: "2-digit", hour12: true, timeZone: IST,
  }).format(new Date(d));
}

export function formatDateTime(d: Date | string | number) {
  return `${formatDateShort(d)} · ${formatTime(d)}`;
}

export function relativeTime(d: Date | string | number) {
  const t = new Date(d).getTime();
  const diff = t - Date.now();
  const abs = Math.abs(diff);
  const units: [Intl.RelativeTimeFormatUnit, number][] = [
    ["day", 86400000], ["hour", 3600000], ["minute", 60000], ["second", 1000],
  ];
  const rtf = new Intl.RelativeTimeFormat("en", { numeric: "auto" });
  for (const [unit, ms] of units) {
    if (abs >= ms || unit === "second") return rtf.format(Math.round(diff / ms), unit);
  }
  return "now";
}

export function minutesBetween(a: Date | string | number, b: Date | string | number) {
  return Math.round((new Date(b).getTime() - new Date(a).getTime()) / 60000);
}

/** yyyy-mm-dd in IST */
export function toDateKey(d: Date | string | number = new Date()) {
  return new Intl.DateTimeFormat("en-CA", { timeZone: IST, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(d));
}

export function addDays(d: Date | string, days: number) {
  const date = new Date(d);
  date.setDate(date.getDate() + days);
  return date;
}

/** Combine an IST calendar date (yyyy-mm-dd) + HH:mm into a UTC Date. IST = UTC+5:30 */
export function istDateTime(dateKey: string, hhmm: string) {
  return new Date(`${dateKey}T${hhmm}:00+05:30`);
}

export function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

export function slugify(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}
