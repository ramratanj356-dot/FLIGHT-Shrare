/**
 * Money is stored and computed in integer paise (1 INR = 100 paise).
 * Never use floats for money in the domain layer — floating point rounding
 * produces fare-splits whose parts do not add up to the total.
 */
export type Paise = number;

export const INR = (rupees: number): Paise => Math.round(rupees * 100);

export function fromPaise(p: Paise) {
  return p / 100;
}

/** ₹1,234 — drops paise when whole, otherwise ₹1,234.50 */
export function formatPaise(p: Paise, opts: { showPaise?: boolean } = {}) {
  const whole = p % 100 === 0 && !opts.showPaise;
  const value = p / 100;
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: whole ? 0 : 2,
    maximumFractionDigits: whole ? 0 : 2,
  }).format(value);
}

export function formatPaiseCompact(p: Paise) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency", currency: "INR", maximumFractionDigits: 0,
  }).format(Math.round(p / 100));
}

export function percent(part: Paise, total: Paise) {
  if (total <= 0) return 0;
  return Math.round((part / total) * 1000) / 10; // one decimal
}

/**
 * Split `total` into weighted integer parts that sum EXACTLY to `total`.
 * Uses the largest-remainder method with a deterministic tie-break
 * (weight desc, then index asc) so results are reproducible.
 */
export function allocate(
  total: Paise,
  weights: { id: string; weight: number }[],
): { id: string; amount: Paise; remainder: boolean }[] {
  if (!Number.isInteger(total)) throw new Error("allocate() requires integer paise");
  if (weights.length === 0) return [];
  const safe = weights.map((w) => ({ id: w.id, weight: Math.max(0, w.weight) }));
  const totalWeight = safe.reduce((s, w) => s + w.weight, 0);
  if (totalWeight <= 0) {
    return allocate(total, safe.map((w) => ({ id: w.id, weight: 1 })));
  }
  const raw = safe.map((w) => ({ ...w, exact: (total * w.weight) / totalWeight }));
  const floored = raw.map((r) => ({ ...r, amount: Math.floor(r.exact), frac: r.exact - Math.floor(r.exact) }));
  let remainder = total - floored.reduce((s, r) => s + r.amount, 0);
  const order = [...floored].sort((a, b) => (b.frac - a.frac) || (b.weight - a.weight) || a.id.localeCompare(b.id));
  const bumped = new Set<string>();
  for (const row of order) {
    if (remainder <= 0) break;
    row.amount += 1;
    bumped.add(row.id);
    remainder -= 1;
  }
  return floored.map((r) => ({ id: r.id, amount: r.amount, remainder: bumped.has(r.id) }));
}

/**
 * Allocate a whole-rupee total into whole-rupee parts that sum exactly.
 * Cab fares in India are quoted in rupees; showing paise fractions on a
 * passenger's share looks like a bug even when it is arithmetically correct.
 * We therefore keep paise internally and settle settlements at rupee
 * granularity, distributing the rounding remainder with the same
 * largest-remainder rule.
 */
export function allocateRupees(totalPaise: Paise, weights: { id: string; weight: number }[]) {
  if (totalPaise % 100 !== 0) throw new Error("allocateRupees requires a whole-rupee total");
  return allocate(totalPaise / 100, weights).map((r) => ({ ...r, amount: r.amount * 100 }));
}

export function roundToRupee(p: Paise): Paise {
  return Math.round(p / 100) * 100;
}
