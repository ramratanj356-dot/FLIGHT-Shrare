import "server-only";
import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";

/**
 * Local data adapter.
 *
 * The application is written against a narrow repository interface
 * (see queries.ts) so the underlying engine can be swapped for
 * PostgreSQL/Supabase in production without touching UI code.
 * See db/schema.postgres.sql for the production schema + RLS policies.
 */
export type DB = Database.Database;

const globalForDb = globalThis as unknown as { __flightshareDb?: DB };

function resolveDbPath() {
  const configured = process.env.DATABASE_PATH ?? "./data/flightshare.db";
  return path.isAbsolute(configured) ? configured : path.join(process.cwd(), configured);
}

function resolveSchemaPath() {
  const candidates = [
    path.join(process.cwd(), "db", "schema.sql"),
    path.join(process.cwd(), "..", "db", "schema.sql"),
  ];
  const found = candidates.find((p) => fs.existsSync(p));
  if (!found) {
    throw new Error(
      "db/schema.sql not found. Run this app from the project root, or run `npm run db:reset`.",
    );
  }
  return found;
}

function open(): DB {
  const file = resolveDbPath();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new Database(file);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  db.pragma("busy_timeout = 5000");
  db.exec(fs.readFileSync(resolveSchemaPath(), "utf8"));
  return db;
}

export function getDb(): DB {
  if (!globalForDb.__flightshareDb) {
    globalForDb.__flightshareDb = open();
    // Demo data has a rolling horizon; keep it fresh on first touch.
    void bootstrapDemoData(globalForDb.__flightshareDb);
  }
  return globalForDb.__flightshareDb;
}

/** Called once per process. Never allowed to break a page render. */
async function bootstrapDemoData(db: DB) {
  try {
    const { ensureDemoData } = await import("@/lib/demo/seed");
    ensureDemoData(db);
  } catch (err) {
    console.error("[flightshare] demo bootstrap skipped:", err);
  }
}

export function nowIso() {
  return new Date().toISOString();
}

export function id(prefix: string) {
  const bytes = new Uint8Array(9);
  crypto.getRandomValues(bytes);
  const s = Array.from(bytes, (b) => b.toString(36).padStart(2, "0")).join("");
  return `${prefix}_${s.slice(0, 14)}`;
}

export function transaction<T>(fn: (db: DB) => T): T {
  const db = getDb();
  const tx = db.transaction(fn);
  return tx(db);
}

export function healthCheck() {
  try {
    const db = getDb();
    const row = db.prepare("SELECT count(*) AS n FROM airports").get() as { n: number };
    return { ok: true, airports: row.n };
  } catch (err) {
    return { ok: false, error: (err as Error).message };
  }
}
