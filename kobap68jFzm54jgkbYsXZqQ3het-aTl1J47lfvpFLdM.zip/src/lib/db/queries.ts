import "server-only";
import { getDb, type DB } from "@/lib/db";
import type { GroupFare } from "@/lib/fares/group";
import type { PricingRules } from "@/lib/config/pricing";
import { loadPricingRules } from "./pricing";

// ── Row types ───────────────────────────────────────────────────────────────
export interface DestinationRow {
  id: string;
  airport_id: string;
  name: string;
  area: string;
  corridor: string;
  lat: number;
  lng: number;
  distance_km: number;
  drive_minutes: number;
  solo_fare_paise: number;
  tolls_paise: number;
  blurb: string | null;
}

export interface FlightRow {
  id: string;
  airport_id: string;
  airline_code: string;
  airline_name: string;
  flight_number: string;
  origin_city: string;
  flight_date: string;
  terminal: string | null;
  scheduled_arrival: string;
  estimated_arrival: string;
  status: "scheduled" | "enroute" | "landed" | "delayed" | "cancelled";
  source: "demo" | "provider" | "manual";
}

export interface PublicMember {
  memberId: string;
  userId: string;
  firstName: string;
  displayName: string;
  seats: number;
  luggageUnits: number;
  destinationId: string;
  destinationName: string;
  readiness: string;
  expectedReadyAt: string | null;
  role: "owner" | "member";
  identityVerified: boolean;
  flightVerified: boolean;
  rating: number;
  ratingCount: number;
  isYou: boolean;
}

export interface RideGroupSummary {
  id: string;
  code: string;
  status: string;
  destination: DestinationRow;
  extraDestinations: DestinationRow[];
  flight: FlightRow;
  vehicleCategory: "sedan" | "suv" | "mpv";
  strategy: string;
  seatsTotal: number;
  seatsTaken: number;
  seatsAvailable: number;
  luggageTotal: number;
  luggageTaken: number;
  luggageAvailable: number;
  meetPoint: string | null;
  departureWindowStart: string;
  departureWindowEnd: string;
  maxWaitMinutes: number;
  fare: GroupFare | null;
  members: PublicMember[];
  driver: { name: string; vehicle: string; rating: number; verified: boolean } | null;
  createdAt: string;
  isDemo: boolean;
}

// ── Helpers ─────────────────────────────────────────────────────────────────
const db = () => getDb();

function parseFare(json: string | null): GroupFare | null {
  if (!json) return null;
  try {
    return JSON.parse(json) as GroupFare;
  } catch {
    return null;
  }
}

function firstName(full: string) {
  return full.split(" ")[0];
}
function shortName(full: string) {
  const parts = full.trim().split(/\s+/);
  if (parts.length === 1) return parts[0];
  return `${parts[0]} ${parts[parts.length - 1][0]}.`;
}

/** Destinations ordered by how many open groups currently head there. */
export function listPopularDestinationsWithGroups(limit = 12) {
  return db()
    .prepare(
      `SELECT d.id, d.name, d.area, d.corridor, d.distance_km, d.drive_minutes, d.solo_fare_paise,
              COUNT(rg.id) AS groups
         FROM destinations d
         LEFT JOIN ride_groups rg ON rg.destination_id = d.id AND rg.status = 'open' AND rg.seats_taken < rg.seats_total
        GROUP BY d.id
        ORDER BY groups DESC, d.distance_km ASC
        LIMIT ?`,
    )
    .all(limit) as {
    id: string; name: string; area: string; corridor: string; distance_km: number;
    drive_minutes: number; solo_fare_paise: number; groups: number;
  }[];
}

export function listDestinations(airportId = "apt_bom"): DestinationRow[] {
  return db()
    .prepare("SELECT * FROM destinations WHERE airport_id = ? AND is_active = 1 ORDER BY sort_order")
    .all(airportId) as DestinationRow[];
}

export function getDestination(id: string): DestinationRow | undefined {
  return db().prepare("SELECT * FROM destinations WHERE id = ?").get(id) as DestinationRow | undefined;
}

export function getAirport(code = "BOM") {
  return db().prepare("SELECT * FROM airports WHERE code = ?").get(code) as
    | { id: string; code: string; name: string; city: string }
    | undefined;
}

export function getPricingRules(): PricingRules {
  return loadPricingRules(db());
}

// ── Flights ─────────────────────────────────────────────────────────────────
export function findFlight(airportId: string, flightNumber: string, date: string): FlightRow | undefined {
  const normalized = flightNumber.replace(/[\s-]/g, "").toUpperCase();
  return db()
    .prepare("SELECT * FROM flights WHERE airport_id = ? AND flight_number = ? AND flight_date = ?")
    .get(airportId, normalized, date) as FlightRow | undefined;
}

export function listFlightsForDate(airportId: string, date: string): FlightRow[] {
  return db()
    .prepare("SELECT * FROM flights WHERE airport_id = ? AND flight_date = ? ORDER BY scheduled_arrival")
    .all(airportId, date) as FlightRow[];
}

export function listFlightDates(airportId = "apt_bom"): { date: string; groups: number }[] {
  return db()
    .prepare(
      `SELECT f.flight_date AS date, COUNT(rg.id) AS groups
         FROM flights f LEFT JOIN ride_groups rg ON rg.flight_id = f.id AND rg.status IN ('open','confirmed','full')
        WHERE f.airport_id = ? AND f.flight_date >= date('now','-1 day')
        GROUP BY f.flight_date HAVING groups > 0 ORDER BY f.flight_date LIMIT 30`,
    )
    .all(airportId) as { date: string; groups: number }[];
}

// ── Ride groups ─────────────────────────────────────────────────────────────
const GROUP_SELECT = `
  SELECT rg.*, f.airline_code, f.airline_name, f.flight_number AS f_flight_number, f.origin_city,
         f.flight_date, f.scheduled_arrival, f.estimated_arrival, f.status AS flight_status,
         f.terminal, f.source AS flight_source, f.airport_id,
         d.name AS dest_name, d.distance_km, d.drive_minutes, d.solo_fare_paise, d.lat, d.lng, d.tolls_paise,
         d.area, d.corridor, d.blurb, d.airport_id AS dest_airport_id, d.id AS dest_id
    FROM ride_groups rg
    JOIN flights f ON f.id = rg.flight_id
    JOIN destinations d ON d.id = rg.destination_id
`;

type GroupRow = Record<string, any>;

function toFlight(r: GroupRow): FlightRow {
  return {
    id: r.flight_id,
    airport_id: r.airport_id,
    airline_code: r.airline_code,
    airline_name: r.airline_name,
    flight_number: r.f_flight_number,
    origin_city: r.origin_city,
    flight_date: r.flight_date,
    terminal: r.terminal,
    scheduled_arrival: r.scheduled_arrival,
    estimated_arrival: r.estimated_arrival,
    status: r.flight_status,
    source: r.flight_source,
  };
}

function toDestination(r: GroupRow): DestinationRow {
  return {
    id: r.dest_id,
    airport_id: r.dest_airport_id,
    name: r.dest_name,
    area: r.area,
    corridor: r.corridor,
    lat: r.lat,
    lng: r.lng,
    distance_km: r.distance_km,
    drive_minutes: r.drive_minutes,
    solo_fare_paise: r.solo_fare_paise,
    tolls_paise: r.tolls_paise,
    blurb: r.blurb,
  };
}

function loadMembers(groupId: string, viewerId?: string | null): PublicMember[] {
  const rows = db()
    .prepare(
      `SELECT rm.id, rm.user_id, rm.seat_count, rm.luggage_units, rm.destination_id, rm.readiness,
              rm.expected_ready_at, rm.role, u.name, p.identity_status, p.rating_avg, p.rating_count,
              d.name AS dest_name,
              (SELECT COUNT(*) FROM flight_verifications fv WHERE fv.user_id = rm.user_id AND fv.status = 'verified') AS fv_count
         FROM ride_members rm
         JOIN users u ON u.id = rm.user_id
         LEFT JOIN passenger_profiles p ON p.user_id = rm.user_id
         LEFT JOIN destinations d ON d.id = rm.destination_id
        WHERE rm.ride_group_id = ? AND rm.status = 'accepted'
        ORDER BY rm.role = 'owner' DESC, rm.joined_at`,
    )
    .all(groupId) as GroupRow[];

  return rows.map((m) => ({
    memberId: m.id,
    userId: m.user_id,
    firstName: firstName(m.name),
    displayName: m.user_id === viewerId ? `${shortName(m.name)} (you)` : shortName(m.name),
    seats: m.seat_count,
    luggageUnits: m.luggage_units,
    destinationId: m.destination_id,
    destinationName: m.dest_name ?? "—",
    readiness: m.readiness,
    expectedReadyAt: m.expected_ready_at,
    role: m.role,
    identityVerified: m.identity_status === "verified",
    flightVerified: Number(m.fv_count) > 0,
    rating: m.rating_avg ?? 0,
    ratingCount: m.rating_count ?? 0,
    isYou: m.user_id === viewerId,
  }));
}

function loadDriver(groupId: string) {
  const row = db()
    .prepare(
      `SELECT u.name, v.make_model, v.registration_number, dp.rating_avg, dp.verification_status
         FROM ride_groups rg
         JOIN driver_profiles dp ON dp.id = rg.driver_id
         JOIN users u ON u.id = dp.user_id
         LEFT JOIN vehicles v ON v.id = rg.vehicle_id
        WHERE rg.id = ?`,
    )
    .get(groupId) as GroupRow | undefined;
  if (!row) return null;
  return {
    name: firstName(row.name),
    vehicle: row.make_model ? `${row.make_model} · ${row.registration_number}` : "Vehicle pending",
    rating: row.rating_avg ?? 0,
    verified: row.verification_status === "verified",
  };
}

function buildSummary(r: GroupRow, viewerId?: string | null): RideGroupSummary {
  const members = loadMembers(r.id, viewerId);
  const extraIds = [...new Set(members.map((m) => m.destinationId))].filter((id) => id !== r.destination_id);
  const extraDestinations = extraIds
    .map((id) => getDestination(id))
    .filter((d): d is DestinationRow => Boolean(d));

  const fareRow = db()
    .prepare("SELECT breakdown_json FROM fare_estimates WHERE ride_group_id = ? ORDER BY created_at DESC LIMIT 1")
    .get(r.id) as { breakdown_json: string } | undefined;

  return {
    id: r.id,
    code: r.code,
    status: r.status,
    destination: toDestination(r),
    extraDestinations,
    flight: toFlight(r),
    vehicleCategory: r.vehicle_category,
    strategy: r.fare_strategy,
    seatsTotal: r.seats_total,
    seatsTaken: r.seats_taken,
    seatsAvailable: Math.max(0, r.seats_total - r.seats_taken),
    luggageTotal: r.luggage_total,
    luggageTaken: r.luggage_taken,
    luggageAvailable: Math.max(0, r.luggage_total - r.luggage_taken),
    meetPoint: r.meet_point,
    departureWindowStart: r.departure_window_start,
    departureWindowEnd: r.departure_window_end,
    maxWaitMinutes: r.max_wait_minutes,
    fare: parseFare(fareRow?.breakdown_json ?? null),
    members,
    driver: loadDriver(r.id),
    createdAt: r.created_at,
    isDemo: r.flight_source === "demo" && Boolean(r.is_demo_origin),
  };
}

export function listGroupsForFlight(flightId: string, viewerId?: string | null): RideGroupSummary[] {
  const rows = db()
    .prepare(`${GROUP_SELECT} WHERE rg.flight_id = ? AND rg.status NOT IN ('cancelled','expired','draft') ORDER BY rg.departure_window_start, rg.seats_taken DESC`)
    .all(flightId) as GroupRow[];
  return rows.map((r) => buildSummary(r, viewerId));
}

export function listUpcomingGroupsForDate(airportId: string, date: string, viewerId?: string | null) {
  const rows = db()
    .prepare(
      `${GROUP_SELECT} WHERE f.airport_id = ? AND f.flight_date = ? AND rg.status IN ('open','full','confirmed')
        ORDER BY f.scheduled_arrival, rg.departure_window_start LIMIT 40`,
    )
    .all(airportId, date) as GroupRow[];
  return rows.map((r) => buildSummary(r, viewerId));
}

export function getRideGroup(groupId: string, viewerId?: string | null): RideGroupSummary | null {
  const row = db().prepare(`${GROUP_SELECT} WHERE rg.id = ?`).get(groupId) as GroupRow | undefined;
  return row ? buildSummary(row, viewerId) : null;
}

export function getGroupMembership(groupId: string, userId: string) {
  return db()
    .prepare("SELECT * FROM ride_members WHERE ride_group_id = ? AND user_id = ? AND status = 'accepted'")
    .get(groupId, userId) as
    | { id: string; seat_count: number; readiness: string; role: string; destination_id: string }
    | undefined;
}

export function getPendingJoinRequest(groupId: string, userId: string) {
  return db()
    .prepare("SELECT * FROM join_requests WHERE ride_group_id = ? AND user_id = ? AND status = 'pending'")
    .get(groupId, userId) as { id: string; status: string } | undefined;
}

export interface JoinRequestRow {
  id: string;
  ride_group_id: string;
  user_id: string;
  passenger_count: number;
  luggage_units: number;
  destination_id: string;
  message: string | null;
  match_score: number | null;
  status: string;
  created_at: string;
  name: string;
  destination_name: string;
  identity_status: string;
  rating_avg: number;
  trip_code: string;
  trip_destination: string;
}

export function listJoinRequestsForGroup(groupId: string): JoinRequestRow[] {
  return db()
    .prepare(
      `SELECT jr.*, u.name, d.name AS destination_name, p.identity_status, p.rating_avg,
              rg.code AS trip_code, dd.name AS trip_destination
         FROM join_requests jr
         JOIN users u ON u.id = jr.user_id
         LEFT JOIN destinations d ON d.id = jr.destination_id
         LEFT JOIN passenger_profiles p ON p.user_id = jr.user_id
         JOIN ride_groups rg ON rg.id = jr.ride_group_id
         JOIN destinations dd ON dd.id = rg.destination_id
        WHERE jr.ride_group_id = ? AND jr.status = 'pending'
        ORDER BY jr.created_at`,
    )
    .all(groupId) as JoinRequestRow[];
}

export function listOwnedJoinRequests(ownerId: string): JoinRequestRow[] {
  return db()
    .prepare(
      `SELECT jr.*, u.name, d.name AS destination_name, p.identity_status, p.rating_avg,
              rg.code AS trip_code, dd.name AS trip_destination
         FROM join_requests jr
         JOIN ride_members rm ON rm.ride_group_id = jr.ride_group_id AND rm.user_id = ? AND rm.role = 'owner' AND rm.status = 'accepted'
         JOIN users u ON u.id = jr.user_id
         LEFT JOIN destinations d ON d.id = jr.destination_id
         LEFT JOIN passenger_profiles p ON p.user_id = jr.user_id
         JOIN ride_groups rg ON rg.id = jr.ride_group_id
         JOIN destinations dd ON dd.id = rg.destination_id
        WHERE jr.status = 'pending'
        ORDER BY jr.created_at DESC`,
    )
    .all(ownerId) as JoinRequestRow[];
}

// ── Trips for a user ────────────────────────────────────────────────────────
export interface UserTrip {
  group: RideGroupSummary;
  membershipRole: string;
  readiness: string;
  myContributionPaise: number;
  mySoloEstimatePaise: number;
  mySavingsPaise: number;
  bookingId: string | null;
  bookingStatus: string | null;
  paymentStatus: string | null;
  hasReviewed: boolean;
}

export function listUserTrips(userId: string, filter: "upcoming" | "past" | "all" = "all"): UserTrip[] {
  const rows = db()
    .prepare(
      `${GROUP_SELECT}
        JOIN ride_members rm2 ON rm2.ride_group_id = rg.id AND rm2.user_id = ? AND rm2.status = 'accepted'
        WHERE (? = 'all'
           OR (? = 'upcoming' AND rg.status IN ('open','full','confirmed','in_progress'))
           OR (? = 'past' AND rg.status IN ('completed','cancelled')))
        ORDER BY f.estimated_arrival DESC`,
    )
    .all(userId, filter, filter, filter) as GroupRow[];

  return rows.map((r) => {
    const group = buildSummary(r, userId);
    const me = db()
      .prepare(
        `SELECT rm.role, rm.readiness, fa.contribution_paise, fa.solo_fare_paise, fa.savings_paise
           FROM ride_members rm
           LEFT JOIN fare_allocations fa ON fa.ride_group_id = rm.ride_group_id AND fa.user_id = rm.user_id
          WHERE rm.ride_group_id = ? AND rm.user_id = ?`,
      )
      .get(r.id, userId) as GroupRow | undefined;
    const booking = db()
      .prepare("SELECT id, status, payment_status FROM bookings WHERE ride_group_id = ? AND user_id = ?")
      .get(r.id, userId) as GroupRow | undefined;
    const reviewed = db()
      .prepare("SELECT 1 AS x FROM reviews WHERE ride_group_id = ? AND author_user_id = ?")
      .get(r.id, userId);

    return {
      group,
      membershipRole: me?.role ?? "member",
      readiness: me?.readiness ?? "not_landed",
      myContributionPaise: me?.contribution_paise ?? 0,
      mySoloEstimatePaise: me?.solo_fare_paise ?? 0,
      mySavingsPaise: me?.savings_paise ?? 0,
      bookingId: booking?.id ?? null,
      bookingStatus: booking?.status ?? null,
      paymentStatus: booking?.payment_status ?? null,
      hasReviewed: Boolean(reviewed),
    };
  });
}

export function getTripDetail(groupId: string, userId: string) {
  const row = db().prepare(`${GROUP_SELECT} WHERE rg.id = ?`).get(groupId) as GroupRow | undefined;
  if (!row) return null;
  const membership = getGroupMembership(groupId, userId);
  const group = buildSummary(row, userId);
  const myFare = group.fare?.members.find((m) => m.userId === userId) ?? null;
  const booking = db()
    .prepare("SELECT * FROM bookings WHERE ride_group_id = ? AND user_id = ?")
    .get(groupId, userId) as GroupRow | undefined;
  const payment = booking
    ? (db().prepare("SELECT * FROM payment_records WHERE booking_id = ? ORDER BY created_at DESC LIMIT 1").get(booking.id) as GroupRow | undefined)
    : undefined;
  const events = db()
    .prepare("SELECT * FROM ride_status_events WHERE ride_group_id = ? ORDER BY created_at DESC LIMIT 12")
    .all(groupId) as GroupRow[];
  const conversation = db().prepare("SELECT id FROM conversations WHERE ride_group_id = ?").get(groupId) as
    | { id: string }
    | undefined;
  const joinRequests = membership?.role === "owner" ? listJoinRequestsForGroup(groupId) : [];

  return {
    group,
    membership,
    isMember: Boolean(membership),
    isOwner: membership?.role === "owner",
    myFare,
    booking,
    payment,
    events,
    conversationId: conversation?.id ?? null,
    joinRequests,
    waitPolicy: { maxWaitMinutes: group.maxWaitMinutes },
  };
}

// ── Notifications ───────────────────────────────────────────────────────────
export function listNotifications(userId: string, limit = 30) {
  return db()
    .prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?")
    .all(userId, limit) as {
    id: string;
    type: string;
    title: string;
    body: string;
    href: string | null;
    is_demo: number;
    read_at: string | null;
    created_at: string;
  }[];
}

/** Total unread messages across every conversation the viewer participates in. */
export function unreadMessageCount(userId: string): number {
  const row = db()
    .prepare(
      `SELECT COUNT(*) AS n
         FROM messages m
         JOIN conversations c ON c.id = m.conversation_id
         JOIN ride_members rm ON rm.ride_group_id = c.ride_group_id AND rm.user_id = ? AND rm.status = 'accepted'
         LEFT JOIN message_reads mr ON mr.message_id = m.id AND mr.user_id = ?
        WHERE m.sender_user_id <> ? AND mr.message_id IS NULL`,
    )
    .get(userId, userId, userId) as { n: number } | undefined;
  return Number(row?.n ?? 0);
}

export function unreadNotificationCount(userId: string) {
  const row = db()
    .prepare("SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND read_at IS NULL")
    .get(userId) as { n: number };
  return row.n;
}

// ── Chat ────────────────────────────────────────────────────────────────────
export function listUserConversations(userId: string) {
  return db()
    .prepare(
      `SELECT c.id, c.ride_group_id, rg.code, d.name AS destination, f.flight_number, f.flight_date,
              rg.status, rg.departure_window_start,
              (SELECT body FROM messages m WHERE m.conversation_id = c.id ORDER BY m.created_at DESC LIMIT 1) AS last_body,
              (SELECT created_at FROM messages m WHERE m.conversation_id = c.id ORDER BY m.created_at DESC LIMIT 1) AS last_at,
              (SELECT COUNT(*) FROM messages m WHERE m.conversation_id = c.id) AS message_count
         FROM conversations c
         JOIN ride_groups rg ON rg.id = c.ride_group_id
         JOIN destinations d ON d.id = rg.destination_id
         JOIN flights f ON f.id = rg.flight_id
         JOIN ride_members rm ON rm.ride_group_id = rg.id AND rm.user_id = ? AND rm.status = 'accepted'
        ORDER BY COALESCE(last_at, c.created_at) DESC`,
    )
    .all(userId) as GroupRow[];
}

export function listMessages(conversationId: string, viewerId: string, after?: string) {
  const params: unknown[] = [conversationId];
  let sql = `SELECT m.id, m.body, m.kind, m.created_at, m.sender_user_id, u.name AS sender_name,
                    CASE WHEN m.sender_user_id = ? THEN 1 ELSE 0 END AS is_mine
               FROM messages m JOIN users u ON u.id = m.sender_user_id
              WHERE m.conversation_id = ?`;
  params.unshift(viewerId);
  if (after) {
    sql += " AND m.created_at > ?";
    params.push(after);
  }
  sql += " ORDER BY m.created_at LIMIT 200";
  return db().prepare(sql).all(...params) as {
    id: string;
    body: string;
    kind: string;
    created_at: string;
    sender_user_id: string;
    sender_name: string;
    is_mine: number;
  }[];
}

export function canAccessConversation(conversationId: string, userId: string) {
  const row = db()
    .prepare(
      `SELECT 1 AS ok FROM conversations c
         JOIN ride_members rm ON rm.ride_group_id = c.ride_group_id AND rm.user_id = ? AND rm.status = 'accepted'
        WHERE c.id = ?`,
    )
    .get(userId, conversationId);
  return Boolean(row);
}

// ── Profile ─────────────────────────────────────────────────────────────────
export function getPassengerProfile(userId: string) {
  return db()
    .prepare(
      `SELECT u.id, u.name, u.email, u.phone, u.avatar_url, u.email_verified_at, u.phone_verified_at, u.role, u.created_at,
              p.identity_status, p.identity_provider, p.home_destination_id, p.luggage_preference, p.accessibility_needs,
              p.language, p.quiet_ride, p.emergency_contact_name, p.emergency_contact_phone, p.rating_avg, p.rating_count
         FROM users u LEFT JOIN passenger_profiles p ON p.user_id = u.id
        WHERE u.id = ?`,
    )
    .get(userId) as GroupRow | undefined;
}

// ── Driver ──────────────────────────────────────────────────────────────────
export function getDriverProfile(userId: string) {
  return db()
    .prepare(
      `SELECT dp.*, u.name, u.email, u.phone,
              v.id AS vehicle_id, v.category, v.make_model, v.registration_number, v.seats, v.luggage_units, v.verification_status AS vehicle_status
         FROM driver_profiles dp
         JOIN users u ON u.id = dp.user_id
         LEFT JOIN vehicles v ON v.driver_id = dp.id AND v.is_active = 1
        WHERE dp.user_id = ?`,
    )
    .get(userId) as GroupRow | undefined;
}

export function listDriverRideRequests(driverId: string) {
  const rows = db()
    .prepare(
      `${GROUP_SELECT}
        WHERE rg.status IN ('open','full','confirmed','in_progress')
          AND (rg.driver_id = ? OR rg.driver_id IS NULL)
          AND f.estimated_arrival >= datetime('now','-6 hours')
        ORDER BY (rg.driver_id = ?) DESC, f.estimated_arrival LIMIT 20`,
    )
    .all(driverId, driverId) as GroupRow[];
  return rows.map((r) => buildSummary(r));
}

export function listDriverTrips(driverId: string) {
  const rows = db()
    .prepare(`${GROUP_SELECT} WHERE rg.driver_id = ? ORDER BY f.estimated_arrival DESC LIMIT 50`)
    .all(driverId) as GroupRow[];
  return rows.map((r) => buildSummary(r));
}

export function getDriverEarnings(driverId: string) {
  const rows = db()
    .prepare("SELECT * FROM driver_earnings WHERE driver_id = ? ORDER BY created_at DESC")
    .all(driverId) as GroupRow[];
  const totals = rows.reduce(
    (acc, r) => ({
      gross: acc.gross + r.gross_paise,
      commission: acc.commission + r.commission_paise,
      net: acc.net + r.net_paise,
      paid: acc.paid + (r.status === "paid" ? r.net_paise : 0),
      pending: acc.pending + (r.status === "pending" ? r.net_paise : 0),
    }),
    { gross: 0, commission: 0, net: 0, paid: 0, pending: 0 },
  );
  return { rows, totals };
}

// ── Admin ───────────────────────────────────────────────────────────────────
export function getAdminMetrics() {
  const one = <T,>(sql: string, ...params: unknown[]) => db().prepare(sql).get(...params) as T;
  const totalUsers = one<{ n: number }>("SELECT COUNT(*) AS n FROM users WHERE status='active'").n;
  const activeGroups = one<{ n: number }>("SELECT COUNT(*) AS n FROM ride_groups WHERE status IN ('open','full','confirmed','in_progress')").n;
  const completed = one<{ n: number }>("SELECT COUNT(*) AS n FROM ride_groups WHERE status='completed'").n;
  const cancelled = one<{ n: number }>("SELECT COUNT(*) AS n FROM ride_groups WHERE status='cancelled'").n;
  const bookings = one<{ n: number }>("SELECT COUNT(*) AS n FROM bookings").n;
  const avgPax = one<{ v: number | null }>("SELECT AVG(seats_taken) AS v FROM ride_groups WHERE status='completed'").v ?? 0;
  const savings = one<{ v: number | null }>("SELECT SUM(savings_paise) AS v FROM fare_estimates").v ?? 0;
  const revenue = one<{ v: number | null }>("SELECT SUM(fee_paise + tax_paise) AS v FROM fare_estimates").v ?? 0;
  const driverPay = one<{ v: number | null }>("SELECT SUM(net_paise) AS v FROM driver_earnings").v ?? 0;
  const verifications = one<{ n: number }>("SELECT COUNT(*) AS n FROM flight_verifications WHERE status='pending'").n;
  const driverPending = one<{ n: number }>("SELECT COUNT(*) AS n FROM driver_profiles WHERE verification_status IN ('pending','in_review')").n;
  const reports = one<{ n: number }>("SELECT COUNT(*) AS n FROM reports WHERE status IN ('open','reviewing')").n;
  const refunds = one<{ n: number }>("SELECT COUNT(*) AS n FROM refunds WHERE status='pending'").n;

  const byDay = db()
    .prepare(
      `SELECT f.flight_date AS date, COUNT(rg.id) AS rides, SUM(rg.seats_taken) AS seats
         FROM ride_groups rg JOIN flights f ON f.id = rg.flight_id
        WHERE f.flight_date >= date('now','-6 days') AND f.flight_date <= date('now','+1 day')
        GROUP BY f.flight_date ORDER BY f.flight_date`,
    )
    .all() as { date: string; rides: number; seats: number | null }[];

  return {
    totalUsers, activeGroups, completed, cancelled,
    cancellationRate: bookings ? Math.round((cancelled / Math.max(1, bookings)) * 1000) / 10 : 0,
    avgPassengersPerRide: Math.round(avgPax * 10) / 10,
    estimatedPassengerSavings: savings,
    platformRevenue: revenue,
    driverEarnings: driverPay,
    pendingVerifications: verifications,
    pendingDriverReviews: driverPending,
    openReports: reports,
    pendingRefunds: refunds,
    byDay,
    bookings,
  };
}

export function listAllUsers(limit = 100) {
  return db()
    .prepare(
      `SELECT u.id, u.name, u.email, u.role, u.status, u.created_at, u.last_login_at,
              u.email_verified_at, p.identity_status, dp.verification_status AS driver_status
         FROM users u
         LEFT JOIN passenger_profiles p ON p.user_id = u.id
         LEFT JOIN driver_profiles dp ON dp.user_id = u.id
        ORDER BY u.created_at DESC LIMIT ?`,
    )
    .all(limit) as GroupRow[];
}

export function listFlightVerificationQueue() {
  return db()
    .prepare(
      `SELECT fv.*, u.name, u.email, f.flight_number, f.flight_date, f.estimated_arrival
         FROM flight_verifications fv
         JOIN users u ON u.id = fv.user_id
         JOIN flights f ON f.id = fv.flight_id
        WHERE fv.status IN ('pending','verified')
        ORDER BY CASE fv.status WHEN 'pending' THEN 0 ELSE 1 END, fv.created_at DESC LIMIT 50`,
    )
    .all() as GroupRow[];
}

export function listDriverVerificationQueue() {
  return db()
    .prepare(
      `SELECT dp.*, u.name, u.email, u.phone, v.make_model, v.registration_number, v.category, v.verification_status AS vehicle_status
         FROM driver_profiles dp JOIN users u ON u.id = dp.user_id
         LEFT JOIN vehicles v ON v.driver_id = dp.id
        ORDER BY CASE dp.verification_status WHEN 'in_review' THEN 0 WHEN 'pending' THEN 1 ELSE 2 END, dp.created_at DESC`,
    )
    .all() as GroupRow[];
}

export function listAdminRides(limit = 60) {
  const rows = db()
    .prepare(`${GROUP_SELECT} ORDER BY rg.updated_at DESC LIMIT ?`)
    .all(limit) as GroupRow[];
  return rows.map((r) => buildSummary(r));
}

export function listReports() {
  return db()
    .prepare(
      `SELECT r.*, ru.name AS reporter_name, su.name AS subject_name
         FROM reports r
         JOIN users ru ON ru.id = r.reporter_user_id
         LEFT JOIN users su ON su.id = r.subject_user_id
        ORDER BY CASE r.status WHEN 'open' THEN 0 WHEN 'reviewing' THEN 1 ELSE 2 END, r.created_at DESC`,
    )
    .all() as GroupRow[];
}

export function listRefunds() {
  return db()
    .prepare(
      `SELECT rf.*, p.provider, p.amount_paise AS payment_amount, b.code AS booking_code, u.name AS requester_name
         FROM refunds rf
         JOIN payment_records p ON p.id = rf.payment_id
         JOIN bookings b ON b.id = p.booking_id
         LEFT JOIN users u ON u.id = rf.requested_by
        ORDER BY rf.created_at DESC`,
    )
    .all() as GroupRow[];
}

export function listSupportTickets() {
  return db()
    .prepare(
      `SELECT t.*, u.name AS user_name, u.email AS user_email FROM support_tickets t
         JOIN users u ON u.id = t.user_id
        ORDER BY CASE t.status WHEN 'open' THEN 0 WHEN 'in_progress' THEN 1 ELSE 2 END, t.created_at DESC`,
    )
    .all() as GroupRow[];
}

export function listAuditLogs(limit = 60) {
  return db()
    .prepare(
      `SELECT a.*, u.name AS actor_name FROM audit_logs a LEFT JOIN users u ON u.id = a.actor_user_id
        ORDER BY a.created_at DESC LIMIT ?`,
    )
    .all(limit) as GroupRow[];
}

export function listPricingRuleRows() {
  return db().prepare("SELECT * FROM pricing_rules ORDER BY key").all() as {
    key: string;
    value_json: string;
    description: string;
    updated_at: string;
  }[];
}

export function getSessionAuditForUser(userId: string) {
  return db()
    .prepare("SELECT id, created_at, last_seen_at, user_agent, expires_at FROM sessions WHERE user_id = ? AND revoked_at IS NULL ORDER BY last_seen_at DESC")
    .all(userId) as GroupRow[];
}

export function countAll(dbOverride: DB) {
  return (dbOverride.prepare("SELECT COUNT(*) AS n FROM users").get() as { n: number }).n;
}
