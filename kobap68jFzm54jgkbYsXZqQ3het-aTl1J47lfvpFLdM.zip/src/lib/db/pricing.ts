import type { DB } from "@/lib/db";
import { DEFAULT_PRICING_RULES, withOverrides, type PricingRules } from "@/lib/config/pricing";

export const PRICING_KEYS = {
  base_fare_paise: "Base fare (paise)",
  per_km_paise: "Per-km rate (paise)",
  extra_stop_paise: "Extra drop-off (paise)",
  detour_km_per_stop: "Detour per stop (km)",
  platform_fee_bps: "Platform fee (basis points)",
  platform_fee_min_paise: "Minimum platform fee (paise)",
  tax_bps: "Tax on platform fee (basis points)",
  max_wait_minutes: "Maximum kerb wait (minutes)",
  destination_threshold: "Destination match threshold (0–1)",
  fare_strategy: "Default fare strategy",
  estimate_ttl_minutes: "Fare estimate validity (minutes)",
} as const;

export type PricingKey = keyof typeof PRICING_KEYS;

export function loadPricingRules(db: DB): PricingRules {
  const rows = db.prepare("SELECT key, value_json FROM pricing_rules").all() as {
    key: string;
    value_json: string;
  }[];
  if (!rows.length) return DEFAULT_PRICING_RULES;
  const map = new Map(rows.map((r) => [r.key, JSON.parse(r.value_json)]));

  return withOverrides({
    baseFarePaise: map.get("base_fare_paise"),
    perKmPaise: map.get("per_km_paise"),
    extraStopPaise: map.get("extra_stop_paise"),
    detourKmPerStop: map.get("detour_km_per_stop"),
    platformFeeBps: map.get("platform_fee_bps"),
    platformFeeMinPaise: map.get("platform_fee_min_paise"),
    platformFeeTaxBps: map.get("tax_bps"),
    maxWaitMinutes: map.get("max_wait_minutes"),
    destinationThreshold: map.get("destination_threshold"),
    defaultStrategy: map.get("fare_strategy"),
    estimateTtlMinutes: map.get("estimate_ttl_minutes"),
  });
}

export function savePricingRules(db: DB, patch: Record<string, unknown>, actorUserId: string | null) {
  const stmt = db.prepare(
    `INSERT INTO pricing_rules (key, value_json, description, updated_by, updated_at)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json,
       updated_by = excluded.updated_by, updated_at = excluded.updated_at`,
  );
  const now = new Date().toISOString();
  const tx = db.transaction(() => {
    for (const [key, value] of Object.entries(patch)) {
      if (!(key in PRICING_KEYS)) continue;
      stmt.run(key, JSON.stringify(value), PRICING_KEYS[key as PricingKey], actorUserId, now);
    }
  });
  tx();
}
