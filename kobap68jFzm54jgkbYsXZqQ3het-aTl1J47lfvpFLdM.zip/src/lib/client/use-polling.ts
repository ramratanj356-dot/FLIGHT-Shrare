"use client";
import { useEffect, useRef, useState, useCallback } from "react";

/**
 * Lightweight realtime transport.
 *
 * Polls a JSON endpoint with backoff, pauses when the tab is hidden, and keeps
 * the last good payload so the UI never flashes empty on a transient failure.
 * Replace the `fetcher` with a Supabase Realtime subscription (or WebSocket)
 * without touching the consuming components.
 */
export function usePolling<T>(
  fetcher: () => Promise<T>,
  { intervalMs = 5000, enabled = true }: { intervalMs?: number; enabled?: boolean } = {},
) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isStale, setIsStale] = useState(false);
  const failures = useRef(0);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const mounted = useRef(true);
  const fetcherRef = useRef(fetcher);
  fetcherRef.current = fetcher;

  const tick = useCallback(async () => {
    if (document.hidden) return schedule();
    try {
      const result = await fetcherRef.current();
      if (!mounted.current) return;
      setData(result);
      setError(null);
      setIsStale(false);
      failures.current = 0;
    } catch (err) {
      if (!mounted.current) return;
      failures.current += 1;
      setError(err instanceof Error ? err.message : "Connection lost");
      setIsStale(true);
    }
    schedule();
  }, []);

  const schedule = useCallback(() => {
    if (timer.current) clearTimeout(timer.current);
    const backoff = Math.min(30_000, intervalMs * Math.pow(1.6, Math.min(failures.current, 4)));
    timer.current = setTimeout(tick, backoff);
  }, [intervalMs, tick]);

  useEffect(() => {
    mounted.current = true;
    if (enabled) tick();
    const onVisible = () => { if (!document.hidden) tick(); };
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      mounted.current = false;
      if (timer.current) clearTimeout(timer.current);
      document.removeEventListener("visibilitychange", onVisible);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled]);

  return { data, error, isStale, refresh: tick };
}
