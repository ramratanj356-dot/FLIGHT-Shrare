"use client";

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public code?: string,
    public fieldErrors?: Record<string, string>,
  ) {
    super(message);
  }
}

interface ApiResponse<T> {
  ok: boolean;
  data?: T;
  error?: string;
  fieldErrors?: Record<string, string>;
  code?: string;
}

export async function api<T = unknown>(path: string, init: RequestInit = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, {
      ...init,
      headers: { "content-type": "application/json", ...(init.headers ?? {}) },
      credentials: "same-origin",
    });
  } catch {
    throw new ApiError("Network unreachable. Check your connection and try again.", 0, "network");
  }

  let body: ApiResponse<T> | null = null;
  try {
    body = (await res.json()) as ApiResponse<T>;
  } catch {
    /* status-based error below */
  }

  if (!res.ok || !body?.ok) {
    throw new ApiError(body?.error ?? `Request failed (${res.status})`, res.status, body?.code, body?.fieldErrors);
  }
  return body.data as T;
}

export const post = <T = unknown>(path: string, data?: unknown) =>
  api<T>(path, { method: "POST", body: data === undefined ? undefined : JSON.stringify(data) });

export const patch = <T = unknown>(path: string, data?: unknown) =>
  api<T>(path, { method: "PATCH", body: data === undefined ? undefined : JSON.stringify(data) });

export const get = <T = unknown>(path: string) => api<T>(path, { method: "GET" });
