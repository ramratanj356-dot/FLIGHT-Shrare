import { randomBytes, scrypt as scryptCb, scryptSync, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";

const scrypt = promisify(scryptCb) as (
  password: string | Buffer,
  salt: string | Buffer,
  keylen: number,
) => Promise<Buffer>;

// OWASP-recommended scrypt parameters (N=2^14, r=8, p=1).
const N = 16_384;
const r = 8;
const p = 1;
const KEYLEN = 64;

/**
 * Format: scrypt$N$r$p$<salt-b64>$<hash-b64>
 * Parameters travel with the hash so they can be raised later without
 * invalidating existing credentials.
 */
export async function hashPassword(password: string) {
  const salt = randomBytes(16);
  const hash = await scrypt(password, salt, KEYLEN);
  return `scrypt$${N}$${r}$${p}$${salt.toString("base64")}$${hash.toString("base64")}`;
}

export async function verifyPassword(password: string, stored: string | null) {
  if (!stored) return false;
  const parts = stored.split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  const [, , , , saltB64, hashB64] = parts;
  const salt = Buffer.from(saltB64, "base64");
  const expected = Buffer.from(hashB64, "base64");
  const actual = await scrypt(password, salt, expected.length);
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

/** Human-friendly one-time token (URL safe). Only its hash is stored. */
export function createOpaqueToken() {
  return randomBytes(32).toString("base64url");
}

/** Synchronous variant used only by the seeding script (startup path). */
export function hashPasswordSync(password: string) {
  const salt = randomBytes(16);
  const hash = scryptSync(password, salt, KEYLEN);
  return `scrypt$${N}$${r}$${p}$${salt.toString("base64")}$${hash.toString("base64")}`;
}
