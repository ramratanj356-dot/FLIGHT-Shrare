import "server-only";
import { redirect } from "next/navigation";
import { getSessionUser, type SessionUser } from "./session";

export class AuthError extends Error {
  constructor(
    public status: 401 | 403,
    message: string,
  ) {
    super(message);
  }
}

/** Server-component guard: redirects to /login, preserving the return path. */
export async function requireUser(returnTo = "/app"): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(returnTo)}`);
  return user;
}

export async function requireRole(role: SessionUser["role"] | SessionUser["role"][], returnTo = "/app") {
  const allowed = Array.isArray(role) ? role : [role];
  const user = await requireUser(returnTo);
  if (!allowed.includes(user.role)) redirect(`/app?denied=${encodeURIComponent(allowed[0])}`);
  return user;
}

/** API-route guard: throws instead of redirecting. */
export async function requireApiUser(): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user) throw new AuthError(401, "Sign in to continue");
  return user;
}

export async function requireApiRole(roles: SessionUser["role"][]) {
  const user = await requireApiUser();
  if (!roles.includes(user.role)) throw new AuthError(403, "You do not have access to this resource");
  return user;
}

export function isStaff(role: SessionUser["role"]) {
  return role === "admin" || role === "support" || role === "coordinator";
}
