import "server-only";
import { createHash, randomBytes } from "node:crypto";
import { cookies } from "next/headers";
import { getDb, id } from "@/lib/db";

export const SESSION_COOKIE = "fs_session";
const SESSION_TTL_DAYS = 7;
const SESSION_TTL_MS = SESSION_TTL_DAYS * 86_400_000;

export function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export function hashIp(ip: string | null) {
  if (!ip) return null;
  return createHash("sha256").update(ip + (process.env.AUTH_SECRET ?? "flightshare")).digest("hex").slice(0, 32);
}

export interface SessionUser {
  id: string;
  email: string;
  name: string;
  role: "passenger" | "driver" | "coordinator" | "admin" | "support";
  phone: string | null;
  emailVerified: boolean;
  phoneVerified: boolean;
  avatarUrl: string | null;
  demoAccount: boolean;
}

export async function createSession(userId: string, meta: { ip?: string | null; userAgent?: string | null } = {}) {
  const db = getDb();
  const token = randomBytes(32).toString("base64url");
  const now = new Date();
  const expires = new Date(now.getTime() + SESSION_TTL_MS);
  db.prepare(
    `INSERT INTO sessions (id, user_id, token_hash, user_agent, ip_hash, created_at, last_seen_at, expires_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    id("ses"),
    userId,
    hashToken(token),
    meta.userAgent?.slice(0, 200) ?? null,
    hashIp(meta.ip ?? null),
    now.toISOString(),
    now.toISOString(),
    expires.toISOString(),
  );

  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    expires,
  });
  return { token, expires };
}

/** Reads + validates the session cookie. Also rotates last_seen_at. */
export async function getSessionUser(): Promise<SessionUser | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;

  const db = getDb();
  const row = db
    .prepare(
      `SELECT s.id AS session_id, s.expires_at, u.id, u.email, u.name, u.role, u.phone,
              u.email_verified_at, u.phone_verified_at, u.avatar_url, u.status
         FROM sessions s
         JOIN users u ON u.id = s.user_id
        WHERE s.token_hash = ? AND s.revoked_at IS NULL`,
    )
    .get(hashToken(token)) as
    | {
        session_id: string;
        expires_at: string;
        id: string;
        email: string;
        name: string;
        role: SessionUser["role"];
        phone: string | null;
        email_verified_at: string | null;
        phone_verified_at: string | null;
        avatar_url: string | null;
        status: string;
      }
    | undefined;

  if (!row) return null;
  if (new Date(row.expires_at).getTime() < Date.now()) {
    db.prepare("UPDATE sessions SET revoked_at = ? WHERE id = ?").run(new Date().toISOString(), row.session_id);
    return null;
  }
  if (row.status !== "active") return null;

  db.prepare("UPDATE sessions SET last_seen_at = ? WHERE id = ?").run(new Date().toISOString(), row.session_id);

  return {
    id: row.id,
    email: row.email,
    name: row.name,
    role: row.role,
    phone: row.phone,
    emailVerified: Boolean(row.email_verified_at),
    phoneVerified: Boolean(row.phone_verified_at),
    avatarUrl: row.avatar_url,
    demoAccount: row.email.endsWith("@demo.flightshare.app"),
  };
}

export async function destroySession() {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    const db = getDb();
    db.prepare("UPDATE sessions SET revoked_at = ? WHERE token_hash = ?").run(new Date().toISOString(), hashToken(token));
  }
  store.set(SESSION_COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
}

export async function revokeAllSessions(userId: string) {
  getDb().prepare("UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL").run(new Date().toISOString(), userId);
}
