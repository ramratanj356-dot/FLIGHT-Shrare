/**
 * Demo fixtures. Every record created from these is tagged `demo` and
 * surfaced in the UI with a SAMPLE DATA badge.
 */
export interface DemoUser {
  id: string;
  name: string;
  email: string;
  password: string;
  role: "passenger" | "driver" | "admin";
  phone: string;
  identity: "verified" | "pending" | "unverified";
  home?: string;
  luggage: "cabin" | "one_checkin" | "two_checkin" | "heavy";
  accessibility?: string;
  quiet?: boolean;
  rating?: [number, number];
  language?: "en" | "hi" | "mr";
}

export const DEMO_PASSWORD = "Demo@1234";
export const DEMO_DRIVER_PASSWORD = "Driver@1234";
export const DEMO_ADMIN_PASSWORD = "Admin@1234";

export const DEMO_USERS: DemoUser[] = [
  {
    id: "usr_aarav", name: "Aarav Mehta", email: "aarav@demo.flightshare.app", password: DEMO_PASSWORD,
    role: "passenger", phone: "+919820011001", identity: "verified", home: "thane-w",
    luggage: "one_checkin", quiet: true, rating: [4.9, 38], language: "en",
  },
  {
    id: "usr_priya", name: "Priya Nair", email: "priya@demo.flightshare.app", password: DEMO_PASSWORD,
    role: "passenger", phone: "+919820011002", identity: "verified", home: "mulund",
    luggage: "two_checkin", rating: [4.8, 24], language: "en",
  },
  {
    id: "usr_rohan", name: "Rohan Deshpande", email: "rohan@demo.flightshare.app", password: DEMO_PASSWORD,
    role: "passenger", phone: "+919820011003", identity: "verified", home: "thane-w",
    luggage: "cabin", rating: [4.7, 12], language: "mr",
  },
  {
    id: "usr_neha", name: "Neha Kulkarni", email: "neha@demo.flightshare.app", password: DEMO_PASSWORD,
    role: "passenger", phone: "+919820011004", identity: "pending", home: "ghatkopar",
    luggage: "one_checkin", rating: [4.6, 9], language: "mr",
  },
  {
    id: "usr_farhan", name: "Farhan Sheikh", email: "farhan@demo.flightshare.app", password: DEMO_PASSWORD,
    role: "passenger", phone: "+919820011005", identity: "verified", home: "bandra-w",
    luggage: "heavy", quiet: true, rating: [4.9, 51], language: "en",
  },
  {
    id: "usr_kavya", name: "Kavya Iyer", email: "kavya@demo.flightshare.app", password: DEMO_PASSWORD,
    role: "passenger", phone: "+919820011006", identity: "unverified", home: "powai",
    luggage: "cabin", accessibility: "Collapsible wheelchair folds into the boot", rating: [4.8, 17], language: "en",
  },
  {
    id: "usr_imran", name: "Imran Qureshi", email: "imran@demo.flightshare.app", password: DEMO_PASSWORD,
    role: "passenger", phone: "+919820011007", identity: "verified", home: "vashi",
    luggage: "one_checkin", rating: [4.5, 6], language: "en",
  },
  {
    id: "usr_ananya", name: "Ananya Rao", email: "ananya@demo.flightshare.app", password: DEMO_PASSWORD,
    role: "passenger", phone: "+919820011008", identity: "verified", home: "andheri-e",
    luggage: "cabin", rating: [5.0, 3], language: "en",
  },
  {
    id: "usr_driver_ramesh", name: "Ramesh Yadav", email: "driver@demo.flightshare.app", password: DEMO_DRIVER_PASSWORD,
    role: "driver", phone: "+919820011010", identity: "verified", luggage: "one_checkin", rating: [4.9, 212],
  },
  {
    id: "usr_driver_suresh", name: "Suresh Patil", email: "suresh.driver@demo.flightshare.app", password: DEMO_DRIVER_PASSWORD,
    role: "driver", phone: "+919820011011", identity: "pending", luggage: "one_checkin", rating: [0, 0],
  },
  {
    id: "usr_admin", name: "Meera Joshi", email: "admin@demo.flightshare.app", password: DEMO_ADMIN_PASSWORD,
    role: "admin", phone: "+919820011012", identity: "verified", luggage: "cabin", rating: [0, 0],
  },
  // Additional demo passengers so future-dated groups feel populated rather
  // than reusing the three featured personas. All are clearly demo accounts.
  { id: "usr_kabir", name: "Kabir Shah", email: "kabir@demo.flightshare.app", password: DEMO_PASSWORD, role: "passenger", phone: "+919820011011", identity: "verified", home: "andheri-e", luggage: "cabin", rating: [4.8, 21], language: "en" },
  { id: "usr_meera", name: "Meera Rao", email: "meera@demo.flightshare.app", password: DEMO_PASSWORD, role: "passenger", phone: "+919820011012", identity: "verified", home: "powai", luggage: "one_checkin", rating: [4.9, 33], language: "en" },
  { id: "usr_rahul", name: "Rahul Verma", email: "rahul@demo.flightshare.app", password: DEMO_PASSWORD, role: "passenger", phone: "+919820011013", identity: "pending", home: "mulund", luggage: "two_checkin", rating: [4.6, 14], language: "hi" },
  { id: "usr_sana", name: "Sana Qureshi", email: "sana@demo.flightshare.app", password: DEMO_PASSWORD, role: "passenger", phone: "+919820011014", identity: "verified", home: "bandra-w", luggage: "cabin", quiet: true, rating: [4.7, 18], language: "en" },
  { id: "usr_aditya", name: "Aditya Kulkarni", email: "aditya@demo.flightshare.app", password: DEMO_PASSWORD, role: "passenger", phone: "+919820011015", identity: "verified", home: "vashi", luggage: "one_checkin", rating: [4.5, 9], language: "mr" },
  { id: "usr_nikita", name: "Nikita Bose", email: "nikita@demo.flightshare.app", password: DEMO_PASSWORD, role: "passenger", phone: "+919820011016", identity: "unverified", home: "ghatkopar", luggage: "cabin", rating: [4.8, 11], language: "en" },
];

export interface FlightTemplate {
  flightNumber: string;
  airlineCode: string;
  airlineName: string;
  originCity: string;
  terminal: string;
  /** Minutes from "now" on day 0 — keeps the featured demo believable at any hour. */
  todayOffsetMinutes: number;
  /** HH:mm IST for future days. */
  timeOfDay: string;
  routes: { destinationId: string; extraStopIds: string[]; members: string[]; vehicle: "sedan" | "suv" | "mpv"; maxWait: number }[];
}

export const FLIGHT_TEMPLATES: FlightTemplate[] = [
  {
    flightNumber: "AI864", airlineCode: "AI", airlineName: "Air India", originCity: "Delhi (DEL)",
    terminal: "T2", todayOffsetMinutes: -22, timeOfDay: "08:45",
    routes: [
      { destinationId: "thane-w", extraStopIds: ["mulund"], members: ["usr_aarav", "usr_priya", "usr_rohan"], vehicle: "suv", maxWait: 45 },
      { destinationId: "powai", extraStopIds: ["ghatkopar"], members: ["usr_kavya", "usr_neha"], vehicle: "sedan", maxWait: 40 },
      { destinationId: "bandra-w", extraStopIds: [], members: ["usr_farhan"], vehicle: "suv", maxWait: 35 },
    ],
  },
  {
    flightNumber: "6E5123", airlineCode: "6E", airlineName: "IndiGo", originCity: "Bengaluru (BLR)",
    terminal: "T2", todayOffsetMinutes: 58, timeOfDay: "11:20",
    routes: [
      { destinationId: "vashi", extraStopIds: ["chembur"], members: ["usr_imran", "usr_ananya"], vehicle: "suv", maxWait: 50 },
      { destinationId: "andheri-e", extraStopIds: ["vile-parle"], members: ["usr_ananya", "usr_farhan"], vehicle: "sedan", maxWait: 30 },
    ],
  },
  {
    flightNumber: "UK927", airlineCode: "UK", airlineName: "Air India Express Connect", originCity: "Kolkata (CCU)",
    terminal: "T1", todayOffsetMinutes: 128, timeOfDay: "14:05",
    routes: [
      { destinationId: "ghatkopar", extraStopIds: ["powai"], members: ["usr_neha", "usr_kavya"], vehicle: "sedan", maxWait: 40 },
      { destinationId: "thane-w", extraStopIds: ["mulund"], members: ["usr_rohan"], vehicle: "sedan", maxWait: 45 },
    ],
  },
  {
    flightNumber: "SG8192", airlineCode: "SG", airlineName: "SpiceJet", originCity: "Goa (GOI)",
    terminal: "T1", todayOffsetMinutes: 196, timeOfDay: "17:30",
    routes: [
      { destinationId: "borivali", extraStopIds: ["andheri-e"], members: ["usr_priya", "usr_aarav"], vehicle: "sedan", maxWait: 40 },
      { destinationId: "dadar", extraStopIds: ["bandra-w"], members: ["usr_farhan"], vehicle: "sedan", maxWait: 35 },
    ],
  },
  {
    flightNumber: "QP1102", airlineCode: "QP", airlineName: "Akasa Air", originCity: "Ahmedabad (AMD)",
    terminal: "T1", todayOffsetMinutes: 292, timeOfDay: "19:15",
    routes: [
      { destinationId: "chembur", extraStopIds: ["vashi"], members: ["usr_imran", "usr_rohan"], vehicle: "suv", maxWait: 50 },
    ],
  },
  {
    flightNumber: "AI640", airlineCode: "AI", airlineName: "Air India", originCity: "Chennai (MAA)",
    terminal: "T2", todayOffsetMinutes: 404, timeOfDay: "21:40",
    routes: [
      { destinationId: "mulund", extraStopIds: ["thane-w"], members: ["usr_priya", "usr_neha"], vehicle: "sedan", maxWait: 45 },
      { destinationId: "colaba", extraStopIds: ["dadar"], members: ["usr_farhan"], vehicle: "sedan", maxWait: 35 },
    ],
  },
  {
    flightNumber: "6E2211", airlineCode: "6E", airlineName: "IndiGo", originCity: "Hyderabad (HYD)",
    terminal: "T1", todayOffsetMinutes: 512, timeOfDay: "23:10",
    routes: [
      { destinationId: "bandra-w", extraStopIds: ["juhu"], members: ["usr_ananya", "usr_kavya"], vehicle: "sedan", maxWait: 40 },
    ],
  },
];

export const MEET_POINTS: Record<string, string> = {
  T2: "T2 Arrivals, Gate 3 — outside the espresso bar, next to Pillar 14",
  T1: "T1 Arrivals, Gate 2 — under the 'Prepaid Taxi' canopy",
};

export const SAMPLE_MESSAGES = [
  { kind: "system" as const, body: "Ride group created. Fare is an estimate until a driver accepts the trip." },
  { kind: "meeting_point" as const, body: "Meeting point confirmed: T2 Arrivals, Gate 3 — outside the espresso bar, next to Pillar 14." },
  { kind: "text" as const, body: "Just landed, waiting for my bag on belt 7. Should be out in 15–20 minutes." },
  { kind: "readiness" as const, body: "I'm at the meeting point, blue cabin trolley by the pillar." },
  { kind: "text" as const, body: "Perfect, I'm 5 minutes away. Shall we ask the driver to pull in?" },
];
