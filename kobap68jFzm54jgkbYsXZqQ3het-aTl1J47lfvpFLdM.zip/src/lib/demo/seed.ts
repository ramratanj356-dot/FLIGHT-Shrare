import type { DB } from "@/lib/db";
import { BOM_DESTINATIONS, BOM_TERMINALS } from "@/lib/data/destinations";
import { DEFAULT_PRICING_RULES } from "@/lib/config/pricing";
import { hashPasswordSync } from "@/lib/auth/password";
import { computeGroupFare } from "@/lib/fares/group";
import { loadPricingRules, PRICING_KEYS } from "@/lib/db/pricing";
import { DEMO_USERS, FLIGHT_TEMPLATES, MEET_POINTS, SAMPLE_MESSAGES } from "./fixtures";

const HORIZON_DAYS = 14;
const PAST_DAYS = 5;

const iso = (d: Date) => d.toISOString();
const dateKey = (d: Date) =>
  new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
const keyNoDash = (s: string) => s.replace(/-/g, "");
const addMin = (d: Date, m: number) => new Date(d.getTime() + m * 60_000);
const addDays = (d: Date, n: number) => new Date(d.getTime() + n * 86_400_000);
const pad = (n: number) => String(n).padStart(2, "0");

function istDateAt(dayKey: string, hhmm: string) {
  return new Date(`${dayKey}T${hhmm}:00+05:30`);
}

const LUGGAGE_UNITS: Record<string, number> = { cabin: 1, one_checkin: 1, two_checkin: 2, heavy: 3 };

/** Stable, collision-resistant reference codes for demo records. */
function refCode(prefix: string, seed: string) {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return `${prefix}${(h >>> 0).toString(36).toUpperCase().padStart(7, "0").slice(0, 7)}`;
}

export function ensureDemoData(db: DB) {
  normalizeFullGroups(db);
  const userCount = (db.prepare("SELECT COUNT(*) AS n FROM users").get() as { n: number }).n;
  if (userCount > 0) {
    const horizon = db.prepare("SELECT MAX(flight_date) AS d FROM flights WHERE source = 'demo'").get() as {
      d: string | null;
    };
    const target = dateKey(addDays(new Date(), HORIZON_DAYS - 2));
    if (horizon.d && horizon.d < target) seedFlights(db, { refresh: true });
    // These are idempotent (INSERT OR IGNORE) so they can top up an existing DB.
    seedHistory(db);
    seedAdminQueues(db);
    seedNotifications(db);
    return;
  }
  seedReference(db);
  seedUsers(db);
  seedFlights(db, { refresh: false });
  seedHistory(db);
  seedAdminQueues(db);
  seedNotifications(db);
}

// ── Reference data ──────────────────────────────────────────────────────────
function seedReference(db: DB) {
  db.prepare(
    `INSERT INTO airports (id, code, name, city, country, timezone, lat, lng, is_active)
     VALUES (?, ?, ?, ?, 'IN', 'Asia/Kolkata', ?, ?, 1)`,
  ).run(
    "apt_bom",
    "BOM",
    "Chhatrapati Shivaji Maharaj International Airport",
    "Mumbai",
    19.0896,
    72.8656,
  );

  const insertDest = db.prepare(
    `INSERT INTO destinations (id, airport_id, name, area, corridor, lat, lng, distance_km, drive_minutes, solo_fare_paise, tolls_paise, blurb, is_active, sort_order)
     VALUES (?, 'apt_bom', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`,
  );
  BOM_DESTINATIONS.forEach((d, i) =>
    insertDest.run(d.id, d.name, d.area, d.corridor, d.lat, d.lng, d.distanceKm, d.driveMinutes, d.soloFarePaise, d.tollsPaise, d.blurb, i),
  );

  const insertRule = db.prepare(
    `INSERT INTO pricing_rules (key, value_json, description, updated_at) VALUES (?, ?, ?, ?)`,
  );
  const r = DEFAULT_PRICING_RULES;
  const values: [string, unknown][] = [
    ["base_fare_paise", r.baseFarePaise],
    ["per_km_paise", r.perKmPaise],
    ["extra_stop_paise", r.extraStopPaise],
    ["detour_km_per_stop", r.detourKmPerStop],
    ["platform_fee_bps", r.platformFeeBps],
    ["platform_fee_min_paise", r.platformFeeMinPaise],
    ["tax_bps", r.platformFeeTaxBps],
    ["max_wait_minutes", r.maxWaitMinutes],
    ["destination_threshold", r.destinationThreshold],
    ["fare_strategy", r.defaultStrategy],
    ["estimate_ttl_minutes", r.estimateTtlMinutes],
  ];
  for (const [key, value] of values) {
    insertRule.run(key, JSON.stringify(value), PRICING_KEYS[key as keyof typeof PRICING_KEYS], iso(new Date()));
  }
}

// ── Users ───────────────────────────────────────────────────────────────────
function seedUsers(db: DB) {
  const insertUser = db.prepare(
    `INSERT INTO users (id, email, password_hash, role, name, phone, email_verified_at, phone_verified_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  const insertPassenger = db.prepare(
    `INSERT INTO passenger_profiles (user_id, identity_status, identity_provider, identity_verified_at, home_destination_id, luggage_preference, accessibility_needs, language, quiet_ride, emergency_contact_name, emergency_contact_phone, rating_avg, rating_count)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  const now = iso(new Date());

  for (const u of DEMO_USERS) {
    const hash = hashPasswordSync(u.password);
    insertUser.run(
      u.id,
      u.email,
      hash,
      u.role,
      u.name,
      u.phone,
      now,
      u.identity === "verified" ? now : null,
      iso(addDays(new Date(), -90)),
      now,
    );
    if (u.role === "passenger") {
      insertPassenger.run(
        u.id,
        u.identity === "verified" ? "verified" : u.identity === "pending" ? "pending" : "unverified",
        "simulated",
        u.identity === "verified" ? now : null,
        u.home ?? null,
        u.luggage,
        u.accessibility ?? null,
        u.language ?? "en",
        u.quiet ? 1 : 0,
        "Emergency contact",
        "+919820011999",
        u.rating?.[0] ?? 0,
        u.rating?.[1] ?? 0,
      );
    }
  }

  // System account that owns contact-form tickets filed by visitors who are
  // not signed in. Its password hash is random, so it cannot be logged into.
  insertUser.run(
    "usr_intake",
    "intake@system.flightshare.app",
    hashPasswordSync(`${Math.random()}-${Date.now()}-system`),
    "passenger",
    "Guest intake",
    null,
    now,
    null,
    iso(addDays(new Date(), -120)),
    now,
  );

  const drivers: { id: string; userId: string; company: string | null; license: string; status: string; verified: boolean }[] = [
    { id: "drv_ramesh", userId: "usr_driver_ramesh", company: "Sahyadri Fleet Partners", license: "MH02 20190012345", status: "verified", verified: true },
    { id: "drv_suresh", userId: "usr_driver_suresh", company: null, license: "MH01 20210067890", status: "in_review", verified: false },
  ];
  const insertDriver = db.prepare(
    `INSERT INTO driver_profiles (id, user_id, company_name, license_number, verification_status, verified_at, rating_avg, rating_count, is_available, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  const insertVehicle = db.prepare(
    `INSERT INTO vehicles (id, driver_id, category, make_model, registration_number, seats, luggage_units, verification_status, is_active)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)`,
  );
  for (const d of drivers) {
    insertDriver.run(
      d.id, d.userId, d.company, d.license, d.status,
      d.verified ? now : null, d.verified ? 4.9 : 0, d.verified ? 212 : 0, d.verified ? 1 : 0,
      iso(addDays(new Date(), -200)), now,
    );
  }
  insertVehicle.run("veh_ramesh", "drv_ramesh", "sedan", "Maruti Suzuki Ciaz", "MH 02 DC 4417", 4, 3, "verified");
  insertVehicle.run("veh_suresh", "drv_suresh", "suv", "Toyota Innova Crysta", "MH 01 BX 9082", 6, 5, "pending");
}

// ── Flights, groups, bookings ───────────────────────────────────────────────
function seedFlights(db: DB, { refresh }: { refresh: boolean }) {
  const rules = loadPricingRules(db);
  const now = new Date();
  const today = dateKey(now);

  if (refresh) {
    // Only remove demo-origin groups in the rolling window, and only if no
    // real (non-demo) account has joined one — user work is never destroyed.
    const protectedGroups = db
      .prepare(
        `SELECT DISTINCT rm.ride_group_id FROM ride_members rm
           JOIN users u ON u.id = rm.user_id
          WHERE u.email NOT LIKE '%@demo.flightshare.app'`,
      )
      .all() as { ride_group_id: string }[];
    const keep = new Set(protectedGroups.map((g) => g.ride_group_id));
    const groups = db.prepare("SELECT id FROM ride_groups WHERE is_demo_origin = 1 AND status = 'open'").all() as {
      id: string;
    }[];
    const del = db.prepare("DELETE FROM ride_groups WHERE id = ?");
    for (const g of groups) if (!keep.has(g.id)) del.run(g.id);
    db.prepare("DELETE FROM flights WHERE source = 'demo' AND flight_date >= ?").run(today);
  }

  const insertFlight = db.prepare(
    `INSERT INTO flights (id, airport_id, airline_code, airline_name, flight_number, origin_city, flight_date, terminal,
       scheduled_arrival, estimated_arrival, status, source, created_at, updated_at)
     VALUES (?, 'apt_bom', ?, ?, ?, ?, ?, ?, ?, ?, ?, 'demo', ?, ?)
     ON CONFLICT(airport_id, flight_number, flight_date) DO UPDATE SET
       estimated_arrival = excluded.estimated_arrival, status = excluded.status, updated_at = excluded.updated_at`,
  );

  for (let dayOffset = 0; dayOffset <= HORIZON_DAYS; dayOffset++) {
    const day = addDays(now, dayOffset);
    const dayKey = dateKey(day);

    for (const t of FLIGHT_TEMPLATES) {
      let scheduled: Date;
      if (dayOffset === 0) {
        const candidate = addMin(now, t.todayOffsetMinutes);
        scheduled = dateKey(candidate) === today ? candidate : istDateAt(dayKey, t.timeOfDay);
      } else {
        scheduled = istDateAt(dayKey, t.timeOfDay);
      }

      const isDelayed = t.flightNumber === "SG8192" && dayOffset === 0;
      const estimated = isDelayed ? addMin(scheduled, 35) : scheduled;
      const status =
        dayOffset === 0
          ? isDelayed
            ? "delayed"
            : estimated.getTime() < now.getTime()
              ? "landed"
              : estimated.getTime() - now.getTime() < 45 * 60_000
                ? "enroute"
                : "scheduled"
          : "scheduled";

      const flightId = `flt_${t.flightNumber}_${keyNoDash(dayKey)}`;
      insertFlight.run(
        flightId, t.airlineCode, t.airlineName, t.flightNumber, t.originCity, dayKey, t.terminal,
        iso(scheduled), iso(estimated), status, iso(now), iso(now),
      );

      const dayGroupCount = dayOffset === 0 ? t.routes.length : Math.min(2, t.routes.length);
      for (let i = 0; i < dayGroupCount; i++) {
        const route = t.routes[i];
        createRideGroup(db, {
          flightId,
          flightNumber: t.flightNumber,
          airlineCode: t.airlineCode,
          dayKey,
          terminal: t.terminal,
          estimatedArrival: estimated,
          route,
          index: i,
          dayOffset,
          rules,
          now,
        });
      }
    }
  }
}

interface CreateArgs {
  flightId: string;
  flightNumber: string;
  airlineCode: string;
  dayKey: string;
  terminal: string;
  estimatedArrival: Date;
  route: { destinationId: string; extraStopIds: string[]; members: string[]; vehicle: "sedan" | "suv" | "mpv"; maxWait: number };
  index: number;
  dayOffset: number;
  rules: ReturnType<typeof loadPricingRules>;
  now: Date;
}

function createRideGroup(db: DB, args: CreateArgs) {
  const { route, rules, now, dayOffset } = args;
  const groupId = `rg_${args.flightNumber}_${keyNoDash(args.dayKey)}_${route.destinationId.replace(/-/g, "")}`;
  const exists = db.prepare("SELECT 1 FROM ride_groups WHERE id = ?").get(groupId);
  if (exists) return;

  const destMap = new Map(BOM_DESTINATIONS.map((d) => [d.id, d]));
  const primary = destMap.get(route.destinationId)!;
  const capacity = rules.vehicleCapacity[route.vehicle];
  // Only today's sample group is fully populated. Future days rotate a single
  // owner so each demo persona shows a realistic handful of trips, not dozens.
  const fillerPassengers = DEMO_USERS.filter((u) => u.role === "passenger").map((u) => u.id);
  const rotated = fillerPassengers[(dayOffset * 3 + args.index) % fillerPassengers.length];
  const memberIds = dayOffset > 0 ? [rotated] : route.members;
  const seatsTotal = Math.min(capacity.seats, Math.max(memberIds.length, 2) + (dayOffset === 0 ? 1 : 0));

  const windowStart = addMin(args.estimatedArrival, rules.baggageClaimMinutes);
  const windowEnd = addMin(windowStart, route.maxWait);

  const status = dayOffset < 0 ? "completed" : "open";

  db.prepare(
    `INSERT INTO ride_groups (id, code, flight_id, created_by_user_id, destination_id, vehicle_category, fare_strategy,
       seats_total, seats_taken, luggage_total, luggage_taken, meet_point, departure_window_start, departure_window_end,
       max_wait_minutes, status, is_demo_origin, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 0, ?, ?, ?, ?, ?, 1, ?, ?)`,
  ).run(
    groupId, refCode("FS", groupId), args.flightId, memberIds[0], route.destinationId,
    route.vehicle, rules.defaultStrategy, seatsTotal, capacity.luggage,
    MEET_POINTS[args.terminal], iso(windowStart), iso(windowEnd), route.maxWait, status,
    iso(addMin(now, -240)), iso(now),
  );

  // Members
  const memberRows: { id: string; userId: string; destinationId: string; seats: number; luggage: number; readiness: string }[] = [];
  memberIds.forEach((userId, idx) => {
    const user = DEMO_USERS.find((u) => u.id === userId)!;
    const destinationId = idx === 0 ? route.destinationId : (route.extraStopIds[idx - 1] ?? route.destinationId);
    const dest = destMap.get(destinationId)!;
    const seats = 1;
    const luggage = LUGGAGE_UNITS[user.luggage] ?? 1;
    const readiness =
      dayOffset === 0
        ? idx === 0
          ? "ready_at_meeting_point"
          : idx === 1
            ? "collecting_baggage"
            : "landed"
        : "not_landed";
    const memberId = `rm_${groupId}_${idx}`;
    db.prepare(
      `INSERT INTO ride_members (id, ride_group_id, user_id, seat_count, luggage_units, destination_id, readiness, expected_ready_at, readiness_updated_at, status, role, joined_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'accepted', ?, ?)`,
    ).run(
      memberId, groupId, userId, seats, luggage, destinationId, readiness,
      iso(addMin(windowStart, idx * 8)), iso(addMin(now, -30)),
      idx === 0 ? "owner" : "member", iso(addMin(now, -300 + idx * 20)),
    );
    memberRows.push({ id: memberId, userId, destinationId, seats, luggage, readiness });
    void dest;
  });

  const seatsTaken = memberRows.reduce((s, m) => s + m.seats, 0);
  const luggageTaken = Math.min(capacity.luggage, memberRows.reduce((s, m) => s + m.luggage, 0));
  db.prepare("UPDATE ride_groups SET seats_taken = ?, luggage_taken = ? WHERE id = ?").run(seatsTaken, luggageTaken, groupId);

  // Fare
  const members = memberRows.map((m) => {
    const dest = destMap.get(m.destinationId)!;
    const profile = DEMO_USERS.find((u) => u.id === m.userId)!;
    return {
      id: m.id, userId: m.userId, destinationId: m.destinationId,
      distanceKm: dest.distanceKm, seatCount: m.seats, soloFarePaise: dest.soloFarePaise,
      luggageUnits: profile.luggage ? LUGGAGE_UNITS[profile.luggage] : 1,
    };
  });

  const groupFare = computeGroupFare({
    members,
    vehicleCategory: route.vehicle,
    strategy: rules.defaultStrategy,
    rules,
    tollsPaise: primary.tollsPaise,
  });

  const estimateId = `fe_${groupId}`;
  const expiresAt = addMin(now, rules.estimateTtlMinutes + 300);
  db.prepare(
    `INSERT INTO fare_estimates (id, ride_group_id, strategy, vehicle_category, breakdown_json, total_paise, vehicle_fare_paise, fee_paise, tax_paise, solo_total_paise, savings_paise, expires_at, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    estimateId, groupId, rules.defaultStrategy, route.vehicle, JSON.stringify(groupFare),
    groupFare.breakdown.totalPaise, groupFare.breakdown.vehicleFarePaise, groupFare.breakdown.platformFeePaise,
    groupFare.breakdown.taxPaise, groupFare.breakdown.soloTotalPaise, groupFare.breakdown.totalSavingsPaise,
    iso(expiresAt), iso(now),
  );
  db.prepare("UPDATE ride_groups SET fare_estimate_id = ? WHERE id = ?").run(estimateId, groupId);

  const insertAlloc = db.prepare(
    `INSERT INTO fare_allocations (id, fare_estimate_id, ride_group_id, user_id, destination_id, distance_km, weight, vehicle_share_paise, fee_paise, tax_paise, contribution_paise, solo_fare_paise, savings_paise, savings_pct)
     VALUES (?, ?, ?, ?, ?, ?, 1, ?, 0, 0, ?, ?, ?, ?)`,
  );
  for (const m of groupFare.members) {
    const dest = destMap.get(m.destinationId)!;
    insertAlloc.run(
      `fa_${groupId}_${m.userId}`, estimateId, groupId, m.userId, m.destinationId, dest.distanceKm,
      m.contributionPaise, m.contributionPaise, m.soloEstimatePaise, m.savingsPaise, m.savingsPct,
    );

    const bookingStatus = dayOffset === 0 ? "confirmed" : "pending";
    db.prepare(
      `INSERT INTO bookings (id, code, ride_group_id, user_id, fare_estimate_id, status, payment_status, amount_paise, confirmed_at, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    ).run(
      `bk_${groupId}_${m.userId}`, refCode("BK", `${groupId}:${m.userId}`),
      groupId, m.userId, estimateId, bookingStatus, dayOffset === 0 ? "authorised" : "unpaid",
      m.contributionPaise, dayOffset === 0 ? iso(addMin(now, -60)) : null, iso(addMin(now, -200)),
    );
  }

  // Conversation + messages
  const conversationId = `cnv_${groupId}`;
  db.prepare("INSERT INTO conversations (id, ride_group_id, created_at) VALUES (?, ?, ?)").run(conversationId, groupId, iso(addMin(now, -200)));
  const msgCount = dayOffset === 0 ? SAMPLE_MESSAGES.length : 3;
  SAMPLE_MESSAGES.slice(0, msgCount).forEach((m, idx) => {
    const sender = memberRows[idx % memberRows.length].userId;
    db.prepare(
      `INSERT INTO messages (id, conversation_id, sender_user_id, body, kind, created_at) VALUES (?, ?, ?, ?, ?, ?)`,
    ).run(`msg_${groupId}_${idx}`, conversationId, sender, m.body, m.kind, iso(addMin(now, -180 + idx * 22)));
  });

  // Simulated flight verification for accepted members (drives the trust score).
  for (const m of memberRows) {
    db.prepare(
      `INSERT OR IGNORE INTO flight_verifications (id, user_id, flight_id, method, status, reference_masked, provider, notes, verified_at, created_at)
       VALUES (?, ?, ?, 'booking_reference', ?, ?, 'demo', 'Simulated verification in demo mode — no airline system was contacted.', ?, ?)`,
    ).run(
      `fv_${args.flightId}_${m.userId}`, m.userId, args.flightId,
      DEMO_USERS.find((u) => u.id === m.userId)?.identity === "unverified" ? "pending" : "verified",
      "••••" + (args.flightNumber.slice(-2)), iso(addMin(now, -120)), iso(addMin(now, -150)),
    );
  }

  // A pending join request on the featured group so owners have something to review.
  if (dayOffset === 0 && route.destinationId === "thane-w") {
    db.prepare(
      `INSERT INTO join_requests (id, ride_group_id, user_id, passenger_count, luggage_units, destination_id, message, match_score, status, created_at)
       VALUES (?, ?, ?, 1, 2, 'mulund', ?, 88, 'pending', ?)`,
    ).run(`jr_${groupId}_neha`, groupId, "usr_neha", "Landed on the same flight — heading to Mulund. Happy to be the second drop-off.", iso(addMin(now, -25)));
  }

  db.prepare(
    `INSERT INTO ride_status_events (id, ride_group_id, actor_user_id, type, to_status, payload_json, created_at)
     VALUES (?, ?, ?, 'group_created', 'open', ?, ?)`,
  ).run(`rse_${groupId}`, groupId, memberIds[0], JSON.stringify({ seatsTotal, destination: primary.name }), iso(addMin(now, -240)));
}

// ── Completed history (driver earnings, reviews, admin metrics) ─────────────
function seedHistory(db: DB) {
  const rules = loadPricingRules(db);
  const destMap = new Map(BOM_DESTINATIONS.map((d) => [d.id, d]));
  const now = new Date();
  const insertEvent = db.prepare(
    `INSERT OR IGNORE INTO ride_status_events (id, ride_group_id, actor_user_id, type, to_status, created_at) VALUES (?, ?, ?, 'status_change', ?, ?)`,
  );

  const historyTrips = [
    { dayOffset: -1, destination: "thane-w", extra: "mulund", members: ["usr_aarav", "usr_priya"], driver: "drv_ramesh", vehicle: "sedan" },
    { dayOffset: -2, destination: "powai", extra: "ghatkopar", members: ["usr_kavya", "usr_neha"], driver: "drv_ramesh", vehicle: "sedan" },
    { dayOffset: -3, destination: "bandra-w", extra: "andheri-e", members: ["usr_farhan", "usr_ananya"], driver: "drv_ramesh", vehicle: "suv" },
    { dayOffset: -4, destination: "vashi", extra: "chembur", members: ["usr_imran", "usr_rohan"], driver: "drv_ramesh", vehicle: "suv" },
  ];

  historyTrips.forEach((trip, ti) => {
    const dayKey = dateKey(addDays(now, trip.dayOffset));
    const groupId = `rg_hist_${keyNoDash(dayKey)}`;
    const flightId = `flt_AI864_${keyNoDash(dayKey)}`;
    const flight = db.prepare("SELECT id FROM flights WHERE id = ?").get(flightId);
    if (!flight) {
      // Past arrivals were never in the forward schedule — create the flight
      // this completed group belongs to (demo data, clearly labelled).
      const arr = istDateAt(dayKey, "09:15");
      db.prepare(
        `INSERT OR IGNORE INTO flights (id, airport_id, airline_code, airline_name, flight_number, origin_city, flight_date,
           terminal, scheduled_arrival, estimated_arrival, status, source, created_at, updated_at)
         VALUES (?, 'apt_bom', 'AI', 'Air India', 'AI864', 'Delhi', ?, 'T2', ?, ?, 'landed', 'demo', ?, ?)`,
      ).run(flightId, dayKey, iso(arr), iso(arr), iso(addDays(arr, -2)), iso(arr));
    }

    const primary = destMap.get(trip.destination)!;
    const windowStart = istDateAt(dayKey, "09:15");
    const windowEnd = addMin(windowStart, 45);

    db.prepare(
      `INSERT OR IGNORE INTO ride_groups (id, code, flight_id, created_by_user_id, destination_id, vehicle_category, fare_strategy,
        seats_total, seats_taken, luggage_total, luggage_taken, meet_point, departure_window_start, departure_window_end,
        max_wait_minutes, status, driver_id, vehicle_id, is_demo_origin, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 4, 2, 5, 4, ?, ?, ?, 45, 'completed', ?, ?, 1, ?, ?)`,
    ).run(
      groupId, refCode("FS-H", groupId), flightId, trip.members[0], trip.destination, trip.vehicle,
      rules.defaultStrategy, MEET_POINTS.T2, iso(windowStart), iso(windowEnd), trip.driver,
      trip.vehicle === "suv" ? "veh_suresh" : "veh_ramesh", iso(addDays(windowStart, -1)), iso(addMin(windowEnd, 90)),
    );

    const memberInputs = trip.members.map((userId, idx) => {
      const destinationId = idx === 0 ? trip.destination : trip.extra;
      const dest = destMap.get(destinationId)!;
      return { id: `rm_${groupId}_${idx}`, userId, destinationId, distanceKm: dest.distanceKm, seatCount: 1, soloFarePaise: dest.soloFarePaise };
    });

    trip.members.forEach((userId, idx) => {
      const m = memberInputs[idx];
      db.prepare(
        `INSERT OR IGNORE INTO ride_members (id, ride_group_id, user_id, seat_count, luggage_units, destination_id, readiness, expected_ready_at, status, role, joined_at)
         VALUES (?, ?, ?, 1, 2, ?, 'trip_started', ?, 'accepted', ?, ?)`,
      ).run(m.id, groupId, userId, m.destinationId, iso(windowStart), idx === 0 ? "owner" : "member", iso(addDays(windowStart, -1)));
    });

    const fare = computeGroupFare({
      members: memberInputs, vehicleCategory: trip.vehicle as "sedan" | "suv", strategy: rules.defaultStrategy, rules,
      tollsPaise: primary.tollsPaise,
    });

    const estimateId = `fe_${groupId}`;
    db.prepare(
      `INSERT OR IGNORE INTO fare_estimates (id, ride_group_id, strategy, vehicle_category, breakdown_json, total_paise, vehicle_fare_paise, fee_paise, tax_paise, solo_total_paise, savings_paise, expires_at, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    ).run(
      estimateId, groupId, rules.defaultStrategy, trip.vehicle, JSON.stringify(fare), fare.breakdown.totalPaise,
      fare.breakdown.vehicleFarePaise, fare.breakdown.platformFeePaise, fare.breakdown.taxPaise,
      fare.breakdown.soloTotalPaise, fare.breakdown.totalSavingsPaise, iso(addMin(windowEnd, 120)), iso(addDays(windowStart, -1)),
    );

    fare.members.forEach((m, idx) => {
      const bookingId = `bk_${groupId}_${m.userId}`;
      db.prepare(
        `INSERT OR IGNORE INTO bookings (id, code, ride_group_id, user_id, fare_estimate_id, status, payment_status, amount_paise, confirmed_at, created_at)
         VALUES (?, ?, ?, ?, ?, 'completed', 'captured', ?, ?, ?)`,
      ).run(bookingId, refCode("BK", `${groupId}:${m.userId}:h`), groupId, m.userId, estimateId, m.contributionPaise, iso(windowStart), iso(addDays(windowStart, -1)));

      db.prepare(
        `INSERT OR IGNORE INTO payment_records (id, booking_id, provider, provider_order_id, provider_payment_id, amount_paise, status, method, captured_at, created_at)
         VALUES (?, ?, 'demo', ?, ?, ?, 'captured', 'demo_card', ?, ?)`,
      ).run(`pay_${bookingId}`, bookingId, `demo_order_${bookingId.slice(-6)}`, `demo_pay_${bookingId.slice(-6)}`, m.contributionPaise, iso(windowStart), iso(windowStart));

      db.prepare(
        `INSERT OR IGNORE INTO reviews (id, ride_group_id, author_user_id, subject_user_id, role_subject, rating, comment, created_at)
         VALUES (?, ?, ?, ?, 'driver', ?, ?, ?)`,
      ).run(
        `rev_${groupId}_${idx}`, groupId, m.userId, null, idx === 0 ? 5 : 4,
        idx === 0 ? "Clean car, punctual pickup at Gate 3 and a very fair fare split." : "Smooth ride and a helpful driver. Would share again.",
        iso(addMin(windowEnd, 240)),
      );
    });

    fare.members.forEach((m) => {
      const dest = destMap.get(m.destinationId)!;
      db.prepare(
        `INSERT OR IGNORE INTO fare_allocations (id, fare_estimate_id, ride_group_id, user_id, destination_id, distance_km, weight,
           vehicle_share_paise, fee_paise, tax_paise, contribution_paise, solo_fare_paise, savings_paise, savings_pct, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 1, ?, 0, 0, ?, ?, ?, ?, ?)`,
      ).run(
        `fa_${groupId}_${m.userId}`, estimateId, groupId, m.userId, m.destinationId, dest.distanceKm,
        m.contributionPaise, m.contributionPaise, m.soloEstimatePaise, m.savingsPaise, m.savingsPct, iso(addDays(windowStart, -1)),
      );
    });

    const commission = fare.breakdown.platformFeePaise + fare.breakdown.taxPaise;
    const gross = fare.breakdown.vehicleFarePaise;
    db.prepare(
      `INSERT OR IGNORE INTO driver_earnings (id, driver_id, ride_group_id, gross_paise, commission_paise, deductions_paise, net_paise, status, payout_reference, period, created_at)
       VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?)`,
    ).run(
      `ern_${groupId}`, trip.driver, groupId, gross, 0, gross, ti < 2 ? "paid" : "pending",
      ti < 2 ? `PAYOUT-${keyNoDash(dayKey)}` : null, dayKey, iso(addMin(windowEnd, 120)),
    );
    void commission;

    insertEvent.run(`rse_${groupId}_done`, groupId, trip.members[0], "completed", iso(addMin(windowEnd, 90)));
  });
}

// ── Admin queues: verifications, reports, refunds, tickets ──────────────────
function seedAdminQueues(db: DB) {
  const now = new Date();
  const today = dateKey(now);
  const flightId = `flt_AI864_${keyNoDash(today)}`;

  const insertVerification = db.prepare(
    `INSERT OR IGNORE INTO flight_verifications (id, user_id, flight_id, method, status, reference_masked, reference_hash, provider, notes, created_at)
     VALUES (?, ?, ?, 'booking_reference', ?, ?, NULL, 'demo', ?, ?)`,
  );
  insertVerification.run("fv_neha", "usr_neha", flightId, "pending", "••••42", "Submitted a booking reference for AI864.", iso(addMin(now, -40)));
  insertVerification.run("fv_kavya", "usr_kavya", flightId, "verified", "••••18", "Simulated verification in demo mode.", iso(addMin(now, -80)));
  insertVerification.run("fv_aarav", "usr_aarav", flightId, "verified", "••••77", "Simulated verification in demo mode.", iso(addMin(now, -300)));

  db.prepare(
    `INSERT OR IGNORE INTO reports (id, reporter_user_id, subject_user_id, ride_group_id, category, details, status, priority, created_at)
     VALUES (?, 'usr_priya', 'usr_rohan', NULL, 'no_show', ?, 'open', 'normal', ?)`,
  ).run("rep_demo_1", "Passenger did not arrive within the agreed waiting window and did not respond in the ride chat.", iso(addMin(now, -600)));

  db.prepare(
    `INSERT OR IGNORE INTO support_tickets (id, user_id, ride_group_id, subject, category, body, status, priority, created_at, updated_at)
     VALUES (?, 'usr_farhan', NULL, ?, 'fare', ?, 'open', 'high', ?, ?)`,
  ).run(
    "tkt_demo_1", "Fare estimate changed after a passenger joined",
    "The estimate on my trip increased by ₹60 after a third passenger joined. I'd like the breakdown explained before I confirm.",
    iso(addMin(now, -300)), iso(addMin(now, -300)),
  );

  // Pick any booking that actually has a captured demo payment.
  const demoBooking = db
    .prepare(
      `SELECT b.id FROM bookings b
         JOIN payment_records p ON p.booking_id = b.id
        WHERE b.status IN ('confirmed', 'completed')
        ORDER BY b.created_at DESC LIMIT 1`,
    )
    .get() as { id: string } | undefined;
  if (demoBooking) {
    const payment = db.prepare("SELECT id FROM payment_records WHERE booking_id = ?").get(demoBooking.id) as
      | { id: string }
      | undefined;
    if (payment) {
      db.prepare(
        `INSERT OR IGNORE INTO refunds (id, payment_id, amount_paise, status, reason, requested_by, created_at)
         VALUES (?, ?, 24800, 'pending', 'Duplicate demo authorisation requested in sandbox.', 'usr_farhan', ?)`,
      ).run("ref_demo_1", payment.id, iso(addMin(now, -120)));
    }
  }

  const insertAudit = db.prepare(
    `INSERT OR IGNORE INTO audit_logs (id, actor_user_id, actor_role, action, entity_type, entity_id, after_json, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  insertAudit.run("aud_demo_1", "usr_admin", "admin", "pricing.updated", "pricing_rules", "platform_fee_bps", JSON.stringify({ value: 800 }), iso(addDays(now, -6)));
  insertAudit.run("aud_demo_2", "usr_admin", "admin", "driver.verified", "driver_profiles", "drv_ramesh", JSON.stringify({ status: "verified" }), iso(addDays(now, -5)));
  insertAudit.run("aud_demo_3", "usr_admin", "admin", "demo.seeded", "system", null, JSON.stringify({ horizonDays: HORIZON_DAYS }), iso(now));

  const insertEvent = db.prepare(
    `INSERT OR IGNORE INTO analytics_events (id, user_id, name, props_json, created_at) VALUES (?, ?, ?, ?, ?)`,
  );
  const events: [string, string | null, string, object][] = [
    ["ev_1", "usr_aarav", "flight_search_initiated", { flight: "AI864", destination: "thane-w" }],
    ["ev_2", "usr_aarav", "match_results_viewed", { groups: 3 }],
    ["ev_3", "usr_aarav", "join_request_submitted", { group: "rg_AI864" }],
    ["ev_4", "usr_priya", "booking_confirmed", { amount: 42100 }],
    ["ev_5", "usr_priya", "ride_completed", { savings: 62000 }],
  ];
  events.forEach(([id, userId, name, props], i) => insertEvent.run(id, userId, name, JSON.stringify(props), iso(addMin(now, -i * 90))));

  void PAST_DAYS;
}

// ── Notifications: the in-app inbox every account sees ──────────────────────
function seedNotifications(db: DB) {
  const now = new Date();
  const today = keyNoDash(dateKey(now));
  const live = db.prepare(
    "SELECT id, code, created_by_user_id FROM ride_groups WHERE id = ?",
  ).get(`rg_AI864_${today}_thanew`) as { id: string; code: string; created_by_user_id: string } | undefined;

  const insert = db.prepare(
    `INSERT OR IGNORE INTO notifications (id, user_id, type, title, body, ride_group_id, href, is_demo, read_at, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`,
  );

  type Row = [string, string, string, string, string, string | null, string | null, string | null, number];
  const rows: Row[] = [
    ["ntf_aarav_1", "usr_aarav", "join_request", "Priya asked to join your Thane ride",
      "Priya Nair requested 1 seat on AI864 · Thane West. Review her booking verification before you approve.",
      live?.id ?? null, live ? `/app/trips/${live.id}` : "/app/trips", null, -25],
    ["ntf_aarav_2", "usr_aarav", "fare_update", "Fare re-split after a third passenger",
      "Your share is now ₹392 for the AI864 group — ₹472 less than a solo cab to Thane West.",
      live?.id ?? null, live ? `/app/trips/${live.id}` : "/app/trips", iso(addDays(now, -1)), -180],
    ["ntf_aarav_3", "usr_aarav", "verification", "Flight AI864 verified",
      "Your AI864 booking reference was verified in demo mode. Other passengers see a verified badge, never your reference.",
      null, "/app/profile", iso(addDays(now, -2)), -1500],
    ["ntf_aarav_4", "usr_aarav", "review", "Rate your last ride",
      "Your Bandra West trip completed. A short rating helps the next passenger decide.",
      `rg_hist_${keyNoDash(dateKey(addDays(now, -3)))}`, "/app/trips?tab=past", null, -2900],
    ["ntf_priya_1", "usr_priya", "request_answer", "Aarav approved your request",
      "You are confirmed on the AI864 group to Thane West. Meeting point: Terminal 2, Gate 3 pillar.",
      live?.id ?? null, live ? `/app/trips/${live.id}` : "/app/trips", null, -90],
    ["ntf_rohan_1", "usr_rohan", "readiness", "Readiness reminder",
      "Tap Collecting baggage when you reach the belt so your group knows you are close.",
      live?.id ?? null, live ? `/app/trips/${live.id}` : "/app/trips", null, -40],
    ["ntf_kavya_1", "usr_kavya", "verification", "Verification in review",
      "Your booking reference is queued for an administrator. You can still browse matches meanwhile.",
      null, "/app/profile", null, -300],
    ["ntf_driver_1", "usr_driver_ramesh", "payout", "Payout recorded (demo)",
      "₹1,732 was marked paid for your recent airport transfers. Demo settlement — no money moved.",
      null, "/driver/earnings", iso(addDays(now, -1)), -1200],
    ["ntf_admin_1", "usr_admin", "report", "New safety report",
      "A no-show report was filed against a passenger. Triage it in the support queue.",
      null, "/admin/support#reports", null, -600],
    ["ntf_admin_2", "usr_admin", "verification", "Driver documents waiting",
      "Suresh Patil submitted vehicle documents and is waiting for review.",
      null, "/admin/verifications#drivers", null, -220],
  ];

  for (const [id, userId, type, title, body, rideGroupId, href, readAt, minutesAgo] of rows) {
    insert.run(id, userId, type, title, body, rideGroupId, href, readAt, iso(addMin(now, minutesAgo)));
  }
}

/** Groups whose last seat is gone must read 'full', not 'open'. Idempotent. */
function normalizeFullGroups(db: DB) {
  db.prepare(
    `UPDATE ride_groups
        SET status = 'full', updated_at = ?
      WHERE status = 'open' AND seats_taken >= seats_total`,
  ).run(new Date().toISOString());
}
