/**
 * Curated BOM (Mumbai) destination catalogue.
 *
 * Coordinates and distances are approximations used for the illustrative map
 * and route-compatibility scoring until a maps + routing provider is wired up.
 * `soloFarePaise` is a market estimate for a pre-booked airport taxi, used only
 * for the savings comparison — never as a charged price.
 */
export interface DestinationSeed {
  id: string;
  name: string;
  area: string;
  corridor: Corridor;
  lat: number;
  lng: number;
  distanceKm: number;
  driveMinutes: number;
  soloFarePaise: number;
  tollsPaise: number;
  blurb: string;
}

export type Corridor =
  | "western-suburbs"
  | "central-suburbs"
  | "thane-corridor"
  | "harbour-corridor"
  | "south-mumbai";

export const BOM_TERMINALS = [
  { id: "BOM-T2", name: "Terminal 2 (International + full-service domestic)", code: "T2", lat: 19.0974, lng: 72.8744 },
  { id: "BOM-T1", name: "Terminal 1 (Domestic)", code: "T1", lat: 19.0896, lng: 72.8656 },
];

export const BOM_DESTINATIONS: DestinationSeed[] = [
  { id: "andheri-e", name: "Andheri East", area: "Western Suburbs", corridor: "western-suburbs", lat: 19.1136, lng: 72.8697, distanceKm: 5, driveMinutes: 18, soloFarePaise: 48_000, tollsPaise: 0, blurb: "Closest business district to the airport." },
  { id: "vile-parle", name: "Vile Parle", area: "Western Suburbs", corridor: "western-suburbs", lat: 19.0992, lng: 72.8468, distanceKm: 6, driveMinutes: 20, soloFarePaise: 54_000, tollsPaise: 0, blurb: "Residential, minutes from the domestic terminal." },
  { id: "juhu", name: "Juhu", area: "Western Suburbs", corridor: "western-suburbs", lat: 19.1075, lng: 72.8263, distanceKm: 7, driveMinutes: 24, soloFarePaise: 60_000, tollsPaise: 0, blurb: "Beachside neighbourhood west of the airport." },
  { id: "bandra-w", name: "Bandra West", area: "Western Suburbs", corridor: "western-suburbs", lat: 19.0596, lng: 72.8295, distanceKm: 8, driveMinutes: 28, soloFarePaise: 65_000, tollsPaise: 0, blurb: "BKC-adjacent, popular with business travellers." },
  { id: "kurla", name: "Kurla", area: "Central Suburbs", corridor: "central-suburbs", lat: 19.0726, lng: 72.8845, distanceKm: 10, driveMinutes: 30, soloFarePaise: 62_000, tollsPaise: 0, blurb: "Central junction, close to BKC." },
  { id: "powai", name: "Powai", area: "Central Lakes", corridor: "central-suburbs", lat: 19.1176, lng: 72.9060, distanceKm: 12, driveMinutes: 32, soloFarePaise: 70_000, tollsPaise: 0, blurb: "Tech parks and lakeside apartments." },
  { id: "ghatkopar", name: "Ghatkopar", area: "Central Suburbs", corridor: "central-suburbs", lat: 19.0864, lng: 72.9081, distanceKm: 13, driveMinutes: 34, soloFarePaise: 75_000, tollsPaise: 0, blurb: "Metro interchange and LBS Marg access." },
  { id: "chembur", name: "Chembur", area: "Central Suburbs", corridor: "central-suburbs", lat: 19.0522, lng: 72.9005, distanceKm: 15, driveMinutes: 38, soloFarePaise: 82_000, tollsPaise: 0, blurb: "Eastern Express Highway entry point." },
  { id: "dadar", name: "Dadar", area: "Central Mumbai", corridor: "south-mumbai", lat: 19.0178, lng: 72.8478, distanceKm: 16, driveMinutes: 40, soloFarePaise: 85_000, tollsPaise: 0, blurb: "Rail hub with easy access to South Mumbai." },
  { id: "borivali", name: "Borivali", area: "Western Suburbs", corridor: "western-suburbs", lat: 19.2307, lng: 72.8567, distanceKm: 20, driveMinutes: 45, soloFarePaise: 90_000, tollsPaise: 0, blurb: "Western line terminus, national park side." },
  { id: "mulund", name: "Mulund", area: "North East", corridor: "thane-corridor", lat: 19.1726, lng: 72.9425, distanceKm: 22, driveMinutes: 48, soloFarePaise: 98_000, tollsPaise: 4_500, blurb: "Eastern Express Highway, Thane border." },
  { id: "colaba", name: "Colaba", area: "South Mumbai", corridor: "south-mumbai", lat: 18.9067, lng: 72.8147, distanceKm: 24, driveMinutes: 52, soloFarePaise: 1_05_000, tollsPaise: 0, blurb: "Southern tip, hotels and heritage district." },
  { id: "thane-w", name: "Thane West", area: "Thane", corridor: "thane-corridor", lat: 19.2183, lng: 72.9781, distanceKm: 26, driveMinutes: 56, soloFarePaise: 1_15_000, tollsPaise: 4_500, blurb: "Fast-growing suburb beyond Mulund." },
  { id: "vashi", name: "Navi Mumbai (Vashi)", area: "Navi Mumbai", corridor: "harbour-corridor", lat: 19.0771, lng: 72.9986, distanceKm: 26, driveMinutes: 54, soloFarePaise: 1_25_000, tollsPaise: 7_500, blurb: "Across the Vashi bridge, planned city grid." },
];

/**
 * Curated pairwise compatibility for landmark pairs the geographic heuristic
 * under-rates (or over-rates). Symmetric. Missing pairs fall back to
 * `geoCompatibility()` in the matching engine.
 */
export const DESTINATION_AFFINITY: Record<string, number> = {
  "andheri-e|vile-parle": 0.95,
  "andheri-e|bandra-w": 0.88,
  "andheri-e|juhu": 0.86,
  "vile-parle|bandra-w": 0.85,
  "vile-parle|juhu": 0.9,
  "bandra-w|dadar": 0.8,
  "bandra-w|juhu": 0.82,
  "powai|ghatkopar": 0.86,
  "powai|mulund": 0.78,
  "powai|andheri-e": 0.7,
  "powai|chembur": 0.72,
  "ghatkopar|mulund": 0.82,
  "ghatkopar|chembur": 0.85,
  "ghatkopar|kurla": 0.86,
  "mulund|thane-w": 0.92,
  "mulund|ghatkopar": 0.82,
  "mulund|chembur": 0.74,
  "thane-w|vashi": 0.62,
  "thane-w|powai": 0.66,
  "kurla|chembur": 0.84,
  "kurla|bandra-w": 0.76,
  "chembur|vashi": 0.8,
  "chembur|dadar": 0.74,
  "dadar|colaba": 0.78,
  "borivali|andheri-e": 0.72,
  "borivali|vile-parle": 0.7,
  "colaba|dadar": 0.78,
};

export function affinityKey(a: string, b: string) {
  return a < b ? `${a}|${b}` : `${b}|${a}`;
}

/**
 * Curated pairs are authored in human-readable order ("thane-w|powai"), but
 * lookups use a canonical alphabetical key. Normalise once at module load so
 * authoring order never silently breaks a match.
 */
export const AFFINITY: Record<string, number> = Object.fromEntries(
  Object.entries(DESTINATION_AFFINITY).map(([pair, value]) => {
    const [a, b] = pair.split("|");
    return [affinityKey(a, b), value];
  }),
);
