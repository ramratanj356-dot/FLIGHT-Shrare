import { allocateRupees, roundToRupee, type Paise } from "@/lib/money";
import {
  DEFAULT_PRICING_RULES,
  type FareStrategy,
  type PricingRules,
  type VehicleCategory,
} from "@/lib/config/pricing";

export interface FarePassenger {
  id: string;
  /** Destination/node this passenger alights at. */
  destinationId: string;
  /** Distance from the airport to that drop-off, in km. */
  distanceKm: number;
  seatCount: number;
  /** Market price of this passenger's own pre-booked airport taxi (per seat). */
  soloFarePaise: Paise;
}

export interface FareInput {
  passengers: FarePassenger[];
  vehicleCategory?: VehicleCategory;
  strategy?: FareStrategy;
  tollsPaise?: Paise;
  parkingPaise?: Paise;
  rules?: PricingRules;
  discountPaise?: Paise;
}

export interface FareLeg extends FarePassenger {
  weight: number;
  /** Share of the vehicle (driver) fare. */
  vehicleSharePaise: Paise;
  platformFeePaise: Paise;
  taxPaise: Paise;
  /** Everything this passenger owes: vehicle share + fee + tax. */
  contributionPaise: Paise;
  soloEstimatePaise: Paise;
  savingsPaise: Paise;
  savingsPct: number;
  savingsIsPositive: boolean;
}

export interface FareStopSummary {
  destinationId: string;
  distanceKm: number;
  passengers: number;
}

export interface FareBreakdown {
  strategy: FareStrategy;
  vehicleCategory: VehicleCategory;
  passengerCount: number;
  seatCount: number;

  baseFarePaise: Paise;
  distanceComponentPaise: Paise;
  extraStopsPaise: Paise;
  extraStopCount: number;
  routeDistanceKm: number;
  detourKm: number;
  tollsPaise: Paise;
  parkingPaise: Paise;
  discountPaise: Paise;

  /** Paid to the transport provider. */
  vehicleFarePaise: Paise;
  platformFeePaise: Paise;
  taxPaise: Paise;
  /** vehicleFare + platformFee + tax (discount already netted off). */
  totalPaise: Paise;

  legs: FareLeg[];
  stops: FareStopSummary[];

  soloTotalPaise: Paise;
  totalSavingsPaise: Paise;
  avgSavingsPct: number;
  perPassengerAveragePaise: Paise;

  allocatedPaise: Paise;
  roundingRemainderPaise: Paise;
}

const round = (n: number) => Math.round(n);

/**
 * Route costing + fair allocation.
 *
 * Route cost is based on the shared journey (farthest drop-off plus a small
 * detour for every additional stop), never on the sum of individual trips.
 * Allocation is then solved per passenger so that:
 *
 *   1. every passenger's contribution is a whole number of paise,
 *   2. the parts sum exactly to the total — no lost or invented paise,
 *   3. the split is explainable (equal / distance / hybrid).
 */
export function computeFare(input: FareInput): FareBreakdown {
  const rules = input.rules ?? DEFAULT_PRICING_RULES;
  const strategy = input.strategy ?? rules.defaultStrategy;
  const vehicleCategory = input.vehicleCategory ?? "sedan";
  const passengers = input.passengers.filter((p) => p.distanceKm > 0);
  if (passengers.length === 0) throw new Error("computeFare requires at least one passenger");

  // ── Route costing ─────────────────────────────────────────────
  const stopIds = [...new Set(passengers.map((p) => p.destinationId))];
  const stops: FareStopSummary[] = stopIds.map((destinationId) => {
    const group = passengers.filter((p) => p.destinationId === destinationId);
    return { destinationId, distanceKm: Math.max(1, group[0].distanceKm), passengers: group.length };
  });

  const extraStopCount = Math.max(0, stops.length - 1);
  const maxKm = Math.max(...stops.map((s) => s.distanceKm));
  const detourKm = extraStopCount * rules.detourKmPerStop;
  const routeDistanceKm = maxKm + detourKm;

  const baseFarePaise = rules.baseFarePaise;
  const distanceComponentPaise = round(routeDistanceKm * rules.perKmPaise);
  const extraStopsPaise = extraStopCount * rules.extraStopPaise;
  const tollsPaise = input.tollsPaise ?? 0;
  const parkingPaise = input.parkingPaise ?? 0;
  const discountPaise = Math.min(
    Math.max(0, input.discountPaise ?? 0),
    baseFarePaise + distanceComponentPaise + extraStopsPaise,
  );

  // Settle at rupee granularity so every passenger share is a clean ₹ amount
  // while still summing exactly to the group total (no lost or invented value).
  const vehicleFarePaise = roundToRupee(
    baseFarePaise + distanceComponentPaise + extraStopsPaise + tollsPaise + parkingPaise - discountPaise,
  );

  const platformFeePaise = roundToRupee(
    Math.max(rules.platformFeeMinPaise, round((vehicleFarePaise * rules.platformFeeBps) / 10_000)),
  );
  const taxPaise = roundToRupee(round((platformFeePaise * rules.platformFeeTaxBps) / 10_000));
  const totalPaise = vehicleFarePaise + platformFeePaise + taxPaise;

  // ── Allocation weights ────────────────────────────────────────
  // A passenger occupying two seats carries twice the weight of one seat.
  const seatTotal = passengers.reduce((s, p) => s + Math.max(1, p.seatCount), 0);
  const distanceTotal = passengers.reduce((s, p) => s + Math.max(1, p.distanceKm) * Math.max(1, p.seatCount), 0);

  const weightFor = (p: FarePassenger) => {
    const seats = Math.max(1, p.seatCount);
    const d = Math.max(1, p.distanceKm) * seats;
    switch (strategy) {
      case "equal":
        return seats;
      case "distance":
        return d;
      case "hybrid": {
        // Equal half + distance half, expressed as one integer weight so the
        // largest-remainder allocator stays deterministic.
        const equalShare = seats / seatTotal;
        const distanceShare = d / distanceTotal;
        return Math.round((0.5 * equalShare + 0.5 * distanceShare) * 1_000_000);
      }
    }
  };

  const weights = passengers.map(weightFor);
  const byId = passengers.map((p, i) => ({ id: p.id, weight: weights[i] }));

  const vehicleAlloc = allocateRupees(vehicleFarePaise, byId);
  const feeAlloc = allocateRupees(
    platformFeePaise,
    vehicleAlloc.map((v) => ({ id: v.id, weight: v.amount || 1 })),
  );
  const taxAlloc = allocateRupees(
    taxPaise,
    feeAlloc.map((f) => ({ id: f.id, weight: f.amount || 1 })),
  );

  let remainderHits = 0;
  const legs: FareLeg[] = passengers.map((p, i) => {
    const v = vehicleAlloc.find((x) => x.id === p.id)!;
    const f = feeAlloc.find((x) => x.id === p.id)!;
    const t = taxAlloc.find((x) => x.id === p.id)!;
    if (v.remainder) remainderHits++;
    const contributionPaise = v.amount + f.amount + t.amount;
    const seats = Math.max(1, p.seatCount);
    const soloEstimatePaise = p.soloFarePaise * seats;
    const savingsPaise = soloEstimatePaise - contributionPaise;
    return {
      ...p,
      weight: weights[i],
      vehicleSharePaise: v.amount,
      platformFeePaise: f.amount,
      taxPaise: t.amount,
      contributionPaise,
      soloEstimatePaise,
      savingsPaise,
      savingsPct: soloEstimatePaise > 0 ? Math.round((savingsPaise / soloEstimatePaise) * 1000) / 10 : 0,
      savingsIsPositive: savingsPaise > 0,
    };
  });

  const allocatedPaise = legs.reduce((s, l) => s + l.contributionPaise, 0);
  if (allocatedPaise !== totalPaise) {
    throw new Error(`Fare allocation mismatch: ${allocatedPaise} !== ${totalPaise}`);
  }

  const soloTotalPaise = legs.reduce((s, l) => s + l.soloEstimatePaise, 0);
  const totalSavingsPaise = soloTotalPaise - totalPaise;
  const avgSavingsPct = soloTotalPaise > 0 ? Math.round((totalSavingsPaise / soloTotalPaise) * 1000) / 10 : 0;

  return {
    strategy,
    vehicleCategory,
    passengerCount: passengers.length,
    seatCount: seatTotal,
    baseFarePaise,
    distanceComponentPaise,
    extraStopsPaise,
    extraStopCount,
    routeDistanceKm: Math.round(routeDistanceKm * 10) / 10,
    detourKm: Math.round(detourKm * 10) / 10,
    tollsPaise,
    parkingPaise,
    discountPaise,
    vehicleFarePaise,
    platformFeePaise,
    taxPaise,
    totalPaise,
    legs,
    stops,
    soloTotalPaise,
    totalSavingsPaise,
    avgSavingsPct,
    perPassengerAveragePaise: Math.round(totalPaise / Math.max(1, seatTotal)),
    allocatedPaise,
    roundingRemainderPaise: remainderHits,
  };
}

/** What one passenger would pay alone, all-in. */
export function soloFare(distanceKm: number, rules = DEFAULT_PRICING_RULES) {
  return computeFare({
    passengers: [{ id: "solo", destinationId: "solo", distanceKm, seatCount: 1, soloFarePaise: 0 }],
    rules,
  }).totalPaise;
}
