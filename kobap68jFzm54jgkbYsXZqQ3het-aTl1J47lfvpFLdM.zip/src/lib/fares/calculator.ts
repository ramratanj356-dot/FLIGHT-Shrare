/**
 * Public savings-calculator math (homepage widget + tests).
 * Pure function, integer paise, no rounding drift.
 */
import { allocate } from "@/lib/money";

export interface CalculatorInput {
  soloFarePaise: number;
  sharedVehicleFarePaise: number;
  passengers: number;
  platformFeeBps: number;
  feeTaxBps?: number;
}

export interface CalculatorResult {
  passengerCount: number;
  sharedVehicleFarePaise: number;
  platformFeePaise: number;
  taxPaise: number;
  totalSharedPaise: number;
  perPassengerPaise: number[];
  individualContributionPaise: number;
  savingsPerPassengerPaise: number;
  savingsPct: number;
  totalSavingPaise: number;
  /** False when sharing is not actually cheaper — the UI must say so. */
  isCheaper: boolean;
}

export function calculateSavings(input: CalculatorInput): CalculatorResult {
  const passengers = Math.max(1, Math.floor(input.passengers));
  const solo = Math.max(0, Math.round(input.soloFarePaise));
  const shared = Math.max(0, Math.round(input.sharedVehicleFarePaise));
  const fee = Math.round((shared * Math.max(0, input.platformFeeBps)) / 10_000);
  const tax = Math.round((fee * Math.max(0, input.feeTaxBps ?? 0)) / 10_000);
  const total = shared + fee + tax;

  const perPassenger = allocate(total, Array.from({ length: passengers }, (_, i) => ({ id: String(i), weight: 1 })))
    .map((a) => a.amount);

  const individual = perPassenger[0] ?? 0;
  const savings = solo - individual;
  const pct = solo > 0 ? Math.round((savings / solo) * 1000) / 10 : 0;

  return {
    passengerCount: passengers,
    sharedVehicleFarePaise: shared,
    platformFeePaise: fee,
    taxPaise: tax,
    totalSharedPaise: total,
    perPassengerPaise: perPassenger,
    individualContributionPaise: individual,
    savingsPerPassengerPaise: savings,
    savingsPct: pct,
    totalSavingPaise: savings * passengers,
    isCheaper: savings > 0,
  };
}
