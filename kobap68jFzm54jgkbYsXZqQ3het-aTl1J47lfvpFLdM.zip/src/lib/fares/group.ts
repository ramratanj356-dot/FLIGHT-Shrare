import type { Paise } from "@/lib/money";
import { computeFare, type FareBreakdown, type FareLeg } from "./engine";
import {
  DEFAULT_PRICING_RULES,
  type FareStrategy,
  type PricingRules,
  type VehicleCategory,
} from "@/lib/config/pricing";

export interface GroupFareMember {
  id: string;
  userId: string;
  destinationId: string;
  distanceKm: number;
  seatCount: number;
  /** Per-seat market price of a solo airport taxi. */
  soloFarePaise: Paise;
  luggageUnits?: number;
}

export interface MemberFare extends FareLeg {
  memberId: string;
  userId: string;
}

export interface GroupFare {
  breakdown: FareBreakdown;
  members: MemberFare[];
  perPassengerAveragePaise: Paise;
  bestSavingsPaise: Paise;
}

export interface GroupFareInput {
  members: GroupFareMember[];
  vehicleCategory: VehicleCategory;
  strategy: FareStrategy;
  rules?: PricingRules;
  tollsPaise?: Paise;
  parkingPaise?: Paise;
  discountPaise?: Paise;
}

/**
 * Group-level fare with a per-member view. This is the single source of truth
 * for every rupee shown in the product — quotes, allocation rows, invoices.
 */
export function computeGroupFare(input: GroupFareInput): GroupFare {
  const rules = input.rules ?? DEFAULT_PRICING_RULES;
  if (input.members.length === 0) throw new Error("computeGroupFare requires at least one member");

  const breakdown = computeFare({
    passengers: input.members.map((m) => ({
      id: m.id,
      destinationId: m.destinationId,
      distanceKm: m.distanceKm,
      seatCount: m.seatCount,
      soloFarePaise: m.soloFarePaise,
    })),
    vehicleCategory: input.vehicleCategory,
    strategy: input.strategy,
    rules,
    tollsPaise: input.tollsPaise,
    parkingPaise: input.parkingPaise,
    discountPaise: input.discountPaise,
  });

  const members: MemberFare[] = breakdown.legs.map((leg) => {
    const source = input.members.find((m) => m.id === leg.id)!;
    return { ...leg, memberId: source.id, userId: source.userId };
  });

  return {
    breakdown,
    members,
    perPassengerAveragePaise: Math.round(breakdown.totalPaise / Math.max(1, breakdown.seatCount)),
    bestSavingsPaise: members.reduce((s, m) => Math.max(s, m.savingsPaise), 0),
  };
}
